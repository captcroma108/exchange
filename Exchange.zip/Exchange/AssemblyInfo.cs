﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Exchange")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Exchange")]
[assembly: AssemblyCopyright("Copyright © 2020")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("8954fd75-51e9-43ad-8d2c-7f6c8f075ce3")]
[assembly: AssemblyFileVersion("1.0.0.142")]
[assembly: AssemblyVersion("1.0.0.142")]
