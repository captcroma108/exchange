﻿// Decompiled with JetBrains decompiler
// Type: Microsoft.Office.Interop.Excel.AppEvents_Event
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel
{
  [CompilerGenerated]
  [ComEventInterface(typeof (AppEvents), typeof (AppEvents))]
  [TypeIdentifier("00020813-0000-0000-c000-000000000046", "Microsoft.Office.Interop.Excel.AppEvents_Event")]
  [ComImport]
  public interface AppEvents_Event
  {
  }
}
