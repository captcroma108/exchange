﻿// Decompiled with JetBrains decompiler
// Type: DTS.Properties.Settings
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.CompilerServices;

namespace DTS.Properties
{
  [CompilerGenerated]
  [GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "14.0.0.0")]
  internal sealed class Settings : ApplicationSettingsBase
  {
    private static Settings defaultInstance = (Settings) SettingsBase.Synchronized((SettingsBase) new Settings());

    private void SettingChangingEventHandler(object sender, SettingChangingEventArgs e)
    {
    }

    private void SettingsSavingEventHandler(object sender, CancelEventArgs e)
    {
    }

    public static Settings Default
    {
      get
      {
        Settings defaultInstance = Settings.defaultInstance;
        return defaultInstance;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("TG92ZXU=")]
    public string ConnString
    {
      get
      {
        return (string) this[nameof (ConnString)];
      }
      set
      {
        this[nameof (ConnString)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("False")]
    public bool RemPassword
    {
      get
      {
        return (bool) this[nameof (RemPassword)];
      }
      set
      {
        this[nameof (RemPassword)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string Password
    {
      get
      {
        return (string) this[nameof (Password)];
      }
      set
      {
        this[nameof (Password)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string Username
    {
      get
      {
        return (string) this[nameof (Username)];
      }
      set
      {
        this[nameof (Username)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("White")]
    public Color MWForecolor
    {
      get
      {
        return (Color) this[nameof (MWForecolor)];
      }
      set
      {
        this[nameof (MWForecolor)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("Black")]
    public Color MWBackcolor
    {
      get
      {
        return (Color) this[nameof (MWBackcolor)];
      }
      set
      {
        this[nameof (MWBackcolor)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("Blue")]
    public Color MWUPcolor
    {
      get
      {
        return (Color) this[nameof (MWUPcolor)];
      }
      set
      {
        this[nameof (MWUPcolor)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("Red")]
    public Color MWDOWNcolor
    {
      get
      {
        return (Color) this[nameof (MWDOWNcolor)];
      }
      set
      {
        this[nameof (MWDOWNcolor)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("Microsoft Sans Serif, 8.25pt")]
    public Font MWFont
    {
      get
      {
        return (Font) this[nameof (MWFont)];
      }
      set
      {
        this[nameof (MWFont)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string MWColumnProfile
    {
      get
      {
        return (string) this[nameof (MWColumnProfile)];
      }
      set
      {
        this[nameof (MWColumnProfile)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("True")]
    public bool Alert
    {
      get
      {
        return (bool) this[nameof (Alert)];
      }
      set
      {
        this[nameof (Alert)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string ModOrdColumnProfile
    {
      get
      {
        return (string) this[nameof (ModOrdColumnProfile)];
      }
      set
      {
        this[nameof (ModOrdColumnProfile)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string TrdColumnProfile
    {
      get
      {
        return (string) this[nameof (TrdColumnProfile)];
      }
      set
      {
        this[nameof (TrdColumnProfile)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string NetPosColPrfl
    {
      get
      {
        return (string) this[nameof (NetPosColPrfl)];
      }
      set
      {
        this[nameof (NetPosColPrfl)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string OrdColumnProfile
    {
      get
      {
        return (string) this[nameof (OrdColumnProfile)];
      }
      set
      {
        this[nameof (OrdColumnProfile)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string CanOrdColumnProfile
    {
      get
      {
        return (string) this[nameof (CanOrdColumnProfile)];
      }
      set
      {
        this[nameof (CanOrdColumnProfile)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MTUxLjEwNi41Ny43OFxTUUxFWFBSRVNTLDE0MzM7SW5pdGlhbCBDYXRhbG9nPURUUztVc2VyIElEPXNhO1Bhc3N3b3JkPVhhbmFkdUBfKygpJiolXiMkIUB+O011bHRpcGxlQWN0aXZlUmVzdWx0U2V0cyA9IFRydWU7Y29ubmVjdGlvbiB0aW1lb3V0ID0gNTAwMDAwMDA=")]
    public string FeedConnstring1
    {
      get
      {
        return (string) this[nameof (FeedConnstring1)];
      }
      set
      {
        this[nameof (FeedConnstring1)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9ODAuMjQxLjIyMi4xMzVcU1FMRVhQUkVTUywxNDMzO0luaXRpYWwgQ2F0YWxvZz1EVFM7VXNlciBJRD1zYTtQYXNzd29yZD1KaXlha2l5YW5AOTtNdWx0aXBsZUFjdGl2ZVJlc3VsdFNldHMgPSBUcnVlO2Nvbm5lY3Rpb24gdGltZW91dCA9IDUwMDAwMDAwOw==")]
    public string FeedConnstring2
    {
      get
      {
        return (string) this[nameof (FeedConnstring2)];
      }
      set
      {
        this[nameof (FeedConnstring2)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MTY0LjY4LjEyMy4yMDRcXE0xMzUwNCwxNDMzO1VzZXIgSUQ9c2E7SW5pdGlhbCBDYXRhbG9nPURUUztQYXNzd29yZD1hRkZXTEA3ODY7SW50ZWdyYXRlZCBTZWN1cml0eT1mYWxzZTtNdWx0aXBsZUFjdGl2ZVJlc3VsdFNldHMgPSBUcnVlO0Nvbm5lY3QgVGltZW91dD01MDAwMDAwMDA=")]
    public string FeedConnstringNEW
    {
      get
      {
        return (string) this[nameof (FeedConnstringNEW)];
      }
      set
      {
        this[nameof (FeedConnstringNEW)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MjA3LjE4MC4yNTUuMjM2XE0xMTgzNlxTUUxFWFBSRVNTLDQ5MTcwO0luaXRpYWwgQ2F0YWxvZz1EVFM7VXNlciBJRD1zYTtQYXNzd29yZD1YYW5hZHVAXysoKSYqJV4jJCFAfjtNdWx0aXBsZUFjdGl2ZVJlc3VsdFNldHMgPSBUcnVlO2Nvbm5lY3Rpb24gdGltZW91dCA9IDUwMDAwMDAwOw==")]
    public string FeedConnstring3
    {
      get
      {
        return (string) this[nameof (FeedConnstring3)];
      }
      set
      {
        this[nameof (FeedConnstring3)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MjA3LjE4MC4yNTUuMjM2XE0xMTgzNlxTUUxFWFBSRVNTLDQ5MTcwO0luaXRpYWwgQ2F0YWxvZz1EVFM7VXNlciBJRD1zYTtQYXNzd29yZD1YYW5hZHVAXysoKSYqJV4jJCFAfjtNdWx0aXBsZUFjdGl2ZVJlc3VsdFNldHMgPSBUcnVlO2Nvbm5lY3Rpb24gdGltZW91dCA9IDUwMDAwMDAwOw==")]
    public string FeedConnstring_236
    {
      get
      {
        return (string) this[nameof (FeedConnstring_236)];
      }
      set
      {
        this[nameof (FeedConnstring_236)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9NDUuMzIuMTU0LjE4MlxcTlNFX0NBU0hfTUFJTlxcU1FMRVhQUkVTUywxNDMzO1VzZXIgSUQ9c2E7UGFzc3dvcmQ9Sml5YWtpeWFuQDk7SW5pdGlhbCBDYXRhbG9nPURUUztJbnRlZ3JhdGVkIFNlY3VyaXR5PWZhbHNlO011bHRpcGxlQWN0aXZlUmVzdWx0U2V0cyA9IFRydWU7Q29ubmVjdCBUaW1lb3V0PTUwMDAwMDAwMA==")]
    public string FeedConnstring_3backup
    {
      get
      {
        return (string) this[nameof (FeedConnstring_3backup)];
      }
      set
      {
        this[nameof (FeedConnstring_3backup)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9ODAuMjQxLjIwOC4yMVxUQkMsMTQzMztJbml0aWFsIENhdGFsb2c9RFRTO1VzZXIgSUQ9c2E7IFBhc3N3b3JkPXF3ZXJ0eSM5OTk5O011bHRpcGxlQWN0aXZlUmVzdWx0U2V0cyA9IFRydWU7Y29ubmVjdGlvbiB0aW1lb3V0ID0gNTAwMDAwMDA=")]
    public string FeedConnstring
    {
      get
      {
        return (string) this[nameof (FeedConnstring)];
      }
      set
      {
        this[nameof (FeedConnstring)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string OrdLstColumnProfile
    {
      get
      {
        return (string) this[nameof (OrdLstColumnProfile)];
      }
      set
      {
        this[nameof (OrdLstColumnProfile)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("False")]
    public bool Autologin
    {
      get
      {
        return (bool) this[nameof (Autologin)];
      }
      set
      {
        this[nameof (Autologin)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MTUxLjEwNi41Ny43OFxTUUxFWFBSRVNTLCAxNDMzOw==")]
    public string c
    {
      get
      {
        return (string) this[nameof (c)];
      }
      set
      {
        this[nameof (c)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9ODAuMjQxLjIyMi4xMzVcU1FMRVhQUkVTUywxNDMzOw==")]
    public string Q
    {
      get
      {
        return (string) this[nameof (Q)];
      }
      set
      {
        this[nameof (Q)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MTY0LjY4LjEyMy4yMDRcTTEzNTA0LDE0MzM7")]
    public string QQQ
    {
      get
      {
        return (string) this[nameof (QQQ)];
      }
      set
      {
        this[nameof (QQQ)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MTczLjIxMi4yNDguMTg4XFNRTEVYUFJFU1MsMTQzMzs=")]
    public string W
    {
      get
      {
        return (string) this[nameof (W)];
      }
      set
      {
        this[nameof (W)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9ODAuMjQxLjIwOC4yMVxUQkMsMTQzMzs=")]
    public string X
    {
      get
      {
        return (string) this[nameof (X)];
      }
      set
      {
        this[nameof (X)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MjA3LjE4MC4yNTUuMjM2XE0xMTgzNlxTUUxFWFBSRVNTLDQ5MTcwOw==")]
    public string Qq
    {
      get
      {
        return (string) this[nameof (Qq)];
      }
      set
      {
        this[nameof (Qq)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("SW5pdGlhbCBDYXRhbG9nPURUUzE7")]
    public string Nn
    {
      get
      {
        return (string) this[nameof (Nn)];
      }
      set
      {
        this[nameof (Nn)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("VXNlciBJRD1zYTs=")]
    public string A
    {
      get
      {
        return (string) this[nameof (A)];
      }
      set
      {
        this[nameof (A)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("UGFzc3dvcmQ9Sml5YWtpeWFuQDk7")]
    public string k
    {
      get
      {
        return (string) this[nameof (k)];
      }
      set
      {
        this[nameof (k)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("UGFzc3dvcmQ9YUZGV0xANzg2Ow==")]
    public string kKK
    {
      get
      {
        return (string) this[nameof (kKK)];
      }
      set
      {
        this[nameof (kKK)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("UGFzc3dvcmQ9WGFuYWR1QF8rKCkmKiVeIyQhQH4=")]
    public string kk
    {
      get
      {
        return (string) this[nameof (kk)];
      }
      set
      {
        this[nameof (kk)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("UGFzc3dvcmQ9cXdlcnR5Izk5OTk7")]
    public string D
    {
      get
      {
        return (string) this[nameof (D)];
      }
      set
      {
        this[nameof (D)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("SW50ZWdyYXRlZCBTZWN1cml0eT1mYWxzZTtNdWx0aXBsZUFjdGl2ZVJlc3VsdFNldHMgPSBUcnVlO0Nvbm5lY3QgVGltZW91dD01MDAwMDAwMDA=")]
    public string U
    {
      get
      {
        return (string) this[nameof (U)];
      }
      set
      {
        this[nameof (U)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("SW5pdGlhbCBDYXRhbG9nPURUUzE7")]
    public string N
    {
      get
      {
        return (string) this[nameof (N)];
      }
      set
      {
        this[nameof (N)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("1")]
    public int McxLots
    {
      get
      {
        return (int) this[nameof (McxLots)];
      }
      set
      {
        this[nameof (McxLots)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("1")]
    public int NsefutLots
    {
      get
      {
        return (int) this[nameof (NsefutLots)];
      }
      set
      {
        this[nameof (NsefutLots)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("1")]
    public int NsecurrLots
    {
      get
      {
        return (int) this[nameof (NsecurrLots)];
      }
      set
      {
        this[nameof (NsecurrLots)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("1")]
    public int NseoptLots
    {
      get
      {
        return (int) this[nameof (NseoptLots)];
      }
      set
      {
        this[nameof (NseoptLots)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("1")]
    public int NcdexLots
    {
      get
      {
        return (int) this[nameof (NcdexLots)];
      }
      set
      {
        this[nameof (NcdexLots)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("CarryForward")]
    public string McxValidity
    {
      get
      {
        return (string) this[nameof (McxValidity)];
      }
      set
      {
        this[nameof (McxValidity)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("CarryForward")]
    public string NsefutValidity
    {
      get
      {
        return (string) this[nameof (NsefutValidity)];
      }
      set
      {
        this[nameof (NsefutValidity)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("CarryForward")]
    public string NsecurrValidity
    {
      get
      {
        return (string) this[nameof (NsecurrValidity)];
      }
      set
      {
        this[nameof (NsecurrValidity)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("CarryForward")]
    public string NseoptValidity
    {
      get
      {
        return (string) this[nameof (NseoptValidity)];
      }
      set
      {
        this[nameof (NseoptValidity)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("CarryForward")]
    public string NcdexValidity
    {
      get
      {
        return (string) this[nameof (NcdexValidity)];
      }
      set
      {
        this[nameof (NcdexValidity)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("0, 0")]
    public Point OrdbookLocation
    {
      get
      {
        return (Point) this[nameof (OrdbookLocation)];
      }
      set
      {
        this[nameof (OrdbookLocation)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("0, 0")]
    public Point RTOrdbookLocation
    {
      get
      {
        return (Point) this[nameof (RTOrdbookLocation)];
      }
      set
      {
        this[nameof (RTOrdbookLocation)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("0, 0")]
    public Point TrdbookLocation
    {
      get
      {
        return (Point) this[nameof (TrdbookLocation)];
      }
      set
      {
        this[nameof (TrdbookLocation)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("0, 0")]
    public Point RTTrdbookLocation
    {
      get
      {
        return (Point) this[nameof (RTTrdbookLocation)];
      }
      set
      {
        this[nameof (RTTrdbookLocation)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string DefaultPortfolio
    {
      get
      {
        return (string) this[nameof (DefaultPortfolio)];
      }
      set
      {
        this[nameof (DefaultPortfolio)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MjA3LjE4MC4yNTUuMjM2XFxNMTE4MzZcXFNRTEVYUFJFU1MsNDkxNzA7VXNlciBJRD1zYTtJbml0aWFsIENhdGFsb2c9QmV0YVRyYWRlckZYWDtQYXNzd29yZD1YYW5hZHVAXysoKSYqJV4jJCFAfjtJbnRlZ3JhdGVkIFNlY3VyaXR5PWZhbHNlO011bHRpcGxlQWN0aXZlUmVzdWx0U2V0cyA9IFRydWU7Q29ubmVjdCBUaW1lb3V0PTUwMDAwMDAwMA==")]
    public string FXConnstring3
    {
      get
      {
        return (string) this[nameof (FXConnstring3)];
      }
      set
      {
        this[nameof (FXConnstring3)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9ODAuMjQxLjIyMi4xMzVcU1FMRVhQUkVTUywxNDMzO0luaXRpYWwgQ2F0YWxvZz1CZXRhVHJhZGVyRlhYO1VzZXIgSUQ9c2E7IFBhc3N3b3JkPVhhbmFkdUBfKygpJiolXiMkIUB+O011bHRpcGxlQWN0aXZlUmVzdWx0U2V0cyA9IFRydWU7Y29ubmVjdGlvbiB0aW1lb3V0ID0gNTAwMDAwMDA=")]
    public string FXConnstring2
    {
      get
      {
        return (string) this[nameof (FXConnstring2)];
      }
      set
      {
        this[nameof (FXConnstring2)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("RGF0YSBTb3VyY2U9MTY0LjY4LjEyMy4yMDRcXE0xMzUwNCwxNDMzO1VzZXIgSUQ9c2E7SW5pdGlhbCBDYXRhbG9nPUJldGFUcmFkZXJGWFg7UGFzc3dvcmQ9YUZGV0xANzg2O0ludGVncmF0ZWQgU2VjdXJpdHk9ZmFsc2U7TXVsdGlwbGVBY3RpdmVSZXN1bHRTZXRzID0gVHJ1ZTtDb25uZWN0IFRpbWVvdXQ9NTAwMDAwMDAw")]
    public string FXConnstringNEW
    {
      get
      {
        return (string) this[nameof (FXConnstringNEW)];
      }
      set
      {
        this[nameof (FXConnstringNEW)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string RTTradesLocation
    {
      get
      {
        return (string) this[nameof (RTTradesLocation)];
      }
      set
      {
        this[nameof (RTTradesLocation)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col0
    {
      get
      {
        return (int) this[nameof (col0)];
      }
      set
      {
        this[nameof (col0)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col1
    {
      get
      {
        return (int) this[nameof (col1)];
      }
      set
      {
        this[nameof (col1)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col2
    {
      get
      {
        return (int) this[nameof (col2)];
      }
      set
      {
        this[nameof (col2)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col3
    {
      get
      {
        return (int) this[nameof (col3)];
      }
      set
      {
        this[nameof (col3)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col4
    {
      get
      {
        return (int) this[nameof (col4)];
      }
      set
      {
        this[nameof (col4)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col5
    {
      get
      {
        return (int) this[nameof (col5)];
      }
      set
      {
        this[nameof (col5)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col6
    {
      get
      {
        return (int) this[nameof (col6)];
      }
      set
      {
        this[nameof (col6)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col7
    {
      get
      {
        return (int) this[nameof (col7)];
      }
      set
      {
        this[nameof (col7)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col8
    {
      get
      {
        return (int) this[nameof (col8)];
      }
      set
      {
        this[nameof (col8)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col9
    {
      get
      {
        return (int) this[nameof (col9)];
      }
      set
      {
        this[nameof (col9)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col10
    {
      get
      {
        return (int) this[nameof (col10)];
      }
      set
      {
        this[nameof (col10)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col11
    {
      get
      {
        return (int) this[nameof (col11)];
      }
      set
      {
        this[nameof (col11)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col12
    {
      get
      {
        return (int) this[nameof (col12)];
      }
      set
      {
        this[nameof (col12)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col13
    {
      get
      {
        return (int) this[nameof (col13)];
      }
      set
      {
        this[nameof (col13)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col14
    {
      get
      {
        return (int) this[nameof (col14)];
      }
      set
      {
        this[nameof (col14)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col15
    {
      get
      {
        return (int) this[nameof (col15)];
      }
      set
      {
        this[nameof (col15)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int col16
    {
      get
      {
        return (int) this[nameof (col16)];
      }
      set
      {
        this[nameof (col16)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string trdordNo
    {
      get
      {
        return (string) this[nameof (trdordNo)];
      }
      set
      {
        this[nameof (trdordNo)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string OrdordNo
    {
      get
      {
        return (string) this[nameof (OrdordNo)];
      }
      set
      {
        this[nameof (OrdordNo)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public string SlordNo
    {
      get
      {
        return (string) this[nameof (SlordNo)];
      }
      set
      {
        this[nameof (SlordNo)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int trdindex
    {
      get
      {
        return (int) this[nameof (trdindex)];
      }
      set
      {
        this[nameof (trdindex)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int ordindex
    {
      get
      {
        return (int) this[nameof (ordindex)];
      }
      set
      {
        this[nameof (ordindex)] = (object) value;
      }
    }

    [UserScopedSetting]
    [DebuggerNonUserCode]
    [DefaultSettingValue("")]
    public int slrdindex
    {
      get
      {
        return (int) this[nameof (slrdindex)];
      }
      set
      {
        this[nameof (slrdindex)] = (object) value;
      }
    }
  }
}
