﻿// Decompiled with JetBrains decompiler
// Type: DTS.CancelledOrders
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class CancelledOrders : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public MWColumnProfile objColProfile;
    private DataGridViewTextBoxColumn Code;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn sym;
    private DataGridViewTextBoxColumn product;
    private DataGridViewTextBoxColumn buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn Userremarks;
    private DataGridViewTextBoxColumn Traderid;
    private DataGridViewTextBoxColumn Orderno;
    public DataGridView dgvCanOrd;

    public CancelledOrders(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      this._ColumnOnOff = new Dictionary<string, int>();
      string ordColumnProfile = Settings.Default.CanOrdColumnProfile;
      if (ordColumnProfile != string.Empty)
      {
        string str1 = ordColumnProfile;
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ '_' };
          string[] strArray = str2.Split(chArray2);
          int int32 = Convert.ToInt32(strArray[1]);
          switch (Convert.ToInt32(strArray[2]))
          {
            case 0:
              this.dgvCanOrd.Columns[int32].Visible = false;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 0);
                break;
              }
              break;
            case 1:
              this.dgvCanOrd.Columns[int32].Visible = true;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 1);
                break;
              }
              break;
          }
        }
      }
      else
      {
        for (int index = 0; index < this.dgvCanOrd.Columns.Count; ++index)
        {
          if (!this._ColumnOnOff.ContainsKey(this.dgvCanOrd.Columns[index].HeaderText))
          {
            if (this.dgvCanOrd.Columns[index].Visible)
              this._ColumnOnOff.Add(this.dgvCanOrd.Columns[index].HeaderText, 1);
            else
              this._ColumnOnOff.Add(this.dgvCanOrd.Columns[index].HeaderText, 0);
          }
        }
      }
    }

    public void LoadOrders()
    {
      this.dgvCanOrd.Rows.Clear();
      foreach (Orders tradeOrder in this.objmain.GetTradeOrders(3))
      {
        int index = this.dgvCanOrd.Rows.Add();
        this.dgvCanOrd.Rows[index].Cells[0].Value = (object) tradeOrder.accountNo;
        this.dgvCanOrd.Rows[index].Cells[1].Value = (object) Utils.GetExch(tradeOrder.ExchangeTypeID);
        this.dgvCanOrd.Rows[index].Cells[2].Value = (object) tradeOrder.symbol;
        this.dgvCanOrd.Rows[index].Cells[3].Value = (object) Utils.GetProductType(tradeOrder.ProductType);
        this.dgvCanOrd.Rows[index].Cells[4].Value = (object) Utils.GetBuysell(tradeOrder.BuySell);
        this.dgvCanOrd.Rows[index].Cells[5].Value = (object) tradeOrder.Ordeqty;
        this.dgvCanOrd.Rows[index].Cells[6].Value = (object) tradeOrder.OrdePrice;
        this.dgvCanOrd.Rows[index].Cells[7].Value = (object) Utils.GetValidity(tradeOrder.ValidityType);
        this.dgvCanOrd.Rows[index].Cells[8].Value = (object) string.Format("{0}:{1}:{2}", (object) tradeOrder.LastModified.Hour, (object) tradeOrder.LastModified.Minute, (object) tradeOrder.LastModified.Second);
        this.dgvCanOrd.Rows[index].Cells[9].Value = (object) tradeOrder.UserRemark;
        this.dgvCanOrd.Rows[index].Cells[10].Value = (object) tradeOrder.TraderId;
        this.dgvCanOrd.Rows[index].Cells[11].Value = (object) tradeOrder.OrderNo;
        if (tradeOrder.BuySell == 1)
          this.dgvCanOrd.Rows[index].DefaultCellStyle.BackColor = Color.Blue;
        else
          this.dgvCanOrd.Rows[index].DefaultCellStyle.BackColor = Color.HotPink;
        int num = index + 1;
      }
    }

    private void dgvCanOrd_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Column Profile", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Save Column Profile", (Image) null, new EventHandler(this.Task2_Click));
      contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task7_Click));
      contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task8_Click));
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task9_Click));
      Point client = this.dgvCanOrd.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvCanOrd, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.objColProfile == null || this.objColProfile.IsDisposed)
      {
        MWColumnProfile mwColumnProfile = new MWColumnProfile(this.objmain, 3);
        mwColumnProfile.MdiParent = (Form) this.objmain;
        this.objColProfile = mwColumnProfile;
        this.objColProfile.Show();
      }
      else
      {
        this.objColProfile.MdiParent = (Form) this.objmain;
        this.objColProfile.Activate();
        this.objColProfile.Show();
      }
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvCanOrd.Columns.Count; ++index)
        str = !this.dgvCanOrd.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvCanOrd.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvCanOrd.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.CanOrdColumnProfile = str;
      Settings.Default.Save();
    }

    private void Task7_Click(object sender, EventArgs e)
    {
      this.dgvCanOrd.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task8_Click(object sender, EventArgs e)
    {
      this.dgvCanOrd.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task9_Click(object sender, EventArgs e)
    {
      if (this.dgvCanOrd.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvCanOrd, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      this.dgvCanOrd = new DataGridView();
      this.Code = new DataGridViewTextBoxColumn();
      this.Exch = new DataGridViewTextBoxColumn();
      this.sym = new DataGridViewTextBoxColumn();
      this.product = new DataGridViewTextBoxColumn();
      this.buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.Userremarks = new DataGridViewTextBoxColumn();
      this.Traderid = new DataGridViewTextBoxColumn();
      this.Orderno = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvCanOrd).BeginInit();
      this.SuspendLayout();
      this.dgvCanOrd.AllowUserToAddRows = false;
      this.dgvCanOrd.AllowUserToDeleteRows = false;
      this.dgvCanOrd.AllowUserToOrderColumns = true;
      this.dgvCanOrd.BackgroundColor = Color.White;
      this.dgvCanOrd.CellBorderStyle = DataGridViewCellBorderStyle.None;
      gridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle1.BackColor = SystemColors.Control;
      gridViewCellStyle1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle1.ForeColor = Color.White;
      gridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle1.WrapMode = DataGridViewTriState.True;
      this.dgvCanOrd.ColumnHeadersDefaultCellStyle = gridViewCellStyle1;
      this.dgvCanOrd.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvCanOrd.Columns.AddRange((DataGridViewColumn) this.Code, (DataGridViewColumn) this.Exch, (DataGridViewColumn) this.sym, (DataGridViewColumn) this.product, (DataGridViewColumn) this.buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Time, (DataGridViewColumn) this.Userremarks, (DataGridViewColumn) this.Traderid, (DataGridViewColumn) this.Orderno);
      gridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle2.BackColor = SystemColors.Window;
      gridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle2.ForeColor = Color.White;
      gridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle2.WrapMode = DataGridViewTriState.False;
      this.dgvCanOrd.DefaultCellStyle = gridViewCellStyle2;
      this.dgvCanOrd.Dock = DockStyle.Fill;
      this.dgvCanOrd.Location = new Point(0, 0);
      this.dgvCanOrd.Name = "dgvCanOrd";
      this.dgvCanOrd.ReadOnly = true;
      this.dgvCanOrd.RowHeadersVisible = false;
      this.dgvCanOrd.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvCanOrd.Size = new Size(945, 290);
      this.dgvCanOrd.TabIndex = 1;
      this.dgvCanOrd.MouseClick += new MouseEventHandler(this.dgvCanOrd_MouseClick);
      this.Code.HeaderText = "RegulationCode";
      this.Code.Name = "Code";
      this.Code.ReadOnly = true;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.Width = 80;
      this.sym.HeaderText = "Symbol";
      this.sym.Name = "sym";
      this.sym.ReadOnly = true;
      this.product.HeaderText = "ProductType";
      this.product.Name = "product";
      this.product.ReadOnly = true;
      this.product.Width = 60;
      this.buysell.HeaderText = "B/S";
      this.buysell.Name = "buysell";
      this.buysell.ReadOnly = true;
      this.buysell.Width = 40;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 50;
      this.Price.HeaderText = "Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 70;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 70;
      this.Time.HeaderText = "CancelledTime";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 60;
      this.Userremarks.HeaderText = "UserRemarks";
      this.Userremarks.Name = "Userremarks";
      this.Userremarks.ReadOnly = true;
      this.Userremarks.Width = 70;
      this.Traderid.HeaderText = "TradedBy";
      this.Traderid.Name = "Traderid";
      this.Traderid.ReadOnly = true;
      this.Orderno.HeaderText = "Orderno";
      this.Orderno.Name = "Orderno";
      this.Orderno.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvCanOrd);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (CancelledOrders);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Cancelled Orders";
      ((ISupportInitialize) this.dgvCanOrd).EndInit();
      this.ResumeLayout(false);
    }
  }
}
