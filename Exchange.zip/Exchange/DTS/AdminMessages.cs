﻿// Decompiled with JetBrains decompiler
// Type: DTS.AdminMessages
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class AdminMessages : Form
  {
    public SqlConnection conn = (SqlConnection) null;
    public Dashboard objdash = (Dashboard) null;
    private IContainer components = (IContainer) null;
    private Button btnsend;
    private Button btnclear;
    private TextBox txtmessage;
    private CheckedListBox chkuserlist;
    private CheckBox chkselectall;
    private Label label14;
    private ComboBox comboBox1;

    public AdminMessages(Dashboard objdash, SqlConnection db)
    {
      this.InitializeComponent();
      this.conn = db;
      this.objdash = objdash;
      this.Icon = objdash.ico;
    }

    private void btnclear_Click(object sender, EventArgs e)
    {
      this.txtmessage.Text = string.Empty;
    }

    public void Loadwindow()
    {
      if (this.objdash._lstAccounts.Count > 0)
      {
        this.chkuserlist.Items.Clear();
        for (int index = 0; index < this.objdash._lstAccounts.Count; ++index)
          this.chkuserlist.Items.Add((object) this.objdash._lstAccounts[index].ToString());
      }
      this.comboBox1.SelectedIndex = 0;
    }

    private void btnsend_Click(object sender, EventArgs e)
    {
      if (this.txtmessage.Text != string.Empty && this.chkuserlist.CheckedItems.Count > 0)
      {
        DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
        for (int index = 0; index < this.chkuserlist.CheckedItems.Count; ++index)
          this.objdash.InsertMessage(this.chkuserlist.CheckedItems[index].ToString(), this.txtmessage.Text, 0);
        this.objdash.DisplayMessage("Message sent successfully!!", 1);
        this.txtmessage.Text = string.Empty;
      }
      else
      {
        this.objdash.DisplayMessage("Please select the user and write message to send.", 2);
        this.txtmessage.Focus();
      }
    }

    private void checkBox1_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkselectall.Checked)
      {
        for (int index = 0; index < this.chkuserlist.Items.Count; ++index)
          this.chkuserlist.SetItemChecked(index, true);
      }
      else
      {
        if (this.chkselectall.Checked)
          return;
        for (int index = 0; index < this.chkuserlist.Items.Count; ++index)
          this.chkuserlist.SetItemChecked(index, false);
      }
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.chkuserlist.Items.Clear();
      if (this.comboBox1.SelectedItem.ToString() == "Dealer")
      {
        foreach (object lstDealer in this.objdash._lstDealers)
          this.chkuserlist.Items.Add(lstDealer);
      }
      else
      {
        for (int index = 0; index < this.objdash._lstAccounts.Count; ++index)
          this.chkuserlist.Items.Add((object) this.objdash._lstAccounts[index].ToString());
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.btnsend = new Button();
      this.btnclear = new Button();
      this.txtmessage = new TextBox();
      this.chkuserlist = new CheckedListBox();
      this.chkselectall = new CheckBox();
      this.label14 = new Label();
      this.comboBox1 = new ComboBox();
      this.SuspendLayout();
      this.btnsend.FlatStyle = FlatStyle.System;
      this.btnsend.ForeColor = Color.FromArgb(0, 0, 192);
      this.btnsend.Location = new Point(54, 267);
      this.btnsend.Name = "btnsend";
      this.btnsend.Size = new Size(75, 23);
      this.btnsend.TabIndex = 2;
      this.btnsend.Text = "Send";
      this.btnsend.UseVisualStyleBackColor = true;
      this.btnsend.Click += new EventHandler(this.btnsend_Click);
      this.btnclear.FlatStyle = FlatStyle.System;
      this.btnclear.ForeColor = Color.FromArgb(0, 0, 192);
      this.btnclear.Location = new Point(188, 265);
      this.btnclear.Name = "btnclear";
      this.btnclear.Size = new Size(75, 23);
      this.btnclear.TabIndex = 3;
      this.btnclear.Text = "Clear";
      this.btnclear.UseVisualStyleBackColor = true;
      this.btnclear.Click += new EventHandler(this.btnclear_Click);
      this.txtmessage.Location = new Point(117, 71);
      this.txtmessage.Multiline = true;
      this.txtmessage.Name = "txtmessage";
      this.txtmessage.Size = new Size(198, 184);
      this.txtmessage.TabIndex = 1;
      this.chkuserlist.CheckOnClick = true;
      this.chkuserlist.FormattingEnabled = true;
      this.chkuserlist.Location = new Point(3, 71);
      this.chkuserlist.Name = "chkuserlist";
      this.chkuserlist.Size = new Size(111, 184);
      this.chkuserlist.Sorted = true;
      this.chkuserlist.TabIndex = 0;
      this.chkselectall.AutoSize = true;
      this.chkselectall.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.chkselectall.ForeColor = Color.Black;
      this.chkselectall.Location = new Point(6, 51);
      this.chkselectall.Name = "chkselectall";
      this.chkselectall.Size = new Size(79, 17);
      this.chkselectall.TabIndex = 11;
      this.chkselectall.Text = "Select all";
      this.chkselectall.UseVisualStyleBackColor = true;
      this.chkselectall.CheckedChanged += new EventHandler(this.checkBox1_CheckedChanged);
      this.label14.AutoSize = true;
      this.label14.Font = new Font("Segoe UI", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label14.ForeColor = Color.Black;
      this.label14.Location = new Point(3, 8);
      this.label14.Name = "label14";
      this.label14.Size = new Size(89, 13);
      this.label14.TabIndex = 22;
      this.label14.Text = "Select Usertype:";
      this.comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Items.AddRange(new object[2]
      {
        (object) "Dealer",
        (object) "Client"
      });
      this.comboBox1.Location = new Point(3, 24);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new Size(86, 21);
      this.comboBox1.TabIndex = 24;
      this.comboBox1.SelectedIndexChanged += new EventHandler(this.comboBox1_SelectedIndexChanged);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = SystemColors.Control;
      this.ClientSize = new Size(317, 298);
      this.Controls.Add((Control) this.comboBox1);
      this.Controls.Add((Control) this.label14);
      this.Controls.Add((Control) this.chkselectall);
      this.Controls.Add((Control) this.chkuserlist);
      this.Controls.Add((Control) this.txtmessage);
      this.Controls.Add((Control) this.btnclear);
      this.Controls.Add((Control) this.btnsend);
      this.ForeColor = Color.Black;
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (AdminMessages);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Admin Messages";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
