﻿// Decompiled with JetBrains decompiler
// Type: DTS.MWColumnProfile
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class MWColumnProfile : Form
  {
    private IContainer components = (IContainer) null;
    private readonly Dictionary<string, int> _ColumnOnof;
    public Dashboard objmain;
    public int windowtype;
    private ComboBox comboBox1;
    private Label label1;
    private ListBox lstColsInvisible;
    private ListBox listColsVisible;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button btnOK;
    private Button btnClose;

    public MWColumnProfile(Dashboard main, int windowtype)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
      this.windowtype = windowtype;
      switch (windowtype)
      {
        case 1:
          this._ColumnOnof = this.objmain.objmw._ColumnOnOff;
          break;
        case 2:
          this._ColumnOnof = this.objmain.objrttrdbook._ColumnOnOff;
          break;
        case 6:
          this._ColumnOnof = this.objmain.objnetpos._ColumnOnOff;
          break;
      }
      this.lstColsInvisible.Items.Clear();
      this.listColsVisible.Items.Clear();
      foreach (KeyValuePair<string, int> keyValuePair in this._ColumnOnof)
      {
        string key = keyValuePair.Key;
        if (keyValuePair.Value == 1)
          this.listColsVisible.Items.Add((object) key);
        else
          this.lstColsInvisible.Items.Add((object) key);
      }
    }

    private void button3_Click(object sender, EventArgs e)
    {
      foreach (string str in this.lstColsInvisible.Items)
        this.listColsVisible.Items.Add((object) str);
      this.lstColsInvisible.Items.Clear();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      if (!(this.lstColsInvisible.Text != string.Empty))
        return;
      string text = this.lstColsInvisible.Text;
      this.listColsVisible.Items.Add((object) text);
      this.lstColsInvisible.Items.Remove((object) text);
    }

    private void button2_Click(object sender, EventArgs e)
    {
      if (!(this.listColsVisible.Text != string.Empty))
        return;
      string text = this.listColsVisible.Text;
      this.lstColsInvisible.Items.Add((object) text);
      this.listColsVisible.Items.Remove((object) text);
    }

    private void button4_Click(object sender, EventArgs e)
    {
      for (int index = 0; index < this.listColsVisible.Items.Count; ++index)
        this.lstColsInvisible.Items.Add(this.listColsVisible.Items[index]);
      this.listColsVisible.Items.Clear();
    }

    private void btnOK_Click(object sender, EventArgs e)
    {
      switch (this.windowtype)
      {
        case 1:
          foreach (string key in this.listColsVisible.Items)
          {
            if (this.objmain.objmw._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 1;
            else
              this._ColumnOnof.Add(key, 1);
          }
          foreach (string key in this.lstColsInvisible.Items)
          {
            if (this.objmain.objmw._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 0;
            else
              this._ColumnOnof.Add(key, 0);
          }
          Dashboard.UpdateColumns(this.objmain.objmw.dgvMarketwatch, this.objmain.objmw._ColumnOnOff);
          break;
        case 2:
          foreach (string key in this.listColsVisible.Items)
          {
            if (this.objmain.objtrdbook._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 1;
            else
              this._ColumnOnof.Add(key, 1);
          }
          foreach (string key in this.lstColsInvisible.Items)
          {
            if (this.objmain.objtrdbook._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 0;
            else
              this._ColumnOnof.Add(key, 0);
          }
          Dashboard.UpdateColumns(this.objmain.objtrdbook.dgvTradeBook, this.objmain.objtrdbook._ColumnOnOff);
          break;
        case 3:
          foreach (string key in this.listColsVisible.Items)
          {
            if (this.objmain.objordbook._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 1;
            else
              this._ColumnOnof.Add(key, 1);
          }
          foreach (string key in this.lstColsInvisible.Items)
          {
            if (this.objmain.objordbook._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 0;
            else
              this._ColumnOnof.Add(key, 0);
          }
          Dashboard.UpdateColumns(this.objmain.objordbook.dgvOrderbook, this.objmain.objordbook._ColumnOnOff);
          break;
        case 6:
          foreach (string key in this.listColsVisible.Items)
          {
            if (this.objmain.objnetpos._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 1;
            else
              this._ColumnOnof.Add(key, 1);
          }
          foreach (string key in this.lstColsInvisible.Items)
          {
            if (this.objmain.objnetpos._ColumnOnOff.ContainsKey(key))
              this._ColumnOnof[key] = 0;
            else
              this._ColumnOnof.Add(key, 0);
          }
          Dashboard.UpdateColumns(this.objmain.objnetpos.dgvNetPosition, this.objmain.objnetpos._ColumnOnOff);
          break;
      }
      this.Close();
    }

    private void btnClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.comboBox1 = new ComboBox();
      this.label1 = new Label();
      this.lstColsInvisible = new ListBox();
      this.listColsVisible = new ListBox();
      this.button1 = new Button();
      this.button2 = new Button();
      this.button3 = new Button();
      this.button4 = new Button();
      this.btnOK = new Button();
      this.btnClose = new Button();
      this.SuspendLayout();
      this.comboBox1.FormattingEnabled = true;
      this.comboBox1.Location = new Point(100, 21);
      this.comboBox1.Name = "comboBox1";
      this.comboBox1.Size = new Size(107, 21);
      this.comboBox1.TabIndex = 0;
      this.comboBox1.Visible = false;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(57, 24);
      this.label1.Name = "label1";
      this.label1.Size = new Size(40, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "Select:";
      this.label1.Visible = false;
      this.lstColsInvisible.FormattingEnabled = true;
      this.lstColsInvisible.Location = new Point(8, 15);
      this.lstColsInvisible.Name = "lstColsInvisible";
      this.lstColsInvisible.Size = new Size(91, 147);
      this.lstColsInvisible.Sorted = true;
      this.lstColsInvisible.TabIndex = 2;
      this.listColsVisible.FormattingEnabled = true;
      this.listColsVisible.Location = new Point(168, 15);
      this.listColsVisible.Name = "listColsVisible";
      this.listColsVisible.Size = new Size(91, 147);
      this.listColsVisible.Sorted = true;
      this.listColsVisible.TabIndex = 3;
      this.button1.Location = new Point(114, 59);
      this.button1.Name = "button1";
      this.button1.Size = new Size(40, 23);
      this.button1.TabIndex = 4;
      this.button1.Text = ">>";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.button2.Location = new Point(114, 99);
      this.button2.Name = "button2";
      this.button2.Size = new Size(40, 23);
      this.button2.TabIndex = 5;
      this.button2.Text = "<<";
      this.button2.UseVisualStyleBackColor = true;
      this.button2.Click += new EventHandler(this.button2_Click);
      this.button3.Location = new Point(114, 19);
      this.button3.Name = "button3";
      this.button3.Size = new Size(40, 23);
      this.button3.TabIndex = 6;
      this.button3.Text = ">>>>";
      this.button3.UseVisualStyleBackColor = true;
      this.button3.Click += new EventHandler(this.button3_Click);
      this.button4.Location = new Point(114, 139);
      this.button4.Name = "button4";
      this.button4.Size = new Size(40, 23);
      this.button4.TabIndex = 7;
      this.button4.Text = "<<<<";
      this.button4.UseVisualStyleBackColor = true;
      this.button4.Click += new EventHandler(this.button4_Click);
      this.btnOK.Location = new Point(24, 183);
      this.btnOK.Name = "btnOK";
      this.btnOK.Size = new Size(75, 23);
      this.btnOK.TabIndex = 8;
      this.btnOK.Text = "OK";
      this.btnOK.UseVisualStyleBackColor = true;
      this.btnOK.Click += new EventHandler(this.btnOK_Click);
      this.btnClose.Location = new Point(168, 183);
      this.btnClose.Name = "btnClose";
      this.btnClose.Size = new Size(75, 23);
      this.btnClose.TabIndex = 9;
      this.btnClose.Text = "Cancel";
      this.btnClose.UseVisualStyleBackColor = true;
      this.btnClose.Click += new EventHandler(this.btnClose_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(265, 218);
      this.Controls.Add((Control) this.btnClose);
      this.Controls.Add((Control) this.btnOK);
      this.Controls.Add((Control) this.button4);
      this.Controls.Add((Control) this.button3);
      this.Controls.Add((Control) this.button2);
      this.Controls.Add((Control) this.button1);
      this.Controls.Add((Control) this.listColsVisible);
      this.Controls.Add((Control) this.lstColsInvisible);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.comboBox1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (MWColumnProfile);
      this.Text = "Column Profile";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
