﻿// Decompiled with JetBrains decompiler
// Type: DTS.RMSClientwise
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class RMSClientwise : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public int sortcolumn;
    public string sortorder;
    private DataGridView dgvRMSClientwise;
    private DataGridViewTextBoxColumn RegulationCode;
    private DataGridViewTextBoxColumn CashMargin;
    private DataGridViewTextBoxColumn MTMPL;
    private DataGridViewTextBoxColumn Commission;
    private DataGridViewTextBoxColumn NetPL;
    private DataGridViewTextBoxColumn MarginU;
    private DataGridViewTextBoxColumn AvailableMrgn;
    private DataGridViewTextBoxColumn LossLimit;
    private DataGridViewTextBoxColumn Risk;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripButton btnSearch;

    public RMSClientwise(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.sortcolumn = 0;
      this.sortorder = string.Empty;
      this.Icon = this.objmain.ico;
    }

    public void LoadRMS()
    {
      this.cmbclientcode.Items.Clear();
      this.cmbclientcode.Items.Add((object) "");
      this.dgvRMSClientwise.Rows.Clear();
      int index = 0;
      foreach (KeyValuePair<string, Limits> clientLimit in this.objmain._ClientLimits)
      {
        Limits limits = clientLimit.Value;
        this.dgvRMSClientwise.Rows.Add();
        if (!this.cmbclientcode.Items.Contains((object) limits.clientcode))
          this.cmbclientcode.Items.Add((object) limits.clientcode);
        this.dgvRMSClientwise.Rows[index].Cells[0].Value = (object) limits.clientcode;
        this.dgvRMSClientwise.Rows[index].Cells[1].Value = (object) limits.cashmrgn;
        this.dgvRMSClientwise.Rows[index].Cells[7].Value = (object) limits.mtmmulti;
        ++index;
      }
      new Thread((ThreadStart) (() => this.UpdateRMS())).Start();
    }

    private void UpdateRMS()
    {
      if (this.dgvRMSClientwise.Rows.Count <= 0)
        return;
      while (true)
      {
        Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>();
        Dictionary<string, buysellnetpospfls> netRmsmtmProftLoss = this.objmain._NetRMSMTMProftLoss;
        for (int index = 0; index < this.dgvRMSClientwise.Rows.Count; ++index)
        {
          string key = this.dgvRMSClientwise.Rows[index].Cells[0].Value.ToString();
          Decimal num1 = Convert.ToDecimal(this.dgvRMSClientwise.Rows[index].Cells[1].Value);
          if (netRmsmtmProftLoss.ContainsKey(key))
          {
            buysellnetpospfls buysellnetpospfls = netRmsmtmProftLoss[key];
            this.dgvRMSClientwise.Rows[index].Cells[2].Value = (object) (buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l);
            this.dgvRMSClientwise.Rows[index].Cells[3].Value = (object) buysellnetpospfls.Commision;
            Decimal num2 = buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l - buysellnetpospfls.Commision;
            this.dgvRMSClientwise.Rows[index].Cells[4].Value = (object) num2;
            this.dgvRMSClientwise.Rows[index].Cells[5].Value = (object) buysellnetpospfls.margin;
            this.dgvRMSClientwise.Rows[index].Cells[6].Value = (object) (num1 - buysellnetpospfls.margin);
            if (num1 > Decimal.Zero)
              this.dgvRMSClientwise.Rows[index].Cells[8].Value = (object) Decimal.Round(num2 / num1 * new Decimal(100), 2);
          }
        }
        Thread.Sleep(3000);
      }
    }

    private void dgvRMSClientwise_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Sort Ascending", (Image) null, new EventHandler(this.Task4_Click));
      contextMenuStrip.Items.Add("Sort Descending", (Image) null, new EventHandler(this.Task5_Click));
      contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task2_Click));
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task3_Click));
      Point client = this.dgvRMSClientwise.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvRMSClientwise, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      this.dgvRMSClientwise.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      this.dgvRMSClientwise.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task3_Click(object sender, EventArgs e)
    {
      if (this.dgvRMSClientwise.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvRMSClientwise, false);
    }

    private void Task4_Click(object sender, EventArgs e)
    {
      if (this.dgvRMSClientwise == null)
        ;
    }

    private void Task5_Click(object sender, EventArgs e)
    {
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvRMSClientwise.Rows)
          row.Visible = true;
      }
      else
      {
        if (!(this.cmbclientcode.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvRMSClientwise.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    private void RMSClientwise_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode != Keys.C)
        return;
      this.cmbclientcode.Focus();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (RMSClientwise));
      this.dgvRMSClientwise = new DataGridView();
      this.RegulationCode = new DataGridViewTextBoxColumn();
      this.CashMargin = new DataGridViewTextBoxColumn();
      this.MTMPL = new DataGridViewTextBoxColumn();
      this.Commission = new DataGridViewTextBoxColumn();
      this.NetPL = new DataGridViewTextBoxColumn();
      this.MarginU = new DataGridViewTextBoxColumn();
      this.AvailableMrgn = new DataGridViewTextBoxColumn();
      this.LossLimit = new DataGridViewTextBoxColumn();
      this.Risk = new DataGridViewTextBoxColumn();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      ((ISupportInitialize) this.dgvRMSClientwise).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvRMSClientwise.AllowUserToAddRows = false;
      this.dgvRMSClientwise.AllowUserToDeleteRows = false;
      this.dgvRMSClientwise.AllowUserToOrderColumns = true;
      this.dgvRMSClientwise.AllowUserToResizeRows = false;
      this.dgvRMSClientwise.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvRMSClientwise.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvRMSClientwise.BackgroundColor = Color.White;
      this.dgvRMSClientwise.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvRMSClientwise.Columns.AddRange((DataGridViewColumn) this.RegulationCode, (DataGridViewColumn) this.CashMargin, (DataGridViewColumn) this.MTMPL, (DataGridViewColumn) this.Commission, (DataGridViewColumn) this.NetPL, (DataGridViewColumn) this.MarginU, (DataGridViewColumn) this.AvailableMrgn, (DataGridViewColumn) this.LossLimit, (DataGridViewColumn) this.Risk);
      this.dgvRMSClientwise.Location = new Point(0, 28);
      this.dgvRMSClientwise.Name = "dgvRMSClientwise";
      this.dgvRMSClientwise.ReadOnly = true;
      this.dgvRMSClientwise.RowHeadersVisible = false;
      this.dgvRMSClientwise.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvRMSClientwise.Size = new Size(945, 262);
      this.dgvRMSClientwise.TabIndex = 0;
      this.dgvRMSClientwise.MouseClick += new MouseEventHandler(this.dgvRMSClientwise_MouseClick);
      this.RegulationCode.HeaderText = "ClientCode";
      this.RegulationCode.Name = "RegulationCode";
      this.RegulationCode.ReadOnly = true;
      this.CashMargin.HeaderText = "CashMargin";
      this.CashMargin.Name = "CashMargin";
      this.CashMargin.ReadOnly = true;
      this.MTMPL.HeaderText = "MTM P/L";
      this.MTMPL.Name = "MTMPL";
      this.MTMPL.ReadOnly = true;
      this.MTMPL.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.Commission.HeaderText = "Brokerage";
      this.Commission.Name = "Commission";
      this.Commission.ReadOnly = true;
      this.Commission.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.NetPL.HeaderText = "NetMTMP/L";
      this.NetPL.Name = "NetPL";
      this.NetPL.ReadOnly = true;
      this.NetPL.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.MarginU.HeaderText = "MarginUtilised";
      this.MarginU.Name = "MarginU";
      this.MarginU.ReadOnly = true;
      this.MarginU.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.AvailableMrgn.HeaderText = "AvailableMargin";
      this.AvailableMrgn.Name = "AvailableMrgn";
      this.AvailableMrgn.ReadOnly = true;
      this.AvailableMrgn.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.LossLimit.HeaderText = "Loss(%)";
      this.LossLimit.Name = "LossLimit";
      this.LossLimit.ReadOnly = true;
      this.LossLimit.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.Risk.HeaderText = "Risk(%)";
      this.Risk.Name = "Risk";
      this.Risk.ReadOnly = true;
      this.Risk.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.toolStrip1.Items.AddRange(new ToolStripItem[3]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(945, 25);
      this.toolStrip1.TabIndex = 3;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.cmbclientcode.Sorted = true;
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.toolStrip1);
      this.Controls.Add((Control) this.dgvRMSClientwise);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (RMSClientwise);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "RMS Clientwise";
      this.KeyUp += new KeyEventHandler(this.RMSClientwise_KeyUp);
      ((ISupportInitialize) this.dgvRMSClientwise).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
