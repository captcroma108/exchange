﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDefMktTradeLots
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmDefMktTradeLots : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objmain;
    private GroupBox groupBox1;
    private Label label2;
    private TextBox txtMcxLots;
    private Label label1;
    private ComboBox cmbMcxValidity;
    private Label label3;
    private ComboBox cmbNcdexValidity;
    private TextBox txtNcdexLots;
    private Label label7;
    private ComboBox cmbNseoptValidity;
    private TextBox txtNseoptLots;
    private Label label6;
    private ComboBox cmbNsecurrValidity;
    private TextBox txtNsecurrLots;
    private Label label5;
    private ComboBox cmbNseFutValidity;
    private TextBox txtNsefutLots;
    private Label label4;
    private Button btnSave;

    public frmDefMktTradeLots(Dashboard dash)
    {
      this.InitializeComponent();
      this.objmain = dash;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      Limits clientLimit = this.objmain._ClientLimits[this.objmain.objinfo.clientcode];
      this.cmbMcxValidity.Items.Clear();
      this.cmbNcdexValidity.Items.Clear();
      this.cmbNsecurrValidity.Items.Clear();
      this.cmbNseFutValidity.Items.Clear();
      this.cmbNseoptValidity.Items.Clear();
      if (clientLimit.possitionValidity.Contains(","))
      {
        string[] strArray = clientLimit.possitionValidity.Split(',');
        for (int index = 0; index < strArray.Length; ++index)
        {
          this.cmbMcxValidity.Items.Add((object) strArray[index]);
          this.cmbNcdexValidity.Items.Add((object) strArray[index]);
          this.cmbNsecurrValidity.Items.Add((object) strArray[index]);
          this.cmbNseFutValidity.Items.Add((object) strArray[index]);
          this.cmbNseoptValidity.Items.Add((object) strArray[index]);
        }
        this.cmbMcxValidity.SelectedIndex = 0;
        this.cmbNcdexValidity.SelectedIndex = 0;
        this.cmbNsecurrValidity.SelectedIndex = 0;
        this.cmbNseFutValidity.SelectedIndex = 0;
        this.cmbNseoptValidity.SelectedIndex = 0;
      }
      else if (clientLimit.possitionValidity != null)
      {
        this.cmbMcxValidity.Items.Add((object) clientLimit.possitionValidity);
        this.cmbMcxValidity.SelectedIndex = 0;
        this.cmbNcdexValidity.Items.Add((object) clientLimit.possitionValidity);
        this.cmbNcdexValidity.SelectedIndex = 0;
        this.cmbNsecurrValidity.Items.Add((object) clientLimit.possitionValidity);
        this.cmbNsecurrValidity.SelectedIndex = 0;
        this.cmbNseFutValidity.Items.Add((object) clientLimit.possitionValidity);
        this.cmbNseFutValidity.SelectedIndex = 0;
        this.cmbNseoptValidity.Items.Add((object) clientLimit.possitionValidity);
        this.cmbNseoptValidity.SelectedIndex = 0;
      }
      string mcxValidity = Settings.Default.McxValidity;
      string nsefutValidity = Settings.Default.NsefutValidity;
      string nsecurrValidity = Settings.Default.NsecurrValidity;
      string nseoptValidity = Settings.Default.NseoptValidity;
      string ncdexValidity = Settings.Default.NcdexValidity;
      if (this.cmbMcxValidity.Items.Contains((object) mcxValidity))
        this.cmbMcxValidity.SelectedValue = (object) mcxValidity;
      if (this.cmbNcdexValidity.Items.Contains((object) ncdexValidity))
        this.cmbNcdexValidity.SelectedValue = (object) ncdexValidity;
      if (this.cmbNsecurrValidity.Items.Contains((object) nsecurrValidity))
        this.cmbNsecurrValidity.SelectedValue = (object) nsecurrValidity;
      if (this.cmbNseFutValidity.Items.Contains((object) nsefutValidity))
        this.cmbNseFutValidity.SelectedValue = (object) nsefutValidity;
      if (this.cmbNseoptValidity.Items.Contains((object) nseoptValidity))
        this.cmbNseoptValidity.SelectedValue = (object) nseoptValidity;
      this.txtMcxLots.Text = Settings.Default.McxLots.ToString();
      TextBox txtNsefutLots = this.txtNsefutLots;
      int num = Settings.Default.NsefutLots;
      string str1 = num.ToString();
      txtNsefutLots.Text = str1;
      TextBox txtNsecurrLots = this.txtNsecurrLots;
      num = Settings.Default.NsecurrLots;
      string str2 = num.ToString();
      txtNsecurrLots.Text = str2;
      TextBox txtNseoptLots = this.txtNseoptLots;
      num = Settings.Default.NseoptLots;
      string str3 = num.ToString();
      txtNseoptLots.Text = str3;
      TextBox txtNcdexLots = this.txtNcdexLots;
      num = Settings.Default.NcdexLots;
      string str4 = num.ToString();
      txtNcdexLots.Text = str4;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      int result1 = 0;
      int result2 = 0;
      int result3 = 0;
      int result4 = 0;
      int result5 = 0;
      if (!int.TryParse(this.txtMcxLots.Text, out result1))
        this.objmain.DisplayMessage("Enter numeric Mcx Lots.", 2);
      else if (!int.TryParse(this.txtNsefutLots.Text, out result3))
        this.objmain.DisplayMessage("Enter numeric NseFut Lots.", 2);
      else if (!int.TryParse(this.txtNsecurrLots.Text, out result4))
        this.objmain.DisplayMessage("Enter numeric NseCurr Lots.", 2);
      else if (!int.TryParse(this.txtNseoptLots.Text, out result5))
        this.objmain.DisplayMessage("Enter numeric NseOpt Lots.", 2);
      else if (!int.TryParse(this.txtNcdexLots.Text, out result2))
      {
        this.objmain.DisplayMessage("Enter numeric Ncdex Lots.", 2);
      }
      else
      {
        Settings.Default.McxLots = Convert.ToInt32(this.txtMcxLots.Text);
        Settings.Default.McxValidity = this.cmbMcxValidity.Text;
        Settings.Default.NsefutLots = Convert.ToInt32(this.txtNsefutLots.Text);
        Settings.Default.NsefutValidity = this.cmbNseFutValidity.Text;
        Settings.Default.NsecurrLots = Convert.ToInt32(this.txtNsecurrLots.Text);
        Settings.Default.NsecurrValidity = this.cmbNsecurrValidity.Text;
        Settings.Default.NseoptLots = Convert.ToInt32(this.txtNseoptLots.Text);
        Settings.Default.NseoptValidity = this.cmbNseoptValidity.Text;
        Settings.Default.NcdexLots = Convert.ToInt32(this.txtNcdexLots.Text);
        Settings.Default.NcdexValidity = this.cmbNcdexValidity.Text;
        Settings.Default.Save();
        this.objmain.DisplayMessage("Default Market Trading Configuration Saved Successfully!!!", 1);
        this.Close();
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.label1 = new Label();
      this.txtMcxLots = new TextBox();
      this.label2 = new Label();
      this.label3 = new Label();
      this.cmbMcxValidity = new ComboBox();
      this.cmbNseFutValidity = new ComboBox();
      this.txtNsefutLots = new TextBox();
      this.label4 = new Label();
      this.cmbNsecurrValidity = new ComboBox();
      this.txtNsecurrLots = new TextBox();
      this.label5 = new Label();
      this.cmbNseoptValidity = new ComboBox();
      this.txtNseoptLots = new TextBox();
      this.label6 = new Label();
      this.cmbNcdexValidity = new ComboBox();
      this.txtNcdexLots = new TextBox();
      this.label7 = new Label();
      this.btnSave = new Button();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.cmbNcdexValidity);
      this.groupBox1.Controls.Add((Control) this.txtNcdexLots);
      this.groupBox1.Controls.Add((Control) this.label7);
      this.groupBox1.Controls.Add((Control) this.cmbNseoptValidity);
      this.groupBox1.Controls.Add((Control) this.txtNseoptLots);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.cmbNsecurrValidity);
      this.groupBox1.Controls.Add((Control) this.txtNsecurrLots);
      this.groupBox1.Controls.Add((Control) this.label5);
      this.groupBox1.Controls.Add((Control) this.cmbNseFutValidity);
      this.groupBox1.Controls.Add((Control) this.txtNsefutLots);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.cmbMcxValidity);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.txtMcxLots);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(16, 8);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(313, 223);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchangewise Definition";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(43, 39);
      this.label1.Name = "label1";
      this.label1.Size = new Size(33, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "MCX:";
      this.txtMcxLots.Location = new Point(82, 36);
      this.txtMcxLots.Name = "txtMcxLots";
      this.txtMcxLots.Size = new Size(64, 20);
      this.txtMcxLots.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(88, 20);
      this.label2.Name = "label2";
      this.label2.Size = new Size(30, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Lots.";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(176, 20);
      this.label3.Name = "label3";
      this.label3.Size = new Size(40, 13);
      this.label3.TabIndex = 3;
      this.label3.Text = "Validity";
      this.cmbMcxValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbMcxValidity.FormattingEnabled = true;
      this.cmbMcxValidity.Location = new Point(179, 36);
      this.cmbMcxValidity.Name = "cmbMcxValidity";
      this.cmbMcxValidity.Size = new Size(121, 21);
      this.cmbMcxValidity.TabIndex = 4;
      this.cmbNseFutValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbNseFutValidity.FormattingEnabled = true;
      this.cmbNseFutValidity.Location = new Point(179, 71);
      this.cmbNseFutValidity.Name = "cmbNseFutValidity";
      this.cmbNseFutValidity.Size = new Size(121, 21);
      this.cmbNseFutValidity.TabIndex = 7;
      this.txtNsefutLots.Location = new Point(82, 71);
      this.txtNsefutLots.Name = "txtNsefutLots";
      this.txtNsefutLots.Size = new Size(64, 20);
      this.txtNsefutLots.TabIndex = 6;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(23, 74);
      this.label4.Name = "label4";
      this.label4.Size = new Size(53, 13);
      this.label4.TabIndex = 5;
      this.label4.Text = "NSEFUT:";
      this.cmbNsecurrValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbNsecurrValidity.FormattingEnabled = true;
      this.cmbNsecurrValidity.Location = new Point(179, 109);
      this.cmbNsecurrValidity.Name = "cmbNsecurrValidity";
      this.cmbNsecurrValidity.Size = new Size(121, 21);
      this.cmbNsecurrValidity.TabIndex = 10;
      this.txtNsecurrLots.Location = new Point(82, 109);
      this.txtNsecurrLots.Name = "txtNsecurrLots";
      this.txtNsecurrLots.Size = new Size(64, 20);
      this.txtNsecurrLots.TabIndex = 9;
      this.label5.AutoSize = true;
      this.label5.Location = new Point(13, 112);
      this.label5.Name = "label5";
      this.label5.Size = new Size(63, 13);
      this.label5.TabIndex = 8;
      this.label5.Text = "NSECURR:";
      this.cmbNseoptValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbNseoptValidity.FormattingEnabled = true;
      this.cmbNseoptValidity.Location = new Point(179, 145);
      this.cmbNseoptValidity.Name = "cmbNseoptValidity";
      this.cmbNseoptValidity.Size = new Size(121, 21);
      this.cmbNseoptValidity.TabIndex = 13;
      this.txtNseoptLots.Location = new Point(82, 145);
      this.txtNseoptLots.Name = "txtNseoptLots";
      this.txtNseoptLots.Size = new Size(64, 20);
      this.txtNseoptLots.TabIndex = 12;
      this.label6.AutoSize = true;
      this.label6.Location = new Point(22, 148);
      this.label6.Name = "label6";
      this.label6.Size = new Size(54, 13);
      this.label6.TabIndex = 11;
      this.label6.Text = "NSEOPT:";
      this.cmbNcdexValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbNcdexValidity.FormattingEnabled = true;
      this.cmbNcdexValidity.Location = new Point(179, 182);
      this.cmbNcdexValidity.Name = "cmbNcdexValidity";
      this.cmbNcdexValidity.Size = new Size(121, 21);
      this.cmbNcdexValidity.TabIndex = 16;
      this.txtNcdexLots.Location = new Point(82, 182);
      this.txtNcdexLots.Name = "txtNcdexLots";
      this.txtNcdexLots.Size = new Size(64, 20);
      this.txtNcdexLots.TabIndex = 15;
      this.label7.AutoSize = true;
      this.label7.Location = new Point(29, 185);
      this.label7.Name = "label7";
      this.label7.Size = new Size(47, 13);
      this.label7.TabIndex = 14;
      this.label7.Text = "NCDEX:";
      this.btnSave.Location = new Point(135, 237);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 23);
      this.btnSave.TabIndex = 1;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(345, 269);
      this.Controls.Add((Control) this.btnSave);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmDefMktTradeLots);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Default Market Trading Config.";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
