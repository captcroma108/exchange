﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmFilterNetPos
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmFilterNetPos : Form
  {
    private IContainer components = (IContainer) null;
    private NetPosition objnetpos;
    private GroupBox groupBox1;
    private Label label2;
    private Label label1;
    private Label label3;
    private Button btnFilter;
    public ComboBox cmbSymbol;
    public ComboBox cmbExch;
    public ComboBox cmbClientcode;
    private TextBox txtName;

    public frmFilterNetPos(NetPosition netpos)
    {
      this.InitializeComponent();
      this.objnetpos = netpos;
      this.Icon = netpos.objmain.ico;
    }

    public void refreshControls(DataGridView dgvNetPosition)
    {
      this.cmbClientcode.Items.Clear();
      this.cmbClientcode.Items.Add((object) "");
      this.cmbExch.Items.Clear();
      this.cmbExch.Items.Add((object) "");
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "");
      foreach (DataGridViewRow row in (IEnumerable) dgvNetPosition.Rows)
      {
        string str1 = row.Cells[2].Value.ToString();
        string str2 = row.Cells[3].Value.ToString();
        string str3 = row.Cells[0].Value.ToString();
        if (!this.cmbClientcode.Items.Contains((object) str3))
          this.cmbClientcode.Items.Add((object) str3);
        if (!this.cmbExch.Items.Contains((object) str1))
          this.cmbExch.Items.Add((object) str1);
        if (!this.cmbSymbol.Items.Contains((object) str2))
          this.cmbSymbol.Items.Add((object) str2);
      }
      this.cmbClientcode.SelectedIndex = 0;
      this.cmbExch.SelectedIndex = 0;
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void btnFilter_Click(object sender, EventArgs e)
    {
      this.objnetpos.ProcessFilter(this.cmbClientcode.Text, this.cmbExch.Text, this.cmbSymbol.Text);
    }

    private void cmbClientcode_Leave(object sender, EventArgs e)
    {
      if (this.cmbClientcode.Text.Length <= 0)
        return;
      if (!this.objnetpos.objmain._lstAccounts.Contains(this.cmbClientcode.Text))
      {
        this.objnetpos.objmain.DisplayMessage("Client code does not exists.", 2);
        this.cmbClientcode.Text = string.Empty;
      }
      else
        this.txtName.Text = this.objnetpos.objmain.GetUserinfo(this.cmbClientcode.Text).name;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.btnFilter = new Button();
      this.cmbClientcode = new ComboBox();
      this.label3 = new Label();
      this.cmbSymbol = new ComboBox();
      this.label2 = new Label();
      this.cmbExch = new ComboBox();
      this.label1 = new Label();
      this.txtName = new TextBox();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.txtName);
      this.groupBox1.Controls.Add((Control) this.btnFilter);
      this.groupBox1.Controls.Add((Control) this.cmbClientcode);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.cmbSymbol);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.cmbExch);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(5, 2);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(575, 72);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Filter Parameters";
      this.btnFilter.Location = new Point(497, 38);
      this.btnFilter.Name = "btnFilter";
      this.btnFilter.Size = new Size(57, 23);
      this.btnFilter.TabIndex = 3;
      this.btnFilter.Text = "Filter";
      this.btnFilter.UseVisualStyleBackColor = true;
      this.btnFilter.Click += new EventHandler(this.btnFilter_Click);
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(13, 40);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(92, 21);
      this.cmbClientcode.TabIndex = 0;
      this.cmbClientcode.Leave += new EventHandler(this.cmbClientcode_Leave);
      this.label3.AutoSize = true;
      this.label3.Location = new Point(16, 20);
      this.label3.Name = "label3";
      this.label3.Size = new Size(58, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "ClientCode";
      this.cmbSymbol.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSymbol.FormattingEnabled = true;
      this.cmbSymbol.Location = new Point(367, 40);
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(110, 21);
      this.cmbSymbol.TabIndex = 2;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(370, 20);
      this.label2.Name = "label2";
      this.label2.Size = new Size(41, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Symbol";
      this.cmbExch.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbExch.FormattingEnabled = true;
      this.cmbExch.Location = new Point(266, 40);
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(82, 21);
      this.cmbExch.TabIndex = 1;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(269, 20);
      this.label1.Name = "label1";
      this.label1.Size = new Size(55, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Exchange";
      this.txtName.Location = new Point(111, 40);
      this.txtName.Name = "txtName";
      this.txtName.ReadOnly = true;
      this.txtName.Size = new Size(145, 20);
      this.txtName.TabIndex = 7;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(592, 78);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (frmFilterNetPos);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Filter";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
