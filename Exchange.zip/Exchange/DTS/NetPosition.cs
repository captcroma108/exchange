﻿// Decompiled with JetBrains decompiler
// Type: DTS.NetPosition
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class NetPosition : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    public Dictionary<string, int> _NetPosList = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public frmFilterNetPos objfilter;
    public MWColumnProfile objColProfile;
    public DataGridView dgvNetPosition;
    private TableLayoutPanel tableLayoutPanel1;
    private Label lblUnRealisedPL;
    private Label label2;
    private Label lblRealisedPL;
    private Label label1;
    private Label label3;
    private Label lblBrkg;
    private Label label4;
    private Label lblNetMTM;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem columnProfileToolStripMenuItem;
    private ToolStripMenuItem changeToolStripMenuItem;
    private ToolStripMenuItem saveToolStripMenuItem;
    private ToolStripMenuItem filterDataToolStripMenuItem;
    private ToolStripMenuItem positionTypeToolStripMenuItem;
    private ToolStripMenuItem carryForwardToolStripMenuItem;
    private ToolStripMenuItem dayToolStripMenuItem;
    private ToolStripMenuItem gridToolStripMenuItem;
    private ToolStripMenuItem exportToCsvToolStripMenuItem;
    private DataGridViewTextBoxColumn Regulation;
    private DataGridViewTextBoxColumn ColName;
    private DataGridViewTextBoxColumn Exchange;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Lotsize;
    private DataGridViewTextBoxColumn BQty;
    private DataGridViewTextBoxColumn BAvgPrice;
    private DataGridViewTextBoxColumn SQty;
    private DataGridViewTextBoxColumn SAvgPrice;
    private DataGridViewTextBoxColumn Netlot;
    private DataGridViewTextBoxColumn CMP;
    private DataGridViewTextBoxColumn Realises;
    private DataGridViewTextBoxColumn Unrealised;
    private DataGridViewTextBoxColumn Commission;
    private DataGridViewTextBoxColumn NetMTM;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripLabel toolStripLabel1;
    private ToolStripComboBox cmbExch;
    private ToolStripLabel toolStripLabel4;
    private ToolStripComboBox cmbSymbol;
    private ToolStripButton btnSearch;
    private ToolStripLabel lblName;

    public NetPosition(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      this._ColumnOnOff = new Dictionary<string, int>();
      string netPosColPrfl = Settings.Default.NetPosColPrfl;
      if (netPosColPrfl != string.Empty)
      {
        string str1 = netPosColPrfl;
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ '_' };
          string[] strArray = str2.Split(chArray2);
          int int32 = Convert.ToInt32(strArray[1]);
          switch (Convert.ToInt32(strArray[2]))
          {
            case 0:
              this.dgvNetPosition.Columns[int32].Visible = false;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 0);
                break;
              }
              break;
            case 1:
              this.dgvNetPosition.Columns[int32].Visible = true;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 1);
                break;
              }
              break;
          }
        }
      }
      else
      {
        for (int index = 0; index < this.dgvNetPosition.Columns.Count; ++index)
        {
          if (!this._ColumnOnOff.ContainsKey(this.dgvNetPosition.Columns[index].HeaderText))
          {
            if (this.dgvNetPosition.Columns[index].Visible)
              this._ColumnOnOff.Add(this.dgvNetPosition.Columns[index].HeaderText, 1);
            else
              this._ColumnOnOff.Add(this.dgvNetPosition.Columns[index].HeaderText, 0);
          }
        }
      }
    }

    private void dgvNetPosition_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvNetPosition.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvNetPosition, client.X, client.Y);
    }

    public void ProcessFilter(string clientcode, string exch, string symbol)
    {
      if (clientcode == string.Empty && exch == string.Empty && symbol == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvNetPosition.Rows)
          row.Visible = true;
      }
      else if (clientcode == string.Empty && exch != string.Empty && symbol != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[2].Value.ToString() == exch && row.Cells[3].Value.ToString() == symbol)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (clientcode == string.Empty && exch == string.Empty && symbol != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[3].Value.ToString() == symbol)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (clientcode != string.Empty && exch == string.Empty && symbol != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == clientcode && row.Cells[3].Value.ToString() == symbol)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (clientcode != string.Empty && exch == string.Empty && symbol == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == clientcode)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (clientcode != string.Empty && exch != string.Empty && symbol == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == clientcode && row.Cells[2].Value.ToString() == exch)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (clientcode == string.Empty && exch != string.Empty && symbol == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[2].Value.ToString() == exch)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(clientcode != string.Empty) || !(exch != string.Empty) || !(symbol != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[2].Value.ToString() == exch && row.Cells[3].Value.ToString() == symbol && row.Cells[0].Value.ToString() == clientcode)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    public void LoadNetPositions(bool isIntraday)
    {
      this.LoadWindow();
      this.dgvNetPosition.Rows.Clear();
      this._NetPosList = new Dictionary<string, int>();
      Dictionary<string, buysellnetpospfls> dictionary1 = new Dictionary<string, buysellnetpospfls>();
      Dictionary<string, buysellnetpospfls> dictionary2;
      if (!isIntraday)
      {
        dictionary2 = this.objmain._NetProftLoss;
      }
      else
      {
        Dictionary<string, buysellPos> _BuySellAvgPos = new Dictionary<string, buysellPos>();
        this.objmain.GetTradePosition(ref _BuySellAvgPos, this.objmain.claccounts, false);
        dictionary2 = this.objmain.ProcessProfitLoss(_BuySellAvgPos);
      }
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dictionary2)
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string index1 = strArray[0];
        string str = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        if (this.objmain._Symconctracts.ContainsKey(index1))
        {
          Contracts symconctract = this.objmain._Symconctracts[index1];
          buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          this.objmain.getFeed(symbol);
          Userinfo userinfo = this.objmain.GetUserinfo(str);
          int index2 = this.dgvNetPosition.Rows.Add();
          this.dgvNetPosition.Rows[index2].Cells[0].Value = (object) str;
          this.dgvNetPosition.Rows[index2].Cells[1].Value = (object) userinfo.name;
          this.dgvNetPosition.Rows[index2].Cells[2].Value = (object) Utils.GetExch(symconctract.exch);
          this.dgvNetPosition.Rows[index2].Cells[3].Value = (object) index1;
          this.dgvNetPosition.Rows[index2].Cells[4].Value = (object) Utils.GetValidity(int32);
          this.dgvNetPosition.Rows[index2].Cells[5].Value = (object) symconctract.lotsize;
          this.dgvNetPosition.Rows[index2].Cells[6].Value = (object) buysellnetpospfls.BQty;
          this.dgvNetPosition.Rows[index2].Cells[7].Value = (object) Decimal.Round(buysellnetpospfls.buyprice, 2);
          this.dgvNetPosition.Rows[index2].Cells[8].Value = (object) buysellnetpospfls.SQty;
          this.dgvNetPosition.Rows[index2].Cells[9].Value = (object) Decimal.Round(buysellnetpospfls.sellprice, 2);
          this.dgvNetPosition.Rows[index2].Cells[10].Value = (object) (buysellnetpospfls.BQty - buysellnetpospfls.SQty);
          this.dgvNetPosition.Rows[index2].Cells[12].Value = (object) Decimal.Round(buysellnetpospfls.p_l, 2);
          this.dgvNetPosition.Rows[index2].Cells[14].Value = (object) buysellnetpospfls.Commision;
          this._NetPosList.Add(keyValuePair.Key, index2);
          this.FillCombobox(str, index1, Utils.GetExch(symconctract.exch));
        }
      }
      new Thread((ThreadStart) (() => this.GetFeedUpdate())).Start();
    }

    private void RealTimeNetPos()
    {
      while (true)
      {
        Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>();
        foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this.objmain._NetProftLoss)
        {
          KeyValuePair<string, buysellnetpospfls> items = keyValuePair;
          string[] strArray = items.Key.Split('_');
          string symbol = strArray[0];
          string account = strArray[1];
          int validity = Convert.ToInt32(strArray[2]);
          if (this._NetPosList.ContainsKey(items.Key))
          {
            int netPos = this._NetPosList[items.Key];
            if (this.objmain._Symconctracts.ContainsKey(symbol) && this.dgvNetPosition.Rows.Count > 0)
            {
              Contracts symconctract = this.objmain._Symconctracts[symbol];
              buysellnetpospfls buysellnetpospfls = items.Value;
              if (Convert.ToInt32(this.dgvNetPosition.Rows[netPos].Cells[6].Value) != buysellnetpospfls.BQty)
                this.dgvNetPosition.Rows[netPos].Cells[6].Value = (object) buysellnetpospfls.BQty;
              if (Convert.ToDecimal(this.dgvNetPosition.Rows[netPos].Cells[7].Value) != Decimal.Round(buysellnetpospfls.buyprice, 2))
                this.dgvNetPosition.Rows[netPos].Cells[7].Value = (object) Decimal.Round(buysellnetpospfls.buyprice, 2);
              if (Convert.ToInt32(this.dgvNetPosition.Rows[netPos].Cells[8].Value) != buysellnetpospfls.SQty)
                this.dgvNetPosition.Rows[netPos].Cells[8].Value = (object) buysellnetpospfls.SQty;
              if (Convert.ToDecimal(this.dgvNetPosition.Rows[netPos].Cells[9].Value) != Decimal.Round(buysellnetpospfls.sellprice, 2))
                this.dgvNetPosition.Rows[netPos].Cells[9].Value = (object) Decimal.Round(buysellnetpospfls.sellprice, 2);
              if (Convert.ToInt32(this.dgvNetPosition.Rows[netPos].Cells[10].Value) != buysellnetpospfls.BQty - buysellnetpospfls.SQty)
                this.dgvNetPosition.Rows[netPos].Cells[10].Value = (object) (buysellnetpospfls.BQty - buysellnetpospfls.SQty);
              if (Convert.ToDecimal(this.dgvNetPosition.Rows[netPos].Cells[12].Value) != Decimal.Round(buysellnetpospfls.p_l, 2))
                this.dgvNetPosition.Rows[netPos].Cells[12].Value = (object) Decimal.Round(buysellnetpospfls.p_l, 2);
              if (Convert.ToDecimal(this.dgvNetPosition.Rows[netPos].Cells[14].Value) != buysellnetpospfls.Commision)
                this.dgvNetPosition.Rows[netPos].Cells[14].Value = (object) buysellnetpospfls.Commision;
            }
          }
          else if (this.objmain._Symconctracts.ContainsKey(symbol))
          {
            int rowcount = this.dgvNetPosition.Rows.Add();
            Contracts objcon = this.objmain._Symconctracts[symbol];
            string symbol1 = objcon.SymDesp;
            if (objcon.symbol == "GOLDMM")
              symbol1 = symbol1.Replace("GOLDMM", "GOLD");
            else if (objcon.symbol == "SILVERMM")
              symbol1 = symbol1.Replace("SILVERMM", "SILVER");
            buysellnetpospfls objpos = items.Value;
            this.objmain.getFeed(symbol1);
            Userinfo objinfo = this.objmain.GetUserinfo(account);
            this.Invoke((Delegate) (() =>
            {
              this.dgvNetPosition.Rows.Add();
              this.dgvNetPosition.Rows[rowcount].Cells[0].Value = (object) account;
              this.dgvNetPosition.Rows[rowcount].Cells[1].Value = (object) objinfo.name;
              this.dgvNetPosition.Rows[rowcount].Cells[2].Value = (object) Utils.GetExch(objcon.exch);
              this.dgvNetPosition.Rows[rowcount].Cells[3].Value = (object) symbol;
              this.dgvNetPosition.Rows[rowcount].Cells[4].Value = (object) Utils.GetValidity(validity);
              this.dgvNetPosition.Rows[rowcount].Cells[5].Value = (object) objcon.lotsize;
              this.dgvNetPosition.Rows[rowcount].Cells[6].Value = (object) objpos.BQty;
              this.dgvNetPosition.Rows[rowcount].Cells[7].Value = (object) Decimal.Round(objpos.buyprice, 2);
              this.dgvNetPosition.Rows[rowcount].Cells[8].Value = (object) objpos.SQty;
              this.dgvNetPosition.Rows[rowcount].Cells[9].Value = (object) Decimal.Round(objpos.sellprice, 2);
              this.dgvNetPosition.Rows[rowcount].Cells[10].Value = (object) (objpos.BQty - objpos.SQty);
              this.dgvNetPosition.Rows[rowcount].Cells[12].Value = (object) Decimal.Round(objpos.p_l, 2);
              this.dgvNetPosition.Rows[rowcount].Cells[14].Value = (object) objpos.Commision;
              this.dgvNetPosition.Rows[rowcount].Cells[15].Value = (object) objpos.Comm_Tax;
              this.dgvNetPosition.Rows[rowcount].Cells[16].Value = (object) objpos.p_ltax;
              this._NetPosList.Add(items.Key, rowcount);
              this.FillCombobox(account, symbol, Utils.GetExch(objcon.exch));
            }));
          }
        }
        Thread.Sleep(5000);
        Application.DoEvents();
      }
    }

    private void GetFeedUpdate()
    {
      while (true)
      {
        Decimal netRealisedPL = new Decimal();
        Decimal netBrkg = new Decimal();
        Decimal netUnrealisedPL = new Decimal();
        Decimal netMTM = new Decimal();
        Decimal num1 = new Decimal();
        for (int index = 0; index < this.dgvNetPosition.Rows.Count; ++index)
        {
          string key = this.dgvNetPosition.Rows[index].Cells[3].Value.ToString();
          if (this.objmain._Symconctracts.ContainsKey(key))
          {
            Contracts symconctract = this.objmain._Symconctracts[key];
            string symbol = symconctract.SymDesp;
            if (symconctract.symbol == "GOLDMM")
              symbol = symbol.Replace("GOLDMM", "GOLD");
            else if (symconctract.symbol == "SILVERMM")
              symbol = symbol.Replace("SILVERMM", "SILVER");
            Feeds feed = this.objmain.getFeed(symbol);
            this.dgvNetPosition.Rows[index].Cells[11].Value = (object) feed.ltp;
            string str = this.dgvNetPosition.Rows[index].Cells[2].Value.ToString();
            int int32_1 = Convert.ToInt32(this.dgvNetPosition.Rows[index].Cells[6].Value);
            Decimal num2 = Convert.ToDecimal(this.dgvNetPosition.Rows[index].Cells[7].Value);
            int int32_2 = Convert.ToInt32(this.dgvNetPosition.Rows[index].Cells[8].Value);
            Decimal num3 = Convert.ToDecimal(this.dgvNetPosition.Rows[index].Cells[9].Value);
            Decimal num4 = Convert.ToDecimal(this.dgvNetPosition.Rows[index].Cells[12].Value);
            Decimal num5 = Convert.ToDecimal(this.dgvNetPosition.Rows[index].Cells[14].Value);
            netRealisedPL += num4;
            netBrkg += num5;
            if (int32_1 > int32_2)
            {
              if (feed.bid > Decimal.Zero)
              {
                int num6 = int32_1 - int32_2;
                Decimal d1 = !(str.ToUpper() == "NSEFUT") ? (feed.bid - num2) * (Decimal) num6 * (Decimal) symconctract.lotsize : (feed.bid - num2) * (Decimal) num6;
                Decimal d2 = num4 + d1 - num5;
                netUnrealisedPL += d1;
                netMTM += d2;
                this.dgvNetPosition.Rows[index].Cells[11].Value = (object) feed.bid;
                this.dgvNetPosition.Rows[index].Cells[13].Value = (object) Decimal.Round(d1, 2);
                this.dgvNetPosition.Rows[index].Cells[15].Value = (object) Decimal.Round(d2, 2);
              }
            }
            else if (int32_1 < int32_2)
            {
              if (feed.ask > Decimal.Zero)
              {
                int num6 = int32_2 - int32_1;
                Decimal d1 = !(str.ToUpper() == "NSEFUT") ? (num3 - feed.ask) * (Decimal) num6 * (Decimal) symconctract.lotsize : (num3 - feed.ask) * (Decimal) num6;
                Decimal d2 = num4 + d1 - num5;
                netUnrealisedPL += d1;
                netMTM += d2;
                this.dgvNetPosition.Rows[index].Cells[11].Value = (object) feed.ask;
                this.dgvNetPosition.Rows[index].Cells[13].Value = (object) Decimal.Round(d1, 2);
                this.dgvNetPosition.Rows[index].Cells[15].Value = (object) Decimal.Round(d2, 2);
              }
            }
            else
            {
              netMTM += num4 - num5;
              this.dgvNetPosition.Rows[index].Cells[15].Value = (object) Decimal.Round(num4 - num5, 2);
            }
          }
          Thread.Sleep(10);
        }
        if (!this.IsDisposed)
        {
          try
          {
            this.Invoke((Delegate) (() =>
            {
              this.lblBrkg.Text = netBrkg.ToString();
              this.lblNetMTM.Text = netMTM.ToString();
              this.lblRealisedPL.Text = netRealisedPL.ToString();
              this.lblUnRealisedPL.Text = netUnrealisedPL.ToString();
            }));
          }
          catch
          {
          }
        }
        Thread.Sleep(2000);
      }
    }

    private void changeToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.objColProfile == null || this.objColProfile.IsDisposed)
      {
        MWColumnProfile mwColumnProfile = new MWColumnProfile(this.objmain, 6);
        mwColumnProfile.MdiParent = (Form) this.objmain;
        this.objColProfile = mwColumnProfile;
        this.objColProfile.Show();
      }
      else
      {
        this.objColProfile.MdiParent = (Form) this.objmain;
        this.objColProfile.Activate();
        this.objColProfile.Show();
      }
    }

    private void saveToolStripMenuItem_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvNetPosition.Columns.Count; ++index)
        str = !this.dgvNetPosition.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvNetPosition.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvNetPosition.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.NetPosColPrfl = str;
      Settings.Default.Save();
      this.objmain.DisplayMessage("Column profile saved successfully!!", 1);
    }

    private void filterDataToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.objfilter == null || this.objfilter.IsDisposed)
      {
        frmFilterNetPos frmFilterNetPos = new frmFilterNetPos(this);
        frmFilterNetPos.MdiParent = (Form) this.objmain;
        this.objfilter = frmFilterNetPos;
        this.objfilter.refreshControls(this.dgvNetPosition);
        this.objfilter.Show();
      }
      else
      {
        this.objfilter.refreshControls(this.dgvNetPosition);
        this.objfilter.Show();
      }
    }

    private void gridToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.gridToolStripMenuItem.Checked)
        this.dgvNetPosition.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
      else
        this.dgvNetPosition.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void exportToCsvToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvNetPosition.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvNetPosition, false);
    }

    private void carryForwardToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.carryForwardToolStripMenuItem.Checked)
      {
        this.LoadNetPositions(false);
        this.dayToolStripMenuItem.Checked = false;
      }
      else
      {
        this.dayToolStripMenuItem.Checked = true;
        this.LoadNetPositions(true);
      }
    }

    private void dayToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dayToolStripMenuItem.Checked)
      {
        this.LoadNetPositions(true);
        this.carryForwardToolStripMenuItem.Checked = false;
      }
      else
      {
        this.carryForwardToolStripMenuItem.Checked = true;
        this.LoadNetPositions(false);
      }
    }

    private void cmbclientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text.Length <= 0)
        return;
      if (!this.objmain._lstAccounts.Contains(this.cmbclientcode.Text))
      {
        this.objmain.DisplayMessage("Client code does not exists.", 2);
        this.cmbclientcode.Text = string.Empty;
      }
      else if (this.objmain._Userinformation.ContainsKey(this.cmbclientcode.Text))
        this.lblName.Text = this.objmain._Userinformation[this.cmbclientcode.Text].name;
    }

    private void FillCombobox(string accno, string symbol, string exch)
    {
      if (!this.cmbclientcode.Items.Contains((object) accno))
        this.cmbclientcode.Items.Add((object) accno);
      if (!this.cmbExch.Items.Contains((object) exch))
        this.cmbExch.Items.Add((object) exch);
      if (this.cmbSymbol.Items.Contains((object) symbol))
        return;
      this.cmbSymbol.Items.Add((object) symbol);
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && this.cmbSymbol.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvNetPosition.Rows)
          row.Visible = true;
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && this.cmbSymbol.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && this.cmbSymbol.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && this.cmbSymbol.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[3].Value.ToString() == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && this.cmbSymbol.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[3].Value.ToString() == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && this.cmbSymbol.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[3].Value.ToString() == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && this.cmbSymbol.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[3].Value.ToString() == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(this.cmbclientcode.Text == string.Empty) || !(this.cmbExch.Text != string.Empty) || !(this.cmbSymbol.Text == string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (NetPosition));
      this.dgvNetPosition = new DataGridView();
      this.Regulation = new DataGridViewTextBoxColumn();
      this.ColName = new DataGridViewTextBoxColumn();
      this.Exchange = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Lotsize = new DataGridViewTextBoxColumn();
      this.BQty = new DataGridViewTextBoxColumn();
      this.BAvgPrice = new DataGridViewTextBoxColumn();
      this.SQty = new DataGridViewTextBoxColumn();
      this.SAvgPrice = new DataGridViewTextBoxColumn();
      this.Netlot = new DataGridViewTextBoxColumn();
      this.CMP = new DataGridViewTextBoxColumn();
      this.Realises = new DataGridViewTextBoxColumn();
      this.Unrealised = new DataGridViewTextBoxColumn();
      this.Commission = new DataGridViewTextBoxColumn();
      this.NetMTM = new DataGridViewTextBoxColumn();
      this.tableLayoutPanel1 = new TableLayoutPanel();
      this.label3 = new Label();
      this.lblUnRealisedPL = new Label();
      this.label2 = new Label();
      this.lblRealisedPL = new Label();
      this.label1 = new Label();
      this.lblBrkg = new Label();
      this.label4 = new Label();
      this.lblNetMTM = new Label();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.columnProfileToolStripMenuItem = new ToolStripMenuItem();
      this.changeToolStripMenuItem = new ToolStripMenuItem();
      this.saveToolStripMenuItem = new ToolStripMenuItem();
      this.filterDataToolStripMenuItem = new ToolStripMenuItem();
      this.positionTypeToolStripMenuItem = new ToolStripMenuItem();
      this.carryForwardToolStripMenuItem = new ToolStripMenuItem();
      this.dayToolStripMenuItem = new ToolStripMenuItem();
      this.gridToolStripMenuItem = new ToolStripMenuItem();
      this.exportToCsvToolStripMenuItem = new ToolStripMenuItem();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.lblName = new ToolStripLabel();
      this.toolStripLabel1 = new ToolStripLabel();
      this.cmbExch = new ToolStripComboBox();
      this.toolStripLabel4 = new ToolStripLabel();
      this.cmbSymbol = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      ((ISupportInitialize) this.dgvNetPosition).BeginInit();
      this.tableLayoutPanel1.SuspendLayout();
      this.contextMenuStrip1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvNetPosition.AllowUserToAddRows = false;
      this.dgvNetPosition.AllowUserToDeleteRows = false;
      this.dgvNetPosition.AllowUserToOrderColumns = true;
      this.dgvNetPosition.AllowUserToResizeRows = false;
      this.dgvNetPosition.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvNetPosition.BackgroundColor = Color.White;
      this.dgvNetPosition.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvNetPosition.Columns.AddRange((DataGridViewColumn) this.Regulation, (DataGridViewColumn) this.ColName, (DataGridViewColumn) this.Exchange, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Lotsize, (DataGridViewColumn) this.BQty, (DataGridViewColumn) this.BAvgPrice, (DataGridViewColumn) this.SQty, (DataGridViewColumn) this.SAvgPrice, (DataGridViewColumn) this.Netlot, (DataGridViewColumn) this.CMP, (DataGridViewColumn) this.Realises, (DataGridViewColumn) this.Unrealised, (DataGridViewColumn) this.Commission, (DataGridViewColumn) this.NetMTM);
      this.dgvNetPosition.Location = new Point(0, 28);
      this.dgvNetPosition.Name = "dgvNetPosition";
      this.dgvNetPosition.ReadOnly = true;
      this.dgvNetPosition.RowHeadersVisible = false;
      this.dgvNetPosition.Size = new Size(1076, 286);
      this.dgvNetPosition.TabIndex = 0;
      this.dgvNetPosition.MouseClick += new MouseEventHandler(this.dgvNetPosition_MouseClick);
      this.Regulation.HeaderText = "ClientCode";
      this.Regulation.Name = "Regulation";
      this.Regulation.ReadOnly = true;
      this.Regulation.Width = 70;
      this.ColName.HeaderText = "Name";
      this.ColName.Name = "ColName";
      this.ColName.ReadOnly = true;
      this.Exchange.HeaderText = "Exchange";
      this.Exchange.Name = "Exchange";
      this.Exchange.ReadOnly = true;
      this.Exchange.Width = 70;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 60;
      this.Lotsize.HeaderText = "Lotsize";
      this.Lotsize.Name = "Lotsize";
      this.Lotsize.ReadOnly = true;
      this.Lotsize.Width = 50;
      this.BQty.HeaderText = "BQty";
      this.BQty.Name = "BQty";
      this.BQty.ReadOnly = true;
      this.BQty.Width = 50;
      this.BAvgPrice.HeaderText = "BAvgPrice";
      this.BAvgPrice.Name = "BAvgPrice";
      this.BAvgPrice.ReadOnly = true;
      this.BAvgPrice.Width = 60;
      this.SQty.HeaderText = "SQty";
      this.SQty.Name = "SQty";
      this.SQty.ReadOnly = true;
      this.SQty.Width = 50;
      this.SAvgPrice.HeaderText = "SAvgPrice";
      this.SAvgPrice.Name = "SAvgPrice";
      this.SAvgPrice.ReadOnly = true;
      this.SAvgPrice.Width = 60;
      this.Netlot.HeaderText = "NetLot";
      this.Netlot.Name = "Netlot";
      this.Netlot.ReadOnly = true;
      this.Netlot.Width = 50;
      this.CMP.HeaderText = "CMP";
      this.CMP.Name = "CMP";
      this.CMP.ReadOnly = true;
      this.CMP.Width = 60;
      this.Realises.HeaderText = "RealisedP/L";
      this.Realises.Name = "Realises";
      this.Realises.ReadOnly = true;
      this.Realises.Width = 70;
      this.Unrealised.HeaderText = "UnrealisedP/L";
      this.Unrealised.Name = "Unrealised";
      this.Unrealised.ReadOnly = true;
      this.Unrealised.Width = 70;
      this.Commission.HeaderText = "Brokerage";
      this.Commission.Name = "Commission";
      this.Commission.ReadOnly = true;
      this.Commission.Width = 50;
      this.NetMTM.HeaderText = "NetMTMP/L";
      this.NetMTM.Name = "NetMTM";
      this.NetMTM.ReadOnly = true;
      this.NetMTM.Width = 80;
      this.tableLayoutPanel1.ColumnCount = 8;
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.Controls.Add((Control) this.label3, 4, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.lblUnRealisedPL, 3, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.label2, 2, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.lblRealisedPL, 1, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.label1, 0, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.lblBrkg, 5, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.label4, 6, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.lblNetMTM, 7, 0);
      this.tableLayoutPanel1.Dock = DockStyle.Bottom;
      this.tableLayoutPanel1.Location = new Point(0, 317);
      this.tableLayoutPanel1.Name = "tableLayoutPanel1";
      this.tableLayoutPanel1.RowCount = 1;
      this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
      this.tableLayoutPanel1.Size = new Size(1076, 22);
      this.tableLayoutPanel1.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label3.Location = new Point(539, 0);
      this.label3.Name = "label3";
      this.label3.Size = new Size(77, 15);
      this.label3.TabIndex = 4;
      this.label3.Text = "Brokerage:";
      this.label3.Visible = false;
      this.lblUnRealisedPL.AutoSize = true;
      this.lblUnRealisedPL.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblUnRealisedPL.Location = new Point(405, 0);
      this.lblUnRealisedPL.Name = "lblUnRealisedPL";
      this.lblUnRealisedPL.Size = new Size(0, 15);
      this.lblUnRealisedPL.TabIndex = 3;
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(271, 0);
      this.label2.Name = "label2";
      this.label2.Size = new Size(111, 15);
      this.label2.TabIndex = 2;
      this.label2.Text = "UnRealised P/L:";
      this.lblRealisedPL.AutoSize = true;
      this.lblRealisedPL.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblRealisedPL.Location = new Point(137, 0);
      this.lblRealisedPL.Name = "lblRealisedPL";
      this.lblRealisedPL.Size = new Size(0, 15);
      this.lblRealisedPL.TabIndex = 1;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(3, 0);
      this.label1.Name = "label1";
      this.label1.Size = new Size(93, 15);
      this.label1.TabIndex = 0;
      this.label1.Text = "Realised P/L:";
      this.lblBrkg.AutoSize = true;
      this.lblBrkg.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblBrkg.Location = new Point(673, 0);
      this.lblBrkg.Name = "lblBrkg";
      this.lblBrkg.Size = new Size(0, 15);
      this.lblBrkg.TabIndex = 5;
      this.lblBrkg.Visible = false;
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label4.Location = new Point(807, 0);
      this.label4.Name = "label4";
      this.label4.Size = new Size(94, 15);
      this.label4.TabIndex = 6;
      this.label4.Text = "Net MTM P/L:";
      this.lblNetMTM.AutoSize = true;
      this.lblNetMTM.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblNetMTM.Location = new Point(941, 0);
      this.lblNetMTM.Name = "lblNetMTM";
      this.lblNetMTM.Size = new Size(0, 15);
      this.lblNetMTM.TabIndex = 7;
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[5]
      {
        (ToolStripItem) this.columnProfileToolStripMenuItem,
        (ToolStripItem) this.filterDataToolStripMenuItem,
        (ToolStripItem) this.positionTypeToolStripMenuItem,
        (ToolStripItem) this.gridToolStripMenuItem,
        (ToolStripItem) this.exportToCsvToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(155, 114);
      this.columnProfileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.changeToolStripMenuItem,
        (ToolStripItem) this.saveToolStripMenuItem
      });
      this.columnProfileToolStripMenuItem.Name = "columnProfileToolStripMenuItem";
      this.columnProfileToolStripMenuItem.Size = new Size(154, 22);
      this.columnProfileToolStripMenuItem.Text = "Column Profile";
      this.changeToolStripMenuItem.Name = "changeToolStripMenuItem";
      this.changeToolStripMenuItem.Size = new Size(115, 22);
      this.changeToolStripMenuItem.Text = "Change";
      this.changeToolStripMenuItem.Click += new EventHandler(this.changeToolStripMenuItem_Click);
      this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
      this.saveToolStripMenuItem.Size = new Size(115, 22);
      this.saveToolStripMenuItem.Text = "Save";
      this.saveToolStripMenuItem.Click += new EventHandler(this.saveToolStripMenuItem_Click);
      this.filterDataToolStripMenuItem.Name = "filterDataToolStripMenuItem";
      this.filterDataToolStripMenuItem.Size = new Size(154, 22);
      this.filterDataToolStripMenuItem.Text = "Filter Data";
      this.filterDataToolStripMenuItem.Click += new EventHandler(this.filterDataToolStripMenuItem_Click);
      this.positionTypeToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.carryForwardToolStripMenuItem,
        (ToolStripItem) this.dayToolStripMenuItem
      });
      this.positionTypeToolStripMenuItem.Name = "positionTypeToolStripMenuItem";
      this.positionTypeToolStripMenuItem.Size = new Size(154, 22);
      this.positionTypeToolStripMenuItem.Text = "Position Type";
      this.carryForwardToolStripMenuItem.Checked = true;
      this.carryForwardToolStripMenuItem.CheckOnClick = true;
      this.carryForwardToolStripMenuItem.CheckState = CheckState.Checked;
      this.carryForwardToolStripMenuItem.Name = "carryForwardToolStripMenuItem";
      this.carryForwardToolStripMenuItem.Size = new Size(145, 22);
      this.carryForwardToolStripMenuItem.Text = "CarryForward";
      this.carryForwardToolStripMenuItem.Click += new EventHandler(this.carryForwardToolStripMenuItem_Click);
      this.dayToolStripMenuItem.CheckOnClick = true;
      this.dayToolStripMenuItem.Name = "dayToolStripMenuItem";
      this.dayToolStripMenuItem.Size = new Size(145, 22);
      this.dayToolStripMenuItem.Text = "Day";
      this.dayToolStripMenuItem.Click += new EventHandler(this.dayToolStripMenuItem_Click);
      this.gridToolStripMenuItem.CheckOnClick = true;
      this.gridToolStripMenuItem.Name = "gridToolStripMenuItem";
      this.gridToolStripMenuItem.Size = new Size(154, 22);
      this.gridToolStripMenuItem.Text = "Grid";
      this.gridToolStripMenuItem.Click += new EventHandler(this.gridToolStripMenuItem_Click);
      this.exportToCsvToolStripMenuItem.Name = "exportToCsvToolStripMenuItem";
      this.exportToCsvToolStripMenuItem.Size = new Size(154, 22);
      this.exportToCsvToolStripMenuItem.Text = "Export to Csv";
      this.exportToCsvToolStripMenuItem.Click += new EventHandler(this.exportToCsvToolStripMenuItem_Click);
      this.toolStrip1.Items.AddRange(new ToolStripItem[8]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.lblName,
        (ToolStripItem) this.toolStripLabel1,
        (ToolStripItem) this.cmbExch,
        (ToolStripItem) this.toolStripLabel4,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1076, 25);
      this.toolStrip1.TabIndex = 3;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.cmbclientcode.SelectedIndexChanged += new EventHandler(this.cmbclientcode_SelectedIndexChanged);
      this.lblName.Name = "lblName";
      this.lblName.Size = new Size(0, 22);
      this.toolStripLabel1.Name = "toolStripLabel1";
      this.toolStripLabel1.Size = new Size(57, 22);
      this.toolStripLabel1.Text = "Exchange";
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(121, 25);
      this.toolStripLabel4.Name = "toolStripLabel4";
      this.toolStripLabel4.Size = new Size(47, 22);
      this.toolStripLabel4.Text = "Symbol";
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(161, 25);
      this.cmbSymbol.Sorted = true;
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1076, 339);
      this.Controls.Add((Control) this.toolStrip1);
      this.Controls.Add((Control) this.tableLayoutPanel1);
      this.Controls.Add((Control) this.dgvNetPosition);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (NetPosition);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Net Position";
      ((ISupportInitialize) this.dgvNetPosition).EndInit();
      this.tableLayoutPanel1.ResumeLayout(false);
      this.tableLayoutPanel1.PerformLayout();
      this.contextMenuStrip1.ResumeLayout(false);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
