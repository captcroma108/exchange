﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmManageContrastStatussuper
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmManageContrastStatussuper : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private RadioButton rdoNseOpt;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private GroupBox groupBox2;
    private RadioButton rdoExchBan;
    private RadioButton rdoSuspend;
    private RadioButton rdoBan;
    private RadioButton rdoActive;
    private GroupBox groupBox3;
    private RadioButton radioButton_ClientCode;
    private RadioButton radioButton_Default;
    private ComboBox cmbClientCode;
    private Button btnSave;
    private CheckBox chkAll;
    private DataGridView dgvContractStatus;
    private DataGridViewTextBoxColumn ColSymbol;
    private DataGridViewTextBoxColumn ColStatus;
    private DataGridViewCheckBoxColumn Colselect;

    public frmManageContrastStatussuper(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      this.dgvContractStatus.Rows.Clear();
      this.cmbClientCode.Items.Clear();
      if (this.objdash.objinfo.usertype == 1)
      {
        foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this.objdash._DAHierarchy)
          this.cmbClientCode.Items.Add((object) keyValuePair.Key);
        this.rdoMcx.Visible = true;
        this.rdoNseFut.Visible = true;
        this.rdoncdex.Visible = true;
        this.rdoNsecurr.Visible = true;
        this.rdoNseOpt.Visible = true;
      }
      else
      {
        if (this.objdash.objinfo.usertype != 2)
          return;
        foreach (object lstAccount in this.objdash._lstAccounts)
          this.cmbClientCode.Items.Add(lstAccount);
        foreach (object lstDealer in this.objdash._lstDealers)
          this.cmbClientCode.Items.Add(lstDealer);
        foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
        {
          switch (exchconctract.Key)
          {
            case 1:
              this.rdoMcx.Visible = true;
              break;
            case 2:
              this.rdoNseFut.Visible = true;
              break;
            case 3:
              this.rdoncdex.Visible = true;
              break;
            case 4:
              this.rdoNsecurr.Visible = true;
              break;
            case 5:
              this.rdoNseOpt.Visible = true;
              break;
          }
        }
      }
    }

    private int GetStattus()
    {
      if (this.rdoActive.Checked)
        return 1;
      if (this.rdoBan.Checked)
        return 2;
      return this.rdoSuspend.Checked ? 3 : 4;
    }

    private int Getexch()
    {
      if (this.rdoMcx.Checked)
        return 1;
      if (this.rdoNseFut.Checked)
        return 2;
      return this.rdoncdex.Checked ? 3 : 4;
    }

    private string Getclientcode()
    {
      return this.cmbClientCode.SelectedIndex > -1 ? this.cmbClientCode.Text : this.objdash.objinfo.clientcode;
    }

    private void LoadSymbols(int exch)
    {
      this.dgvContractStatus.Rows.Clear();
      List<string> stringList = new List<string>();
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
      {
        if (!stringList.Contains(keyValuePair.Value.symbol))
        {
          int index = this.dgvContractStatus.Rows.Add();
          this.dgvContractStatus.Rows[index].Cells[0].Value = (object) keyValuePair.Value.SymDesp;
          this.dgvContractStatus.Rows[index].Cells[1].Value = (object) "Active";
          this.dgvContractStatus.Rows[index].Cells[2].Value = (object) false;
          stringList.Add(keyValuePair.Value.symbol);
        }
      }
    }

    private void rdoMcx_Click(object sender, EventArgs e)
    {
      this.rdoMcx.Checked = true;
      this.rdoExchBan.Visible = false;
      this.LoadSymbols(1);
    }

    private void rdoNseFut_Click(object sender, EventArgs e)
    {
      this.rdoNseFut.Checked = true;
      this.rdoExchBan.Visible = true;
      this.LoadSymbols(2);
    }

    private void rdoncdex_Click(object sender, EventArgs e)
    {
      this.rdoncdex.Checked = true;
      this.rdoExchBan.Visible = false;
      this.LoadSymbols(3);
    }

    private void rdoNsecurr_Click(object sender, EventArgs e)
    {
      this.rdoncdex.Checked = true;
      this.rdoExchBan.Visible = false;
      this.LoadSymbols(4);
    }

    private void chkAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkAll.Checked)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvContractStatus.Rows)
          row.Cells[2].Value = (object) true;
      }
      else
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvContractStatus.Rows)
          row.Cells[2].Value = (object) false;
      }
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.radioButton_Default.Checked)
      {
        string clientcode = this.objdash.objinfo.clientcode;
        string[] strArray = this.objdash.GetClientCodes(1, clientcode).Split(',');
        int length = strArray.Length;
        int stattus = this.GetStattus();
        int exch = this.Getexch();
        string stringStatus = Utils.GetStringStatus(stattus);
        SqlConnection conn = this.objdash.getConn();
        int num = 0;
        for (int index = 0; index < length; ++index)
        {
          foreach (DataGridViewRow row in (IEnumerable) this.dgvContractStatus.Rows)
          {
            if (row.Cells[2].Value.Equals((object) true))
            {
              string symbol = row.Cells[0].Value.ToString();
              if (conn.State == ConnectionState.Open)
              {
                SqlCommand sqlCommand1 = new SqlCommand("SaveContractStatus", conn);
                sqlCommand1.CommandType = CommandType.StoredProcedure;
                using (SqlCommand sqlCommand2 = sqlCommand1)
                {
                  sqlCommand2.Parameters.AddWithValue("@clientcode", (object) clientcode);
                  sqlCommand2.Parameters.AddWithValue("@symbol", (object) symbol);
                  sqlCommand2.Parameters.AddWithValue("@status", (object) stattus);
                  sqlCommand2.Parameters.AddWithValue("@exch", (object) exch);
                  if (this.objdash.objinfo.usertype == 1)
                    sqlCommand2.Parameters.AddWithValue("@isSA", (object) 1);
                  else
                    sqlCommand2.Parameters.AddWithValue("@isSA", (object) 2);
                  try
                  {
                    sqlCommand2.ExecuteNonQuery();
                    ++num;
                    row.Cells[1].Value = (object) stringStatus;
                    this.objdash.ManageContractStatus(clientcode, symbol, stattus, exch);
                  }
                  catch
                  {
                    this.objdash.DisplayMessage("Unable to save Contract Status", 3);
                    break;
                  }
                }
              }
              else
                break;
            }
          }
          clientcode = strArray[index];
        }
        if (num > 0)
          this.objdash.DisplayMessage("Contract Status saved Successfully!!", 1);
        else
          this.objdash.DisplayMessage("Select Clientcode to save Contract Status", 2);
      }
      else if (this.cmbClientCode.SelectedIndex > 0)
      {
        string str = this.Getclientcode();
        int length = this.objdash.GetClientCodes(1, str).Split(',').Length;
        int stattus = this.GetStattus();
        int exch = this.Getexch();
        string stringStatus = Utils.GetStringStatus(stattus);
        SqlConnection conn = this.objdash.getConn();
        int num = 0;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvContractStatus.Rows)
        {
          if (row.Cells[2].Value.Equals((object) true))
          {
            string symbol = row.Cells[0].Value.ToString();
            if (conn.State == ConnectionState.Open)
            {
              SqlCommand sqlCommand1 = new SqlCommand("SaveContractStatus", conn);
              sqlCommand1.CommandType = CommandType.StoredProcedure;
              using (SqlCommand sqlCommand2 = sqlCommand1)
              {
                sqlCommand2.Parameters.AddWithValue("@clientcode", (object) str);
                sqlCommand2.Parameters.AddWithValue("@symbol", (object) symbol);
                sqlCommand2.Parameters.AddWithValue("@status", (object) stattus);
                sqlCommand2.Parameters.AddWithValue("@exch", (object) exch);
                if (this.objdash.objinfo.usertype == 1)
                  sqlCommand2.Parameters.AddWithValue("@isSA", (object) 1);
                else
                  sqlCommand2.Parameters.AddWithValue("@isSA", (object) 2);
                try
                {
                  sqlCommand2.ExecuteNonQuery();
                  ++num;
                  row.Cells[1].Value = (object) stringStatus;
                  this.objdash.ManageContractStatus(str, symbol, stattus, exch);
                }
                catch
                {
                  this.objdash.DisplayMessage("Unable to save Contract Status", 3);
                  break;
                }
              }
            }
            else
              break;
          }
        }
        if (num <= 0)
          return;
        this.objdash.DisplayMessage("Contract Status saved Successfully!!", 1);
      }
      else
        this.objdash.DisplayMessage("Select Clientcode to save Contract Status", 2);
    }

    private void radioButton_Default_Click(object sender, EventArgs e)
    {
      this.cmbClientCode.Visible = false;
      this.radioButton_ClientCode.Checked = false;
      string clientcode = this.objdash.objinfo.clientcode;
      string[] strArray = this.objdash.GetClientCodes(1, clientcode).Split(',');
      int length = strArray.Length;
      int key = this.Getexch();
      List<string> stringList = new List<string>();
      if (!this.objdash._Exchconctracts.ContainsKey(key))
        return;
      this.chkAll.Checked = false;
      this.dgvContractStatus.Rows.Clear();
      for (int index1 = 0; index1 < length; ++index1)
      {
        SortedDictionary<string, int> sortedDictionary = new SortedDictionary<string, int>();
        if (this.objdash._ClientContractStatus.ContainsKey(clientcode))
        {
          Dictionary<int, SortedDictionary<string, int>> clientContractStatu = this.objdash._ClientContractStatus[clientcode];
          if (clientContractStatu.ContainsKey(key))
            sortedDictionary = clientContractStatu[key];
        }
        foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[key])
        {
          if (!stringList.Contains(keyValuePair.Value.SymDesp))
          {
            int index2 = this.dgvContractStatus.Rows.Add();
            this.dgvContractStatus.Rows[index2].Cells[0].Value = (object) keyValuePair.Value.SymDesp;
            this.dgvContractStatus.Rows[index2].Cells[1].Value = !sortedDictionary.ContainsKey(keyValuePair.Value.SymDesp) ? (object) "Active" : (object) Utils.GetStringStatus(sortedDictionary[keyValuePair.Value.SymDesp]);
            this.dgvContractStatus.Rows[index2].Cells[2].Value = (object) false;
            stringList.Add(keyValuePair.Value.SymDesp);
          }
        }
        clientcode = strArray[index1];
      }
    }

    private void radioButton_ClientCode_Click(object sender, EventArgs e)
    {
      this.cmbClientCode.Visible = true;
      this.radioButton_Default.Checked = false;
    }

    private void cmbClientCode_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmbClientCode.SelectedIndex <= -1)
        return;
      string key1 = this.Getclientcode();
      int key2 = this.Getexch();
      List<string> stringList = new List<string>();
      if (this.objdash._Exchconctracts.ContainsKey(key2))
      {
        this.chkAll.Checked = false;
        this.dgvContractStatus.Rows.Clear();
        SortedDictionary<string, int> sortedDictionary = new SortedDictionary<string, int>();
        if (this.objdash._ClientContractStatus.ContainsKey(key1))
        {
          Dictionary<int, SortedDictionary<string, int>> clientContractStatu = this.objdash._ClientContractStatus[key1];
          if (clientContractStatu.ContainsKey(key2))
            sortedDictionary = clientContractStatu[key2];
        }
        foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[key2])
        {
          if (!stringList.Contains(keyValuePair.Value.SymDesp))
          {
            int index = this.dgvContractStatus.Rows.Add();
            this.dgvContractStatus.Rows[index].Cells[0].Value = (object) keyValuePair.Value.SymDesp;
            this.dgvContractStatus.Rows[index].Cells[1].Value = !sortedDictionary.ContainsKey(keyValuePair.Value.SymDesp) ? (object) "Active" : (object) Utils.GetStringStatus(sortedDictionary[keyValuePair.Value.SymDesp]);
            this.dgvContractStatus.Rows[index].Cells[2].Value = (object) false;
            stringList.Add(keyValuePair.Value.SymDesp);
          }
        }
      }
    }

    private void rdoExchBan_Click(object sender, EventArgs e)
    {
      Thread thread = new Thread((ThreadStart) (() => this.UploadExchBanSymbols()));
      thread.SetApartmentState(ApartmentState.STA);
      thread.Start();
    }

    private void UploadExchBanSymbols()
    {
      bool flag = true;
      OpenFileDialog openFileDialog1 = new OpenFileDialog();
      openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      openFileDialog1.Title = "Upload File";
      openFileDialog1.FilterIndex = 1;
      using (OpenFileDialog openFileDialog2 = openFileDialog1)
      {
        if (openFileDialog2.ShowDialog() == DialogResult.Cancel)
          return;
        try
        {
          string fileName = openFileDialog2.FileName;
          using (StreamReader streamReader = new StreamReader(fileName))
          {
            int length = File.ReadAllLines(fileName).Length;
            this.FlushExchangeBanSymbols();
            while (true)
            {
              string str = streamReader.ReadLine();
              if (flag)
                flag = false;
              else if (str != null)
              {
                string key = str.Split(',')[1];
                if (this.objdash._SymNameconctracts.ContainsKey(key))
                {
                  foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._SymNameconctracts[key])
                  {
                    SqlConnection conn = this.objdash.getConn();
                    if (conn.State == ConnectionState.Open)
                    {
                      SqlCommand sqlCommand1 = new SqlCommand("SaveContractStatus", conn);
                      sqlCommand1.CommandType = CommandType.StoredProcedure;
                      using (SqlCommand sqlCommand2 = sqlCommand1)
                      {
                        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.objdash.objinfo.clientcode);
                        sqlCommand2.Parameters.AddWithValue("@symbol", (object) keyValuePair.Key);
                        sqlCommand2.Parameters.AddWithValue("@status", (object) 4);
                        sqlCommand2.Parameters.AddWithValue("@exch", (object) 2);
                        try
                        {
                          sqlCommand2.ExecuteNonQuery();
                          this.objdash.ManageContractStatus(this.objdash.objinfo.clientcode, keyValuePair.Key, 4, 2);
                        }
                        catch (Exception ex)
                        {
                          this.objdash.DisplayMessage("Unable to save Contract Status", 3);
                          break;
                        }
                      }
                    }
                  }
                }
              }
              else
                break;
            }
            int num = (int) MessageBox.Show("Ban Symbol file uploaded Successfully!!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
          }
        }
        catch
        {
        }
      }
    }

    private void FlushExchangeBanSymbols()
    {
      using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where Clientcode = '" + this.objdash.objinfo.clientcode + "' and Status = 4", this.objdash.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    private void rdoNseOpt_Click(object sender, EventArgs e)
    {
      this.rdoNseOpt.Checked = true;
      this.LoadSymbols(5);
    }

    private void dgvContractStatus_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.ColumnIndex != 2)
        return;
      this.dgvContractStatus.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = !this.dgvContractStatus.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.Equals((object) true) ? (object) true : (object) false;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoNseOpt = new RadioButton();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.groupBox2 = new GroupBox();
      this.rdoExchBan = new RadioButton();
      this.rdoSuspend = new RadioButton();
      this.rdoBan = new RadioButton();
      this.rdoActive = new RadioButton();
      this.groupBox3 = new GroupBox();
      this.btnSave = new Button();
      this.cmbClientCode = new ComboBox();
      this.radioButton_ClientCode = new RadioButton();
      this.radioButton_Default = new RadioButton();
      this.chkAll = new CheckBox();
      this.dgvContractStatus = new DataGridView();
      this.ColSymbol = new DataGridViewTextBoxColumn();
      this.ColStatus = new DataGridViewTextBoxColumn();
      this.Colselect = new DataGridViewCheckBoxColumn();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      ((ISupportInitialize) this.dgvContractStatus).BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoNseOpt);
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoncdex);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(12, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(292, 63);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchanges";
      this.rdoNseOpt.AutoSize = true;
      this.rdoNseOpt.Location = new Point(6, 39);
      this.rdoNseOpt.Name = "rdoNseOpt";
      this.rdoNseOpt.Size = new Size(69, 17);
      this.rdoNseOpt.TabIndex = 8;
      this.rdoNseOpt.Text = "NSEOPT";
      this.rdoNseOpt.UseVisualStyleBackColor = true;
      this.rdoNseOpt.Visible = false;
      this.rdoNseOpt.Click += new EventHandler(this.rdoNseOpt_Click);
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(202, 16);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 7;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNsecurr.Click += new EventHandler(this.rdoNsecurr_Click);
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(134, 16);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 6;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoncdex.Visible = false;
      this.rdoncdex.Click += new EventHandler(this.rdoncdex_Click);
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(60, 16);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 5;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoNseFut.Click += new EventHandler(this.rdoNseFut_Click);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(6, 16);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 4;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.rdoMcx.Click += new EventHandler(this.rdoMcx_Click);
      this.groupBox2.Controls.Add((Control) this.rdoExchBan);
      this.groupBox2.Controls.Add((Control) this.rdoSuspend);
      this.groupBox2.Controls.Add((Control) this.rdoBan);
      this.groupBox2.Controls.Add((Control) this.rdoActive);
      this.groupBox2.Location = new Point(12, 81);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(292, 53);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Contract Status";
      this.rdoExchBan.AutoSize = true;
      this.rdoExchBan.Location = new Point(202, 23);
      this.rdoExchBan.Name = "rdoExchBan";
      this.rdoExchBan.Size = new Size(68, 17);
      this.rdoExchBan.TabIndex = 3;
      this.rdoExchBan.Text = "ExchBan";
      this.rdoExchBan.UseVisualStyleBackColor = true;
      this.rdoExchBan.Click += new EventHandler(this.rdoExchBan_Click);
      this.rdoSuspend.AutoSize = true;
      this.rdoSuspend.Location = new Point(128, 23);
      this.rdoSuspend.Name = "rdoSuspend";
      this.rdoSuspend.Size = new Size(67, 17);
      this.rdoSuspend.TabIndex = 2;
      this.rdoSuspend.Text = "Suspend";
      this.rdoSuspend.UseVisualStyleBackColor = true;
      this.rdoBan.AutoSize = true;
      this.rdoBan.Location = new Point(77, 23);
      this.rdoBan.Name = "rdoBan";
      this.rdoBan.Size = new Size(44, 17);
      this.rdoBan.TabIndex = 1;
      this.rdoBan.Text = "Ban";
      this.rdoBan.UseVisualStyleBackColor = true;
      this.rdoActive.AutoSize = true;
      this.rdoActive.Checked = true;
      this.rdoActive.Cursor = Cursors.Default;
      this.rdoActive.Location = new Point(15, 23);
      this.rdoActive.Name = "rdoActive";
      this.rdoActive.Size = new Size(55, 17);
      this.rdoActive.TabIndex = 0;
      this.rdoActive.TabStop = true;
      this.rdoActive.Text = "Active";
      this.rdoActive.UseVisualStyleBackColor = true;
      this.groupBox3.Controls.Add((Control) this.btnSave);
      this.groupBox3.Controls.Add((Control) this.cmbClientCode);
      this.groupBox3.Controls.Add((Control) this.radioButton_ClientCode);
      this.groupBox3.Controls.Add((Control) this.radioButton_Default);
      this.groupBox3.Location = new Point(12, 140);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(292, 77);
      this.groupBox3.TabIndex = 3;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "User Type Selection";
      this.btnSave.Location = new Point(109, 46);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 23);
      this.btnSave.TabIndex = 3;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.cmbClientCode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientCode.FormattingEnabled = true;
      this.cmbClientCode.Location = new Point(159, 19);
      this.cmbClientCode.Name = "cmbClientCode";
      this.cmbClientCode.Size = new Size(121, 21);
      this.cmbClientCode.TabIndex = 2;
      this.cmbClientCode.SelectedIndexChanged += new EventHandler(this.cmbClientCode_SelectedIndexChanged);
      this.radioButton_ClientCode.AutoSize = true;
      this.radioButton_ClientCode.Location = new Point(77, 19);
      this.radioButton_ClientCode.Name = "radioButton_ClientCode";
      this.radioButton_ClientCode.Size = new Size(79, 17);
      this.radioButton_ClientCode.TabIndex = 1;
      this.radioButton_ClientCode.Text = "Client Code";
      this.radioButton_ClientCode.UseVisualStyleBackColor = true;
      this.radioButton_ClientCode.Click += new EventHandler(this.radioButton_ClientCode_Click);
      this.radioButton_Default.AutoSize = true;
      this.radioButton_Default.Location = new Point(15, 19);
      this.radioButton_Default.Name = "radioButton_Default";
      this.radioButton_Default.Size = new Size(59, 17);
      this.radioButton_Default.TabIndex = 0;
      this.radioButton_Default.Text = "Default";
      this.radioButton_Default.UseVisualStyleBackColor = true;
      this.radioButton_Default.Click += new EventHandler(this.radioButton_Default_Click);
      this.chkAll.AutoSize = true;
      this.chkAll.Location = new Point((int) byte.MaxValue, 228);
      this.chkAll.Name = "chkAll";
      this.chkAll.Size = new Size(37, 17);
      this.chkAll.TabIndex = 6;
      this.chkAll.Text = "All";
      this.chkAll.UseVisualStyleBackColor = true;
      this.chkAll.CheckedChanged += new EventHandler(this.chkAll_CheckedChanged);
      this.dgvContractStatus.AllowUserToAddRows = false;
      this.dgvContractStatus.AllowUserToDeleteRows = false;
      this.dgvContractStatus.AllowUserToOrderColumns = true;
      this.dgvContractStatus.AllowUserToResizeRows = false;
      this.dgvContractStatus.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
      this.dgvContractStatus.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvContractStatus.Columns.AddRange((DataGridViewColumn) this.ColSymbol, (DataGridViewColumn) this.ColStatus, (DataGridViewColumn) this.Colselect);
      this.dgvContractStatus.Location = new Point(12, 251);
      this.dgvContractStatus.Name = "dgvContractStatus";
      this.dgvContractStatus.ReadOnly = true;
      this.dgvContractStatus.RowHeadersVisible = false;
      this.dgvContractStatus.Size = new Size(292, 252);
      this.dgvContractStatus.TabIndex = 5;
      this.dgvContractStatus.CellClick += new DataGridViewCellEventHandler(this.dgvContractStatus_CellClick);
      this.ColSymbol.HeaderText = "Symbol";
      this.ColSymbol.Name = "ColSymbol";
      this.ColSymbol.ReadOnly = true;
      this.ColSymbol.Width = 150;
      this.ColStatus.HeaderText = "Status";
      this.ColStatus.Name = "ColStatus";
      this.ColStatus.ReadOnly = true;
      this.ColStatus.Width = 80;
      this.Colselect.HeaderText = "";
      this.Colselect.Name = "Colselect";
      this.Colselect.ReadOnly = true;
      this.Colselect.Width = 50;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(316, 504);
      this.Controls.Add((Control) this.chkAll);
      this.Controls.Add((Control) this.dgvContractStatus);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.Name = nameof (frmManageContrastStatussuper);
      this.Text = nameof (frmManageContrastStatussuper);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      ((ISupportInitialize) this.dgvContractStatus).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
