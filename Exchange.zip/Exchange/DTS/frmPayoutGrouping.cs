﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmPayoutGrouping
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmPayoutGrouping : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private Label label5;
    private Label label6;
    private Label label3;
    private Label label4;
    private Label label2;
    private Label label1;
    private MaskedTextBox txtPercent6;
    private MaskedTextBox txtPercent5;
    private MaskedTextBox txtPercent4;
    private MaskedTextBox txtPercent3;
    private MaskedTextBox txtPercent2;
    private MaskedTextBox txtPercent1;
    private Button btnSave;
    private GroupBox groupBox2;
    private Label label7;
    private ComboBox cmbGroupType;
    private CheckedListBox lstMappedClients;
    private CheckBox chkMappdAll;
    private CheckBox chkAll;
    private CheckedListBox lstClients;
    private Button button1;
    private Button btnremove;
    private Button btnAdd;
    private Label label8;
    private Label label9;
    private Label label11;
    private MaskedTextBox txtRs6;
    private MaskedTextBox txtRs5;
    private MaskedTextBox txtRs4;
    private MaskedTextBox txtRs3;
    private MaskedTextBox txtRs2;
    private MaskedTextBox txtRs1;
    private Label label10;

    public frmPayoutGrouping(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      this.cmbGroupType.SelectedIndex = 0;
      this.lstClients.Items.Clear();
      foreach (string lstAccount in this.objdash._lstAccounts)
      {
        if (!this.objdash._AllGroupingCLients.Contains(lstAccount))
          this.lstClients.Items.Add((object) lstAccount);
      }
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("select * from GroupingInfo where DACode = '" + this.objdash.objinfo.clientcode + "' order by GroupName ", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(1))
            {
              string str = sqlDataReader.GetString(1).Trim();
              if (!(str == "Group1"))
              {
                if (!(str == "Group2"))
                {
                  if (!(str == "Group3"))
                  {
                    if (!(str == "Group4"))
                    {
                      if (!(str == "Group5"))
                      {
                        if (str == "Group6")
                        {
                          if (!sqlDataReader.IsDBNull(3))
                            this.txtPercent6.Text = sqlDataReader.GetInt32(3).ToString();
                          if (!sqlDataReader.IsDBNull(4))
                            this.txtRs6.Text = sqlDataReader.GetInt32(4).ToString();
                        }
                      }
                      else
                      {
                        if (!sqlDataReader.IsDBNull(3))
                          this.txtPercent5.Text = sqlDataReader.GetInt32(3).ToString();
                        if (!sqlDataReader.IsDBNull(4))
                          this.txtRs5.Text = sqlDataReader.GetInt32(4).ToString();
                      }
                    }
                    else
                    {
                      if (!sqlDataReader.IsDBNull(3))
                        this.txtPercent4.Text = sqlDataReader.GetInt32(3).ToString();
                      if (!sqlDataReader.IsDBNull(4))
                        this.txtRs4.Text = sqlDataReader.GetInt32(4).ToString();
                    }
                  }
                  else
                  {
                    if (!sqlDataReader.IsDBNull(3))
                      this.txtPercent3.Text = sqlDataReader.GetInt32(3).ToString();
                    if (!sqlDataReader.IsDBNull(4))
                      this.txtRs3.Text = sqlDataReader.GetInt32(4).ToString();
                  }
                }
                else
                {
                  if (!sqlDataReader.IsDBNull(3))
                    this.txtPercent2.Text = sqlDataReader.GetInt32(3).ToString();
                  if (!sqlDataReader.IsDBNull(4))
                    this.txtRs2.Text = sqlDataReader.GetInt32(4).ToString();
                }
              }
              else
              {
                if (!sqlDataReader.IsDBNull(3))
                  this.txtPercent1.Text = sqlDataReader.GetInt32(3).ToString();
                if (!sqlDataReader.IsDBNull(4))
                  this.txtRs1.Text = sqlDataReader.GetInt32(4).ToString();
              }
            }
          }
        }
      }
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      if (this.lstClients.CheckedItems.Count <= 0)
        return;
      ArrayList arrayList = new ArrayList();
      for (int index = 0; index < this.lstClients.Items.Count; ++index)
      {
        if (this.lstClients.GetItemCheckState(index) == CheckState.Checked)
        {
          if (!this.objdash._AllGroupingCLients.Contains(this.lstClients.Items[index].ToString()))
            this.objdash._AllGroupingCLients.Add(this.lstClients.Items[index].ToString());
          if (!this.lstMappedClients.Items.Contains((object) this.lstClients.Items[index].ToString()))
            this.lstMappedClients.Items.Add((object) this.lstClients.Items[index].ToString());
          arrayList.Add((object) this.lstClients.Items[index].ToString());
        }
      }
      foreach (object obj in arrayList)
        this.lstClients.Items.Remove((object) obj.ToString());
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      int result1 = 0;
      int result2 = 0;
      int result3 = 0;
      int result4 = 0;
      int result5 = 0;
      int result6 = 0;
      int result7 = 0;
      int result8 = 0;
      int result9 = 0;
      int result10 = 0;
      int result11 = 0;
      int result12 = 0;
      if (!int.TryParse(this.txtPercent1.Text, out result1))
        this.objdash.DisplayMessage("Enter Group1 Percent or Enter 0.", 1);
      else if (!int.TryParse(this.txtRs1.Text, out result7))
        this.objdash.DisplayMessage("Enter Group1 Rs. or Enter 0.", 1);
      else if (!int.TryParse(this.txtPercent2.Text, out result2))
        this.objdash.DisplayMessage("Enter Group2 Percent or Enter 0.", 2);
      else if (!int.TryParse(this.txtRs2.Text, out result8))
        this.objdash.DisplayMessage("Enter Group2 Rs. or Enter 0.", 2);
      else if (!int.TryParse(this.txtPercent3.Text, out result3))
        this.objdash.DisplayMessage("Enter Group3 Percent or Enter 0.", 2);
      else if (!int.TryParse(this.txtRs3.Text, out result9))
        this.objdash.DisplayMessage("Enter Group3 Rs. or Enter 0.", 2);
      else if (!int.TryParse(this.txtPercent4.Text, out result4))
        this.objdash.DisplayMessage("Enter Group4 Percent or Enter 0.", 2);
      else if (!int.TryParse(this.txtRs4.Text, out result10))
        this.objdash.DisplayMessage("Enter Group4 Rs. or Enter 0.", 2);
      else if (!int.TryParse(this.txtPercent5.Text, out result5))
        this.objdash.DisplayMessage("Enter Group5 Percent or Enter 0.", 2);
      else if (!int.TryParse(this.txtRs5.Text, out result11))
        this.objdash.DisplayMessage("Enter Group5 Rs5. or Enter 0.", 2);
      else if (!int.TryParse(this.txtPercent6.Text, out result6))
        this.objdash.DisplayMessage("Enter Group6 Percent or Enter 0.", 2);
      else if (!int.TryParse(this.txtRs6.Text, out result12))
      {
        this.objdash.DisplayMessage("Enter Group6 Rs6. or Enter 0.", 2);
      }
      else
      {
        SqlConnection conn = this.objdash.getConn();
        if (conn.State != ConnectionState.Open)
          return;
        SqlCommand sqlCommand1 = new SqlCommand("SaveGroupingInfo", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@Grp1Percent", (object) result1);
          sqlCommand2.Parameters.AddWithValue("@Grp2Percent", (object) result2);
          sqlCommand2.Parameters.AddWithValue("@Grp3Percent", (object) result3);
          sqlCommand2.Parameters.AddWithValue("@Grp4Percent", (object) result4);
          sqlCommand2.Parameters.AddWithValue("@Grp5Percent", (object) result5);
          sqlCommand2.Parameters.AddWithValue("@Grp6Percent", (object) result6);
          sqlCommand2.Parameters.AddWithValue("@Grp1Rs", (object) result7);
          sqlCommand2.Parameters.AddWithValue("@Grp2Rs", (object) result8);
          sqlCommand2.Parameters.AddWithValue("@Grp3Rs", (object) result9);
          sqlCommand2.Parameters.AddWithValue("@Grp4Rs", (object) result10);
          sqlCommand2.Parameters.AddWithValue("@Grp5Rs", (object) result11);
          sqlCommand2.Parameters.AddWithValue("@Grp6Rs", (object) result12);
          sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.objdash.objinfo.clientcode);
          try
          {
            sqlCommand2.ExecuteNonQuery();
            this.objdash.DisplayMessage("Groupwise % saved Successfully!!", 1);
          }
          catch
          {
            this.objdash.DisplayMessage("Unable to save Groupwise %.", 3);
          }
        }
      }
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.lstMappedClients.Items.Clear();
      if (!this.objdash._GroupwiseClientList.ContainsKey(this.cmbGroupType.Text))
        return;
      foreach (object obj in this.objdash._GroupwiseClientList[this.cmbGroupType.Text])
        this.lstMappedClients.Items.Add(obj);
    }

    private void chkAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkAll.Checked)
      {
        for (int index = 0; index < this.lstClients.Items.Count; ++index)
          this.lstClients.SetItemChecked(index, true);
      }
      else
      {
        for (int index = 0; index < this.lstClients.Items.Count; ++index)
          this.lstClients.SetItemChecked(index, false);
      }
    }

    private void chkMappdAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkMappdAll.Checked)
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          this.lstMappedClients.SetItemChecked(index, true);
      }
      else
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          this.lstMappedClients.SetItemChecked(index, false);
      }
    }

    private void btnremove_Click(object sender, EventArgs e)
    {
      if (this.chkMappdAll.Checked)
      {
        this.lstMappedClients.Items.Clear();
        this.chkMappdAll.Checked = false;
      }
      else
      {
        ArrayList arrayList = new ArrayList();
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
        {
          if (this.lstMappedClients.GetItemCheckState(index) == CheckState.Checked)
          {
            this.lstClients.Items.Add((object) this.lstMappedClients.Items[index].ToString());
            arrayList.Add((object) this.lstMappedClients.Items[index].ToString());
            if (this.objdash._AllGroupingCLients.Contains(this.lstMappedClients.Items[index].ToString()))
              this.objdash._AllGroupingCLients.Remove(this.lstMappedClients.Items[index].ToString());
          }
        }
        foreach (object obj in arrayList)
          this.lstMappedClients.Items.Remove((object) obj.ToString());
      }
    }

    private void button1_Click(object sender, EventArgs e)
    {
      if (this.cmbGroupType.SelectedIndex <= 0)
      {
        this.objdash.DisplayMessage("Select Group Type.", 2);
      }
      else
      {
        SqlConnection conn = this.objdash.getConn();
        if (conn.State != ConnectionState.Open || !this.DeleteGroupData(this.cmbGroupType.Text, conn))
          return;
        List<string> stringList = new List<string>();
        if (this.lstMappedClients.Items.Count > 0)
        {
          for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          {
            SqlCommand sqlCommand1 = new SqlCommand("SaveUserwiseGrouping", conn);
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            using (SqlCommand sqlCommand2 = sqlCommand1)
            {
              sqlCommand2.Parameters.AddWithValue("@grouptype", (object) this.cmbGroupType.Text);
              sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.lstMappedClients.Items[index].ToString());
              sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.objdash.objinfo.clientcode);
              try
              {
                sqlCommand2.ExecuteNonQuery();
                if (!stringList.Contains(this.lstMappedClients.Items[index].ToString()))
                  stringList.Add(this.lstMappedClients.Items[index].ToString());
              }
              catch
              {
              }
            }
          }
        }
        if (this.objdash._GroupwiseClientList.ContainsKey(this.cmbGroupType.Text))
          this.objdash._GroupwiseClientList[this.cmbGroupType.Text] = stringList;
        else
          this.objdash._GroupwiseClientList.Add(this.cmbGroupType.Text, stringList);
        this.RefreshGroupingList();
        this.objdash.DisplayMessage("Account Grouped Successfully!!", 1);
      }
    }

    private void RefreshGroupingList()
    {
      this.objdash._AllGroupingCLients.Clear();
      foreach (KeyValuePair<string, List<string>> groupwiseClient in this.objdash._GroupwiseClientList)
      {
        foreach (string str in groupwiseClient.Value)
        {
          if (!this.objdash._AllGroupingCLients.Contains(str))
            this.objdash._AllGroupingCLients.Add(str);
        }
      }
    }

    private bool DeleteGroupData(string groupname, SqlConnection conn)
    {
      using (SqlCommand sqlCommand = new SqlCommand("Delete from PayIN_OUTGrouping where GroupType = '" + groupname + "' and DACode = '" + this.objdash.objinfo.clientcode + "'", conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.label11 = new Label();
      this.txtRs6 = new MaskedTextBox();
      this.txtRs5 = new MaskedTextBox();
      this.txtRs4 = new MaskedTextBox();
      this.txtRs3 = new MaskedTextBox();
      this.txtRs2 = new MaskedTextBox();
      this.txtRs1 = new MaskedTextBox();
      this.label10 = new Label();
      this.btnSave = new Button();
      this.txtPercent6 = new MaskedTextBox();
      this.txtPercent5 = new MaskedTextBox();
      this.txtPercent4 = new MaskedTextBox();
      this.txtPercent3 = new MaskedTextBox();
      this.txtPercent2 = new MaskedTextBox();
      this.txtPercent1 = new MaskedTextBox();
      this.label5 = new Label();
      this.label6 = new Label();
      this.label3 = new Label();
      this.label4 = new Label();
      this.label2 = new Label();
      this.label1 = new Label();
      this.groupBox2 = new GroupBox();
      this.lstMappedClients = new CheckedListBox();
      this.chkMappdAll = new CheckBox();
      this.chkAll = new CheckBox();
      this.lstClients = new CheckedListBox();
      this.button1 = new Button();
      this.btnremove = new Button();
      this.btnAdd = new Button();
      this.label8 = new Label();
      this.label9 = new Label();
      this.cmbGroupType = new ComboBox();
      this.label7 = new Label();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.label11);
      this.groupBox1.Controls.Add((Control) this.txtRs6);
      this.groupBox1.Controls.Add((Control) this.txtRs5);
      this.groupBox1.Controls.Add((Control) this.txtRs4);
      this.groupBox1.Controls.Add((Control) this.txtRs3);
      this.groupBox1.Controls.Add((Control) this.txtRs2);
      this.groupBox1.Controls.Add((Control) this.txtRs1);
      this.groupBox1.Controls.Add((Control) this.label10);
      this.groupBox1.Controls.Add((Control) this.btnSave);
      this.groupBox1.Controls.Add((Control) this.txtPercent6);
      this.groupBox1.Controls.Add((Control) this.txtPercent5);
      this.groupBox1.Controls.Add((Control) this.txtPercent4);
      this.groupBox1.Controls.Add((Control) this.txtPercent3);
      this.groupBox1.Controls.Add((Control) this.txtPercent2);
      this.groupBox1.Controls.Add((Control) this.txtPercent1);
      this.groupBox1.Controls.Add((Control) this.label5);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(12, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(210, 461);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Groupwise % & Rs.";
      this.label11.AutoSize = true;
      this.label11.Location = new Point(132, 13);
      this.label11.Name = "label11";
      this.label11.Size = new Size(23, 13);
      this.label11.TabIndex = 29;
      this.label11.Text = "Rs.";
      this.txtRs6.Location = new Point(122, 186);
      this.txtRs6.Mask = "00000000";
      this.txtRs6.Name = "txtRs6";
      this.txtRs6.Size = new Size(70, 20);
      this.txtRs6.TabIndex = 11;
      this.txtRs6.Text = "0";
      this.txtRs5.Location = new Point(122, 155);
      this.txtRs5.Mask = "00000000";
      this.txtRs5.Name = "txtRs5";
      this.txtRs5.Size = new Size(70, 20);
      this.txtRs5.TabIndex = 9;
      this.txtRs5.Text = "0";
      this.txtRs4.Location = new Point(122, 122);
      this.txtRs4.Mask = "00000000";
      this.txtRs4.Name = "txtRs4";
      this.txtRs4.Size = new Size(70, 20);
      this.txtRs4.TabIndex = 7;
      this.txtRs4.Text = "0";
      this.txtRs3.Location = new Point(122, 91);
      this.txtRs3.Mask = "00000000";
      this.txtRs3.Name = "txtRs3";
      this.txtRs3.Size = new Size(70, 20);
      this.txtRs3.TabIndex = 5;
      this.txtRs3.Text = "0";
      this.txtRs2.Location = new Point(122, 60);
      this.txtRs2.Mask = "00000000";
      this.txtRs2.Name = "txtRs2";
      this.txtRs2.Size = new Size(70, 20);
      this.txtRs2.TabIndex = 3;
      this.txtRs2.Text = "0";
      this.txtRs1.Location = new Point(122, 29);
      this.txtRs1.Mask = "00000000";
      this.txtRs1.Name = "txtRs1";
      this.txtRs1.Size = new Size(70, 20);
      this.txtRs1.TabIndex = 1;
      this.txtRs1.Text = "0";
      this.label10.AutoSize = true;
      this.label10.Location = new Point(79, 13);
      this.label10.Name = "label10";
      this.label10.Size = new Size(15, 13);
      this.label10.TabIndex = 22;
      this.label10.Text = "%";
      this.btnSave.Location = new Point(68, 244);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 30);
      this.btnSave.TabIndex = 12;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.txtPercent6.Location = new Point(69, 186);
      this.txtPercent6.Mask = "00";
      this.txtPercent6.Name = "txtPercent6";
      this.txtPercent6.Size = new Size(39, 20);
      this.txtPercent6.TabIndex = 10;
      this.txtPercent6.Text = "0";
      this.txtPercent5.Location = new Point(69, 155);
      this.txtPercent5.Mask = "00";
      this.txtPercent5.Name = "txtPercent5";
      this.txtPercent5.Size = new Size(39, 20);
      this.txtPercent5.TabIndex = 8;
      this.txtPercent5.Text = "0";
      this.txtPercent4.Location = new Point(69, 122);
      this.txtPercent4.Mask = "00";
      this.txtPercent4.Name = "txtPercent4";
      this.txtPercent4.Size = new Size(39, 20);
      this.txtPercent4.TabIndex = 6;
      this.txtPercent4.Text = "0";
      this.txtPercent3.Location = new Point(69, 91);
      this.txtPercent3.Mask = "00";
      this.txtPercent3.Name = "txtPercent3";
      this.txtPercent3.Size = new Size(39, 20);
      this.txtPercent3.TabIndex = 4;
      this.txtPercent3.Text = "0";
      this.txtPercent2.Location = new Point(69, 60);
      this.txtPercent2.Mask = "00";
      this.txtPercent2.Name = "txtPercent2";
      this.txtPercent2.Size = new Size(39, 20);
      this.txtPercent2.TabIndex = 2;
      this.txtPercent2.Text = "0";
      this.txtPercent1.Location = new Point(69, 29);
      this.txtPercent1.Mask = "00";
      this.txtPercent1.Name = "txtPercent1";
      this.txtPercent1.Size = new Size(39, 20);
      this.txtPercent1.TabIndex = 0;
      this.txtPercent1.Text = "0";
      this.label5.AutoSize = true;
      this.label5.Location = new Point(18, 189);
      this.label5.Name = "label5";
      this.label5.Size = new Size(45, 13);
      this.label5.TabIndex = 6;
      this.label5.Text = "Group6:";
      this.label6.AutoSize = true;
      this.label6.Location = new Point(18, 158);
      this.label6.Name = "label6";
      this.label6.Size = new Size(45, 13);
      this.label6.TabIndex = 9;
      this.label6.Text = "Group5:";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(18, 125);
      this.label3.Name = "label3";
      this.label3.Size = new Size(45, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Group4:";
      this.label4.AutoSize = true;
      this.label4.Location = new Point(18, 94);
      this.label4.Name = "label4";
      this.label4.Size = new Size(45, 13);
      this.label4.TabIndex = 3;
      this.label4.Text = "Group3:";
      this.label2.AutoSize = true;
      this.label2.Location = new Point(18, 63);
      this.label2.Name = "label2";
      this.label2.Size = new Size(45, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Group2:";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(18, 32);
      this.label1.Name = "label1";
      this.label1.Size = new Size(45, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "Group1:";
      this.groupBox2.Controls.Add((Control) this.lstMappedClients);
      this.groupBox2.Controls.Add((Control) this.chkMappdAll);
      this.groupBox2.Controls.Add((Control) this.chkAll);
      this.groupBox2.Controls.Add((Control) this.lstClients);
      this.groupBox2.Controls.Add((Control) this.button1);
      this.groupBox2.Controls.Add((Control) this.btnremove);
      this.groupBox2.Controls.Add((Control) this.btnAdd);
      this.groupBox2.Controls.Add((Control) this.label8);
      this.groupBox2.Controls.Add((Control) this.label9);
      this.groupBox2.Controls.Add((Control) this.cmbGroupType);
      this.groupBox2.Controls.Add((Control) this.label7);
      this.groupBox2.Location = new Point(228, 12);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(345, 461);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Map Clients";
      this.lstMappedClients.CheckOnClick = true;
      this.lstMappedClients.FormattingEnabled = true;
      this.lstMappedClients.Location = new Point(210, 84);
      this.lstMappedClients.Name = "lstMappedClients";
      this.lstMappedClients.Size = new Size(120, 334);
      this.lstMappedClients.Sorted = true;
      this.lstMappedClients.TabIndex = 4;
      this.chkMappdAll.AutoSize = true;
      this.chkMappdAll.Location = new Point(212, 67);
      this.chkMappdAll.Name = "chkMappdAll";
      this.chkMappdAll.Size = new Size(45, 17);
      this.chkMappdAll.TabIndex = 20;
      this.chkMappdAll.Text = "ALL";
      this.chkMappdAll.UseVisualStyleBackColor = true;
      this.chkMappdAll.CheckedChanged += new EventHandler(this.chkMappdAll_CheckedChanged);
      this.chkAll.AutoSize = true;
      this.chkAll.Location = new Point(15, 66);
      this.chkAll.Name = "chkAll";
      this.chkAll.Size = new Size(45, 17);
      this.chkAll.TabIndex = 19;
      this.chkAll.Text = "ALL";
      this.chkAll.UseVisualStyleBackColor = true;
      this.chkAll.CheckedChanged += new EventHandler(this.chkAll_CheckedChanged);
      this.lstClients.CheckOnClick = true;
      this.lstClients.FormattingEnabled = true;
      this.lstClients.Location = new Point(12, 84);
      this.lstClients.Name = "lstClients";
      this.lstClients.Size = new Size(120, 334);
      this.lstClients.Sorted = true;
      this.lstClients.TabIndex = 1;
      this.button1.Location = new Point(136, 426);
      this.button1.Name = "button1";
      this.button1.Size = new Size(75, 30);
      this.button1.TabIndex = 5;
      this.button1.Text = "Save";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.btnremove.Location = new Point(146, 295);
      this.btnremove.Name = "btnremove";
      this.btnremove.Size = new Size(43, 44);
      this.btnremove.TabIndex = 3;
      this.btnremove.Text = "<<";
      this.btnremove.UseVisualStyleBackColor = true;
      this.btnremove.Click += new EventHandler(this.btnremove_Click);
      this.btnAdd.Location = new Point(146, 147);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new Size(43, 44);
      this.btnAdd.TabIndex = 2;
      this.btnAdd.Text = ">>";
      this.btnAdd.UseVisualStyleBackColor = true;
      this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
      this.label8.AutoSize = true;
      this.label8.Location = new Point((int) byte.MaxValue, 68);
      this.label8.Name = "label8";
      this.label8.Size = new Size(83, 13);
      this.label8.TabIndex = 14;
      this.label8.Text = "Mapped Clients:";
      this.label9.AutoSize = true;
      this.label9.Location = new Point(62, 68);
      this.label9.Name = "label9";
      this.label9.Size = new Size(70, 13);
      this.label9.TabIndex = 13;
      this.label9.Text = "No of Clients:";
      this.cmbGroupType.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbGroupType.FormattingEnabled = true;
      this.cmbGroupType.Items.AddRange(new object[7]
      {
        (object) "--Select--",
        (object) "Group1",
        (object) "Group2",
        (object) "Group3",
        (object) "Group4",
        (object) "Group5",
        (object) "Group6"
      });
      this.cmbGroupType.Location = new Point(12, 39);
      this.cmbGroupType.Name = "cmbGroupType";
      this.cmbGroupType.Size = new Size(120, 21);
      this.cmbGroupType.TabIndex = 0;
      this.cmbGroupType.SelectedIndexChanged += new EventHandler(this.comboBox1_SelectedIndexChanged);
      this.label7.AutoSize = true;
      this.label7.Location = new Point(12, 23);
      this.label7.Name = "label7";
      this.label7.Size = new Size(72, 13);
      this.label7.TabIndex = 0;
      this.label7.Text = "Select Group:";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(577, 485);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmPayoutGrouping);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Payin/Payout Grouping";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
