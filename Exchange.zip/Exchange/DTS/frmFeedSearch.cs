﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmFeedSearch
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmFeedSearch : Form
  {
    private IContainer components = (IContainer) null;
    public BuySellOrder objbuysell;
    private Dashboard objdash;
    private ComboBox cmbSymbol;
    private Label label1;
    private TextBox txtBid;
    private Label label2;
    private Label label3;
    private TextBox txtAsk;
    private Label label4;
    private TextBox txtLTP;

    public frmFeedSearch(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadWindow()
    {
      this.txtAsk.Text = this.txtBid.Text = this.txtLTP.Text = string.Empty;
      this.cmbSymbol.Items.Clear();
      foreach (KeyValuePair<string, Contracts> symconctract in this.objdash._Symconctracts)
        this.cmbSymbol.Items.Add((object) symconctract.Key);
    }

    private void cmbSymbol_Leave(object sender, EventArgs e)
    {
      if (!this.objdash._SymFeeds.ContainsKey(this.cmbSymbol.Text))
        return;
      Feeds symFeed = this.objdash._SymFeeds[this.cmbSymbol.Text];
      this.txtBid.Text = symFeed.bid.ToString();
      this.txtAsk.Text = symFeed.ask.ToString();
      this.txtLTP.Text = symFeed.ltp.ToString();
    }

    private void cmbSymbol_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (!this.objdash._SymFeeds.ContainsKey(this.cmbSymbol.Text))
        return;
      Feeds symFeed = this.objdash._SymFeeds[this.cmbSymbol.Text];
      this.txtBid.Text = symFeed.bid.ToString();
      this.txtAsk.Text = symFeed.ask.ToString();
      this.txtLTP.Text = symFeed.ltp.ToString();
    }

    private void frmFeedSearch_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.F1 | e.KeyCode == Keys.Oemplus | e.KeyCode == Keys.Add)
      {
        if (this.cmbSymbol == null || !this.objdash._Symconctracts.ContainsKey(this.cmbSymbol.Text) || this.txtAsk.Text == string.Empty)
          return;
        Contracts contract = this.objdash.GetContract(this.cmbSymbol.Text);
        string exch = Utils.GetExch(contract.exch);
        string symDesp = contract.SymDesp;
        Decimal price = Convert.ToDecimal(this.txtAsk.Text);
        if (this.objbuysell == null || this.objbuysell.IsDisposed)
        {
          BuySellOrder buySellOrder = new BuySellOrder(this.objdash);
          buySellOrder.MdiParent = (Form) this.objdash;
          this.objbuysell = buySellOrder;
        }
        this.objbuysell.LoadWindow(1, exch, symDesp, price, false, 0, Decimal.Zero, 0, string.Empty, 0);
        this.objbuysell.Location = new Point(0, !(this.objdash.objinfo.usertype == 3 | this.objdash.objinfo.usertype == 4) ? this.objdash.Height - 330 : this.objdash.Height - 380);
        this.objbuysell.BringToFront();
        this.objbuysell.Show();
      }
      else
      {
        if (!(e.KeyCode == Keys.F2 | e.KeyCode == Keys.OemMinus | e.KeyCode == Keys.Subtract) || (this.cmbSymbol == null || !this.objdash._Symconctracts.ContainsKey(this.cmbSymbol.Text) || this.txtBid.Text == string.Empty))
          return;
        Contracts contract = this.objdash.GetContract(this.cmbSymbol.Text);
        string exch = Utils.GetExch(contract.exch);
        string symDesp = contract.SymDesp;
        Decimal price = Convert.ToDecimal(this.txtBid.Text);
        if (this.objbuysell == null || this.objbuysell.IsDisposed)
        {
          BuySellOrder buySellOrder = new BuySellOrder(this.objdash);
          buySellOrder.MdiParent = (Form) this.objdash;
          this.objbuysell = buySellOrder;
        }
        this.objbuysell.LoadWindow(2, exch, symDesp, price, false, 0, Decimal.Zero, 0, string.Empty, 0);
        this.objbuysell.Location = new Point(0, !(this.objdash.objinfo.usertype == 3 | this.objdash.objinfo.usertype == 4) ? this.objdash.Height - 330 : this.objdash.Height - 380);
        this.objbuysell.BringToFront();
        this.objbuysell.Show();
      }
    }

    private void cmbSymbol_KeyDown(object sender, KeyEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.cmbSymbol = new ComboBox();
      this.label1 = new Label();
      this.txtBid = new TextBox();
      this.label2 = new Label();
      this.label3 = new Label();
      this.txtAsk = new TextBox();
      this.label4 = new Label();
      this.txtLTP = new TextBox();
      this.SuspendLayout();
      this.cmbSymbol.FormattingEnabled = true;
      this.cmbSymbol.Location = new Point(19, 41);
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(179, 21);
      this.cmbSymbol.Sorted = true;
      this.cmbSymbol.TabIndex = 0;
      this.cmbSymbol.SelectedIndexChanged += new EventHandler(this.cmbSymbol_SelectedIndexChanged);
      this.cmbSymbol.KeyDown += new KeyEventHandler(this.cmbSymbol_KeyDown);
      this.cmbSymbol.Leave += new EventHandler(this.cmbSymbol_Leave);
      this.label1.AutoSize = true;
      this.label1.Location = new Point(24, 25);
      this.label1.Name = "label1";
      this.label1.Size = new Size(41, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "Symbol";
      this.txtBid.Enabled = false;
      this.txtBid.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.txtBid.Location = new Point(219, 41);
      this.txtBid.Name = "txtBid";
      this.txtBid.Size = new Size(75, 21);
      this.txtBid.TabIndex = 2;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(216, 25);
      this.label2.Name = "label2";
      this.label2.Size = new Size(22, 13);
      this.label2.TabIndex = 3;
      this.label2.Text = "Bid";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(312, 25);
      this.label3.Name = "label3";
      this.label3.Size = new Size(25, 13);
      this.label3.TabIndex = 5;
      this.label3.Text = "Ask";
      this.txtAsk.Enabled = false;
      this.txtAsk.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.txtAsk.Location = new Point(314, 41);
      this.txtAsk.Name = "txtAsk";
      this.txtAsk.Size = new Size(75, 21);
      this.txtAsk.TabIndex = 4;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(406, 25);
      this.label4.Name = "label4";
      this.label4.Size = new Size(27, 13);
      this.label4.TabIndex = 7;
      this.label4.Text = "LTP";
      this.txtLTP.Enabled = false;
      this.txtLTP.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.txtLTP.Location = new Point(409, 41);
      this.txtLTP.Name = "txtLTP";
      this.txtLTP.Size = new Size(75, 21);
      this.txtLTP.TabIndex = 6;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(502, 86);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.txtLTP);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.txtAsk);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.txtBid);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.cmbSymbol);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.Name = nameof (frmFeedSearch);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Symbol Search";
      this.KeyUp += new KeyEventHandler(this.frmFeedSearch_KeyUp);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
