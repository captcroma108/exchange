﻿// Decompiled with JetBrains decompiler
// Type: DTS.Limits
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Data;
using System.Data.SqlClient;

namespace DTS
{
  public class Limits
  {
    public string clientcode { get; set; }

    public Decimal cashmrgn { get; set; }

    public Decimal turnoverlimit { get; set; }

    public Decimal mtmlosslimit { get; set; }

    public int turnmulti { get; set; }

    public int mtmmulti { get; set; }

    public int breakup { get; set; }

    public int brkgtype { get; set; }

    public Decimal mcxIntrdybrkg { get; set; }

    public Decimal nsefutIntrdybrkg { get; set; }

    public Decimal ncdexIntrdybrkg { get; set; }

    public Decimal nsecurrIntrdybrkg { get; set; }

    public Decimal nseoptIntrdybrkg { get; set; }

    public Decimal mcxCnfbrkg { get; set; }

    public Decimal nsefutCnfbrkg { get; set; }

    public Decimal ncdexCnfbrkg { get; set; }

    public Decimal nsecurrCnfbrkg { get; set; }

    public Decimal nseoptCnfbrkg { get; set; }

    public int tradeattributes { get; set; }

    public int mrgntype { get; set; }

    public int isIntrasqoff { get; set; }

    public int IsMrgnsqoff { get; set; }

    public DateTime timestamp { get; set; }

    public int lotwisetype { get; set; }

    public int mcxlots { get; set; }

    public int ncxlots { get; set; }

    public int nsefutlots { get; set; }

    public int nsecurlots { get; set; }

    public string possitionValidity { get; set; }

    public string Productype { get; set; }

    public int McxBrkup { get; set; }

    public int NsefutBrkup { get; set; }

    public int NcdexBrkup { get; set; }

    public int NsecurBrkup { get; set; }

    public int PendingOrderExec { get; set; }

    public int brkupType { get; set; }

    public static int SaveLimits(SqlConnection conn, Limits objlimits)
    {
      SqlCommand sqlCommand1 = new SqlCommand(nameof (SaveLimits), conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objlimits.clientcode);
        sqlCommand2.Parameters.AddWithValue("@cashmrgn", (object) objlimits.cashmrgn);
        sqlCommand2.Parameters.AddWithValue("@turnoverlimit", (object) objlimits.turnoverlimit);
        sqlCommand2.Parameters.AddWithValue("@mtmlosslimit", (object) objlimits.mtmlosslimit);
        sqlCommand2.Parameters.AddWithValue("@turnmulti", (object) objlimits.turnmulti);
        sqlCommand2.Parameters.AddWithValue("@mtmmulti", (object) objlimits.mtmmulti);
        sqlCommand2.Parameters.AddWithValue("@breakup", (object) objlimits.breakup);
        sqlCommand2.Parameters.AddWithValue("@brkgtype", (object) objlimits.brkgtype);
        sqlCommand2.Parameters.AddWithValue("@mcxbrkg", (object) objlimits.mcxIntrdybrkg);
        sqlCommand2.Parameters.AddWithValue("@nsefutbrkg", (object) objlimits.nsefutIntrdybrkg);
        sqlCommand2.Parameters.AddWithValue("@ncdexbrkg", (object) objlimits.ncdexIntrdybrkg);
        sqlCommand2.Parameters.AddWithValue("@nsecurrbrkg", (object) objlimits.nsecurrIntrdybrkg);
        sqlCommand2.Parameters.AddWithValue("@mcxCNFbrkg", (object) objlimits.mcxCnfbrkg);
        sqlCommand2.Parameters.AddWithValue("@nsefutCNFbrkg", (object) objlimits.nsefutCnfbrkg);
        sqlCommand2.Parameters.AddWithValue("@ncdexCNFbrkg", (object) objlimits.ncdexCnfbrkg);
        sqlCommand2.Parameters.AddWithValue("@nsecurrCNFbrkg", (object) objlimits.nsecurrCnfbrkg);
        sqlCommand2.Parameters.AddWithValue("@tradeatt", (object) objlimits.tradeattributes);
        sqlCommand2.Parameters.AddWithValue("@mrgntype", (object) objlimits.mrgntype);
        sqlCommand2.Parameters.AddWithValue("@isintrasqoff", (object) objlimits.isIntrasqoff);
        sqlCommand2.Parameters.AddWithValue("@ismrgnsqoff", (object) objlimits.IsMrgnsqoff);
        sqlCommand2.Parameters.AddWithValue("@lotwisetype", (object) objlimits.lotwisetype);
        sqlCommand2.Parameters.AddWithValue("@mcxlots", (object) objlimits.mcxlots);
        sqlCommand2.Parameters.AddWithValue("@ncxlots", (object) objlimits.ncxlots);
        sqlCommand2.Parameters.AddWithValue("@nsefutlots", (object) objlimits.nsefutlots);
        sqlCommand2.Parameters.AddWithValue("@nsecurlots", (object) objlimits.nsecurlots);
        sqlCommand2.Parameters.AddWithValue("@validity", (object) objlimits.possitionValidity);
        sqlCommand2.Parameters.AddWithValue("@producttype", (object) objlimits.Productype);
        sqlCommand2.Parameters.AddWithValue("@mcxbrkup", (object) objlimits.McxBrkup);
        sqlCommand2.Parameters.AddWithValue("@nsefutbrkup", (object) objlimits.NsefutBrkup);
        sqlCommand2.Parameters.AddWithValue("@ncdexbrkup", (object) objlimits.NcdexBrkup);
        sqlCommand2.Parameters.AddWithValue("@nsecurbrkup", (object) objlimits.NsecurBrkup);
        sqlCommand2.Parameters.AddWithValue("@pendingexecon", (object) objlimits.PendingOrderExec);
        sqlCommand2.Parameters.AddWithValue("@breakuptype", (object) objlimits.brkupType);
        return sqlCommand2.ExecuteNonQuery();
      }
    }

    public static bool UpdateLeverage(string clientcode, string leverage, SqlConnection conn)
    {
      if (conn == null || conn.State != ConnectionState.Open)
        return false;
      using (SqlCommand sqlCommand = new SqlCommand("Update Limitset SET Leverage = '" + leverage + "' where clientcode = '" + clientcode + "'", conn))
      {
        try
        {
          return sqlCommand.ExecuteNonQuery() > 0;
        }
        catch
        {
          return false;
        }
      }
    }
  }
}
