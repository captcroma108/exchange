﻿// Decompiled with JetBrains decompiler
// Type: DTS.BrkgType
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System.Data;
using System.Data.SqlClient;

namespace DTS
{
  public class BrkgType
  {
    public string clientCode { get; set; }

    public int mcx { get; set; }

    public int nsefut { get; set; }

    public int ncdex { get; set; }

    public int nsecurr { get; set; }

    public static bool SaveBrkgType(SqlConnection conn, BrkgType _data)
    {
      if (conn == null || conn.State != ConnectionState.Open)
        return false;
      SqlCommand sqlCommand1 = new SqlCommand(nameof (SaveBrkgType), conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) _data.clientCode);
        sqlCommand2.Parameters.AddWithValue("@mcxtype", (object) _data.mcx);
        sqlCommand2.Parameters.AddWithValue("@nsefuttype", (object) _data.nsefut);
        sqlCommand2.Parameters.AddWithValue("@nsecurtype", (object) _data.nsecurr);
        sqlCommand2.Parameters.AddWithValue("@ncdextype", (object) _data.ncdex);
        try
        {
          return sqlCommand2.ExecuteNonQuery() > 0;
        }
        catch
        {
          return false;
        }
      }
    }
  }
}
