﻿// Decompiled with JetBrains decompiler
// Type: DTS.OpenPosition
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class OpenPosition : Form
  {
    public Dictionary<string, int> _OpenPosList = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public Thread cThread;
    private DataGridView dgvOpenPos;
    private DataGridViewTextBoxColumn Regulationcode;
    private DataGridViewTextBoxColumn Exchange;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn BuySell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn AvgPrice;
    private DataGridViewCheckBoxColumn ColSelect;

    public OpenPosition(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    private void dgvOpenPos_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right || this.dgvOpenPos.Rows.Count <= 0)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Close Position", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Close All Positions", (Image) null, new EventHandler(this.Task2_Click));
      contextMenuStrip.Items.Add("Close N Reverse Position", (Image) null, new EventHandler(this.Task7_Click));
      contextMenuStrip.Items.Add("Close N Reverse ALL Position", (Image) null, new EventHandler(this.Task3_Click));
      contextMenuStrip.Items.Add("Close Selected Positions", (Image) null, new EventHandler(this.Task8_Click));
      contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task4_Click));
      contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task5_Click));
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task6_Click));
      Point client = this.dgvOpenPos.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvOpenPos, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      DataGridView dgvOpenPos = this.dgvOpenPos;
      if (dgvOpenPos != null && this.dgvOpenPos.Rows.Count > 0)
      {
        try
        {
          if (MessageBox.Show("Do you really want to Close This Position?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
            return;
          int index = dgvOpenPos.CurrentRow.Index;
          string account = this.dgvOpenPos.Rows[index].Cells[0].Value.ToString();
          string exch = this.dgvOpenPos.Rows[index].Cells[1].Value.ToString();
          string symbol = this.dgvOpenPos.Rows[index].Cells[2].Value.ToString();
          int validity = (int) Enum.Parse(typeof (ValidityType), this.dgvOpenPos.Rows[index].Cells[3].Value.ToString().ToUpper());
          int buysell = !(this.dgvOpenPos.Rows[index].Cells[4].Value.ToString() == "B") ? 1 : 2;
          int int32 = Convert.ToInt32(this.dgvOpenPos.Rows[index].Cells[5].Value);
          DateTime dtnow = new DateTime();
          if (!this.objmain.ValidateMarketTime(exch, ref dtnow))
          {
            this.objmain.DisplayMessage(string.Format(" {0} Market is closed!!", (object) exch), 2);
            this.objmain.insertSurveillanceMessages(account, string.Format(" {0} Market is closed!!", (object) exch), dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
          }
          else if (!this.ClosePositions(account, symbol, validity, buysell, int32, false, Utils.GetIntExch(exch)))
            ;
        }
        catch
        {
          this.objmain.DisplayMessage("Unable to Close Position", 3);
        }
      }
      else
        this.objmain.DisplayMessage("No Position to Close", 2);
    }

    private bool ClosePositions(
      string account,
      string symbol,
      int validity,
      int buysell,
      int qty,
      bool isreverse,
      int exchh)
    {
      bool flag = false;
      string empty = string.Empty;
      if (this.objmain._Symconctracts.ContainsKey(symbol))
      {
        Contracts symconctract = this.objmain._Symconctracts[symbol];
        DateTime serverTime = this.objmain.GetServerTime();
        string symbol1 = symconctract.SymDesp;
        if (symconctract.symbol == "GOLDMM")
          symbol1 = symbol1.Replace("GOLDMM", "GOLD");
        else if (symconctract.symbol == "SILVERMM")
          symbol1 = symbol1.Replace("SILVERMM", "SILVER");
        Feeds feed = this.objmain.getFeed(symbol1);
        Trades trades = new Trades()
        {
          exch = exchh,
          Symbol = symbol,
          validity = validity,
          userremarks = string.Empty,
          producttype = 1,
          qty = qty,
          orderno = Trades.OrderNoGenerate(),
          clientcode = account,
          traderid = account,
          Createon = serverTime,
          Lastmodified = serverTime,
          ordstatus = 1,
          buysell = buysell
        };
        if (buysell == 1)
        {
          trades.price = feed.ask;
          trades.Ordprice = feed.ask;
        }
        else
        {
          trades.price = feed.bid;
          trades.Ordprice = feed.bid;
        }
        if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.SaveOrder(trades, this.objmain.getConn()) && Trades.SaveTrade(trades, this.objmain.getConn()))
        {
          flag = true;
          this.objmain.DisplayConfirmationMsg(trades);
        }
        if (isreverse && (trades.qty > 0 && trades.price > Decimal.Zero))
        {
          trades.orderno = Trades.OrderNoGenerate();
          if (Trades.SaveOrder(trades, this.objmain.getConn()) && Trades.SaveTrade(trades, this.objmain.getConn()))
          {
            flag = true;
            this.objmain.DisplayConfirmationMsg(trades);
          }
        }
      }
      return flag;
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      if (this.dgvOpenPos.Rows.Count <= 0)
        return;
      try
      {
        if (MessageBox.Show("Do you really want to Close All the Positions?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
        {
          for (int index = 0; index < this.dgvOpenPos.Rows.Count; ++index)
          {
            string account = this.dgvOpenPos.Rows[index].Cells[0].Value.ToString();
            string exch = this.dgvOpenPos.Rows[index].Cells[1].Value.ToString();
            string symbol = this.dgvOpenPos.Rows[index].Cells[2].Value.ToString();
            int validity = (int) Enum.Parse(typeof (ValidityType), this.dgvOpenPos.Rows[index].Cells[3].Value.ToString().ToUpper());
            int buysell = !(this.dgvOpenPos.Rows[index].Cells[4].Value.ToString() == "B") ? 1 : 2;
            int int32 = Convert.ToInt32(this.dgvOpenPos.Rows[index].Cells[5].Value);
            DateTime dtnow = new DateTime();
            if (this.objmain.ValidateMarketTime(exch, ref dtnow))
            {
              this.ClosePositions(account, symbol, validity, buysell, int32, false, Utils.GetIntExch(exch));
              Application.DoEvents();
            }
          }
        }
      }
      catch
      {
        this.objmain.DisplayMessage("Unable to Close Position", 3);
      }
    }

    private void Task3_Click(object sender, EventArgs e)
    {
      if (this.dgvOpenPos.Rows.Count <= 0)
        return;
      try
      {
        if (MessageBox.Show("Do you really want to Close and Reverse ALL The Positions?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
        {
          for (int index = 0; index < this.dgvOpenPos.Rows.Count; ++index)
          {
            string account = this.dgvOpenPos.Rows[index].Cells[0].Value.ToString();
            string exch = this.dgvOpenPos.Rows[index].Cells[1].Value.ToString();
            string symbol = this.dgvOpenPos.Rows[index].Cells[2].Value.ToString();
            int validity = (int) Enum.Parse(typeof (ValidityType), this.dgvOpenPos.Rows[index].Cells[3].Value.ToString().ToUpper());
            int buysell = !(this.dgvOpenPos.Rows[index].Cells[4].Value.ToString() == "B") ? 1 : 2;
            int int32 = Convert.ToInt32(this.dgvOpenPos.Rows[index].Cells[5].Value);
            DateTime dtnow = new DateTime();
            if (this.objmain.ValidateMarketTime(exch, ref dtnow))
            {
              this.ClosePositions(account, symbol, validity, buysell, int32, true, Utils.GetIntExch(exch));
              Application.DoEvents();
            }
          }
        }
      }
      catch
      {
        this.objmain.DisplayMessage("Unable to Close Position", 3);
      }
    }

    private void Task4_Click(object sender, EventArgs e)
    {
      this.dgvOpenPos.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task5_Click(object sender, EventArgs e)
    {
      this.dgvOpenPos.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task6_Click(object sender, EventArgs e)
    {
      if (this.dgvOpenPos.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvOpenPos, false);
    }

    private void Task7_Click(object sender, EventArgs e)
    {
      DataGridView dgvOpenPos = this.dgvOpenPos;
      if (dgvOpenPos != null && this.dgvOpenPos.Rows.Count > 0)
      {
        try
        {
          if (MessageBox.Show("Do you really want to Close and Reverse This Position?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
            return;
          int index = dgvOpenPos.CurrentRow.Index;
          string account = this.dgvOpenPos.Rows[index].Cells[0].Value.ToString();
          string exch = this.dgvOpenPos.Rows[index].Cells[1].Value.ToString();
          string symbol = this.dgvOpenPos.Rows[index].Cells[2].Value.ToString();
          int validity = (int) Enum.Parse(typeof (ValidityType), this.dgvOpenPos.Rows[index].Cells[3].Value.ToString().ToUpper());
          int buysell = !(this.dgvOpenPos.Rows[index].Cells[4].Value.ToString() == "B") ? 1 : 2;
          int int32 = Convert.ToInt32(this.dgvOpenPos.Rows[index].Cells[5].Value);
          DateTime dtnow = new DateTime();
          if (!this.objmain.ValidateMarketTime(exch, ref dtnow) || !this.ClosePositions(account, symbol, validity, buysell, int32, true, Utils.GetIntExch(exch)))
            ;
        }
        catch
        {
          this.objmain.DisplayMessage("Unable to Close Position", 3);
        }
      }
      else
        this.objmain.DisplayMessage("No Position to Close", 2);
    }

    private void Task8_Click(object sender, EventArgs e)
    {
      if (this.dgvOpenPos.Rows.Count <= 0)
        return;
      try
      {
        if (MessageBox.Show("Do you really want to Close Selected Positions?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
        {
          for (int index = 0; index < this.dgvOpenPos.Rows.Count; ++index)
          {
            if (this.dgvOpenPos.Rows[index].Cells[7].Value.Equals((object) true))
            {
              string account = this.dgvOpenPos.Rows[index].Cells[0].Value.ToString();
              string exch = this.dgvOpenPos.Rows[index].Cells[1].Value.ToString();
              string symbol = this.dgvOpenPos.Rows[index].Cells[2].Value.ToString();
              int validity = (int) Enum.Parse(typeof (ValidityType), this.dgvOpenPos.Rows[index].Cells[3].Value.ToString().ToUpper());
              int buysell = !(this.dgvOpenPos.Rows[index].Cells[4].Value.ToString() == "B") ? 1 : 2;
              int int32 = Convert.ToInt32(this.dgvOpenPos.Rows[index].Cells[5].Value);
              DateTime dtnow = new DateTime();
              if (this.objmain.ValidateMarketTime(exch, ref dtnow))
              {
                this.ClosePositions(account, symbol, validity, buysell, int32, false, Utils.GetIntExch(exch));
                Application.DoEvents();
              }
            }
          }
        }
      }
      catch
      {
        this.objmain.DisplayMessage("Unable to Close Position", 3);
      }
    }

    public void UpdateNetPosition()
    {
      this.Invoke((Delegate) (() => this.dgvOpenPos.Rows.Clear()));
      while (true)
      {
        if (!this.IsDisposed)
        {
          foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetProftLoss))
          {
            string[] strArray = keyValuePair.Key.Split('_');
            string symbol = strArray[0];
            string account = strArray[1];
            int validity = Convert.ToInt32(strArray[2]);
            if (this.objmain._Symconctracts.ContainsKey(symbol))
            {
              Contracts objcon = this.objmain._Symconctracts[symbol];
              buysellnetpospfls objpos = keyValuePair.Value;
              int count = 0;
              if (!this._OpenPosList.ContainsKey(keyValuePair.Key))
              {
                if (objpos.buy_sell > 0)
                {
                  this.Invoke((Delegate) (() =>
                  {
                    count = this.dgvOpenPos.Rows.Add();
                    this.dgvOpenPos.Rows[count].Cells[0].Value = (object) account;
                    this.dgvOpenPos.Rows[count].Cells[1].Value = (object) Utils.GetExch(objcon.exch);
                    this.dgvOpenPos.Rows[count].Cells[2].Value = (object) symbol;
                    this.dgvOpenPos.Rows[count].Cells[3].Value = (object) Utils.GetValidity(validity);
                    this.dgvOpenPos.Rows[count].Cells[4].Value = (object) Utils.GetBuysell(objpos.buy_sell);
                    this.dgvOpenPos.Rows[count].Cells[5].Value = (object) objpos.Qty;
                    this.dgvOpenPos.Rows[count].Cells[6].Value = objpos.buy_sell != 1 ? (object) Decimal.Round(objpos.sellprice, 2) : (object) Decimal.Round(objpos.buyprice, 2);
                    this.dgvOpenPos.Rows[count].Cells[7].Value = (object) false;
                  }));
                  this._OpenPosList.Add(keyValuePair.Key, count);
                }
              }
              else
              {
                int rowcount = this._OpenPosList[keyValuePair.Key];
                if (objpos.buy_sell > 0)
                  this.Invoke((Delegate) (() =>
                  {
                    this.dgvOpenPos.Rows[rowcount].Cells[0].Value = (object) account;
                    this.dgvOpenPos.Rows[rowcount].Cells[1].Value = (object) Utils.GetExch(objcon.exch);
                    this.dgvOpenPos.Rows[rowcount].Cells[2].Value = (object) symbol;
                    this.dgvOpenPos.Rows[rowcount].Cells[3].Value = (object) Utils.GetValidity(validity);
                    this.dgvOpenPos.Rows[rowcount].Cells[4].Value = (object) Utils.GetBuysell(objpos.buy_sell);
                    this.dgvOpenPos.Rows[rowcount].Cells[5].Value = (object) objpos.Qty;
                    this.dgvOpenPos.Rows[rowcount].Cells[6].Value = objpos.buy_sell != 1 ? (object) Decimal.Round(objpos.sellprice, 2) : (object) Decimal.Round(objpos.buyprice, 2);
                    this.dgvOpenPos.Rows[count].Cells[7].Value = (object) false;
                    if (this.dgvOpenPos.Rows[rowcount].Visible)
                      return;
                    this.dgvOpenPos.Rows[rowcount].Visible = true;
                  }));
                else if (objpos.buy_sell == 0)
                  this.Invoke((Delegate) (() => this.dgvOpenPos.Rows[rowcount].Visible = false));
              }
            }
          }
          Thread.Sleep(10000);
          Application.DoEvents();
        }
      }
    }

    public void LoadNetPositions()
    {
      if (this.cThread != null)
        return;
      this.cThread = new Thread(new ThreadStart(((ThreadStart) (() => this.UpdateNetPosition())).Invoke));
      this.cThread.Start();
    }

    private void OpenPosition_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (this.cThread == null)
        return;
      this.cThread.Abort();
    }

    private void dgvOpenPos_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
      if (e.ColumnIndex != 7 || e.RowIndex <= -1)
        return;
      this.dgvOpenPos.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = !this.dgvOpenPos.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.Equals((object) true) ? (object) true : (object) false;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvOpenPos = new DataGridView();
      this.Regulationcode = new DataGridViewTextBoxColumn();
      this.Exchange = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.BuySell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.AvgPrice = new DataGridViewTextBoxColumn();
      this.ColSelect = new DataGridViewCheckBoxColumn();
      ((ISupportInitialize) this.dgvOpenPos).BeginInit();
      this.SuspendLayout();
      this.dgvOpenPos.AllowUserToAddRows = false;
      this.dgvOpenPos.AllowUserToDeleteRows = false;
      this.dgvOpenPos.AllowUserToOrderColumns = true;
      this.dgvOpenPos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvOpenPos.BackgroundColor = Color.White;
      this.dgvOpenPos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvOpenPos.Columns.AddRange((DataGridViewColumn) this.Regulationcode, (DataGridViewColumn) this.Exchange, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.BuySell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.AvgPrice, (DataGridViewColumn) this.ColSelect);
      this.dgvOpenPos.Dock = DockStyle.Fill;
      this.dgvOpenPos.Location = new Point(0, 0);
      this.dgvOpenPos.Name = "dgvOpenPos";
      this.dgvOpenPos.ReadOnly = true;
      this.dgvOpenPos.RowHeadersVisible = false;
      this.dgvOpenPos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvOpenPos.Size = new Size(945, 290);
      this.dgvOpenPos.TabIndex = 0;
      this.dgvOpenPos.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgvOpenPos_CellMouseClick);
      this.dgvOpenPos.MouseClick += new MouseEventHandler(this.dgvOpenPos_MouseClick);
      this.Regulationcode.HeaderText = "ClientCode";
      this.Regulationcode.Name = "Regulationcode";
      this.Regulationcode.ReadOnly = true;
      this.Exchange.HeaderText = "Exchange";
      this.Exchange.Name = "Exchange";
      this.Exchange.ReadOnly = true;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.BuySell.HeaderText = "B/S";
      this.BuySell.Name = "BuySell";
      this.BuySell.ReadOnly = true;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.AvgPrice.HeaderText = "AvgPrice";
      this.AvgPrice.Name = "AvgPrice";
      this.AvgPrice.ReadOnly = true;
      this.ColSelect.HeaderText = "Select";
      this.ColSelect.Name = "ColSelect";
      this.ColSelect.ReadOnly = true;
      this.ColSelect.Resizable = DataGridViewTriState.True;
      this.ColSelect.SortMode = DataGridViewColumnSortMode.Automatic;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvOpenPos);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (OpenPosition);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Open Position";
      this.FormClosing += new FormClosingEventHandler(this.OpenPosition_FormClosing);
      ((ISupportInitialize) this.dgvOpenPos).EndInit();
      this.ResumeLayout(false);
    }
  }
}
