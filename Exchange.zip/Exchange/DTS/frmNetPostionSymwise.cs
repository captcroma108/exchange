﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmNetPostionSymwise
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmNetPostionSymwise : Form
  {
    public Dashboard objdash = (Dashboard) null;
    private frmClntSymbolPos objclntpos = (frmClntSymbolPos) null;
    private IContainer components = (IContainer) null;
    public int dgvrowindex;
    private DataGridView dgvNetPosition;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem clientwisePositionToolStripMenuItem;
    private ToolStripMenuItem exportToExcelToolStripMenuItem;
    private DataGridViewTextBoxColumn ColSymbol;
    private DataGridViewTextBoxColumn ColPosition;
    private DataGridViewTextBoxColumn ColQty;
    private DataGridViewTextBoxColumn ColAvgPrice;
    private DataGridViewTextBoxColumn ColCMP;
    private DataGridViewTextBoxColumn ColMTMPL;
    private Timer timer1;

    public frmNetPostionSymwise(Dashboard objdash)
    {
      this.InitializeComponent();
      this.objdash = objdash;
      this.Icon = objdash.ico;
    }

    public void Loadwindow()
    {
      this.dgvNetPosition.Rows.Clear();
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objdash._NetProftLoss);
      SortedDictionary<string, buysellnetpospfls> sortedDictionary = new SortedDictionary<string, buysellnetpospfls>();
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dictionary)
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string key = strArray[0];
        string str = strArray[1];
        Convert.ToInt32(strArray[2]);
        if (this.objdash._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objdash._Symconctracts[key];
          buysellnetpospfls buysellnetpospfls1 = keyValuePair.Value;
          if (buysellnetpospfls1.buy_sell > 0)
          {
            if (!sortedDictionary.ContainsKey(key))
            {
              buysellnetpospfls buysellnetpospfls2 = new buysellnetpospfls();
              if (buysellnetpospfls1.buy_sell == 1)
              {
                buysellnetpospfls2.BQty = buysellnetpospfls1.Qty;
                buysellnetpospfls2.buyprice = Decimal.Round(buysellnetpospfls1.buyprice, 2);
              }
              else
              {
                buysellnetpospfls2.SQty = buysellnetpospfls1.Qty;
                buysellnetpospfls2.sellprice = Decimal.Round(buysellnetpospfls1.sellprice, 2);
              }
              sortedDictionary.Add(key, buysellnetpospfls2);
            }
            else
            {
              buysellnetpospfls buysellnetpospfls2 = sortedDictionary[key];
              if (buysellnetpospfls1.buy_sell == 1)
              {
                if (buysellnetpospfls2.BQty > 0)
                {
                  Decimal num = Decimal.Round(((Decimal) buysellnetpospfls2.BQty * buysellnetpospfls2.buyprice + (Decimal) buysellnetpospfls1.Qty * buysellnetpospfls1.buyprice) / (Decimal) (buysellnetpospfls1.Qty + buysellnetpospfls2.BQty), 2);
                  buysellnetpospfls2.BQty += buysellnetpospfls1.Qty;
                  buysellnetpospfls2.buyprice = num;
                }
                else
                {
                  buysellnetpospfls2.BQty += buysellnetpospfls1.Qty;
                  buysellnetpospfls2.buyprice = Decimal.Round(buysellnetpospfls1.buyprice, 2);
                }
              }
              else if (buysellnetpospfls2.SQty > 0)
              {
                Decimal num = Decimal.Round(((Decimal) buysellnetpospfls2.SQty * buysellnetpospfls2.sellprice + (Decimal) buysellnetpospfls1.Qty * buysellnetpospfls1.sellprice) / (Decimal) (buysellnetpospfls1.Qty + buysellnetpospfls2.SQty), 2);
                buysellnetpospfls2.SQty += buysellnetpospfls1.Qty;
                buysellnetpospfls2.sellprice = num;
              }
              else
              {
                buysellnetpospfls2.SQty += buysellnetpospfls1.Qty;
                buysellnetpospfls2.sellprice = Decimal.Round(buysellnetpospfls1.sellprice, 2);
              }
              sortedDictionary[key] = buysellnetpospfls2;
            }
          }
        }
      }
      Decimal num1 = new Decimal();
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in sortedDictionary)
      {
        Contracts contract = this.objdash.GetContract(keyValuePair.Key);
        string symbol = contract.SymDesp;
        if (contract.symbol == "GOLDMM")
          symbol = symbol.Replace("GOLDMM", "GOLD");
        else if (contract.symbol == "SILVERMM")
          symbol = symbol.Replace("SILVERMM", "SILVER");
        if (keyValuePair.Value.BQty > keyValuePair.Value.SQty)
        {
          int index = this.dgvNetPosition.Rows.Add();
          this.dgvNetPosition.Rows[index].Cells[0].Value = (object) keyValuePair.Key;
          this.dgvNetPosition.Rows[index].Cells[1].Value = (object) "BUY";
          this.dgvNetPosition.Rows[index].Cells[2].Value = (object) (keyValuePair.Value.BQty - keyValuePair.Value.SQty);
          this.dgvNetPosition.Rows[index].Cells[3].Value = (object) keyValuePair.Value.buyprice;
          Feeds feed = this.objdash.getFeed(symbol);
          if (feed.ltp > Decimal.Zero)
          {
            this.dgvNetPosition.Rows[index].Cells[4].Value = (object) feed.ltp;
            if (contract.exch == 2)
            {
              Decimal num2 = Decimal.Round((feed.ltp - keyValuePair.Value.buyprice) * (Decimal) (keyValuePair.Value.BQty - keyValuePair.Value.SQty), 2);
              this.dgvNetPosition.Rows[index].Cells[5].Value = (object) num2;
              num1 += num2;
            }
            else
            {
              Decimal num2 = Decimal.Round((feed.ltp - keyValuePair.Value.buyprice) * (Decimal) ((keyValuePair.Value.BQty - keyValuePair.Value.SQty) * contract.lotsize), 2);
              this.dgvNetPosition.Rows[index].Cells[5].Value = (object) num2;
              num1 += num2;
            }
          }
        }
        else if (keyValuePair.Value.SQty > keyValuePair.Value.BQty)
        {
          int index = this.dgvNetPosition.Rows.Add();
          this.dgvNetPosition.Rows[index].Cells[0].Value = (object) keyValuePair.Key;
          this.dgvNetPosition.Rows[index].Cells[1].Value = (object) "SELL";
          this.dgvNetPosition.Rows[index].Cells[2].Value = (object) (keyValuePair.Value.SQty - keyValuePair.Value.BQty);
          this.dgvNetPosition.Rows[index].Cells[3].Value = (object) keyValuePair.Value.sellprice;
          Feeds feed = this.objdash.getFeed(symbol);
          if (feed.ltp > Decimal.Zero)
          {
            this.dgvNetPosition.Rows[index].Cells[4].Value = (object) feed.ltp;
            if (contract.exch == 2)
            {
              Decimal num2 = Decimal.Round((keyValuePair.Value.sellprice - feed.ltp) * (Decimal) (keyValuePair.Value.SQty - keyValuePair.Value.BQty), 2);
              this.dgvNetPosition.Rows[index].Cells[5].Value = (object) num2;
              num1 += num2;
            }
            else
            {
              Decimal num2 = Decimal.Round((keyValuePair.Value.sellprice - feed.ltp) * (Decimal) ((keyValuePair.Value.SQty - keyValuePair.Value.BQty) * contract.lotsize), 2);
              this.dgvNetPosition.Rows[index].Cells[5].Value = (object) num2;
              num1 += num2;
            }
          }
        }
      }
      this.dgvNetPosition.Rows[this.dgvNetPosition.Rows.Add()].Cells[5].Value = (object) num1;
    }

    private void clientwisePositionToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvNetPosition.Rows.Count <= 0 || this.dgvrowindex <= -1)
        return;
      string Displaysymbol = this.dgvNetPosition.Rows[this.dgvrowindex].Cells[0].Value.ToString();
      if (this.objclntpos == null || this.objclntpos.IsDisposed)
      {
        frmClntSymbolPos frmClntSymbolPos = new frmClntSymbolPos(this.objdash);
        frmClntSymbolPos.MdiParent = (Form) this.objdash;
        this.objclntpos = frmClntSymbolPos;
        this.objclntpos.Loadwindow(Displaysymbol);
        this.objclntpos.Show();
      }
      else
      {
        this.objclntpos.MdiParent = (Form) this.objdash;
        this.objclntpos.BringToFront();
        this.objclntpos.Loadwindow(Displaysymbol);
        this.objclntpos.Show();
      }
    }

    private void exportToExcelToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvNetPosition.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvNetPosition, false);
    }

    private void dgvNetPosition_MouseClick(object sender, MouseEventArgs e)
    {
      if (this.dgvNetPosition.Rows.Count > 0)
      {
        this.dgvrowindex = this.dgvNetPosition.HitTest(e.X, e.Y).RowIndex;
        if (this.dgvrowindex > -1)
          this.dgvNetPosition.Rows[this.dgvrowindex].Selected = true;
      }
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvNetPosition.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvNetPosition, client.X, client.Y);
    }

    private void frmNetPostionSymwise_Load(object sender, EventArgs e)
    {
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      this.Loadwindow();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      this.dgvNetPosition = new DataGridView();
      this.ColSymbol = new DataGridViewTextBoxColumn();
      this.ColPosition = new DataGridViewTextBoxColumn();
      this.ColQty = new DataGridViewTextBoxColumn();
      this.ColAvgPrice = new DataGridViewTextBoxColumn();
      this.ColCMP = new DataGridViewTextBoxColumn();
      this.ColMTMPL = new DataGridViewTextBoxColumn();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.clientwisePositionToolStripMenuItem = new ToolStripMenuItem();
      this.exportToExcelToolStripMenuItem = new ToolStripMenuItem();
      this.timer1 = new Timer(this.components);
      ((ISupportInitialize) this.dgvNetPosition).BeginInit();
      this.contextMenuStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvNetPosition.AllowUserToAddRows = false;
      this.dgvNetPosition.AllowUserToDeleteRows = false;
      this.dgvNetPosition.AllowUserToOrderColumns = true;
      this.dgvNetPosition.AllowUserToResizeRows = false;
      this.dgvNetPosition.BackgroundColor = Color.White;
      this.dgvNetPosition.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvNetPosition.Columns.AddRange((DataGridViewColumn) this.ColSymbol, (DataGridViewColumn) this.ColPosition, (DataGridViewColumn) this.ColQty, (DataGridViewColumn) this.ColAvgPrice, (DataGridViewColumn) this.ColCMP, (DataGridViewColumn) this.ColMTMPL);
      this.dgvNetPosition.Dock = DockStyle.Fill;
      this.dgvNetPosition.Location = new Point(0, 0);
      this.dgvNetPosition.Name = "dgvNetPosition";
      this.dgvNetPosition.ReadOnly = true;
      this.dgvNetPosition.RowHeadersVisible = false;
      this.dgvNetPosition.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvNetPosition.Size = new Size(660, 290);
      this.dgvNetPosition.TabIndex = 0;
      this.dgvNetPosition.MouseClick += new MouseEventHandler(this.dgvNetPosition_MouseClick);
      this.ColSymbol.HeaderText = "Symbol";
      this.ColSymbol.Name = "ColSymbol";
      this.ColSymbol.ReadOnly = true;
      this.ColSymbol.Width = 150;
      this.ColPosition.HeaderText = "Position";
      this.ColPosition.Name = "ColPosition";
      this.ColPosition.ReadOnly = true;
      this.ColQty.HeaderText = "Qty";
      this.ColQty.Name = "ColQty";
      this.ColQty.ReadOnly = true;
      this.ColAvgPrice.HeaderText = "AvgPrice";
      this.ColAvgPrice.Name = "ColAvgPrice";
      this.ColAvgPrice.ReadOnly = true;
      this.ColCMP.HeaderText = "CMP";
      this.ColCMP.Name = "ColCMP";
      this.ColCMP.ReadOnly = true;
      this.ColMTMPL.HeaderText = "MTM_Profit/Loss";
      this.ColMTMPL.Name = "ColMTMPL";
      this.ColMTMPL.ReadOnly = true;
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.clientwisePositionToolStripMenuItem,
        (ToolStripItem) this.exportToExcelToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(175, 48);
      this.clientwisePositionToolStripMenuItem.Name = "clientwisePositionToolStripMenuItem";
      this.clientwisePositionToolStripMenuItem.Size = new Size(174, 22);
      this.clientwisePositionToolStripMenuItem.Text = "Clientwise Position";
      this.clientwisePositionToolStripMenuItem.Click += new EventHandler(this.clientwisePositionToolStripMenuItem_Click);
      this.exportToExcelToolStripMenuItem.Name = "exportToExcelToolStripMenuItem";
      this.exportToExcelToolStripMenuItem.Size = new Size(174, 22);
      this.exportToExcelToolStripMenuItem.Text = "Export to Excel";
      this.exportToExcelToolStripMenuItem.Click += new EventHandler(this.exportToExcelToolStripMenuItem_Click);
      this.timer1.Tick += new EventHandler(this.timer1_Tick);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(660, 290);
      this.Controls.Add((Control) this.dgvNetPosition);
      this.MaximizeBox = false;
      this.Name = nameof (frmNetPostionSymwise);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Net Postion Contractwise";
      this.Load += new EventHandler(this.frmNetPostionSymwise_Load);
      ((ISupportInitialize) this.dgvNetPosition).EndInit();
      this.contextMenuStrip1.ResumeLayout(false);
      this.ResumeLayout(false);
    }
  }
}
