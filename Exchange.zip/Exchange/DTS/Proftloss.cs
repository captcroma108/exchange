﻿// Decompiled with JetBrains decompiler
// Type: DTS.Proftloss
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public class Proftloss
  {
    public string Symbol { get; set; }

    public int buysell { get; set; }

    public int Bqty { get; set; }

    public int Sqty { get; set; }

    public Decimal Bavgprice { get; set; }

    public Decimal Savgprice { get; set; }

    public string validity { get; set; }

    public string clientcode { get; set; }

    public DateTime timestamp { get; set; }

    public Decimal RealisedPL { get; set; }

    public Decimal Brkg { get; set; }

    public Decimal NetMTMPL { get; set; }
  }
}
