﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmGrouping
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmGrouping : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private CheckedListBox lstMappedClients;
    private CheckBox chkMappdAll;
    private CheckBox chkAll;
    private CheckedListBox lstClients;
    private Button btnremove;
    private Button btnAdd;
    private Label label8;
    private Label label9;
    private Button btnSave;
    private ComboBox cmbGroupType;
    private Label label7;
    private Label label1;
    private TextBox txtGroupName;
    private Button btncreate;

    public frmGrouping(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      this.cmbGroupType.Items.Clear();
      foreach (KeyValuePair<string, List<string>> keyValuePair in this.objdash._UsertradeGrouping)
        this.cmbGroupType.Items.Add((object) keyValuePair.Key);
      if (this.cmbGroupType.Items.Count > 0)
        this.cmbGroupType.SelectedIndex = 0;
      this.lstClients.Items.Clear();
      foreach (object lstAccount in this.objdash._lstAccounts)
        this.lstClients.Items.Add(lstAccount);
    }

    private void cmbGroupType_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.lstMappedClients.Items.Clear();
      if (this.cmbGroupType.SelectedIndex <= -1 || !this.objdash._UsertradeGrouping.ContainsKey(this.cmbGroupType.Text))
        return;
      foreach (object obj in this.objdash._UsertradeGrouping[this.cmbGroupType.Text])
        this.lstMappedClients.Items.Add(obj);
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.cmbGroupType.SelectedIndex <= -1 || !this.objdash._UsertradeGrouping.ContainsKey(this.cmbGroupType.Text))
        return;
      List<string> stringList = new List<string>();
      SqlConnection conn = this.objdash.getConn();
      if (conn.State == ConnectionState.Open)
      {
        if (this.lstMappedClients.Items.Count > 0)
        {
          this.DeleteOldGroup(this.cmbGroupType.Text, conn);
          for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          {
            if (!stringList.Contains(this.lstMappedClients.Items[index].ToString()))
            {
              SqlCommand sqlCommand1 = new SqlCommand("SaveTradeGrouping", conn);
              sqlCommand1.CommandType = CommandType.StoredProcedure;
              using (SqlCommand sqlCommand2 = sqlCommand1)
              {
                sqlCommand2.Parameters.AddWithValue("@grouptype", (object) this.cmbGroupType.Text);
                sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.lstMappedClients.Items[index].ToString());
                sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.objdash.objinfo.clientcode);
                try
                {
                  sqlCommand2.ExecuteNonQuery();
                  stringList.Add(this.lstMappedClients.Items[index].ToString());
                }
                catch
                {
                }
              }
            }
          }
          if (this.objdash._UsertradeGrouping.ContainsKey(this.cmbGroupType.Text))
            this.objdash._UsertradeGrouping[this.cmbGroupType.Text] = stringList;
          else
            this.objdash._UsertradeGrouping.Add(this.cmbGroupType.Text, stringList);
          this.LoadControls();
          this.objdash.DisplayMessage("Account Grouped Successfully!!", 1);
        }
        else
          this.objdash.DisplayMessage("Please select clients to map.", 2);
      }
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      if (this.lstClients.CheckedItems.Count <= 0)
        return;
      ArrayList arrayList = new ArrayList();
      for (int index = 0; index < this.lstClients.Items.Count; ++index)
      {
        if (this.lstClients.GetItemCheckState(index) == CheckState.Checked)
        {
          if (!this.objdash._AllTradeGroupingCLients.Contains(this.lstClients.Items[index].ToString()))
            this.objdash._AllTradeGroupingCLients.Add(this.lstClients.Items[index].ToString());
          if (!this.lstMappedClients.Items.Contains((object) this.lstClients.Items[index].ToString()))
            this.lstMappedClients.Items.Add((object) this.lstClients.Items[index].ToString());
          arrayList.Add((object) this.lstClients.Items[index].ToString());
        }
      }
      foreach (object obj in arrayList)
        this.lstClients.Items.Remove((object) obj.ToString());
    }

    private void btnremove_Click(object sender, EventArgs e)
    {
      if (this.chkMappdAll.Checked)
      {
        this.lstMappedClients.Items.Clear();
        this.chkMappdAll.Checked = false;
      }
      else
      {
        ArrayList arrayList = new ArrayList();
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
        {
          if (this.lstMappedClients.GetItemCheckState(index) == CheckState.Checked)
          {
            this.lstClients.Items.Add((object) this.lstMappedClients.Items[index].ToString());
            arrayList.Add((object) this.lstMappedClients.Items[index].ToString());
            if (this.objdash._AllTradeGroupingCLients.Contains(this.lstMappedClients.Items[index].ToString()))
              this.objdash._AllTradeGroupingCLients.Remove(this.lstMappedClients.Items[index].ToString());
          }
        }
        foreach (object obj in arrayList)
          this.lstMappedClients.Items.Remove((object) obj.ToString());
      }
    }

    private void btncreate_Click(object sender, EventArgs e)
    {
      if (this.txtGroupName.Text == string.Empty)
        this.objdash.DisplayMessage("Please specify a name to create new Group", 2);
      else if (this.lstMappedClients.Items.Count == 0)
        this.objdash.DisplayMessage("Please select clients to map with a Group", 2);
      else if (this.objdash._UsertradeGrouping.ContainsKey(this.txtGroupName.Text))
      {
        this.objdash.DisplayMessage("Group with this name already exists, please specify a unique name.", 2);
      }
      else
      {
        List<string> stringList = new List<string>();
        SqlConnection conn = this.objdash.getConn();
        if (conn.State == ConnectionState.Open)
        {
          string key = this.txtGroupName.Text.Trim();
          for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          {
            if (!stringList.Contains(this.lstMappedClients.Items[index].ToString()))
            {
              SqlCommand sqlCommand1 = new SqlCommand("SaveTradeGrouping", conn);
              sqlCommand1.CommandType = CommandType.StoredProcedure;
              using (SqlCommand sqlCommand2 = sqlCommand1)
              {
                sqlCommand2.Parameters.AddWithValue("@grouptype", (object) key);
                sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.lstMappedClients.Items[index].ToString());
                sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.objdash.objinfo.clientcode);
                try
                {
                  sqlCommand2.ExecuteNonQuery();
                  stringList.Add(this.lstMappedClients.Items[index].ToString());
                }
                catch
                {
                }
              }
            }
          }
          if (this.objdash._UsertradeGrouping.ContainsKey(key))
            this.objdash._UsertradeGrouping[key] = stringList;
          else
            this.objdash._UsertradeGrouping.Add(key, stringList);
          this.LoadControls();
          this.objdash.DisplayMessage("Account Grouped Successfully!!", 1);
        }
        else
          this.objdash.DisplayMessage("Unable to connect to server, please check your internet connection.", 3);
      }
    }

    private void DeleteOldGroup(string groupname, SqlConnection conn)
    {
      using (SqlCommand sqlCommand = new SqlCommand("Delete from TradeGrouping where GroupType = '" + groupname + "'", conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    private void chkAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkAll.Checked)
      {
        for (int index = 0; index < this.lstClients.Items.Count; ++index)
          this.lstClients.SetItemChecked(index, true);
      }
      else
      {
        for (int index = 0; index < this.lstClients.Items.Count; ++index)
          this.lstClients.SetItemChecked(index, false);
      }
    }

    private void chkMappdAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkMappdAll.Checked)
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          this.lstMappedClients.SetItemChecked(index, true);
      }
      else
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          this.lstMappedClients.SetItemChecked(index, false);
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.lstMappedClients = new CheckedListBox();
      this.chkMappdAll = new CheckBox();
      this.chkAll = new CheckBox();
      this.lstClients = new CheckedListBox();
      this.btnremove = new Button();
      this.btnAdd = new Button();
      this.label8 = new Label();
      this.label9 = new Label();
      this.btnSave = new Button();
      this.cmbGroupType = new ComboBox();
      this.label7 = new Label();
      this.label1 = new Label();
      this.txtGroupName = new TextBox();
      this.btncreate = new Button();
      this.SuspendLayout();
      this.lstMappedClients.CheckOnClick = true;
      this.lstMappedClients.FormattingEnabled = true;
      this.lstMappedClients.Location = new Point(216, 74);
      this.lstMappedClients.Name = "lstMappedClients";
      this.lstMappedClients.Size = new Size(120, 334);
      this.lstMappedClients.Sorted = true;
      this.lstMappedClients.TabIndex = 24;
      this.chkMappdAll.AutoSize = true;
      this.chkMappdAll.Location = new Point(218, 57);
      this.chkMappdAll.Name = "chkMappdAll";
      this.chkMappdAll.Size = new Size(45, 17);
      this.chkMappdAll.TabIndex = 28;
      this.chkMappdAll.Text = "ALL";
      this.chkMappdAll.UseVisualStyleBackColor = true;
      this.chkMappdAll.CheckedChanged += new EventHandler(this.chkMappdAll_CheckedChanged);
      this.chkAll.AutoSize = true;
      this.chkAll.Location = new Point(21, 56);
      this.chkAll.Name = "chkAll";
      this.chkAll.Size = new Size(45, 17);
      this.chkAll.TabIndex = 27;
      this.chkAll.Text = "ALL";
      this.chkAll.UseVisualStyleBackColor = true;
      this.chkAll.CheckedChanged += new EventHandler(this.chkAll_CheckedChanged);
      this.lstClients.CheckOnClick = true;
      this.lstClients.FormattingEnabled = true;
      this.lstClients.Location = new Point(18, 74);
      this.lstClients.Name = "lstClients";
      this.lstClients.Size = new Size(120, 334);
      this.lstClients.Sorted = true;
      this.lstClients.TabIndex = 21;
      this.btnremove.Location = new Point(152, 285);
      this.btnremove.Name = "btnremove";
      this.btnremove.Size = new Size(43, 44);
      this.btnremove.TabIndex = 23;
      this.btnremove.Text = "<<";
      this.btnremove.UseVisualStyleBackColor = true;
      this.btnremove.Click += new EventHandler(this.btnremove_Click);
      this.btnAdd.Location = new Point(152, 137);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new Size(43, 44);
      this.btnAdd.TabIndex = 22;
      this.btnAdd.Text = ">>";
      this.btnAdd.UseVisualStyleBackColor = true;
      this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
      this.label8.AutoSize = true;
      this.label8.Location = new Point(261, 58);
      this.label8.Name = "label8";
      this.label8.Size = new Size(83, 13);
      this.label8.TabIndex = 26;
      this.label8.Text = "Mapped Clients:";
      this.label9.AutoSize = true;
      this.label9.Location = new Point(68, 58);
      this.label9.Name = "label9";
      this.label9.Size = new Size(70, 13);
      this.label9.TabIndex = 25;
      this.label9.Text = "No of Clients:";
      this.btnSave.Location = new Point(139, 420);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 30);
      this.btnSave.TabIndex = 29;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.cmbGroupType.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbGroupType.FormattingEnabled = true;
      this.cmbGroupType.Location = new Point(15, 25);
      this.cmbGroupType.Name = "cmbGroupType";
      this.cmbGroupType.Size = new Size(120, 21);
      this.cmbGroupType.TabIndex = 31;
      this.cmbGroupType.SelectedIndexChanged += new EventHandler(this.cmbGroupType_SelectedIndexChanged);
      this.label7.AutoSize = true;
      this.label7.Location = new Point(15, 9);
      this.label7.Name = "label7";
      this.label7.Size = new Size(72, 13);
      this.label7.TabIndex = 30;
      this.label7.Text = "Select Group:";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(164, 9);
      this.label1.Name = "label1";
      this.label1.Size = new Size(61, 13);
      this.label1.TabIndex = 32;
      this.label1.Text = "New Group";
      this.txtGroupName.Location = new Point(167, 25);
      this.txtGroupName.MaxLength = 25;
      this.txtGroupName.Name = "txtGroupName";
      this.txtGroupName.Size = new Size(123, 20);
      this.txtGroupName.TabIndex = 33;
      this.btncreate.Location = new Point(296, 22);
      this.btncreate.Name = "btncreate";
      this.btncreate.Size = new Size(55, 23);
      this.btncreate.TabIndex = 34;
      this.btncreate.Text = "Create";
      this.btncreate.UseVisualStyleBackColor = true;
      this.btncreate.Click += new EventHandler(this.btncreate_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(363, 463);
      this.Controls.Add((Control) this.btncreate);
      this.Controls.Add((Control) this.txtGroupName);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.cmbGroupType);
      this.Controls.Add((Control) this.label7);
      this.Controls.Add((Control) this.btnSave);
      this.Controls.Add((Control) this.lstMappedClients);
      this.Controls.Add((Control) this.chkMappdAll);
      this.Controls.Add((Control) this.chkAll);
      this.Controls.Add((Control) this.lstClients);
      this.Controls.Add((Control) this.btnremove);
      this.Controls.Add((Control) this.btnAdd);
      this.Controls.Add((Control) this.label8);
      this.Controls.Add((Control) this.label9);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (frmGrouping);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Grouping";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
