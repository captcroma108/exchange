﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmLimits
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace DTS
{
  public class frmLimits : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public SqlConnection conn;
    private DataGridView dgvLimits;
    private GroupBox groupBox1;
    private NumericUpDown txtLotBrkup;
    private Label label13;
    private TextBox txtaccno;
    private Label label9;
    private TextBox txtusername;
    private Label label18;
    private Label label14;
    private TextBox txtmtmlimit;
    private TextBox txtcashmargin;
    private Label label3;
    private GroupBox groupBox3;
    private NumericUpDown txtMTMmulti;
    private Label label7;
    private Button button2;
    private Button btnapply;
    private GroupBox groupBox2;
    private RadioButton rdoblock;
    private RadioButton rdoclose;
    private RadioButton rdofully;
    private GroupBox groupBox5;
    private GroupBox groupBox6;
    private CheckBox chkMrgnSqOff;
    private CheckBox chkIntraSqoff;
    private NumericUpDown TurnoverMulti;
    private Label label2;
    private GroupBox groupBox4;
    private GroupBox groupBox7;
    private RadioButton rdosymwise;
    private RadioButton rdodefault;
    private Label lblNsefutLots1;
    private Label lblMcxLots;
    private RadioButton radioButton1;
    private Label lblNcdexLots1;
    private TextBox txtMcxlots;
    private Label lblNcdexLots;
    private Label lblMcxlots1;
    private Label lblNsefutLots;
    private TextBox txtncxlot;
    private TextBox txtnselot;
    private Label label16;
    private TextBox txtturnoverlimit;
    private Button btnFlushASOD;
    private Button btnreset;
    private Button btnset;
    private MaskedTextBox txtIntrdymcx;
    private MaskedTextBox txtIntrdynsecurr;
    private MaskedTextBox txtIntrdyncdex;
    private MaskedTextBox txtIntrdynsefut;
    private GroupBox groupBox8;
    private DataGridViewTextBoxColumn ClientCode;
    private DataGridViewTextBoxColumn frmName;
    private Label lblNsecurrLots1;
    private Label lblNsecurrLots;
    private TextBox txtnsecurrLots;
    private NumericUpDown numericUpDown1;
    private Label label10;
    private GroupBox groupBox9;
    private CheckBox chkGTC;
    private CheckBox chkCnF;
    private CheckBox chkDay;
    private GroupBox groupBox10;
    private CheckBox chkRL;
    private CheckBox chkSL;
    private CheckBox chkMkt;
    private TextBox txtClientCode;
    private TextBox txtName;
    private Label label21;
    private Label label22;
    private MaskedTextBox txtCnfNseCurr;
    private MaskedTextBox txtCnfMcx;
    private MaskedTextBox txtCnfNseFut;
    private MaskedTextBox txtCnfNcdex;
    private Label label1;
    private Label lblAllocatedMrgn;
    private Label lblUtilisedMrgn;
    private Label label6;
    private Label lblAvailMrgn;
    private Label label11;
    private GroupBox groupBox11;
    private NumericUpDown txtMCXBrkup;
    private Label lblMCXBrkup;
    private NumericUpDown txtNSECURBrkup;
    private Label lblNsecurBrkup;
    private NumericUpDown txtNCDEXBrkup;
    private Label lblNcdexBrkup;
    private NumericUpDown txtNSEFUTBrkup;
    private Label lblNsefutBrkup;
    private GroupBox groupBox12;
    private RadioButton rdoPendingOnBidAsk;
    private RadioButton rdoPendingOnLTP;
    private CheckBox chk_MCX;
    private CheckBox chk_Nsecur;
    private CheckBox chk_Ncdex;
    private CheckBox chk_NSEFUT;
    private GroupBox groupBox13;
    private CheckBox chk_lot_Brkg_NSECUR;
    private CheckBox chk_lot_Brkg_NCDEX;
    private CheckBox chk_lot_Brkg_NSEFUT;
    private CheckBox chk_lot_Brkg_MCX;
    private Label label4;
    private MaskedTextBox maskedTextBox1;
    private MaskedTextBox maskedTextBox2;
    private MaskedTextBox maskedTextBox3;
    private MaskedTextBox maskedTextBox4;
    private Label label5;
    private MaskedTextBox maskedTextBox5;
    private MaskedTextBox maskedTextBox6;
    private MaskedTextBox maskedTextBox7;
    private MaskedTextBox maskedTextBox8;
    private CheckBox rdoSymbolwise;
    private CheckBox rdoTurnoverwse;
    private CheckBox rdolotwse;
    private RadioButton rdosymbolwise1;
    private RadioButton rdoExchange;

    public frmLimits(Dashboard dash, SqlConnection db)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = db;
      this.Icon = this.objdash.ico;
    }

    public void Loadwindow()
    {
      this.dgvLimits.Rows.Clear();
      foreach (string lstAccount in this.objdash._lstAccounts)
      {
        int index = this.dgvLimits.Rows.Add();
        this.dgvLimits.Rows[index].Cells[0].Value = (object) lstAccount;
        if (this.objdash._Userinformation.ContainsKey(lstAccount))
        {
          Userinfo userinfo = this.objdash._Userinformation[lstAccount];
          this.dgvLimits.Rows[index].Cells[1].Value = (object) userinfo.username;
        }
      }
      this.dgvLimits.BackgroundColor = Color.Black;
      this.txtIntrdymcx.Text = "0";
      this.txtCnfMcx.Text = "0";
      this.txtIntrdyncdex.Text = "0";
      this.txtCnfNcdex.Text = "0";
      this.txtIntrdynsecurr.Text = "0";
      this.txtCnfNseCurr.Text = "0";
      this.txtIntrdynsefut.Text = "0";
      this.txtCnfNseFut.Text = "0";
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.chk_MCX.Visible = true;
            this.txtIntrdymcx.Visible = true;
            this.txtCnfMcx.Visible = true;
            this.lblMcxLots.Visible = true;
            this.txtMcxlots.Visible = true;
            this.lblMcxlots1.Visible = true;
            break;
          case 2:
            this.chk_NSEFUT.Visible = true;
            this.txtIntrdynsefut.Visible = true;
            this.txtCnfNseFut.Visible = true;
            this.lblNsefutLots.Visible = true;
            this.txtnselot.Visible = true;
            this.lblNsefutLots1.Visible = true;
            break;
          case 3:
            this.chk_Ncdex.Visible = true;
            this.txtncxlot.Visible = true;
            this.txtIntrdyncdex.Visible = true;
            this.txtCnfNcdex.Visible = true;
            this.lblNcdexLots.Visible = true;
            this.lblNcdexLots1.Visible = true;
            break;
          case 4:
            this.chk_Nsecur.Visible = true;
            this.txtIntrdynsecurr.Visible = true;
            this.txtCnfNseCurr.Visible = true;
            this.lblNsecurrLots.Visible = true;
            this.lblNsecurrLots1.Visible = true;
            this.txtnsecurrLots.Visible = true;
            break;
        }
      }
      this.lblNsefutLots1.Visible = false;
      this.lblNcdexLots1.Visible = false;
      this.lblMcxlots1.Visible = false;
      this.lblNsefutLots.Visible = false;
      this.lblNcdexLots.Visible = false;
      this.lblMcxLots.Visible = false;
      this.lblNsecurrLots1.Visible = false;
      this.lblNsecurrLots.Visible = false;
      this.txtnsecurrLots.Visible = false;
      this.txtMcxlots.Visible = false;
      this.txtncxlot.Visible = false;
      this.txtnselot.Visible = false;
      this.lblAllocatedMrgn.Text = this.objdash.objinfo.DAfund.ToString();
      this.UpdateDAMargin();
    }

    private void rdoTurnoverwse_CheckedChanged_1(object sender, EventArgs e)
    {
      if (this.rdoTurnoverwse.Checked)
      {
        this.txtturnoverlimit.Visible = true;
        this.label16.Visible = true;
        this.groupBox7.Visible = false;
      }
      else
      {
        this.txtturnoverlimit.Visible = false;
        this.label16.Visible = false;
        this.groupBox7.Visible = false;
      }
      if (this.rdolotwse.Checked)
      {
        this.groupBox7.Visible = true;
        this.rdodefault.Checked = true;
      }
      else
        this.groupBox7.Visible = false;
    }

    private void rdolotwse_CheckedChanged_1(object sender, EventArgs e)
    {
      if (this.rdolotwse.Checked)
      {
        this.groupBox7.Visible = true;
        this.txtturnoverlimit.Visible = false;
        this.label16.Visible = false;
        this.rdodefault.Checked = true;
      }
      else
      {
        this.groupBox7.Visible = false;
        this.txtturnoverlimit.Visible = false;
        this.label16.Visible = false;
        this.rdodefault.Checked = false;
      }
      if (this.rdoTurnoverwse.Checked)
      {
        this.txtturnoverlimit.Visible = true;
        this.label16.Visible = true;
      }
      else
      {
        this.txtturnoverlimit.Visible = false;
        this.label16.Visible = false;
      }
    }

    private void rdoSymbolwise_CheckedChanged_1(object sender, EventArgs e)
    {
      if (this.rdoSymbolwise.Checked)
      {
        this.txtturnoverlimit.Visible = false;
        this.label16.Visible = false;
        this.groupBox7.Visible = false;
      }
      if (this.rdoTurnoverwse.Checked)
      {
        this.txtturnoverlimit.Visible = true;
        this.label16.Visible = true;
        this.groupBox7.Visible = false;
      }
      if (!this.rdolotwse.Checked)
        return;
      this.groupBox7.Visible = true;
    }

    private void rdodefault_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdodefault.Checked)
        return;
      this.lblNsefutLots1.Visible = false;
      this.lblNcdexLots1.Visible = false;
      this.lblMcxlots1.Visible = false;
      this.lblNsefutLots.Visible = false;
      this.lblNcdexLots.Visible = false;
      this.lblMcxLots.Visible = false;
      this.lblNsecurrLots1.Visible = false;
      this.lblNsecurrLots.Visible = false;
      this.txtnsecurrLots.Visible = false;
      this.txtMcxlots.Visible = false;
      this.txtncxlot.Visible = false;
      this.txtnselot.Visible = false;
    }

    private void rdosymwise_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdosymwise.Checked)
        return;
      this.lblNsefutLots1.Visible = false;
      this.lblNcdexLots1.Visible = false;
      this.lblMcxlots1.Visible = false;
      this.lblNsefutLots.Visible = false;
      this.lblNcdexLots.Visible = false;
      this.lblMcxLots.Visible = false;
      this.lblNsecurrLots1.Visible = false;
      this.lblNsecurrLots.Visible = false;
      this.txtnsecurrLots.Visible = false;
      this.txtMcxlots.Visible = false;
      this.txtncxlot.Visible = false;
      this.txtnselot.Visible = false;
    }

    private void btnapply_Click(object sender, EventArgs e)
    {
      if (this.txtcashmargin.Text.Length > 1)
      {
        this.txtturnoverlimit.Text = Convert.ToDouble(Convert.ToDouble(this.txtcashmargin.Text) * Convert.ToDouble(this.TurnoverMulti.Value)).ToString();
        this.txtmtmlimit.Text = Convert.ToDouble(Convert.ToDouble(this.txtcashmargin.Text) * Convert.ToDouble(this.txtMTMmulti.Text) / 100.0).ToString();
      }
      else
      {
        int num = (int) MessageBox.Show("Please enter cash margin to enter MTM loss limit.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
      }
    }

    private void ClearControls(Control Control)
    {
      foreach (Control control in (ArrangedElementCollection) Control.Controls)
      {
        if (control is TextBox)
          ((TextBoxBase) control).Clear();
        if (control.HasChildren)
          this.ClearControls(control);
        if (control is MaskedTextBox)
          ((TextBoxBase) control).Clear();
        if (control is CheckBox)
          ((CheckBox) control).Checked = false;
      }
      this.txtusername.Enabled = true;
      this.txtaccno.Enabled = true;
      this.txtLotBrkup.Value = new Decimal(9);
      this.txtLotBrkup.UpButton();
      this.TurnoverMulti.Value = new Decimal(299);
      this.TurnoverMulti.UpButton();
      this.txtMTMmulti.Value = new Decimal(98);
      this.txtMTMmulti.UpButton();
      this.rdofully.Checked = true;
      this.txtIntrdymcx.Text = "0";
      this.txtCnfMcx.Text = "0";
      this.txtIntrdyncdex.Text = "0";
      this.txtCnfNcdex.Text = "0";
      this.txtIntrdynsecurr.Text = "0";
      this.txtCnfNseCurr.Text = "0";
      this.txtIntrdynsefut.Text = "0";
      this.txtCnfNseFut.Text = "0";
      this.txtncxlot.Text = "0";
      this.txtnsecurrLots.Text = "0";
    }

    private void dgvLimits_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1)
        return;
      DataGridViewRow row = this.dgvLimits.Rows[e.RowIndex];
      int rowIndex = e.RowIndex;
      if (row != null)
      {
        this.ClearControls((Control) this);
        this.txtaccno.Text = this.dgvLimits.Rows[rowIndex].Cells[0].Value.ToString();
        this.txtusername.Text = this.dgvLimits.Rows[rowIndex].Cells[1].Value.ToString();
        this.txtaccno.Enabled = false;
        this.txtusername.Enabled = false;
        if (this.objdash._ClientLimits.ContainsKey(this.txtaccno.Text.Trim()))
        {
          Limits clientLimit = this.objdash._ClientLimits[this.txtaccno.Text.Trim()];
          BrkgType brkgType = this.objdash._ClientBrokerageType.ContainsKey(clientLimit.clientcode) ? this.objdash._ClientBrokerageType[clientLimit.clientcode] : new BrkgType();
          this.txtcashmargin.Text = clientLimit.cashmrgn.ToString();
          TextBox txtmtmlimit = this.txtmtmlimit;
          Decimal num1 = clientLimit.mtmlosslimit;
          string str1 = num1.ToString();
          txtmtmlimit.Text = str1;
          this.txtMCXBrkup.Value = Decimal.One;
          if (clientLimit.McxBrkup > 0)
          {
            this.txtMCXBrkup.Value = Convert.ToDecimal(clientLimit.McxBrkup);
            this.txtMCXBrkup.UpButton();
            this.txtMCXBrkup.DownButton();
          }
          this.txtNSEFUTBrkup.Value = Decimal.One;
          if (clientLimit.NsefutBrkup > 0)
          {
            this.txtNSEFUTBrkup.Value = Convert.ToDecimal(clientLimit.NsefutBrkup);
            this.txtNSEFUTBrkup.UpButton();
            this.txtNSEFUTBrkup.DownButton();
          }
          this.txtNCDEXBrkup.Value = Decimal.One;
          if (clientLimit.NcdexBrkup > 0)
          {
            this.txtNCDEXBrkup.Value = Convert.ToDecimal(clientLimit.NcdexBrkup);
            this.txtNCDEXBrkup.UpButton();
            this.txtNCDEXBrkup.DownButton();
          }
          this.txtNSECURBrkup.Value = Decimal.One;
          if (clientLimit.NsecurBrkup > 0)
          {
            this.txtNSECURBrkup.Value = Convert.ToDecimal(clientLimit.NsecurBrkup);
            this.txtNSECURBrkup.UpButton();
            this.txtNSECURBrkup.DownButton();
          }
          this.TurnoverMulti.Value = Decimal.One;
          this.TurnoverMulti.Value = (Decimal) clientLimit.turnmulti;
          this.txtMTMmulti.Value = Decimal.One;
          this.txtMTMmulti.Value = (Decimal) clientLimit.mtmmulti;
          this.chk_MCX.Checked = brkgType.mcx == 1;
          this.chk_lot_Brkg_MCX.Checked = brkgType.mcx == 2;
          this.chk_NSEFUT.Checked = brkgType.nsefut == 1;
          this.chk_lot_Brkg_NSEFUT.Checked = brkgType.nsefut == 2;
          this.chk_Ncdex.Checked = brkgType.ncdex == 1;
          this.chk_lot_Brkg_NCDEX.Checked = brkgType.ncdex == 2;
          this.chk_Nsecur.Checked = brkgType.nsecurr == 1;
          this.chk_lot_Brkg_NSECUR.Checked = brkgType.nsecurr == 2;
          MaskedTextBox txtIntrdymcx = this.txtIntrdymcx;
          num1 = clientLimit.mcxIntrdybrkg;
          string str2 = num1.ToString();
          txtIntrdymcx.Text = str2;
          MaskedTextBox txtIntrdynsefut = this.txtIntrdynsefut;
          num1 = clientLimit.nsefutIntrdybrkg;
          string str3 = num1.ToString();
          txtIntrdynsefut.Text = str3;
          MaskedTextBox txtIntrdyncdex = this.txtIntrdyncdex;
          num1 = clientLimit.ncdexIntrdybrkg;
          string str4 = num1.ToString();
          txtIntrdyncdex.Text = str4;
          MaskedTextBox txtIntrdynsecurr = this.txtIntrdynsecurr;
          num1 = clientLimit.nsecurrIntrdybrkg;
          string str5 = num1.ToString();
          txtIntrdynsecurr.Text = str5;
          MaskedTextBox txtCnfMcx = this.txtCnfMcx;
          num1 = clientLimit.mcxCnfbrkg;
          string str6 = num1.ToString();
          txtCnfMcx.Text = str6;
          MaskedTextBox txtCnfNseFut = this.txtCnfNseFut;
          num1 = clientLimit.nsefutCnfbrkg;
          string str7 = num1.ToString();
          txtCnfNseFut.Text = str7;
          MaskedTextBox txtCnfNcdex = this.txtCnfNcdex;
          num1 = clientLimit.ncdexCnfbrkg;
          string str8 = num1.ToString();
          txtCnfNcdex.Text = str8;
          MaskedTextBox txtCnfNseCurr = this.txtCnfNseCurr;
          num1 = clientLimit.nsecurrCnfbrkg;
          string str9 = num1.ToString();
          txtCnfNseCurr.Text = str9;
          if (clientLimit.brkupType == 1)
            this.rdoExchange.Checked = true;
          else
            this.rdosymbolwise1.Checked = true;
          switch (clientLimit.mrgntype)
          {
            case 1:
              this.rdoTurnoverwse.Checked = true;
              TextBox txtturnoverlimit1 = this.txtturnoverlimit;
              num1 = clientLimit.turnoverlimit;
              string str10 = num1.ToString();
              txtturnoverlimit1.Text = str10;
              break;
            case 2:
              this.rdolotwse.Checked = true;
              switch (clientLimit.lotwisetype)
              {
                case 1:
                  this.rdodefault.Checked = true;
                  break;
                case 2:
                  this.radioButton1.Checked = true;
                  this.txtMcxlots.Text = clientLimit.mcxlots.ToString();
                  this.txtncxlot.Text = clientLimit.ncxlots.ToString();
                  TextBox txtnselot1 = this.txtnselot;
                  int num2 = clientLimit.nsefutlots;
                  string str11 = num2.ToString();
                  txtnselot1.Text = str11;
                  TextBox txtnsecurrLots1 = this.txtnsecurrLots;
                  num2 = clientLimit.nsecurlots;
                  string str12 = num2.ToString();
                  txtnsecurrLots1.Text = str12;
                  break;
                case 3:
                  this.rdosymwise.Checked = true;
                  break;
              }
              break;
            case 3:
              this.rdoSymbolwise.Checked = true;
              break;
            case 4:
              this.rdoTurnoverwse.Checked = true;
              TextBox txtturnoverlimit2 = this.txtturnoverlimit;
              num1 = clientLimit.turnoverlimit;
              string str13 = num1.ToString();
              txtturnoverlimit2.Text = str13;
              this.rdolotwse.Checked = true;
              switch (clientLimit.lotwisetype)
              {
                case 1:
                  this.rdodefault.Checked = true;
                  break;
                case 2:
                  this.radioButton1.Checked = true;
                  this.txtMcxlots.Text = clientLimit.mcxlots.ToString();
                  this.txtncxlot.Text = clientLimit.ncxlots.ToString();
                  TextBox txtnselot2 = this.txtnselot;
                  int num3 = clientLimit.nsefutlots;
                  string str14 = num3.ToString();
                  txtnselot2.Text = str14;
                  TextBox txtnsecurrLots2 = this.txtnsecurrLots;
                  num3 = clientLimit.nsecurlots;
                  string str15 = num3.ToString();
                  txtnsecurrLots2.Text = str15;
                  break;
                case 3:
                  this.rdosymwise.Checked = true;
                  break;
              }
              break;
            case 5:
              this.rdoSymbolwise.Checked = true;
              this.rdolotwse.Checked = true;
              switch (clientLimit.lotwisetype)
              {
                case 1:
                  this.rdodefault.Checked = true;
                  break;
                case 2:
                  this.radioButton1.Checked = true;
                  this.txtMcxlots.Text = clientLimit.mcxlots.ToString();
                  this.txtncxlot.Text = clientLimit.ncxlots.ToString();
                  TextBox txtnselot3 = this.txtnselot;
                  int num4 = clientLimit.nsefutlots;
                  string str16 = num4.ToString();
                  txtnselot3.Text = str16;
                  TextBox txtnsecurrLots3 = this.txtnsecurrLots;
                  num4 = clientLimit.nsecurlots;
                  string str17 = num4.ToString();
                  txtnsecurrLots3.Text = str17;
                  break;
                case 3:
                  this.rdosymwise.Checked = true;
                  break;
              }
              break;
            case 6:
              this.rdoTurnoverwse.Checked = true;
              TextBox txtturnoverlimit3 = this.txtturnoverlimit;
              num1 = clientLimit.turnoverlimit;
              string str18 = num1.ToString();
              txtturnoverlimit3.Text = str18;
              this.rdoSymbolwise.Checked = true;
              switch (clientLimit.lotwisetype)
              {
                case 1:
                  this.rdodefault.Checked = true;
                  break;
                case 2:
                  this.radioButton1.Checked = true;
                  this.txtMcxlots.Text = clientLimit.mcxlots.ToString();
                  this.txtncxlot.Text = clientLimit.ncxlots.ToString();
                  TextBox txtnselot4 = this.txtnselot;
                  int num5 = clientLimit.nsefutlots;
                  string str19 = num5.ToString();
                  txtnselot4.Text = str19;
                  TextBox txtnsecurrLots4 = this.txtnsecurrLots;
                  num5 = clientLimit.nsecurlots;
                  string str20 = num5.ToString();
                  txtnsecurrLots4.Text = str20;
                  break;
                case 3:
                  this.rdosymwise.Checked = true;
                  break;
              }
              break;
            case 7:
              this.rdoTurnoverwse.Checked = true;
              TextBox txtturnoverlimit4 = this.txtturnoverlimit;
              num1 = clientLimit.turnoverlimit;
              string str21 = num1.ToString();
              txtturnoverlimit4.Text = str21;
              this.rdoSymbolwise.Checked = true;
              this.rdolotwse.Checked = true;
              switch (clientLimit.lotwisetype)
              {
                case 1:
                  this.rdodefault.Checked = true;
                  break;
                case 2:
                  this.radioButton1.Checked = true;
                  this.txtMcxlots.Text = clientLimit.mcxlots.ToString();
                  this.txtncxlot.Text = clientLimit.ncxlots.ToString();
                  TextBox txtnselot5 = this.txtnselot;
                  int num6 = clientLimit.nsefutlots;
                  string str22 = num6.ToString();
                  txtnselot5.Text = str22;
                  TextBox txtnsecurrLots5 = this.txtnsecurrLots;
                  num6 = clientLimit.nsecurlots;
                  string str23 = num6.ToString();
                  txtnsecurrLots5.Text = str23;
                  break;
                case 3:
                  this.rdosymwise.Checked = true;
                  break;
              }
              break;
          }
          switch (clientLimit.tradeattributes)
          {
            case 1:
              this.rdofully.Checked = true;
              break;
            case 2:
              this.rdoclose.Checked = true;
              break;
            case 3:
              this.rdoblock.Checked = true;
              break;
          }
          if (clientLimit.isIntrasqoff == 1)
            this.chkIntraSqoff.Checked = true;
          if (clientLimit.IsMrgnsqoff == 1)
            this.chkMrgnSqOff.Checked = true;
          if (clientLimit.possitionValidity.Contains(","))
          {
            string[] strArray = clientLimit.possitionValidity.Split(',');
            for (int index = 0; index < strArray.Length; ++index)
            {
              if (strArray[index] != string.Empty)
                this.MarkValidity(strArray[index]);
            }
          }
          else if (clientLimit.possitionValidity != null)
            this.MarkValidity(clientLimit.possitionValidity);
          if (clientLimit.Productype.Contains(","))
          {
            string[] strArray = clientLimit.Productype.Split(',');
            for (int index = 0; index < strArray.Length; ++index)
            {
              if (strArray[index] != string.Empty)
              {
                if (strArray[index] == "RL")
                  this.chkRL.Checked = true;
                else if (strArray[index] == "SL")
                  this.chkSL.Checked = true;
                else if (strArray[index] == "MKT")
                  this.chkMkt.Checked = true;
              }
            }
          }
          else if (clientLimit.Productype != null && clientLimit.Productype != string.Empty)
          {
            if (clientLimit.Productype.ToUpper() == "RL")
              this.chkRL.Checked = true;
            else if (clientLimit.Productype.ToUpper() == "SL")
              this.chkSL.Checked = true;
            else if (clientLimit.Productype.ToUpper() == "MKT")
              this.chkMkt.Checked = true;
          }
          if (clientLimit.PendingOrderExec <= 1)
            this.rdoPendingOnLTP.Checked = true;
          else if (clientLimit.PendingOrderExec == 2)
            this.rdoPendingOnBidAsk.Checked = true;
        }
      }
    }

    private void MarkValidity(string validity)
    {
      string upper = validity.ToUpper();
      if (!(upper == "DAY"))
      {
        if (!(upper == "CARRYFORWARD"))
        {
          if (!(upper == "GTC"))
            return;
          this.chkGTC.Checked = true;
        }
        else
          this.chkCnF.Checked = true;
      }
      else
        this.chkDay.Checked = true;
    }

    private void radioButton1_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.radioButton1.Checked)
        return;
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.lblMcxLots.Visible = true;
            this.txtMcxlots.Visible = true;
            this.lblMcxlots1.Visible = true;
            break;
          case 2:
            this.lblNsefutLots.Visible = true;
            this.txtnselot.Visible = true;
            this.lblNsefutLots1.Visible = true;
            break;
          case 3:
            this.txtncxlot.Visible = true;
            this.lblNcdexLots.Visible = true;
            this.lblNcdexLots1.Visible = true;
            break;
          case 4:
            this.lblNsecurrLots.Visible = true;
            this.lblNsecurrLots1.Visible = true;
            this.txtnsecurrLots.Visible = true;
            break;
        }
      }
    }

    private void btnset_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      Decimal result = new Decimal();
      if (this.txtaccno.Text != string.Empty)
      {
        this.registerBrkgTypes();
        if (this.txtmtmlimit.Text == string.Empty)
          str += "Enter MTM Loss Limit\n";
        if (this.chk_MCX.Checked && (this.txtIntrdymcx.Text == string.Empty || !Decimal.TryParse(this.txtIntrdymcx.Text, out result)))
          str += "Enter Intraday MCX Brokerage %\n";
        if (this.chk_NSEFUT.Checked && (this.txtIntrdynsefut.Text == string.Empty || !Decimal.TryParse(this.txtIntrdynsefut.Text, out result)))
          str += "Enter Intraday NSE FUT Brokerage %\n";
        if (this.chk_Nsecur.Checked && (this.txtIntrdynsecurr.Text == string.Empty || !Decimal.TryParse(this.txtIntrdynsecurr.Text, out result)))
          str += "Enter Intraday NSE CURRENCY Brokerage %\n";
        if (this.chk_Ncdex.Checked && (this.txtIntrdyncdex.Text == string.Empty || !Decimal.TryParse(this.txtIntrdyncdex.Text, out result)))
          str += "Enter Intraday NCDEX Brokerage %\n";
        if (this.chk_MCX.Checked && (this.txtCnfMcx.Text == string.Empty || !Decimal.TryParse(this.txtCnfMcx.Text, out result)))
          str += "Enter CNF MCX Brokerage %\n";
        if (this.chk_NSEFUT.Checked && (this.txtCnfNseFut.Text == string.Empty || !Decimal.TryParse(this.txtCnfNseFut.Text, out result)))
          str += "Enter CNF NSE FUT Brokerage %\n";
        if (this.chk_Ncdex.Checked && (this.txtCnfNcdex.Text == string.Empty || !Decimal.TryParse(this.txtCnfNcdex.Text, out result)))
          str += "Enter CNF NCDEX Brokerage %\n";
        if (this.chk_Nsecur.Checked && (this.txtCnfNseCurr.Text == string.Empty || !Decimal.TryParse(this.txtCnfNseCurr.Text, out result)))
          str += "Enter CNF NSE CURRENCY Brokerage %\n";
        if (this.rdoTurnoverwse.Checked && this.txtturnoverlimit.Text == string.Empty)
          str += "Enter Turnover Limit\n";
        if (this.rdolotwse.Checked && this.radioButton1.Checked)
        {
          if (this.txtMcxlots.Text == string.Empty)
            str += "Enter MCX Lots\n";
          if (this.txtnselot.Text == string.Empty)
            str += "Enter NSE FUT Lots\n";
          if (this.txtncxlot.Text == string.Empty)
            str += "Enter NCDEX Lots\n";
          if (this.txtnsecurrLots.Text == string.Empty)
            str += "Enter NSE CURRENCY Lots\n";
        }
        if (this.objdash._Userinformation.ContainsKey(this.txtaccno.Text) && (this.objdash._Userinformation[this.txtaccno.Text].oddlot == 1 && this.objdash._ClientBrokerageType[this.txtaccno.Text.Trim()].nsefut == 2))
          str += "Cannot select Margin type and Brokerage type other than Turnover as Trading type is 'Odd lot trading' for this Client.\n";
        if (!this.chkCnF.Checked && !this.chkDay.Checked && !this.chkGTC.Checked)
          str = "Select atleast one Trade Validity Attribute.\n";
        if (!this.chkRL.Checked && !this.chkSL.Checked && !this.chkMkt.Checked)
          str = "Select atleast one Trade Type Attribute.\n";
        if (!this.rdoTurnoverwse.Checked && !this.rdolotwse.Checked && !this.rdoSymbolwise.Checked)
          str = "Select atleast one Trading Margin.\n";
        if (!this.ValidateDAMargin(Convert.ToDouble(this.txtcashmargin.Text.Trim())))
        {
          if (str == string.Empty)
          {
            Limits objlimits = new Limits()
            {
              clientcode = this.txtaccno.Text.Trim(),
              cashmrgn = Convert.ToDecimal(this.txtcashmargin.Text.Trim()) * new Decimal(100),
              mtmlosslimit = Convert.ToDecimal(this.txtmtmlimit.Text.Trim()) * new Decimal(100),
              turnmulti = Convert.ToInt32(this.TurnoverMulti.Value),
              mtmmulti = Convert.ToInt32(this.txtMTMmulti.Value),
              McxBrkup = Convert.ToInt32(this.txtMCXBrkup.Value),
              NsefutBrkup = Convert.ToInt32(this.txtNSEFUTBrkup.Value),
              NcdexBrkup = Convert.ToInt32(this.txtNCDEXBrkup.Value),
              NsecurBrkup = Convert.ToInt32(this.txtNSECURBrkup.Value)
            };
            if (this.rdoExchange.Checked)
              objlimits.brkupType = 1;
            else if (this.rdosymbolwise1.Checked)
              objlimits.brkupType = 2;
            if (this.rdoTurnoverwse.Checked)
            {
              objlimits.mrgntype = 1;
              objlimits.turnoverlimit = Convert.ToDecimal(this.txtturnoverlimit.Text.Trim()) * new Decimal(100);
            }
            else if (this.rdolotwse.Checked)
            {
              objlimits.mrgntype = 2;
              if (this.rdodefault.Checked)
                objlimits.lotwisetype = 1;
              else if (this.radioButton1.Checked)
              {
                objlimits.lotwisetype = 2;
                objlimits.mcxlots = Convert.ToInt32(this.txtMcxlots.Text);
                objlimits.ncxlots = Convert.ToInt32(this.txtncxlot.Text);
                objlimits.nsefutlots = Convert.ToInt32(this.txtnselot.Text);
                objlimits.nsecurlots = Convert.ToInt32(this.txtnsecurrLots.Text);
              }
              else if (this.rdosymwise.Checked)
                objlimits.lotwisetype = 3;
            }
            else if (this.rdoSymbolwise.Checked)
              objlimits.mrgntype = 3;
            if (this.rdoTurnoverwse.Checked && this.rdolotwse.Checked)
            {
              objlimits.mrgntype = 4;
              objlimits.turnoverlimit = Convert.ToDecimal(this.txtturnoverlimit.Text.Trim()) * new Decimal(100);
              if (this.rdodefault.Checked)
                objlimits.lotwisetype = 1;
              else if (this.radioButton1.Checked)
              {
                objlimits.lotwisetype = 2;
                objlimits.mcxlots = Convert.ToInt32(this.txtMcxlots.Text);
                objlimits.ncxlots = Convert.ToInt32(this.txtncxlot.Text);
                objlimits.nsefutlots = Convert.ToInt32(this.txtnselot.Text);
                objlimits.nsecurlots = Convert.ToInt32(this.txtnsecurrLots.Text);
              }
              else if (this.rdosymwise.Checked)
                objlimits.lotwisetype = 3;
            }
            if (this.rdolotwse.Checked && this.rdoSymbolwise.Checked)
            {
              objlimits.mrgntype = 5;
              if (this.rdodefault.Checked)
                objlimits.lotwisetype = 1;
              else if (this.radioButton1.Checked)
              {
                objlimits.lotwisetype = 2;
                objlimits.mcxlots = Convert.ToInt32(this.txtMcxlots.Text);
                objlimits.ncxlots = Convert.ToInt32(this.txtncxlot.Text);
                objlimits.nsefutlots = Convert.ToInt32(this.txtnselot.Text);
                objlimits.nsecurlots = Convert.ToInt32(this.txtnsecurrLots.Text);
              }
              else if (this.rdosymwise.Checked)
                objlimits.lotwisetype = 3;
            }
            if (this.rdoTurnoverwse.Checked && this.rdoSymbolwise.Checked)
            {
              objlimits.mrgntype = 6;
              objlimits.turnoverlimit = Convert.ToDecimal(this.txtturnoverlimit.Text.Trim()) * new Decimal(100);
            }
            if (this.rdoTurnoverwse.Checked && this.rdoSymbolwise.Checked && this.rdolotwse.Checked)
            {
              objlimits.mrgntype = 7;
              objlimits.turnoverlimit = Convert.ToDecimal(this.txtturnoverlimit.Text.Trim()) * new Decimal(100);
              if (this.rdodefault.Checked)
                objlimits.lotwisetype = 1;
              else if (this.radioButton1.Checked)
              {
                objlimits.lotwisetype = 2;
                objlimits.mcxlots = Convert.ToInt32(this.txtMcxlots.Text);
                objlimits.ncxlots = Convert.ToInt32(this.txtncxlot.Text);
                objlimits.nsefutlots = Convert.ToInt32(this.txtnselot.Text);
                objlimits.nsecurlots = Convert.ToInt32(this.txtnsecurrLots.Text);
              }
              else if (this.rdosymwise.Checked)
                objlimits.lotwisetype = 3;
            }
            objlimits.mcxIntrdybrkg = this.chk_MCX.Checked ? Convert.ToDecimal(this.txtIntrdymcx.Text) : Decimal.Zero;
            objlimits.nsefutIntrdybrkg = this.chk_NSEFUT.Checked ? Convert.ToDecimal(this.txtIntrdynsefut.Text) : Decimal.Zero;
            objlimits.ncdexIntrdybrkg = this.chk_Ncdex.Checked ? Convert.ToDecimal(this.txtIntrdyncdex.Text) : Decimal.Zero;
            objlimits.nsecurrIntrdybrkg = this.chk_Nsecur.Checked ? Convert.ToDecimal(this.txtIntrdynsecurr.Text) : Decimal.Zero;
            objlimits.mcxCnfbrkg = this.chk_MCX.Checked ? Convert.ToDecimal(this.txtCnfMcx.Text) : Decimal.Zero;
            objlimits.nsefutCnfbrkg = this.chk_NSEFUT.Checked ? Convert.ToDecimal(this.txtCnfNseFut.Text) : Decimal.Zero;
            objlimits.ncdexCnfbrkg = this.chk_Ncdex.Checked ? Convert.ToDecimal(this.txtCnfNcdex.Text) : Decimal.Zero;
            objlimits.nsecurrCnfbrkg = this.chk_Nsecur.Checked ? Convert.ToDecimal(this.txtCnfNseCurr.Text) : Decimal.Zero;
            if (this.rdofully.Checked)
              objlimits.tradeattributes = 1;
            else if (this.rdoclose.Checked)
              objlimits.tradeattributes = 2;
            else if (this.rdoblock.Checked)
              objlimits.tradeattributes = 3;
            if (this.chkIntraSqoff.Checked)
              objlimits.isIntrasqoff = 1;
            if (this.chkMrgnSqOff.Checked)
              objlimits.IsMrgnsqoff = 1;
            if (this.chkCnF.Checked)
              objlimits.possitionValidity += "CarryForward,";
            if (this.chkDay.Checked)
              objlimits.possitionValidity += "Day,";
            if (this.chkGTC.Checked)
              objlimits.possitionValidity += "GTC";
            if (this.chkRL.Checked)
              objlimits.Productype += "RL,";
            if (this.chkSL.Checked)
              objlimits.Productype += "SL";
            if (this.chkMkt.Checked)
              objlimits.Productype = "MKT";
            if (this.rdoPendingOnLTP.Checked)
              objlimits.PendingOrderExec = 1;
            else if (this.rdoPendingOnBidAsk.Checked)
              objlimits.PendingOrderExec = 2;
            BrkgType _data = new BrkgType();
            _data.clientCode = objlimits.clientcode;
            if (this.chk_MCX.Checked)
              _data.mcx = 1;
            else if (this.chk_lot_Brkg_MCX.Checked)
              _data.mcx = 2;
            if (this.chk_NSEFUT.Checked)
              _data.nsefut = 1;
            else if (this.chk_lot_Brkg_NSEFUT.Checked)
              _data.nsefut = 2;
            if (this.chk_Ncdex.Checked)
              _data.ncdex = 1;
            else if (this.chk_lot_Brkg_NCDEX.Checked)
              _data.ncdex = 2;
            if (this.chk_Nsecur.Checked)
              _data.nsecurr = 1;
            else if (this.chk_lot_Brkg_NSECUR.Checked)
              _data.nsecurr = 2;
            if (Limits.SaveLimits(this.conn, objlimits) > 0)
            {
              if (BrkgType.SaveBrkgType(this.conn, _data))
                this.objdash.ManageBrokerageType(_data);
              objlimits.cashmrgn /= new Decimal(100);
              objlimits.mtmlosslimit /= new Decimal(100);
              if (objlimits.turnoverlimit > Decimal.Zero)
                objlimits.turnoverlimit /= new Decimal(100);
              this.objdash.ManageLimitset(objlimits);
              this.UpdateDAMargin();
              this.objdash.InsertMessage(objlimits.clientcode, " Funds Updated by Admin", 1);
              this.objdash.DisplayMessage("Limits saved successfully!!", 1);
            }
            else
              this.objdash.DisplayMessage("Unable to Save Limits", 3);
          }
          else
            this.objdash.DisplayMessage(str + "These Fields are Mandatory", 2);
        }
        else
          this.objdash.DisplayMessage("New Cash Margin definition exceeding Allocated Margin.", 2);
      }
      else
        this.objdash.DisplayMessage("Select Clientcode to Set Limits.", 2);
    }

    private void btnreset_Click(object sender, EventArgs e)
    {
      if (this.txtaccno.Text != string.Empty && MessageBox.Show("Do you really want to reset this user? All the information of this user will be removed.", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes && this.conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("ResetUser", this.conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.txtaccno.Text);
          try
          {
            if (sqlCommand2.ExecuteNonQuery() > 0)
              this.objdash.DisplayMessage("User id reset successful!!", 1);
            else
              this.objdash.DisplayMessage("User id reset failed, try again later", 2);
          }
          catch
          {
            this.objdash.DisplayMessage("User id reset failed, try again later", 3);
          }
        }
      }
      this.ClearControls((Control) this);
    }

    private void chkMkt_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.chkMkt.Checked)
        return;
      this.chkRL.Checked = false;
      this.chkSL.Checked = false;
    }

    private void txtClientCode_TextChanged(object sender, EventArgs e)
    {
      this.txtName.Text = "";
      if (this.txtClientCode.Text.Length > 0)
        this.FilterUsers(0, this.txtClientCode.Text.Trim(), 1);
      else
        this.FilterUsers(0, "", 0);
    }

    private void FilterUsers(int cell, string text, int type)
    {
      if (type == 1)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvLimits.Rows)
        {
          if (row.Cells[cell].Value.ToString().StartsWith(text, StringComparison.CurrentCultureIgnoreCase))
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvLimits.Rows)
          row.Visible = true;
      }
    }

    private void txtName_TextChanged(object sender, EventArgs e)
    {
      this.txtClientCode.Text = "";
      if (this.txtName.Text.Length > 0)
        this.FilterUsers(1, this.txtName.Text.Trim(), 1);
      else
        this.FilterUsers(0, "", 0);
    }

    private void btnFlushASOD_Click(object sender, EventArgs e)
    {
      if (this.txtaccno.Text == string.Empty)
        this.objdash.DisplayMessage("Please select Clientcode to Flush Auto Sq-Off Data.", 2);
      else if (this.ExecuteQuery("Insert into Orders_History (Symbol,Exch,BuySell,Productype,Qty,OrdPrice,Price,Orderno,Validity,Userremarks,Clientcode, Traderid,Createon,Lastmodified,OrdStatus,IsAdmin,IsMaintenance,ExecType) Select Symbol,Exch,BuySell,Productype,Qty,OrdPrice,Price,Orderno,Validity,   Userremarks, Clientcode,Traderid,Createon,Lastmodified,OrdStatus,IsAdmin,IsMaintenance,ExecType from Orders where ClientCode = '" + this.txtaccno.Text.Trim() + "'") & this.ExecuteQuery("Delete from Orders  where ClientCode = '" + this.txtaccno.Text.Trim() + "'") & this.ExecuteQuery("Insert into Trade_History Select Clientcode,Symbol,Qty,Orderno,Price,[Timestamp],BuySell,Exch from Trade  where ClientCode = '" + this.txtaccno.Text.Trim() + "'") & this.ExecuteQuery("Delete from Trade where ClientCode = '" + this.txtaccno.Text.Trim() + "'"))
        this.objdash.DisplayMessage("Auto Square Off Data Flushed Successfully!!", 1);
      else
        this.objdash.DisplayMessage("Unable to Flush Auto Square Off Data", 3);
    }

    private bool ExecuteQuery(string Query)
    {
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return false;
      using (SqlCommand sqlCommand = new SqlCommand(Query, conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    private void UpdateDAMargin()
    {
      double utilisedMargin = this.GetUtilisedMargin();
      this.lblUtilisedMrgn.Text = utilisedMargin.ToString();
      if (this.objdash.objinfo.DAfund <= 0.0)
        return;
      this.lblAvailMrgn.Text = Math.Round(this.objdash.objinfo.DAfund - utilisedMargin, 2).ToString();
    }

    private double GetUtilisedMargin()
    {
      double num = 0.0;
      foreach (KeyValuePair<string, Limits> clientLimit in this.objdash._ClientLimits)
        num += Convert.ToDouble(clientLimit.Value.cashmrgn);
      return num;
    }

    private bool ValidateDAMargin(double clientmrgn)
    {
      this.GetUtilisedMargin();
      return false;
    }

    private void chk_MCX_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_MCX.Checked)
      {
        this.txtIntrdymcx.Enabled = this.txtCnfMcx.Enabled = true;
        this.chk_lot_Brkg_MCX.Enabled = false;
      }
      else
      {
        this.txtIntrdymcx.Enabled = this.txtCnfMcx.Enabled = false;
        this.chk_lot_Brkg_MCX.Enabled = true;
      }
    }

    private void chk_NSEFUT_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_NSEFUT.Checked)
      {
        this.txtIntrdynsefut.Enabled = this.txtCnfNseFut.Enabled = true;
        this.chk_lot_Brkg_NSEFUT.Enabled = false;
      }
      else
      {
        this.txtIntrdynsefut.Enabled = this.txtCnfNseFut.Enabled = false;
        this.chk_lot_Brkg_NSEFUT.Enabled = true;
        this.txtIntrdynsefut.Text = this.txtCnfNseFut.Text = "0";
      }
    }

    private void chk_Ncdex_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_Ncdex.Checked)
      {
        this.txtIntrdyncdex.Enabled = this.txtCnfNcdex.Enabled = true;
        this.chk_lot_Brkg_NCDEX.Enabled = false;
      }
      else
      {
        this.txtIntrdyncdex.Enabled = this.txtCnfNcdex.Enabled = false;
        this.txtIntrdyncdex.Text = this.txtCnfNcdex.Text = "0";
        this.chk_lot_Brkg_NCDEX.Enabled = true;
      }
    }

    private void chk_Nsecur_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_Nsecur.Checked)
      {
        this.txtIntrdynsecurr.Enabled = this.txtCnfNseCurr.Enabled = true;
        this.chk_lot_Brkg_NSECUR.Enabled = false;
      }
      else
      {
        this.txtIntrdynsecurr.Enabled = this.txtCnfNseCurr.Enabled = false;
        this.txtIntrdynsecurr.Text = this.txtCnfNseCurr.Text = "0";
        this.chk_lot_Brkg_NSECUR.Enabled = true;
      }
    }

    private void ManageBrkgTypeData(int exch, int type)
    {
      if (this.txtaccno.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Please select clientcode", 2);
      }
      else
      {
        BrkgType _data = new BrkgType();
        string text = this.txtaccno.Text;
        if (this.objdash._ClientBrokerageType.ContainsKey(text))
          _data = this.objdash._ClientBrokerageType[text];
        else
          _data.clientCode = text;
        switch (exch)
        {
          case 1:
            _data.mcx = type;
            break;
          case 2:
            _data.nsefut = type;
            break;
          case 3:
            _data.ncdex = type;
            break;
          case 4:
            _data.nsecurr = type;
            break;
        }
        this.objdash.ManageBrokerageType(_data);
      }
    }

    private void registerBrkgTypes()
    {
      if (this.chk_MCX.Checked)
        this.ManageBrkgTypeData(1, 1);
      else if (this.chk_lot_Brkg_MCX.Checked)
        this.ManageBrkgTypeData(1, 2);
      else
        this.ManageBrkgTypeData(1, 0);
      if (this.chk_NSEFUT.Checked)
        this.ManageBrkgTypeData(2, 1);
      else if (this.chk_lot_Brkg_NSEFUT.Checked)
        this.ManageBrkgTypeData(2, 2);
      else
        this.ManageBrkgTypeData(2, 0);
      if (this.chk_Ncdex.Checked)
        this.ManageBrkgTypeData(3, 1);
      else if (this.chk_lot_Brkg_NCDEX.Checked)
        this.ManageBrkgTypeData(3, 2);
      else
        this.ManageBrkgTypeData(3, 0);
      if (this.chk_Nsecur.Checked)
        this.ManageBrkgTypeData(4, 1);
      else if (this.chk_lot_Brkg_NSECUR.Checked)
        this.ManageBrkgTypeData(4, 2);
      else
        this.ManageBrkgTypeData(4, 0);
    }

    private void chk_lot_Brkg_MCX_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_lot_Brkg_MCX.Checked)
        this.chk_MCX.Enabled = false;
      else
        this.chk_MCX.Enabled = true;
    }

    private void chk_lot_Brkg_NSEFUT_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_lot_Brkg_NSEFUT.Checked)
        this.chk_NSEFUT.Enabled = false;
      else
        this.chk_NSEFUT.Enabled = true;
    }

    private void chk_lot_Brkg_NCDEX_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_lot_Brkg_NCDEX.Checked)
        this.chk_Ncdex.Enabled = false;
      else
        this.chk_Ncdex.Enabled = true;
    }

    private void chk_lot_Brkg_NSECUR_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chk_lot_Brkg_NSECUR.Checked)
        this.chk_Nsecur.Enabled = false;
      else
        this.chk_Nsecur.Enabled = true;
    }

    private void rdoExchange_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoExchange.Checked)
      {
        this.lblMCXBrkup.Visible = true;
        this.lblNsefutBrkup.Visible = true;
        this.lblNsecurBrkup.Visible = true;
        this.lblNcdexBrkup.Visible = true;
        this.txtMCXBrkup.Visible = true;
        this.txtNSEFUTBrkup.Visible = true;
        this.txtNSECURBrkup.Visible = true;
        this.txtNCDEXBrkup.Visible = true;
      }
      else
      {
        this.lblMCXBrkup.Visible = false;
        this.lblNsefutBrkup.Visible = false;
        this.lblNsecurBrkup.Visible = false;
        this.lblNcdexBrkup.Visible = false;
        this.txtMCXBrkup.Visible = false;
        this.txtNSEFUTBrkup.Visible = false;
        this.txtNSECURBrkup.Visible = false;
        this.txtNCDEXBrkup.Visible = false;
      }
    }

    private void rdosymbolwise1_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdosymbolwise1.Checked)
      {
        this.lblMCXBrkup.Visible = false;
        this.lblNsefutBrkup.Visible = false;
        this.lblNsecurBrkup.Visible = false;
        this.lblNcdexBrkup.Visible = false;
        this.txtMCXBrkup.Visible = false;
        this.txtNSEFUTBrkup.Visible = false;
        this.txtNSECURBrkup.Visible = false;
        this.txtNCDEXBrkup.Visible = false;
      }
      else
      {
        this.lblMCXBrkup.Visible = true;
        this.lblNsefutBrkup.Visible = true;
        this.lblNsecurBrkup.Visible = true;
        this.lblNcdexBrkup.Visible = true;
        this.txtMCXBrkup.Visible = true;
        this.txtNSEFUTBrkup.Visible = true;
        this.txtNSECURBrkup.Visible = true;
        this.txtNCDEXBrkup.Visible = true;
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvLimits = new DataGridView();
      this.ClientCode = new DataGridViewTextBoxColumn();
      this.frmName = new DataGridViewTextBoxColumn();
      this.groupBox1 = new GroupBox();
      this.numericUpDown1 = new NumericUpDown();
      this.label10 = new Label();
      this.txtLotBrkup = new NumericUpDown();
      this.label13 = new Label();
      this.txtaccno = new TextBox();
      this.label9 = new Label();
      this.txtusername = new TextBox();
      this.label18 = new Label();
      this.label14 = new Label();
      this.txtmtmlimit = new TextBox();
      this.txtcashmargin = new TextBox();
      this.label3 = new Label();
      this.groupBox3 = new GroupBox();
      this.TurnoverMulti = new NumericUpDown();
      this.label2 = new Label();
      this.txtMTMmulti = new NumericUpDown();
      this.label7 = new Label();
      this.button2 = new Button();
      this.btnapply = new Button();
      this.groupBox2 = new GroupBox();
      this.rdoblock = new RadioButton();
      this.rdoclose = new RadioButton();
      this.rdofully = new RadioButton();
      this.groupBox5 = new GroupBox();
      this.groupBox13 = new GroupBox();
      this.chk_lot_Brkg_NSECUR = new CheckBox();
      this.chk_lot_Brkg_NCDEX = new CheckBox();
      this.chk_lot_Brkg_NSEFUT = new CheckBox();
      this.chk_lot_Brkg_MCX = new CheckBox();
      this.label4 = new Label();
      this.maskedTextBox1 = new MaskedTextBox();
      this.maskedTextBox2 = new MaskedTextBox();
      this.maskedTextBox3 = new MaskedTextBox();
      this.maskedTextBox4 = new MaskedTextBox();
      this.label5 = new Label();
      this.maskedTextBox5 = new MaskedTextBox();
      this.maskedTextBox6 = new MaskedTextBox();
      this.maskedTextBox7 = new MaskedTextBox();
      this.maskedTextBox8 = new MaskedTextBox();
      this.groupBox8 = new GroupBox();
      this.chk_Nsecur = new CheckBox();
      this.chk_Ncdex = new CheckBox();
      this.chk_NSEFUT = new CheckBox();
      this.chk_MCX = new CheckBox();
      this.label22 = new Label();
      this.txtCnfNseCurr = new MaskedTextBox();
      this.txtCnfMcx = new MaskedTextBox();
      this.txtCnfNseFut = new MaskedTextBox();
      this.txtCnfNcdex = new MaskedTextBox();
      this.label21 = new Label();
      this.txtIntrdynsecurr = new MaskedTextBox();
      this.txtIntrdymcx = new MaskedTextBox();
      this.txtIntrdynsefut = new MaskedTextBox();
      this.txtIntrdyncdex = new MaskedTextBox();
      this.groupBox6 = new GroupBox();
      this.chkMrgnSqOff = new CheckBox();
      this.chkIntraSqoff = new CheckBox();
      this.groupBox4 = new GroupBox();
      this.rdoSymbolwise = new CheckBox();
      this.rdoTurnoverwse = new CheckBox();
      this.rdolotwse = new CheckBox();
      this.groupBox7 = new GroupBox();
      this.lblNsecurrLots1 = new Label();
      this.lblNsecurrLots = new Label();
      this.txtnsecurrLots = new TextBox();
      this.rdosymwise = new RadioButton();
      this.rdodefault = new RadioButton();
      this.lblNsefutLots1 = new Label();
      this.lblMcxLots = new Label();
      this.radioButton1 = new RadioButton();
      this.lblNcdexLots1 = new Label();
      this.txtMcxlots = new TextBox();
      this.lblMcxlots1 = new Label();
      this.lblNsefutLots = new Label();
      this.lblNcdexLots = new Label();
      this.txtncxlot = new TextBox();
      this.txtnselot = new TextBox();
      this.label16 = new Label();
      this.txtturnoverlimit = new TextBox();
      this.btnFlushASOD = new Button();
      this.btnreset = new Button();
      this.btnset = new Button();
      this.groupBox9 = new GroupBox();
      this.chkGTC = new CheckBox();
      this.chkCnF = new CheckBox();
      this.chkDay = new CheckBox();
      this.groupBox10 = new GroupBox();
      this.chkMkt = new CheckBox();
      this.chkRL = new CheckBox();
      this.chkSL = new CheckBox();
      this.txtClientCode = new TextBox();
      this.txtName = new TextBox();
      this.label1 = new Label();
      this.lblAllocatedMrgn = new Label();
      this.lblUtilisedMrgn = new Label();
      this.label6 = new Label();
      this.lblAvailMrgn = new Label();
      this.label11 = new Label();
      this.groupBox11 = new GroupBox();
      this.txtNSECURBrkup = new NumericUpDown();
      this.lblNsecurBrkup = new Label();
      this.txtNCDEXBrkup = new NumericUpDown();
      this.lblNcdexBrkup = new Label();
      this.txtNSEFUTBrkup = new NumericUpDown();
      this.lblNsefutBrkup = new Label();
      this.txtMCXBrkup = new NumericUpDown();
      this.lblMCXBrkup = new Label();
      this.groupBox12 = new GroupBox();
      this.rdoPendingOnBidAsk = new RadioButton();
      this.rdoPendingOnLTP = new RadioButton();
      this.rdoExchange = new RadioButton();
      this.rdosymbolwise1 = new RadioButton();
      ((ISupportInitialize) this.dgvLimits).BeginInit();
      this.groupBox1.SuspendLayout();
      this.numericUpDown1.BeginInit();
      this.txtLotBrkup.BeginInit();
      this.groupBox3.SuspendLayout();
      this.TurnoverMulti.BeginInit();
      this.txtMTMmulti.BeginInit();
      this.groupBox2.SuspendLayout();
      this.groupBox5.SuspendLayout();
      this.groupBox13.SuspendLayout();
      this.groupBox8.SuspendLayout();
      this.groupBox6.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.groupBox7.SuspendLayout();
      this.groupBox9.SuspendLayout();
      this.groupBox10.SuspendLayout();
      this.groupBox11.SuspendLayout();
      this.txtNSECURBrkup.BeginInit();
      this.txtNCDEXBrkup.BeginInit();
      this.txtNSEFUTBrkup.BeginInit();
      this.txtMCXBrkup.BeginInit();
      this.groupBox12.SuspendLayout();
      this.SuspendLayout();
      this.dgvLimits.AllowUserToAddRows = false;
      this.dgvLimits.AllowUserToDeleteRows = false;
      this.dgvLimits.AllowUserToOrderColumns = true;
      this.dgvLimits.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
      this.dgvLimits.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvLimits.BackgroundColor = Color.White;
      this.dgvLimits.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvLimits.Columns.AddRange((DataGridViewColumn) this.ClientCode, (DataGridViewColumn) this.frmName);
      this.dgvLimits.Location = new Point(3, 26);
      this.dgvLimits.Name = "dgvLimits";
      this.dgvLimits.ReadOnly = true;
      this.dgvLimits.RowHeadersVisible = false;
      this.dgvLimits.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
      this.dgvLimits.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvLimits.Size = new Size(203, 529);
      this.dgvLimits.TabIndex = 0;
      this.dgvLimits.CellClick += new DataGridViewCellEventHandler(this.dgvLimits_CellClick);
      this.ClientCode.HeaderText = "ClientCode";
      this.ClientCode.Name = "ClientCode";
      this.ClientCode.ReadOnly = true;
      this.frmName.HeaderText = "Name";
      this.frmName.Name = "frmName";
      this.frmName.ReadOnly = true;
      this.groupBox1.Controls.Add((Control) this.numericUpDown1);
      this.groupBox1.Controls.Add((Control) this.label10);
      this.groupBox1.Controls.Add((Control) this.txtLotBrkup);
      this.groupBox1.Controls.Add((Control) this.label13);
      this.groupBox1.Controls.Add((Control) this.txtaccno);
      this.groupBox1.Controls.Add((Control) this.label9);
      this.groupBox1.Controls.Add((Control) this.txtusername);
      this.groupBox1.Controls.Add((Control) this.label18);
      this.groupBox1.Controls.Add((Control) this.label14);
      this.groupBox1.Controls.Add((Control) this.txtmtmlimit);
      this.groupBox1.Controls.Add((Control) this.txtcashmargin);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Location = new Point(212, 27);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(270, 117);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Limits";
      this.numericUpDown1.Location = new Point(112, 141);
      this.numericUpDown1.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.numericUpDown1.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.numericUpDown1.Name = "numericUpDown1";
      this.numericUpDown1.ReadOnly = true;
      this.numericUpDown1.Size = new Size(125, 20);
      this.numericUpDown1.TabIndex = 5;
      this.numericUpDown1.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.numericUpDown1.Visible = false;
      this.label10.AutoSize = true;
      this.label10.ForeColor = Color.Black;
      this.label10.Location = new Point(8, 141);
      this.label10.Name = "label10";
      this.label10.Size = new Size(72, 13);
      this.label10.TabIndex = 59;
      this.label10.Text = "Net Day Lots:";
      this.label10.Visible = false;
      this.txtLotBrkup.Location = new Point(112, 116);
      this.txtLotBrkup.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.txtLotBrkup.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtLotBrkup.Name = "txtLotBrkup";
      this.txtLotBrkup.Size = new Size(125, 20);
      this.txtLotBrkup.TabIndex = 4;
      this.txtLotBrkup.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtLotBrkup.Visible = false;
      this.label13.AutoSize = true;
      this.label13.ForeColor = Color.Black;
      this.label13.Location = new Point(8, 45);
      this.label13.Name = "label13";
      this.label13.Size = new Size(63, 13);
      this.label13.TabIndex = 56;
      this.label13.Text = "Client code:";
      this.txtaccno.BackColor = Color.WhiteSmoke;
      this.txtaccno.ForeColor = Color.Black;
      this.txtaccno.Location = new Point(112, 42);
      this.txtaccno.Name = "txtaccno";
      this.txtaccno.ReadOnly = true;
      this.txtaccno.Size = new Size(125, 20);
      this.txtaccno.TabIndex = 1;
      this.label9.AutoSize = true;
      this.label9.ForeColor = Color.Black;
      this.label9.Location = new Point(8, 115);
      this.label9.Name = "label9";
      this.label9.Size = new Size(76, 13);
      this.label9.TabIndex = 57;
      this.label9.Text = "Breakup(Lots):";
      this.label9.Visible = false;
      this.txtusername.BackColor = Color.WhiteSmoke;
      this.txtusername.ForeColor = Color.Black;
      this.txtusername.Location = new Point(112, 17);
      this.txtusername.Name = "txtusername";
      this.txtusername.ReadOnly = true;
      this.txtusername.Size = new Size(125, 20);
      this.txtusername.TabIndex = 0;
      this.label18.AutoSize = true;
      this.label18.ForeColor = Color.Black;
      this.label18.Location = new Point(8, 21);
      this.label18.Name = "label18";
      this.label18.Size = new Size(38, 13);
      this.label18.TabIndex = 55;
      this.label18.Text = "Name:";
      this.label14.AutoSize = true;
      this.label14.ForeColor = Color.Black;
      this.label14.Location = new Point(8, 91);
      this.label14.Name = "label14";
      this.label14.Size = new Size(96, 13);
      this.label14.TabIndex = 54;
      this.label14.Text = "M To M Loss Limit:";
      this.txtmtmlimit.BackColor = Color.WhiteSmoke;
      this.txtmtmlimit.ForeColor = Color.Black;
      this.txtmtmlimit.Location = new Point(112, 91);
      this.txtmtmlimit.Name = "txtmtmlimit";
      this.txtmtmlimit.ReadOnly = true;
      this.txtmtmlimit.Size = new Size(125, 20);
      this.txtmtmlimit.TabIndex = 3;
      this.txtcashmargin.BackColor = Color.WhiteSmoke;
      this.txtcashmargin.ForeColor = Color.Black;
      this.txtcashmargin.Location = new Point(112, 67);
      this.txtcashmargin.MaxLength = 12;
      this.txtcashmargin.Name = "txtcashmargin";
      this.txtcashmargin.Size = new Size(125, 20);
      this.txtcashmargin.TabIndex = 2;
      this.txtcashmargin.Text = "0";
      this.label3.AutoSize = true;
      this.label3.ForeColor = Color.Black;
      this.label3.Location = new Point(8, 69);
      this.label3.Name = "label3";
      this.label3.Size = new Size(69, 13);
      this.label3.TabIndex = 49;
      this.label3.Text = "Cash Margin:";
      this.groupBox3.Controls.Add((Control) this.TurnoverMulti);
      this.groupBox3.Controls.Add((Control) this.label2);
      this.groupBox3.Controls.Add((Control) this.txtMTMmulti);
      this.groupBox3.Controls.Add((Control) this.label7);
      this.groupBox3.Controls.Add((Control) this.button2);
      this.groupBox3.Controls.Add((Control) this.btnapply);
      this.groupBox3.ForeColor = SystemColors.ControlText;
      this.groupBox3.Location = new Point(486, 27);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(270, 117);
      this.groupBox3.TabIndex = 1;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Multipliers";
      this.TurnoverMulti.Location = new Point(113, 19);
      this.TurnoverMulti.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.TurnoverMulti.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.TurnoverMulti.Name = "TurnoverMulti";
      this.TurnoverMulti.Size = new Size(125, 20);
      this.TurnoverMulti.TabIndex = 0;
      this.TurnoverMulti.Value = new Decimal(new int[4]
      {
        300,
        0,
        0,
        0
      });
      this.label2.AutoSize = true;
      this.label2.ForeColor = Color.Black;
      this.label2.Location = new Point(3, 22);
      this.label2.Name = "label2";
      this.label2.Size = new Size(97, 13);
      this.label2.TabIndex = 46;
      this.label2.Text = "Turnover Multiplier:";
      this.txtMTMmulti.Location = new Point(113, 43);
      this.txtMTMmulti.Maximum = new Decimal(new int[4]
      {
        500,
        0,
        0,
        0
      });
      this.txtMTMmulti.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtMTMmulti.Name = "txtMTMmulti";
      this.txtMTMmulti.Size = new Size(125, 20);
      this.txtMTMmulti.TabIndex = 1;
      this.txtMTMmulti.Value = new Decimal(new int[4]
      {
        98,
        0,
        0,
        0
      });
      this.label7.AutoSize = true;
      this.label7.ForeColor = Color.Black;
      this.label7.Location = new Point(3, 46);
      this.label7.Name = "label7";
      this.label7.Size = new Size(79, 13);
      this.label7.TabIndex = 44;
      this.label7.Text = "MTM Multiplier:";
      this.button2.FlatStyle = FlatStyle.System;
      this.button2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.button2.ForeColor = Color.Navy;
      this.button2.Location = new Point(184, 78);
      this.button2.Name = "button2";
      this.button2.Size = new Size(54, 23);
      this.button2.TabIndex = 3;
      this.button2.Text = "Reset";
      this.button2.UseVisualStyleBackColor = true;
      this.btnapply.FlatStyle = FlatStyle.System;
      this.btnapply.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnapply.ForeColor = Color.Navy;
      this.btnapply.Location = new Point(115, 78);
      this.btnapply.Name = "btnapply";
      this.btnapply.Size = new Size(54, 23);
      this.btnapply.TabIndex = 2;
      this.btnapply.Text = "Apply";
      this.btnapply.UseVisualStyleBackColor = true;
      this.btnapply.Click += new EventHandler(this.btnapply_Click);
      this.groupBox2.Controls.Add((Control) this.rdoblock);
      this.groupBox2.Controls.Add((Control) this.rdoclose);
      this.groupBox2.Controls.Add((Control) this.rdofully);
      this.groupBox2.ForeColor = SystemColors.ControlText;
      this.groupBox2.Location = new Point(212, 328);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(270, 40);
      this.groupBox2.TabIndex = 4;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Trade Attributes";
      this.rdoblock.AutoSize = true;
      this.rdoblock.ForeColor = Color.Black;
      this.rdoblock.Location = new Point(173, 19);
      this.rdoblock.Name = "rdoblock";
      this.rdoblock.Size = new Size(52, 17);
      this.rdoblock.TabIndex = 2;
      this.rdoblock.Text = "Block";
      this.rdoblock.UseVisualStyleBackColor = true;
      this.rdoclose.AutoSize = true;
      this.rdoclose.ForeColor = Color.Black;
      this.rdoclose.Location = new Point(93, 19);
      this.rdoclose.Name = "rdoclose";
      this.rdoclose.Size = new Size(51, 17);
      this.rdoclose.TabIndex = 1;
      this.rdoclose.Text = "Close";
      this.rdoclose.UseVisualStyleBackColor = true;
      this.rdofully.AutoSize = true;
      this.rdofully.Checked = true;
      this.rdofully.ForeColor = Color.Black;
      this.rdofully.Location = new Point(18, 19);
      this.rdofully.Name = "rdofully";
      this.rdofully.Size = new Size(46, 17);
      this.rdofully.TabIndex = 0;
      this.rdofully.TabStop = true;
      this.rdofully.Text = "Fully";
      this.rdofully.UseVisualStyleBackColor = true;
      this.groupBox5.Controls.Add((Control) this.groupBox13);
      this.groupBox5.Controls.Add((Control) this.groupBox8);
      this.groupBox5.ForeColor = SystemColors.ControlText;
      this.groupBox5.Location = new Point(212, 149);
      this.groupBox5.Name = "groupBox5";
      this.groupBox5.Size = new Size(270, 176);
      this.groupBox5.TabIndex = 2;
      this.groupBox5.TabStop = false;
      this.groupBox5.Text = "Brokerage Type";
      this.groupBox13.Controls.Add((Control) this.chk_lot_Brkg_NSECUR);
      this.groupBox13.Controls.Add((Control) this.chk_lot_Brkg_NCDEX);
      this.groupBox13.Controls.Add((Control) this.chk_lot_Brkg_NSEFUT);
      this.groupBox13.Controls.Add((Control) this.chk_lot_Brkg_MCX);
      this.groupBox13.Controls.Add((Control) this.label4);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox1);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox2);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox3);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox4);
      this.groupBox13.Controls.Add((Control) this.label5);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox5);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox6);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox7);
      this.groupBox13.Controls.Add((Control) this.maskedTextBox8);
      this.groupBox13.ForeColor = SystemColors.ControlText;
      this.groupBox13.Location = new Point(188, 16);
      this.groupBox13.Name = "groupBox13";
      this.groupBox13.Size = new Size(81, 122);
      this.groupBox13.TabIndex = 22;
      this.groupBox13.TabStop = false;
      this.groupBox13.Text = "Lotwise";
      this.chk_lot_Brkg_NSECUR.AutoSize = true;
      this.chk_lot_Brkg_NSECUR.ForeColor = SystemColors.ControlText;
      this.chk_lot_Brkg_NSECUR.Location = new Point(5, 88);
      this.chk_lot_Brkg_NSECUR.Name = "chk_lot_Brkg_NSECUR";
      this.chk_lot_Brkg_NSECUR.Size = new Size(71, 17);
      this.chk_lot_Brkg_NSECUR.TabIndex = 21;
      this.chk_lot_Brkg_NSECUR.Text = "NSECUR";
      this.chk_lot_Brkg_NSECUR.UseVisualStyleBackColor = true;
      this.chk_lot_Brkg_NSECUR.CheckedChanged += new EventHandler(this.chk_lot_Brkg_NSECUR_CheckedChanged);
      this.chk_lot_Brkg_NCDEX.AutoSize = true;
      this.chk_lot_Brkg_NCDEX.ForeColor = SystemColors.ControlText;
      this.chk_lot_Brkg_NCDEX.Location = new Point(5, 66);
      this.chk_lot_Brkg_NCDEX.Name = "chk_lot_Brkg_NCDEX";
      this.chk_lot_Brkg_NCDEX.Size = new Size(63, 17);
      this.chk_lot_Brkg_NCDEX.TabIndex = 20;
      this.chk_lot_Brkg_NCDEX.Text = "NCDEX";
      this.chk_lot_Brkg_NCDEX.UseVisualStyleBackColor = true;
      this.chk_lot_Brkg_NCDEX.CheckedChanged += new EventHandler(this.chk_lot_Brkg_NCDEX_CheckedChanged);
      this.chk_lot_Brkg_NSEFUT.AutoSize = true;
      this.chk_lot_Brkg_NSEFUT.ForeColor = SystemColors.ControlText;
      this.chk_lot_Brkg_NSEFUT.Location = new Point(5, 44);
      this.chk_lot_Brkg_NSEFUT.Name = "chk_lot_Brkg_NSEFUT";
      this.chk_lot_Brkg_NSEFUT.Size = new Size(69, 17);
      this.chk_lot_Brkg_NSEFUT.TabIndex = 19;
      this.chk_lot_Brkg_NSEFUT.Text = "NSEFUT";
      this.chk_lot_Brkg_NSEFUT.UseVisualStyleBackColor = true;
      this.chk_lot_Brkg_NSEFUT.CheckedChanged += new EventHandler(this.chk_lot_Brkg_NSEFUT_CheckedChanged);
      this.chk_lot_Brkg_MCX.AutoSize = true;
      this.chk_lot_Brkg_MCX.ForeColor = SystemColors.ControlText;
      this.chk_lot_Brkg_MCX.Location = new Point(5, 22);
      this.chk_lot_Brkg_MCX.Name = "chk_lot_Brkg_MCX";
      this.chk_lot_Brkg_MCX.Size = new Size(49, 17);
      this.chk_lot_Brkg_MCX.TabIndex = 18;
      this.chk_lot_Brkg_MCX.Text = "MCX";
      this.chk_lot_Brkg_MCX.UseVisualStyleBackColor = true;
      this.chk_lot_Brkg_MCX.CheckedChanged += new EventHandler(this.chk_lot_Brkg_MCX_CheckedChanged);
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label4.ForeColor = SystemColors.ControlText;
      this.label4.Location = new Point(137, 7);
      this.label4.Name = "label4";
      this.label4.Size = new Size(31, 13);
      this.label4.TabIndex = 17;
      this.label4.Text = "CNF";
      this.maskedTextBox1.Enabled = false;
      this.maskedTextBox1.Location = new Point(132, 86);
      this.maskedTextBox1.Mask = "0.00000";
      this.maskedTextBox1.Name = "maskedTextBox1";
      this.maskedTextBox1.Size = new Size(45, 20);
      this.maskedTextBox1.TabIndex = 7;
      this.maskedTextBox1.Text = "0";
      this.maskedTextBox1.Visible = false;
      this.maskedTextBox2.Enabled = false;
      this.maskedTextBox2.Location = new Point(132, 22);
      this.maskedTextBox2.Mask = "0.00000";
      this.maskedTextBox2.Name = "maskedTextBox2";
      this.maskedTextBox2.Size = new Size(45, 20);
      this.maskedTextBox2.TabIndex = 1;
      this.maskedTextBox2.Text = "0";
      this.maskedTextBox2.Visible = false;
      this.maskedTextBox3.Enabled = false;
      this.maskedTextBox3.Location = new Point(132, 43);
      this.maskedTextBox3.Mask = "0.00000";
      this.maskedTextBox3.Name = "maskedTextBox3";
      this.maskedTextBox3.Size = new Size(45, 20);
      this.maskedTextBox3.TabIndex = 3;
      this.maskedTextBox3.Text = "0";
      this.maskedTextBox3.Visible = false;
      this.maskedTextBox4.Enabled = false;
      this.maskedTextBox4.Location = new Point(132, 64);
      this.maskedTextBox4.Mask = "0.00000";
      this.maskedTextBox4.Name = "maskedTextBox4";
      this.maskedTextBox4.Size = new Size(45, 20);
      this.maskedTextBox4.TabIndex = 5;
      this.maskedTextBox4.Text = "0";
      this.maskedTextBox4.Visible = false;
      this.label5.AutoSize = true;
      this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label5.ForeColor = SystemColors.ControlText;
      this.label5.Location = new Point(86, 7);
      this.label5.Name = "label5";
      this.label5.Size = new Size(39, 13);
      this.label5.TabIndex = 12;
      this.label5.Text = "Intrdy";
      this.maskedTextBox5.Enabled = false;
      this.maskedTextBox5.Location = new Point(81, 86);
      this.maskedTextBox5.Mask = "0.00000";
      this.maskedTextBox5.Name = "maskedTextBox5";
      this.maskedTextBox5.Size = new Size(45, 20);
      this.maskedTextBox5.TabIndex = 6;
      this.maskedTextBox5.Text = "0";
      this.maskedTextBox5.Visible = false;
      this.maskedTextBox6.Enabled = false;
      this.maskedTextBox6.Location = new Point(81, 22);
      this.maskedTextBox6.Mask = "0.00000";
      this.maskedTextBox6.Name = "maskedTextBox6";
      this.maskedTextBox6.Size = new Size(45, 20);
      this.maskedTextBox6.TabIndex = 0;
      this.maskedTextBox6.Text = "0";
      this.maskedTextBox6.Visible = false;
      this.maskedTextBox7.Enabled = false;
      this.maskedTextBox7.Location = new Point(81, 43);
      this.maskedTextBox7.Mask = "0.00000";
      this.maskedTextBox7.Name = "maskedTextBox7";
      this.maskedTextBox7.Size = new Size(45, 20);
      this.maskedTextBox7.TabIndex = 2;
      this.maskedTextBox7.Text = "0";
      this.maskedTextBox7.Visible = false;
      this.maskedTextBox8.Enabled = false;
      this.maskedTextBox8.Location = new Point(81, 64);
      this.maskedTextBox8.Mask = "0.00000";
      this.maskedTextBox8.Name = "maskedTextBox8";
      this.maskedTextBox8.Size = new Size(45, 20);
      this.maskedTextBox8.TabIndex = 4;
      this.maskedTextBox8.Text = "0";
      this.maskedTextBox8.Visible = false;
      this.groupBox8.Controls.Add((Control) this.chk_Nsecur);
      this.groupBox8.Controls.Add((Control) this.chk_Ncdex);
      this.groupBox8.Controls.Add((Control) this.chk_NSEFUT);
      this.groupBox8.Controls.Add((Control) this.chk_MCX);
      this.groupBox8.Controls.Add((Control) this.label22);
      this.groupBox8.Controls.Add((Control) this.txtCnfNseCurr);
      this.groupBox8.Controls.Add((Control) this.txtCnfMcx);
      this.groupBox8.Controls.Add((Control) this.txtCnfNseFut);
      this.groupBox8.Controls.Add((Control) this.txtCnfNcdex);
      this.groupBox8.Controls.Add((Control) this.label21);
      this.groupBox8.Controls.Add((Control) this.txtIntrdynsecurr);
      this.groupBox8.Controls.Add((Control) this.txtIntrdymcx);
      this.groupBox8.Controls.Add((Control) this.txtIntrdynsefut);
      this.groupBox8.Controls.Add((Control) this.txtIntrdyncdex);
      this.groupBox8.ForeColor = SystemColors.ControlText;
      this.groupBox8.Location = new Point(4, 16);
      this.groupBox8.Name = "groupBox8";
      this.groupBox8.Size = new Size(183, 122);
      this.groupBox8.TabIndex = 2;
      this.groupBox8.TabStop = false;
      this.groupBox8.Text = "Turnover";
      this.chk_Nsecur.AutoSize = true;
      this.chk_Nsecur.ForeColor = SystemColors.ControlText;
      this.chk_Nsecur.Location = new Point(6, 88);
      this.chk_Nsecur.Name = "chk_Nsecur";
      this.chk_Nsecur.Size = new Size(74, 17);
      this.chk_Nsecur.TabIndex = 21;
      this.chk_Nsecur.Text = "NSECUR:";
      this.chk_Nsecur.UseVisualStyleBackColor = true;
      this.chk_Nsecur.CheckedChanged += new EventHandler(this.chk_Nsecur_CheckedChanged);
      this.chk_Ncdex.AutoSize = true;
      this.chk_Ncdex.ForeColor = SystemColors.ControlText;
      this.chk_Ncdex.Location = new Point(6, 66);
      this.chk_Ncdex.Name = "chk_Ncdex";
      this.chk_Ncdex.Size = new Size(66, 17);
      this.chk_Ncdex.TabIndex = 20;
      this.chk_Ncdex.Text = "NCDEX:";
      this.chk_Ncdex.UseVisualStyleBackColor = true;
      this.chk_Ncdex.CheckedChanged += new EventHandler(this.chk_Ncdex_CheckedChanged);
      this.chk_NSEFUT.AutoSize = true;
      this.chk_NSEFUT.ForeColor = SystemColors.ControlText;
      this.chk_NSEFUT.Location = new Point(6, 44);
      this.chk_NSEFUT.Name = "chk_NSEFUT";
      this.chk_NSEFUT.Size = new Size(72, 17);
      this.chk_NSEFUT.TabIndex = 19;
      this.chk_NSEFUT.Text = "NSEFUT:";
      this.chk_NSEFUT.UseVisualStyleBackColor = true;
      this.chk_NSEFUT.CheckedChanged += new EventHandler(this.chk_NSEFUT_CheckedChanged);
      this.chk_MCX.AutoSize = true;
      this.chk_MCX.ForeColor = SystemColors.ControlText;
      this.chk_MCX.Location = new Point(6, 22);
      this.chk_MCX.Name = "chk_MCX";
      this.chk_MCX.Size = new Size(52, 17);
      this.chk_MCX.TabIndex = 18;
      this.chk_MCX.Text = "MCX:";
      this.chk_MCX.UseVisualStyleBackColor = true;
      this.chk_MCX.CheckedChanged += new EventHandler(this.chk_MCX_CheckedChanged);
      this.label22.AutoSize = true;
      this.label22.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label22.ForeColor = SystemColors.ControlText;
      this.label22.Location = new Point(137, 7);
      this.label22.Name = "label22";
      this.label22.Size = new Size(31, 13);
      this.label22.TabIndex = 17;
      this.label22.Text = "CNF";
      this.txtCnfNseCurr.Enabled = false;
      this.txtCnfNseCurr.Location = new Point(132, 86);
      this.txtCnfNseCurr.Mask = "0.00000";
      this.txtCnfNseCurr.Name = "txtCnfNseCurr";
      this.txtCnfNseCurr.Size = new Size(45, 20);
      this.txtCnfNseCurr.TabIndex = 7;
      this.txtCnfNseCurr.Text = "0";
      this.txtCnfNseCurr.Visible = false;
      this.txtCnfMcx.Enabled = false;
      this.txtCnfMcx.Location = new Point(132, 22);
      this.txtCnfMcx.Mask = "0.00000";
      this.txtCnfMcx.Name = "txtCnfMcx";
      this.txtCnfMcx.Size = new Size(45, 20);
      this.txtCnfMcx.TabIndex = 1;
      this.txtCnfMcx.Text = "0";
      this.txtCnfMcx.Visible = false;
      this.txtCnfNseFut.Enabled = false;
      this.txtCnfNseFut.Location = new Point(132, 43);
      this.txtCnfNseFut.Mask = "0.00000";
      this.txtCnfNseFut.Name = "txtCnfNseFut";
      this.txtCnfNseFut.Size = new Size(45, 20);
      this.txtCnfNseFut.TabIndex = 3;
      this.txtCnfNseFut.Text = "0";
      this.txtCnfNseFut.Visible = false;
      this.txtCnfNcdex.Enabled = false;
      this.txtCnfNcdex.Location = new Point(132, 64);
      this.txtCnfNcdex.Mask = "0.00000";
      this.txtCnfNcdex.Name = "txtCnfNcdex";
      this.txtCnfNcdex.Size = new Size(45, 20);
      this.txtCnfNcdex.TabIndex = 5;
      this.txtCnfNcdex.Text = "0";
      this.txtCnfNcdex.Visible = false;
      this.label21.AutoSize = true;
      this.label21.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label21.ForeColor = SystemColors.ControlText;
      this.label21.Location = new Point(86, 7);
      this.label21.Name = "label21";
      this.label21.Size = new Size(39, 13);
      this.label21.TabIndex = 12;
      this.label21.Text = "Intrdy";
      this.txtIntrdynsecurr.Enabled = false;
      this.txtIntrdynsecurr.Location = new Point(81, 86);
      this.txtIntrdynsecurr.Mask = "0.00000";
      this.txtIntrdynsecurr.Name = "txtIntrdynsecurr";
      this.txtIntrdynsecurr.Size = new Size(45, 20);
      this.txtIntrdynsecurr.TabIndex = 6;
      this.txtIntrdynsecurr.Text = "0";
      this.txtIntrdynsecurr.Visible = false;
      this.txtIntrdymcx.Enabled = false;
      this.txtIntrdymcx.Location = new Point(81, 22);
      this.txtIntrdymcx.Mask = "0.00000";
      this.txtIntrdymcx.Name = "txtIntrdymcx";
      this.txtIntrdymcx.Size = new Size(45, 20);
      this.txtIntrdymcx.TabIndex = 0;
      this.txtIntrdymcx.Text = "0";
      this.txtIntrdymcx.Visible = false;
      this.txtIntrdynsefut.Enabled = false;
      this.txtIntrdynsefut.Location = new Point(81, 43);
      this.txtIntrdynsefut.Mask = "0.00000";
      this.txtIntrdynsefut.Name = "txtIntrdynsefut";
      this.txtIntrdynsefut.Size = new Size(45, 20);
      this.txtIntrdynsefut.TabIndex = 2;
      this.txtIntrdynsefut.Text = "0";
      this.txtIntrdynsefut.Visible = false;
      this.txtIntrdyncdex.Enabled = false;
      this.txtIntrdyncdex.Location = new Point(81, 64);
      this.txtIntrdyncdex.Mask = "0.00000";
      this.txtIntrdyncdex.Name = "txtIntrdyncdex";
      this.txtIntrdyncdex.Size = new Size(45, 20);
      this.txtIntrdyncdex.TabIndex = 4;
      this.txtIntrdyncdex.Text = "0";
      this.txtIntrdyncdex.Visible = false;
      this.groupBox6.Controls.Add((Control) this.chkMrgnSqOff);
      this.groupBox6.Controls.Add((Control) this.chkIntraSqoff);
      this.groupBox6.ForeColor = SystemColors.ControlText;
      this.groupBox6.Location = new Point(486, 372);
      this.groupBox6.Name = "groupBox6";
      this.groupBox6.Size = new Size(270, 40);
      this.groupBox6.TabIndex = 5;
      this.groupBox6.TabStop = false;
      this.groupBox6.Text = "Position Management";
      this.chkMrgnSqOff.AutoSize = true;
      this.chkMrgnSqOff.ForeColor = SystemColors.ControlText;
      this.chkMrgnSqOff.Location = new Point(134, 19);
      this.chkMrgnSqOff.Name = "chkMrgnSqOff";
      this.chkMrgnSqOff.Size = new Size(91, 17);
      this.chkMrgnSqOff.TabIndex = 1;
      this.chkMrgnSqOff.Text = "Margin Sq Off";
      this.chkMrgnSqOff.UseVisualStyleBackColor = true;
      this.chkIntraSqoff.AutoSize = true;
      this.chkIntraSqoff.ForeColor = SystemColors.ControlText;
      this.chkIntraSqoff.Location = new Point(12, 19);
      this.chkIntraSqoff.Name = "chkIntraSqoff";
      this.chkIntraSqoff.Size = new Size(97, 17);
      this.chkIntraSqoff.TabIndex = 0;
      this.chkIntraSqoff.Text = "Intraday Sq Off";
      this.chkIntraSqoff.UseVisualStyleBackColor = true;
      this.groupBox4.Controls.Add((Control) this.rdoSymbolwise);
      this.groupBox4.Controls.Add((Control) this.rdoTurnoverwse);
      this.groupBox4.Controls.Add((Control) this.rdolotwse);
      this.groupBox4.Controls.Add((Control) this.groupBox7);
      this.groupBox4.Controls.Add((Control) this.label16);
      this.groupBox4.Controls.Add((Control) this.txtturnoverlimit);
      this.groupBox4.Location = new Point(486, 149);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new Size(272, 217);
      this.groupBox4.TabIndex = 3;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Trading Margin";
      this.rdoSymbolwise.AutoSize = true;
      this.rdoSymbolwise.Location = new Point(167, 19);
      this.rdoSymbolwise.Name = "rdoSymbolwise";
      this.rdoSymbolwise.Size = new Size(103, 17);
      this.rdoSymbolwise.TabIndex = 62;
      this.rdoSymbolwise.Text = "Symbolwise(Rs.)";
      this.rdoSymbolwise.UseVisualStyleBackColor = true;
      this.rdoSymbolwise.CheckedChanged += new EventHandler(this.rdoSymbolwise_CheckedChanged_1);
      this.rdoTurnoverwse.AutoSize = true;
      this.rdoTurnoverwse.Location = new Point(3, 18);
      this.rdoTurnoverwse.Name = "rdoTurnoverwse";
      this.rdoTurnoverwse.Size = new Size(90, 17);
      this.rdoTurnoverwse.TabIndex = 61;
      this.rdoTurnoverwse.Text = "Turnoverwise";
      this.rdoTurnoverwse.UseVisualStyleBackColor = true;
      this.rdoTurnoverwse.CheckedChanged += new EventHandler(this.rdoTurnoverwse_CheckedChanged_1);
      this.rdolotwse.AutoSize = true;
      this.rdolotwse.Location = new Point(99, 18);
      this.rdolotwse.Name = "rdolotwse";
      this.rdolotwse.Size = new Size(62, 17);
      this.rdolotwse.TabIndex = 60;
      this.rdolotwse.Text = "Lotwise";
      this.rdolotwse.UseVisualStyleBackColor = true;
      this.rdolotwse.CheckedChanged += new EventHandler(this.rdolotwse_CheckedChanged_1);
      this.groupBox7.Controls.Add((Control) this.lblNsecurrLots1);
      this.groupBox7.Controls.Add((Control) this.lblNsecurrLots);
      this.groupBox7.Controls.Add((Control) this.txtnsecurrLots);
      this.groupBox7.Controls.Add((Control) this.rdosymwise);
      this.groupBox7.Controls.Add((Control) this.rdodefault);
      this.groupBox7.Controls.Add((Control) this.lblNsefutLots1);
      this.groupBox7.Controls.Add((Control) this.lblMcxLots);
      this.groupBox7.Controls.Add((Control) this.radioButton1);
      this.groupBox7.Controls.Add((Control) this.lblNcdexLots1);
      this.groupBox7.Controls.Add((Control) this.txtMcxlots);
      this.groupBox7.Controls.Add((Control) this.lblMcxlots1);
      this.groupBox7.Controls.Add((Control) this.lblNsefutLots);
      this.groupBox7.Controls.Add((Control) this.lblNcdexLots);
      this.groupBox7.Controls.Add((Control) this.txtncxlot);
      this.groupBox7.Controls.Add((Control) this.txtnselot);
      this.groupBox7.Location = new Point(18, 70);
      this.groupBox7.Name = "groupBox7";
      this.groupBox7.Size = new Size(220, 137);
      this.groupBox7.TabIndex = 3;
      this.groupBox7.TabStop = false;
      this.groupBox7.Visible = false;
      this.lblNsecurrLots1.AutoSize = true;
      this.lblNsecurrLots1.ForeColor = Color.Black;
      this.lblNsecurrLots1.Location = new Point(183, 115);
      this.lblNsecurrLots1.Name = "lblNsecurrLots1";
      this.lblNsecurrLots1.Size = new Size(33, 13);
      this.lblNsecurrLots1.TabIndex = 59;
      this.lblNsecurrLots1.Text = " Lots.";
      this.lblNsecurrLots1.Visible = false;
      this.lblNsecurrLots.AutoSize = true;
      this.lblNsecurrLots.ForeColor = Color.Black;
      this.lblNsecurrLots.Location = new Point(3, 115);
      this.lblNsecurrLots.Name = "lblNsecurrLots";
      this.lblNsecurrLots.Size = new Size(63, 13);
      this.lblNsecurrLots.TabIndex = 57;
      this.lblNsecurrLots.Text = "NSECURR:";
      this.lblNsecurrLots.Visible = false;
      this.txtnsecurrLots.BackColor = Color.WhiteSmoke;
      this.txtnsecurrLots.ForeColor = Color.Black;
      this.txtnsecurrLots.Location = new Point(115, 112);
      this.txtnsecurrLots.MaxLength = 3;
      this.txtnsecurrLots.Name = "txtnsecurrLots";
      this.txtnsecurrLots.Size = new Size(62, 20);
      this.txtnsecurrLots.TabIndex = 3;
      this.txtnsecurrLots.Text = "0";
      this.txtnsecurrLots.Visible = false;
      this.rdosymwise.AutoSize = true;
      this.rdosymwise.Location = new Point(137, 14);
      this.rdosymwise.Name = "rdosymwise";
      this.rdosymwise.Size = new Size(80, 17);
      this.rdosymwise.TabIndex = 56;
      this.rdosymwise.Text = "Symbolwise";
      this.rdosymwise.UseVisualStyleBackColor = true;
      this.rdosymwise.CheckedChanged += new EventHandler(this.rdosymwise_CheckedChanged);
      this.rdodefault.AutoSize = true;
      this.rdodefault.Checked = true;
      this.rdodefault.Location = new Point(6, 14);
      this.rdodefault.Name = "rdodefault";
      this.rdodefault.Size = new Size(59, 17);
      this.rdodefault.TabIndex = 0;
      this.rdodefault.TabStop = true;
      this.rdodefault.Text = "Default";
      this.rdodefault.UseVisualStyleBackColor = true;
      this.rdodefault.CheckedChanged += new EventHandler(this.rdodefault_CheckedChanged);
      this.lblNsefutLots1.AutoSize = true;
      this.lblNsefutLots1.ForeColor = Color.Black;
      this.lblNsefutLots1.Location = new Point(183, 66);
      this.lblNsefutLots1.Name = "lblNsefutLots1";
      this.lblNsefutLots1.Size = new Size(33, 13);
      this.lblNsefutLots1.TabIndex = 55;
      this.lblNsefutLots1.Text = " Lots.";
      this.lblNsefutLots1.Visible = false;
      this.lblMcxLots.AutoSize = true;
      this.lblMcxLots.ForeColor = Color.Black;
      this.lblMcxLots.Location = new Point(3, 40);
      this.lblMcxLots.Name = "lblMcxLots";
      this.lblMcxLots.Size = new Size(33, 13);
      this.lblMcxLots.TabIndex = 47;
      this.lblMcxLots.Text = "MCX:";
      this.lblMcxLots.Visible = false;
      this.radioButton1.AutoSize = true;
      this.radioButton1.Location = new Point(73, 14);
      this.radioButton1.Name = "radioButton1";
      this.radioButton1.Size = new Size(56, 17);
      this.radioButton1.TabIndex = 1;
      this.radioButton1.Text = "Define";
      this.radioButton1.UseVisualStyleBackColor = true;
      this.radioButton1.CheckedChanged += new EventHandler(this.radioButton1_CheckedChanged);
      this.lblNcdexLots1.AutoSize = true;
      this.lblNcdexLots1.ForeColor = Color.Black;
      this.lblNcdexLots1.Location = new Point(183, 91);
      this.lblNcdexLots1.Name = "lblNcdexLots1";
      this.lblNcdexLots1.Size = new Size(33, 13);
      this.lblNcdexLots1.TabIndex = 54;
      this.lblNcdexLots1.Text = " Lots.";
      this.lblNcdexLots1.Visible = false;
      this.txtMcxlots.BackColor = Color.WhiteSmoke;
      this.txtMcxlots.ForeColor = Color.Black;
      this.txtMcxlots.Location = new Point(115, 37);
      this.txtMcxlots.MaxLength = 3;
      this.txtMcxlots.Name = "txtMcxlots";
      this.txtMcxlots.Size = new Size(62, 20);
      this.txtMcxlots.TabIndex = 0;
      this.txtMcxlots.Text = "0";
      this.txtMcxlots.Visible = false;
      this.lblMcxlots1.AutoSize = true;
      this.lblMcxlots1.ForeColor = Color.Black;
      this.lblMcxlots1.Location = new Point(183, 40);
      this.lblMcxlots1.Name = "lblMcxlots1";
      this.lblMcxlots1.Size = new Size(33, 13);
      this.lblMcxlots1.TabIndex = 53;
      this.lblMcxlots1.Text = " Lots.";
      this.lblMcxlots1.Visible = false;
      this.lblNsefutLots.AutoSize = true;
      this.lblNsefutLots.ForeColor = Color.Black;
      this.lblNsefutLots.Location = new Point(3, 65);
      this.lblNsefutLots.Name = "lblNsefutLots";
      this.lblNsefutLots.Size = new Size(53, 13);
      this.lblNsefutLots.TabIndex = 50;
      this.lblNsefutLots.Text = "NSEFUT:";
      this.lblNsefutLots.Visible = false;
      this.lblNcdexLots.AutoSize = true;
      this.lblNcdexLots.ForeColor = Color.Black;
      this.lblNcdexLots.Location = new Point(3, 90);
      this.lblNcdexLots.Name = "lblNcdexLots";
      this.lblNcdexLots.Size = new Size(47, 13);
      this.lblNcdexLots.TabIndex = 49;
      this.lblNcdexLots.Text = "NCDEX:";
      this.lblNcdexLots.Visible = false;
      this.txtncxlot.BackColor = Color.WhiteSmoke;
      this.txtncxlot.ForeColor = Color.Black;
      this.txtncxlot.Location = new Point(115, 87);
      this.txtncxlot.MaxLength = 3;
      this.txtncxlot.Name = "txtncxlot";
      this.txtncxlot.Size = new Size(62, 20);
      this.txtncxlot.TabIndex = 2;
      this.txtncxlot.Text = "0";
      this.txtncxlot.Visible = false;
      this.txtnselot.BackColor = Color.WhiteSmoke;
      this.txtnselot.ForeColor = Color.Black;
      this.txtnselot.Location = new Point(115, 62);
      this.txtnselot.MaxLength = 3;
      this.txtnselot.Name = "txtnselot";
      this.txtnselot.Size = new Size(62, 20);
      this.txtnselot.TabIndex = 1;
      this.txtnselot.Text = "0";
      this.txtnselot.Visible = false;
      this.label16.AutoSize = true;
      this.label16.ForeColor = Color.Black;
      this.label16.Location = new Point(6, 49);
      this.label16.Name = "label16";
      this.label16.Size = new Size(77, 13);
      this.label16.TabIndex = 59;
      this.label16.Text = "Turnover Limit:";
      this.txtturnoverlimit.BackColor = Color.WhiteSmoke;
      this.txtturnoverlimit.ForeColor = Color.Black;
      this.txtturnoverlimit.Location = new Point(122, 44);
      this.txtturnoverlimit.Name = "txtturnoverlimit";
      this.txtturnoverlimit.ReadOnly = true;
      this.txtturnoverlimit.Size = new Size(125, 20);
      this.txtturnoverlimit.TabIndex = 58;
      this.txtturnoverlimit.Text = "0";
      this.btnFlushASOD.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.btnFlushASOD.FlatStyle = FlatStyle.System;
      this.btnFlushASOD.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnFlushASOD.ForeColor = Color.Navy;
      this.btnFlushASOD.Location = new Point(386, 530);
      this.btnFlushASOD.Name = "btnFlushASOD";
      this.btnFlushASOD.Size = new Size(195, 23);
      this.btnFlushASOD.TabIndex = 9;
      this.btnFlushASOD.Text = "Flush Auto Square Off Data";
      this.btnFlushASOD.UseVisualStyleBackColor = true;
      this.btnFlushASOD.Click += new EventHandler(this.btnFlushASOD_Click);
      this.btnreset.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.btnreset.FlatStyle = FlatStyle.System;
      this.btnreset.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnreset.ForeColor = Color.Navy;
      this.btnreset.Location = new Point(611, 530);
      this.btnreset.Name = "btnreset";
      this.btnreset.Size = new Size(100, 23);
      this.btnreset.TabIndex = 10;
      this.btnreset.Text = "Reset User";
      this.btnreset.UseVisualStyleBackColor = true;
      this.btnreset.Click += new EventHandler(this.btnreset_Click);
      this.btnset.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
      this.btnset.FlatStyle = FlatStyle.System;
      this.btnset.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnset.ForeColor = Color.Navy;
      this.btnset.Location = new Point(281, 530);
      this.btnset.Name = "btnset";
      this.btnset.Size = new Size(75, 23);
      this.btnset.TabIndex = 8;
      this.btnset.Text = "Set";
      this.btnset.UseVisualStyleBackColor = true;
      this.btnset.Click += new EventHandler(this.btnset_Click);
      this.groupBox9.Controls.Add((Control) this.chkGTC);
      this.groupBox9.Controls.Add((Control) this.chkCnF);
      this.groupBox9.Controls.Add((Control) this.chkDay);
      this.groupBox9.ForeColor = SystemColors.ControlText;
      this.groupBox9.Location = new Point(212, 371);
      this.groupBox9.Name = "groupBox9";
      this.groupBox9.Size = new Size(270, 40);
      this.groupBox9.TabIndex = 6;
      this.groupBox9.TabStop = false;
      this.groupBox9.Text = "Trade Validity Attributes";
      this.chkGTC.AutoSize = true;
      this.chkGTC.ForeColor = SystemColors.ControlText;
      this.chkGTC.Location = new Point(181, 17);
      this.chkGTC.Name = "chkGTC";
      this.chkGTC.Size = new Size(48, 17);
      this.chkGTC.TabIndex = 2;
      this.chkGTC.Text = "GTC";
      this.chkGTC.UseVisualStyleBackColor = true;
      this.chkCnF.AutoSize = true;
      this.chkCnF.ForeColor = SystemColors.ControlText;
      this.chkCnF.Location = new Point(16, 17);
      this.chkCnF.Name = "chkCnF";
      this.chkCnF.Size = new Size(88, 17);
      this.chkCnF.TabIndex = 1;
      this.chkCnF.Text = "CarryForward";
      this.chkCnF.UseVisualStyleBackColor = true;
      this.chkDay.AutoSize = true;
      this.chkDay.ForeColor = SystemColors.ControlText;
      this.chkDay.Location = new Point(120, 17);
      this.chkDay.Name = "chkDay";
      this.chkDay.Size = new Size(45, 17);
      this.chkDay.TabIndex = 0;
      this.chkDay.Text = "Day";
      this.chkDay.UseVisualStyleBackColor = true;
      this.groupBox10.Controls.Add((Control) this.chkMkt);
      this.groupBox10.Controls.Add((Control) this.chkRL);
      this.groupBox10.Controls.Add((Control) this.chkSL);
      this.groupBox10.ForeColor = SystemColors.ControlText;
      this.groupBox10.Location = new Point(486, 418);
      this.groupBox10.Name = "groupBox10";
      this.groupBox10.Size = new Size(270, 40);
      this.groupBox10.TabIndex = 7;
      this.groupBox10.TabStop = false;
      this.groupBox10.Text = "Trade Type Attributes";
      this.chkMkt.AutoSize = true;
      this.chkMkt.ForeColor = SystemColors.ControlText;
      this.chkMkt.Location = new Point(171, 17);
      this.chkMkt.Name = "chkMkt";
      this.chkMkt.Size = new Size(49, 17);
      this.chkMkt.TabIndex = 2;
      this.chkMkt.Text = "MKT";
      this.chkMkt.UseVisualStyleBackColor = true;
      this.chkMkt.CheckedChanged += new EventHandler(this.chkMkt_CheckedChanged);
      this.chkRL.AutoSize = true;
      this.chkRL.ForeColor = SystemColors.ControlText;
      this.chkRL.Location = new Point(34, 19);
      this.chkRL.Name = "chkRL";
      this.chkRL.Size = new Size(40, 17);
      this.chkRL.TabIndex = 1;
      this.chkRL.Text = "RL";
      this.chkRL.UseVisualStyleBackColor = true;
      this.chkSL.AutoSize = true;
      this.chkSL.ForeColor = SystemColors.ControlText;
      this.chkSL.Location = new Point(103, 19);
      this.chkSL.Name = "chkSL";
      this.chkSL.Size = new Size(39, 17);
      this.chkSL.TabIndex = 0;
      this.chkSL.Text = "SL";
      this.chkSL.UseVisualStyleBackColor = true;
      this.txtClientCode.Location = new Point(6, 4);
      this.txtClientCode.Name = "txtClientCode";
      this.txtClientCode.Size = new Size(97, 20);
      this.txtClientCode.TabIndex = 47;
      this.txtClientCode.TextChanged += new EventHandler(this.txtClientCode_TextChanged);
      this.txtName.Location = new Point(109, 4);
      this.txtName.Name = "txtName";
      this.txtName.Size = new Size(97, 20);
      this.txtName.TabIndex = 48;
      this.txtName.TextChanged += new EventHandler(this.txtName_TextChanged);
      this.label1.AutoSize = true;
      this.label1.Location = new Point(215, 11);
      this.label1.Name = "label1";
      this.label1.Size = new Size(89, 13);
      this.label1.TabIndex = 49;
      this.label1.Text = "Allocated Margin:";
      this.lblAllocatedMrgn.AutoSize = true;
      this.lblAllocatedMrgn.Location = new Point(306, 11);
      this.lblAllocatedMrgn.Name = "lblAllocatedMrgn";
      this.lblAllocatedMrgn.Size = new Size(10, 13);
      this.lblAllocatedMrgn.TabIndex = 50;
      this.lblAllocatedMrgn.Text = ".";
      this.lblUtilisedMrgn.AutoSize = true;
      this.lblUtilisedMrgn.Location = new Point(471, 11);
      this.lblUtilisedMrgn.Name = "lblUtilisedMrgn";
      this.lblUtilisedMrgn.Size = new Size(10, 13);
      this.lblUtilisedMrgn.TabIndex = 52;
      this.lblUtilisedMrgn.Text = ".";
      this.label6.AutoSize = true;
      this.label6.Location = new Point(391, 11);
      this.label6.Name = "label6";
      this.label6.Size = new Size(79, 13);
      this.label6.TabIndex = 51;
      this.label6.Text = "Utilised Margin:";
      this.lblAvailMrgn.AutoSize = true;
      this.lblAvailMrgn.Location = new Point(650, 11);
      this.lblAvailMrgn.Name = "lblAvailMrgn";
      this.lblAvailMrgn.Size = new Size(10, 13);
      this.lblAvailMrgn.TabIndex = 54;
      this.lblAvailMrgn.Text = ".";
      this.label11.AutoSize = true;
      this.label11.Location = new Point(561, 11);
      this.label11.Name = "label11";
      this.label11.Size = new Size(88, 13);
      this.label11.TabIndex = 53;
      this.label11.Text = "Available Margin:";
      this.groupBox11.Controls.Add((Control) this.rdosymbolwise1);
      this.groupBox11.Controls.Add((Control) this.rdoExchange);
      this.groupBox11.Controls.Add((Control) this.txtNSECURBrkup);
      this.groupBox11.Controls.Add((Control) this.lblNsecurBrkup);
      this.groupBox11.Controls.Add((Control) this.txtNCDEXBrkup);
      this.groupBox11.Controls.Add((Control) this.lblNcdexBrkup);
      this.groupBox11.Controls.Add((Control) this.txtNSEFUTBrkup);
      this.groupBox11.Controls.Add((Control) this.lblNsefutBrkup);
      this.groupBox11.Controls.Add((Control) this.txtMCXBrkup);
      this.groupBox11.Controls.Add((Control) this.lblMCXBrkup);
      this.groupBox11.Location = new Point(212, 412);
      this.groupBox11.Name = "groupBox11";
      this.groupBox11.Size = new Size(268, 112);
      this.groupBox11.TabIndex = 55;
      this.groupBox11.TabStop = false;
      this.groupBox11.Text = "Breakup";
      this.txtNSECURBrkup.Location = new Point(64, 79);
      this.txtNSECURBrkup.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.txtNSECURBrkup.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtNSECURBrkup.Name = "txtNSECURBrkup";
      this.txtNSECURBrkup.Size = new Size(53, 20);
      this.txtNSECURBrkup.TabIndex = 11;
      this.txtNSECURBrkup.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtNSECURBrkup.Visible = false;
      this.lblNsecurBrkup.AutoSize = true;
      this.lblNsecurBrkup.Location = new Point(3, 81);
      this.lblNsecurBrkup.Name = "lblNsecurBrkup";
      this.lblNsecurBrkup.Size = new Size(55, 13);
      this.lblNsecurBrkup.TabIndex = 10;
      this.lblNsecurBrkup.Text = "NSECUR:";
      this.lblNsecurBrkup.Visible = false;
      this.txtNCDEXBrkup.Location = new Point(197, 79);
      this.txtNCDEXBrkup.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.txtNCDEXBrkup.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtNCDEXBrkup.Name = "txtNCDEXBrkup";
      this.txtNCDEXBrkup.Size = new Size(53, 20);
      this.txtNCDEXBrkup.TabIndex = 9;
      this.txtNCDEXBrkup.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtNCDEXBrkup.Visible = false;
      this.lblNcdexBrkup.AutoSize = true;
      this.lblNcdexBrkup.Location = new Point(142, 81);
      this.lblNcdexBrkup.Name = "lblNcdexBrkup";
      this.lblNcdexBrkup.Size = new Size(47, 13);
      this.lblNcdexBrkup.TabIndex = 8;
      this.lblNcdexBrkup.Text = "NCDEX:";
      this.lblNcdexBrkup.Visible = false;
      this.txtNSEFUTBrkup.Location = new Point(197, 48);
      this.txtNSEFUTBrkup.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.txtNSEFUTBrkup.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtNSEFUTBrkup.Name = "txtNSEFUTBrkup";
      this.txtNSEFUTBrkup.Size = new Size(53, 20);
      this.txtNSEFUTBrkup.TabIndex = 7;
      this.txtNSEFUTBrkup.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtNSEFUTBrkup.Visible = false;
      this.lblNsefutBrkup.AutoSize = true;
      this.lblNsefutBrkup.Location = new Point(141, 52);
      this.lblNsefutBrkup.Name = "lblNsefutBrkup";
      this.lblNsefutBrkup.Size = new Size(53, 13);
      this.lblNsefutBrkup.TabIndex = 6;
      this.lblNsefutBrkup.Text = "NSEFUT:";
      this.lblNsefutBrkup.Visible = false;
      this.txtMCXBrkup.Location = new Point(64, 50);
      this.txtMCXBrkup.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.txtMCXBrkup.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtMCXBrkup.Name = "txtMCXBrkup";
      this.txtMCXBrkup.Size = new Size(53, 20);
      this.txtMCXBrkup.TabIndex = 5;
      this.txtMCXBrkup.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtMCXBrkup.Visible = false;
      this.lblMCXBrkup.AutoSize = true;
      this.lblMCXBrkup.Location = new Point(3, 50);
      this.lblMCXBrkup.Name = "lblMCXBrkup";
      this.lblMCXBrkup.Size = new Size(33, 13);
      this.lblMCXBrkup.TabIndex = 0;
      this.lblMCXBrkup.Text = "MCX:";
      this.lblMCXBrkup.Visible = false;
      this.groupBox12.Controls.Add((Control) this.rdoPendingOnBidAsk);
      this.groupBox12.Controls.Add((Control) this.rdoPendingOnLTP);
      this.groupBox12.Location = new Point(486, 464);
      this.groupBox12.Name = "groupBox12";
      this.groupBox12.Size = new Size(270, 42);
      this.groupBox12.TabIndex = 56;
      this.groupBox12.TabStop = false;
      this.groupBox12.Text = "Pending Order Execution";
      this.rdoPendingOnBidAsk.AutoSize = true;
      this.rdoPendingOnBidAsk.Location = new Point(121, 19);
      this.rdoPendingOnBidAsk.Name = "rdoPendingOnBidAsk";
      this.rdoPendingOnBidAsk.Size = new Size(86, 17);
      this.rdoPendingOnBidAsk.TabIndex = 1;
      this.rdoPendingOnBidAsk.TabStop = true;
      this.rdoPendingOnBidAsk.Text = "On BID/ASK";
      this.rdoPendingOnBidAsk.UseVisualStyleBackColor = true;
      this.rdoPendingOnLTP.AutoSize = true;
      this.rdoPendingOnLTP.Checked = true;
      this.rdoPendingOnLTP.Location = new Point(12, 19);
      this.rdoPendingOnLTP.Name = "rdoPendingOnLTP";
      this.rdoPendingOnLTP.Size = new Size(62, 17);
      this.rdoPendingOnLTP.TabIndex = 0;
      this.rdoPendingOnLTP.TabStop = true;
      this.rdoPendingOnLTP.Text = "On LTP";
      this.rdoPendingOnLTP.UseVisualStyleBackColor = true;
      this.rdoExchange.AutoSize = true;
      this.rdoExchange.Location = new Point(32, 19);
      this.rdoExchange.Name = "rdoExchange";
      this.rdoExchange.Size = new Size(94, 17);
      this.rdoExchange.TabIndex = 12;
      this.rdoExchange.TabStop = true;
      this.rdoExchange.Text = "Exchangewise";
      this.rdoExchange.UseVisualStyleBackColor = true;
      this.rdoExchange.CheckedChanged += new EventHandler(this.rdoExchange_CheckedChanged);
      this.rdosymbolwise1.AutoSize = true;
      this.rdosymbolwise1.Location = new Point(156, 19);
      this.rdosymbolwise1.Name = "rdosymbolwise1";
      this.rdosymbolwise1.Size = new Size(80, 17);
      this.rdosymbolwise1.TabIndex = 13;
      this.rdosymbolwise1.TabStop = true;
      this.rdosymbolwise1.Text = "Symbolwise";
      this.rdosymbolwise1.UseVisualStyleBackColor = true;
      this.rdosymbolwise1.CheckedChanged += new EventHandler(this.rdosymbolwise1_CheckedChanged);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(760, 559);
      this.Controls.Add((Control) this.groupBox12);
      this.Controls.Add((Control) this.groupBox11);
      this.Controls.Add((Control) this.lblAvailMrgn);
      this.Controls.Add((Control) this.label11);
      this.Controls.Add((Control) this.lblUtilisedMrgn);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.lblAllocatedMrgn);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.txtName);
      this.Controls.Add((Control) this.txtClientCode);
      this.Controls.Add((Control) this.groupBox10);
      this.Controls.Add((Control) this.groupBox9);
      this.Controls.Add((Control) this.btnFlushASOD);
      this.Controls.Add((Control) this.btnreset);
      this.Controls.Add((Control) this.btnset);
      this.Controls.Add((Control) this.groupBox4);
      this.Controls.Add((Control) this.groupBox6);
      this.Controls.Add((Control) this.groupBox5);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.dgvLimits);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (frmLimits);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Limits";
      ((ISupportInitialize) this.dgvLimits).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.numericUpDown1.EndInit();
      this.txtLotBrkup.EndInit();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.TurnoverMulti.EndInit();
      this.txtMTMmulti.EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox5.ResumeLayout(false);
      this.groupBox13.ResumeLayout(false);
      this.groupBox13.PerformLayout();
      this.groupBox8.ResumeLayout(false);
      this.groupBox8.PerformLayout();
      this.groupBox6.ResumeLayout(false);
      this.groupBox6.PerformLayout();
      this.groupBox4.ResumeLayout(false);
      this.groupBox4.PerformLayout();
      this.groupBox7.ResumeLayout(false);
      this.groupBox7.PerformLayout();
      this.groupBox9.ResumeLayout(false);
      this.groupBox9.PerformLayout();
      this.groupBox10.ResumeLayout(false);
      this.groupBox10.PerformLayout();
      this.groupBox11.ResumeLayout(false);
      this.groupBox11.PerformLayout();
      this.txtNSECURBrkup.EndInit();
      this.txtNCDEXBrkup.EndInit();
      this.txtNSEFUTBrkup.EndInit();
      this.txtMCXBrkup.EndInit();
      this.groupBox12.ResumeLayout(false);
      this.groupBox12.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
