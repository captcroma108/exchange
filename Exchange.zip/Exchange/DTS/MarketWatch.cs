﻿// Decompiled with JetBrains decompiler
// Type: DTS.MarketWatch
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class MarketWatch : UserControl
  {
    private IContainer components = (IContainer) null;
    private ToolStrip toolStrip1;
    private ToolStripComboBox cmbExchange;
    private ToolStripComboBox cmbSymbol;
    private ToolStripComboBox cmbExpiry;
    private ToolStripButton btnAddsymbols;
    private ToolStripButton btnSaveportfolio;
    private ToolStripButton btnUploadPortfolio;
    public DataGridView dgvMarketwatch;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn BidQty;
    private DataGridViewTextBoxColumn bid;
    private DataGridViewTextBoxColumn ask;
    private DataGridViewTextBoxColumn AskQty;
    private DataGridViewTextBoxColumn LTP;
    private DataGridViewTextBoxColumn Open;
    private DataGridViewTextBoxColumn High;
    private DataGridViewTextBoxColumn Low;
    private DataGridViewTextBoxColumn Close;
    private DataGridViewTextBoxColumn Netchange;
    private DataGridViewTextBoxColumn Percenchange;
    private DataGridViewTextBoxColumn LastUpdate;
    private DataGridViewButtonColumn ColBuy;
    private DataGridViewButtonColumn ColSell;

    public MarketWatch()
    {
      this.InitializeComponent();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (MarketWatch));
      DataGridViewCellStyle gridViewCellStyle = new DataGridViewCellStyle();
      this.toolStrip1 = new ToolStrip();
      this.cmbExchange = new ToolStripComboBox();
      this.cmbSymbol = new ToolStripComboBox();
      this.cmbExpiry = new ToolStripComboBox();
      this.btnAddsymbols = new ToolStripButton();
      this.btnSaveportfolio = new ToolStripButton();
      this.btnUploadPortfolio = new ToolStripButton();
      this.dgvMarketwatch = new DataGridView();
      this.Exch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.BidQty = new DataGridViewTextBoxColumn();
      this.bid = new DataGridViewTextBoxColumn();
      this.ask = new DataGridViewTextBoxColumn();
      this.AskQty = new DataGridViewTextBoxColumn();
      this.LTP = new DataGridViewTextBoxColumn();
      this.Open = new DataGridViewTextBoxColumn();
      this.High = new DataGridViewTextBoxColumn();
      this.Low = new DataGridViewTextBoxColumn();
      this.Close = new DataGridViewTextBoxColumn();
      this.Netchange = new DataGridViewTextBoxColumn();
      this.Percenchange = new DataGridViewTextBoxColumn();
      this.LastUpdate = new DataGridViewTextBoxColumn();
      this.ColBuy = new DataGridViewButtonColumn();
      this.ColSell = new DataGridViewButtonColumn();
      this.toolStrip1.SuspendLayout();
      ((ISupportInitialize) this.dgvMarketwatch).BeginInit();
      this.SuspendLayout();
      this.toolStrip1.Items.AddRange(new ToolStripItem[6]
      {
        (ToolStripItem) this.cmbExchange,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.cmbExpiry,
        (ToolStripItem) this.btnAddsymbols,
        (ToolStripItem) this.btnSaveportfolio,
        (ToolStripItem) this.btnUploadPortfolio
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(977, 25);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      this.cmbExchange.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbExchange.Name = "cmbExchange";
      this.cmbExchange.Size = new Size(110, 25);
      this.cmbSymbol.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(160, 25);
      this.cmbExpiry.Name = "cmbExpiry";
      this.cmbExpiry.Size = new Size(110, 25);
      this.cmbExpiry.Visible = false;
      this.btnAddsymbols.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnAddsymbols.Image = (Image) componentResourceManager.GetObject("btnAddsymbols.Image");
      this.btnAddsymbols.ImageTransparentColor = Color.Magenta;
      this.btnAddsymbols.Name = "btnAddsymbols";
      this.btnAddsymbols.Size = new Size(23, 22);
      this.btnAddsymbols.Text = "Add Symbol";
      this.btnSaveportfolio.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSaveportfolio.Image = (Image) componentResourceManager.GetObject("btnSaveportfolio.Image");
      this.btnSaveportfolio.ImageTransparentColor = Color.Magenta;
      this.btnSaveportfolio.Name = "btnSaveportfolio";
      this.btnSaveportfolio.Size = new Size(23, 22);
      this.btnSaveportfolio.Text = "Save Portfolio";
      this.btnUploadPortfolio.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnUploadPortfolio.Image = (Image) componentResourceManager.GetObject("btnUploadPortfolio.Image");
      this.btnUploadPortfolio.ImageTransparentColor = Color.Magenta;
      this.btnUploadPortfolio.Name = "btnUploadPortfolio";
      this.btnUploadPortfolio.Size = new Size(23, 22);
      this.btnUploadPortfolio.Text = "Load Portfolio";
      this.dgvMarketwatch.AllowUserToAddRows = false;
      this.dgvMarketwatch.AllowUserToDeleteRows = false;
      this.dgvMarketwatch.AllowUserToOrderColumns = true;
      this.dgvMarketwatch.AllowUserToResizeRows = false;
      this.dgvMarketwatch.BackgroundColor = Color.Black;
      this.dgvMarketwatch.CellBorderStyle = DataGridViewCellBorderStyle.None;
      this.dgvMarketwatch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvMarketwatch.Columns.AddRange((DataGridViewColumn) this.Exch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.BidQty, (DataGridViewColumn) this.bid, (DataGridViewColumn) this.ask, (DataGridViewColumn) this.AskQty, (DataGridViewColumn) this.LTP, (DataGridViewColumn) this.Open, (DataGridViewColumn) this.High, (DataGridViewColumn) this.Low, (DataGridViewColumn) this.Close, (DataGridViewColumn) this.Netchange, (DataGridViewColumn) this.Percenchange, (DataGridViewColumn) this.LastUpdate, (DataGridViewColumn) this.ColBuy, (DataGridViewColumn) this.ColSell);
      gridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle.BackColor = Color.Black;
      gridViewCellStyle.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle.ForeColor = SystemColors.ControlLightLight;
      gridViewCellStyle.SelectionBackColor = SystemColors.GrayText;
      gridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle.WrapMode = DataGridViewTriState.False;
      this.dgvMarketwatch.DefaultCellStyle = gridViewCellStyle;
      this.dgvMarketwatch.Dock = DockStyle.Fill;
      this.dgvMarketwatch.EditMode = DataGridViewEditMode.EditOnF2;
      this.dgvMarketwatch.GridColor = SystemColors.Control;
      this.dgvMarketwatch.Location = new Point(0, 25);
      this.dgvMarketwatch.Name = "dgvMarketwatch";
      this.dgvMarketwatch.ReadOnly = true;
      this.dgvMarketwatch.RowHeadersVisible = false;
      this.dgvMarketwatch.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvMarketwatch.Size = new Size(977, 431);
      this.dgvMarketwatch.TabIndex = 3;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Exch.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Symbol.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Symbol.Width = 150;
      this.BidQty.HeaderText = "BidQty";
      this.BidQty.Name = "BidQty";
      this.BidQty.ReadOnly = true;
      this.BidQty.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.BidQty.Width = 70;
      this.bid.HeaderText = "Bid";
      this.bid.Name = "bid";
      this.bid.ReadOnly = true;
      this.bid.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.bid.Width = 70;
      this.ask.HeaderText = "Ask";
      this.ask.Name = "ask";
      this.ask.ReadOnly = true;
      this.ask.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.ask.Width = 70;
      this.AskQty.HeaderText = "AskQty";
      this.AskQty.Name = "AskQty";
      this.AskQty.ReadOnly = true;
      this.AskQty.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.AskQty.Width = 70;
      this.LTP.HeaderText = "LTP";
      this.LTP.Name = "LTP";
      this.LTP.ReadOnly = true;
      this.LTP.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.LTP.Width = 70;
      this.Open.HeaderText = "Open";
      this.Open.Name = "Open";
      this.Open.ReadOnly = true;
      this.Open.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Open.Width = 60;
      this.High.HeaderText = "High";
      this.High.Name = "High";
      this.High.ReadOnly = true;
      this.High.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.High.Width = 60;
      this.Low.HeaderText = "Low";
      this.Low.Name = "Low";
      this.Low.ReadOnly = true;
      this.Low.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Low.Width = 60;
      this.Close.HeaderText = "Close";
      this.Close.Name = "Close";
      this.Close.ReadOnly = true;
      this.Close.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Close.Width = 60;
      this.Netchange.HeaderText = "Net Change";
      this.Netchange.Name = "Netchange";
      this.Netchange.ReadOnly = true;
      this.Netchange.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Netchange.Width = 70;
      this.Percenchange.HeaderText = "% Change";
      this.Percenchange.Name = "Percenchange";
      this.Percenchange.ReadOnly = true;
      this.Percenchange.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Percenchange.Width = 70;
      this.LastUpdate.HeaderText = "LTT";
      this.LastUpdate.Name = "LastUpdate";
      this.LastUpdate.ReadOnly = true;
      this.LastUpdate.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.LastUpdate.Width = 70;
      this.ColBuy.HeaderText = "B";
      this.ColBuy.Name = "ColBuy";
      this.ColBuy.ReadOnly = true;
      this.ColBuy.Resizable = DataGridViewTriState.True;
      this.ColBuy.SortMode = DataGridViewColumnSortMode.Automatic;
      this.ColBuy.ToolTipText = "Buy";
      this.ColBuy.Width = 20;
      this.ColSell.HeaderText = "S";
      this.ColSell.Name = "ColSell";
      this.ColSell.ReadOnly = true;
      this.ColSell.Resizable = DataGridViewTriState.True;
      this.ColSell.SortMode = DataGridViewColumnSortMode.Automatic;
      this.ColSell.ToolTipText = "Sell";
      this.ColSell.Width = 20;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.Controls.Add((Control) this.dgvMarketwatch);
      this.Controls.Add((Control) this.toolStrip1);
      this.Name = nameof (MarketWatch);
      this.Size = new Size(977, 456);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((ISupportInitialize) this.dgvMarketwatch).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
