﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDefExchMrgn
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmDefExchMrgn : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private Label label1;
    private Label label8;
    private TextBox txtnsecurrLots;
    private Label label11;
    private Label label20;
    private Label label12;
    private TextBox txtMcxlots;
    private Label label15;
    private Label label17;
    private Label label19;
    private TextBox txtncxlot;
    private TextBox txtnselot;
    private Label label2;
    private Label label3;
    private TextBox txtNseOptLots;
    private Button btnSave;

    public frmDefExchMrgn(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    private void frmDefExchMrgn_Load(object sender, EventArgs e)
    {
    }

    public void Loadwindow()
    {
      this.txtMcxlots.Enabled = this.txtncxlot.Enabled = this.txtnsecurrLots.Enabled = this.txtnselot.Enabled = this.txtNseOptLots.Enabled = false;
      if (this.objdash.objinfo.exchange.Contains(","))
      {
        string exchange = this.objdash.objinfo.exchange;
        char[] chArray = new char[1]{ ',' };
        foreach (string str in exchange.Split(chArray))
        {
          if (!(str == "MCX"))
          {
            if (!(str == "NSEFUT"))
            {
              if (!(str == "NCDEX"))
              {
                if (!(str == "NSECURR"))
                {
                  if (str == "NSEOPT")
                    this.txtNseOptLots.Enabled = true;
                }
                else
                  this.txtnsecurrLots.Enabled = true;
              }
              else
                this.txtncxlot.Enabled = true;
            }
            else
              this.txtnselot.Enabled = true;
          }
          else
            this.txtMcxlots.Enabled = true;
        }
      }
      else
      {
        string exchange = this.objdash.objinfo.exchange;
        if (!(exchange == "MCX"))
        {
          if (!(exchange == "NSEFUT"))
          {
            if (!(exchange == "NCDEX"))
            {
              if (!(exchange == "NSECURR"))
              {
                if (exchange == "NSEOPT")
                  this.txtNseOptLots.Enabled = true;
              }
              else
                this.txtnsecurrLots.Enabled = true;
            }
            else
              this.txtncxlot.Enabled = true;
          }
          else
            this.txtnselot.Enabled = true;
        }
        else
          this.txtMcxlots.Enabled = true;
      }
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select * from ExchwiseMarginLots where Clientcode = '" + this.objdash.objinfo.clientcode + "'", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(2))
              this.txtMcxlots.Text = sqlDataReader.GetValue(2).ToString();
            if (!sqlDataReader.IsDBNull(3))
              this.txtnselot.Text = sqlDataReader.GetValue(3).ToString();
            if (!sqlDataReader.IsDBNull(4))
              this.txtncxlot.Text = sqlDataReader.GetValue(4).ToString();
            if (!sqlDataReader.IsDBNull(5))
              this.txtnsecurrLots.Text = sqlDataReader.GetValue(5).ToString();
            if (!sqlDataReader.IsDBNull(6))
              this.txtNseOptLots.Text = sqlDataReader.GetValue(6).ToString();
          }
        }
      }
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      int result = 0;
      if (this.txtMcxlots.Text.Length > 0 && !int.TryParse(this.txtMcxlots.Text, out result))
        this.objdash.DisplayMessage("Enter Numeric lots MCX.", 2);
      else if (this.txtnselot.Text.Length > 0 && !int.TryParse(this.txtnselot.Text, out result))
        this.objdash.DisplayMessage("Enter Numeric lots NSEFUT.", 2);
      else if (this.txtnsecurrLots.Text.Length > 0 && !int.TryParse(this.txtnsecurrLots.Text, out result))
        this.objdash.DisplayMessage("Enter Numeric lots NSECURR.", 2);
      else if (this.txtncxlot.Text.Length > 0 && !int.TryParse(this.txtncxlot.Text, out result))
        this.objdash.DisplayMessage("Enter Numeric lots NCDEX.", 2);
      else if (this.txtNseOptLots.Text.Length > 0 && !int.TryParse(this.txtNseOptLots.Text, out result))
      {
        this.objdash.DisplayMessage("Enter Numeric lots NSEOPT.", 2);
      }
      else
      {
        SqlConnection conn = this.objdash.getConn();
        if (conn.State != ConnectionState.Open)
          return;
        SqlCommand sqlCommand1 = new SqlCommand("SaveExchMrgn", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.objdash.objinfo.clientcode);
          sqlCommand2.Parameters.AddWithValue("@mcxlots", (object) this.txtMcxlots.Text);
          sqlCommand2.Parameters.AddWithValue("@nsefutlots", (object) this.txtnselot.Text);
          sqlCommand2.Parameters.AddWithValue("@nsecurrlots", (object) this.txtnsecurrLots.Text);
          sqlCommand2.Parameters.AddWithValue("@ncxlots", (object) this.txtncxlot.Text);
          sqlCommand2.Parameters.AddWithValue("@nseopt", (object) this.txtNseOptLots.Text);
          try
          {
            sqlCommand2.ExecuteNonQuery();
            this.objdash.DisplayMessage("Exchangewise Default Margin Saved Successfully!!.", 1);
          }
          catch
          {
            this.objdash.DisplayMessage("Unable to Save Record.", 2);
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.label8 = new Label();
      this.txtnsecurrLots = new TextBox();
      this.label11 = new Label();
      this.label20 = new Label();
      this.label12 = new Label();
      this.txtMcxlots = new TextBox();
      this.label15 = new Label();
      this.label17 = new Label();
      this.label19 = new Label();
      this.txtncxlot = new TextBox();
      this.txtnselot = new TextBox();
      this.label2 = new Label();
      this.label3 = new Label();
      this.txtNseOptLots = new TextBox();
      this.btnSave = new Button();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.ForeColor = Color.Black;
      this.label1.Location = new Point(235, 93);
      this.label1.Name = "label1";
      this.label1.Size = new Size(33, 13);
      this.label1.TabIndex = 71;
      this.label1.Text = " Lots.";
      this.label8.AutoSize = true;
      this.label8.ForeColor = Color.Black;
      this.label8.Location = new Point(55, 93);
      this.label8.Name = "label8";
      this.label8.Size = new Size(63, 13);
      this.label8.TabIndex = 69;
      this.label8.Text = "NSECURR:";
      this.txtnsecurrLots.BackColor = Color.WhiteSmoke;
      this.txtnsecurrLots.ForeColor = Color.Black;
      this.txtnsecurrLots.Location = new Point(167, 90);
      this.txtnsecurrLots.MaxLength = 3;
      this.txtnsecurrLots.Name = "txtnsecurrLots";
      this.txtnsecurrLots.Size = new Size(62, 20);
      this.txtnsecurrLots.TabIndex = 3;
      this.txtnsecurrLots.Text = "0";
      this.label11.AutoSize = true;
      this.label11.ForeColor = Color.Black;
      this.label11.Location = new Point(235, 44);
      this.label11.Name = "label11";
      this.label11.Size = new Size(33, 13);
      this.label11.TabIndex = 68;
      this.label11.Text = " Lots.";
      this.label20.AutoSize = true;
      this.label20.ForeColor = Color.Black;
      this.label20.Location = new Point(55, 18);
      this.label20.Name = "label20";
      this.label20.Size = new Size(33, 13);
      this.label20.TabIndex = 60;
      this.label20.Text = "MCX:";
      this.label12.AutoSize = true;
      this.label12.ForeColor = Color.Black;
      this.label12.Location = new Point(235, 69);
      this.label12.Name = "label12";
      this.label12.Size = new Size(33, 13);
      this.label12.TabIndex = 67;
      this.label12.Text = " Lots.";
      this.txtMcxlots.BackColor = Color.WhiteSmoke;
      this.txtMcxlots.ForeColor = Color.Black;
      this.txtMcxlots.Location = new Point(167, 15);
      this.txtMcxlots.MaxLength = 3;
      this.txtMcxlots.Name = "txtMcxlots";
      this.txtMcxlots.Size = new Size(62, 20);
      this.txtMcxlots.TabIndex = 0;
      this.txtMcxlots.Text = "0";
      this.label15.AutoSize = true;
      this.label15.ForeColor = Color.Black;
      this.label15.Location = new Point(235, 18);
      this.label15.Name = "label15";
      this.label15.Size = new Size(33, 13);
      this.label15.TabIndex = 66;
      this.label15.Text = " Lots.";
      this.label17.AutoSize = true;
      this.label17.ForeColor = Color.Black;
      this.label17.Location = new Point(55, 43);
      this.label17.Name = "label17";
      this.label17.Size = new Size(53, 13);
      this.label17.TabIndex = 63;
      this.label17.Text = "NSEFUT:";
      this.label19.AutoSize = true;
      this.label19.ForeColor = Color.Black;
      this.label19.Location = new Point(55, 68);
      this.label19.Name = "label19";
      this.label19.Size = new Size(47, 13);
      this.label19.TabIndex = 62;
      this.label19.Text = "NCDEX:";
      this.txtncxlot.BackColor = Color.WhiteSmoke;
      this.txtncxlot.ForeColor = Color.Black;
      this.txtncxlot.Location = new Point(167, 65);
      this.txtncxlot.MaxLength = 3;
      this.txtncxlot.Name = "txtncxlot";
      this.txtncxlot.Size = new Size(62, 20);
      this.txtncxlot.TabIndex = 2;
      this.txtncxlot.Text = "0";
      this.txtnselot.BackColor = Color.WhiteSmoke;
      this.txtnselot.ForeColor = Color.Black;
      this.txtnselot.Location = new Point(167, 40);
      this.txtnselot.MaxLength = 3;
      this.txtnselot.Name = "txtnselot";
      this.txtnselot.Size = new Size(62, 20);
      this.txtnselot.TabIndex = 1;
      this.txtnselot.Text = "0";
      this.label2.AutoSize = true;
      this.label2.ForeColor = Color.Black;
      this.label2.Location = new Point(235, 119);
      this.label2.Name = "label2";
      this.label2.Size = new Size(33, 13);
      this.label2.TabIndex = 74;
      this.label2.Text = " Lots.";
      this.label3.AutoSize = true;
      this.label3.ForeColor = Color.Black;
      this.label3.Location = new Point(55, 119);
      this.label3.Name = "label3";
      this.label3.Size = new Size(54, 13);
      this.label3.TabIndex = 72;
      this.label3.Text = "NSEOPT:";
      this.txtNseOptLots.BackColor = Color.WhiteSmoke;
      this.txtNseOptLots.ForeColor = Color.Black;
      this.txtNseOptLots.Location = new Point(167, 116);
      this.txtNseOptLots.MaxLength = 3;
      this.txtNseOptLots.Name = "txtNseOptLots";
      this.txtNseOptLots.Size = new Size(62, 20);
      this.txtNseOptLots.TabIndex = 4;
      this.txtNseOptLots.Text = "0";
      this.btnSave.Location = new Point(124, 153);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 23);
      this.btnSave.TabIndex = 5;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(323, 190);
      this.Controls.Add((Control) this.btnSave);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.txtNseOptLots);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.label8);
      this.Controls.Add((Control) this.txtnsecurrLots);
      this.Controls.Add((Control) this.label11);
      this.Controls.Add((Control) this.label20);
      this.Controls.Add((Control) this.label12);
      this.Controls.Add((Control) this.txtMcxlots);
      this.Controls.Add((Control) this.label15);
      this.Controls.Add((Control) this.label17);
      this.Controls.Add((Control) this.label19);
      this.Controls.Add((Control) this.txtncxlot);
      this.Controls.Add((Control) this.txtnselot);
      this.MaximizeBox = false;
      this.Name = nameof (frmDefExchMrgn);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Exchangewise Margin(Lots)";
      this.Load += new EventHandler(this.frmDefExchMrgn_Load);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
