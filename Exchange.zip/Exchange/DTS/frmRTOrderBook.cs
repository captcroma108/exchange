﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmRTOrderBook
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmRTOrderBook : Form
  {
    private int index = -1;
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private Thread threadObjRT_Orders;
    public int dgvrowindex;
    private DataGridView dgvOrdersList;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem executeMarketToolStripMenuItem;
    private ToolStripMenuItem executeAllMarketToolStripMenuItem;
    private ToolStripMenuItem cancelToolStripMenuItem;
    private ToolStripMenuItem cancelAllToolStripMenuItem;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripLabel toolStripLabel1;
    private ToolStripComboBox cmbExch;
    private ToolStripLabel toolStripLabel4;
    private ToolStripComboBox cmbSymbol;
    private ToolStripLabel toolStripLabel5;
    private ToolStripComboBox cmbBuySell;
    private ToolStripLabel toolStripLabel3;
    private ToolStripComboBox cmbTraderid;
    private ToolStripButton btnSearch;
    private ToolStripMenuItem exportToCsvToolStripMenuItem;
    private ToolStripMenuItem copyToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripSeparator toolStripSeparator3;
    private DataGridViewTextBoxColumn regulationcode;
    private DataGridViewTextBoxColumn ColName;
    private DataGridViewTextBoxColumn Exchange;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn ColExpiry;
    private DataGridViewTextBoxColumn ProductType;
    private DataGridViewTextBoxColumn Buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Orderby;
    private DataGridViewTextBoxColumn Status;
    private DataGridViewTextBoxColumn UserRemarks;
    private DataGridViewTextBoxColumn LastModified;
    private DataGridViewTextBoxColumn colOrderno;
    private DataGridViewTextBoxColumn colDacode;
    private DataGridViewTextBoxColumn colIp;
    private DataGridViewCheckBoxColumn read;

    public frmRTOrderBook(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadWindow()
    {
      this.Location = Settings.Default.RTOrdbookLocation;
      if (this.threadObjRT_Orders != null)
        return;
      this.threadObjRT_Orders = new Thread(new ThreadStart(((ThreadStart) (() => this.LoadRTOrders())).Invoke));
      this.threadObjRT_Orders.Start();
    }

    private void LoadRTOrders()
    {
      SqlConnection conn = this.objdash.getConn();
      DateTime dateTime = this.objdash.GetServerTime();
      dateTime = new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 9, 0, 0);
      List<double> doubleList1 = new List<double>();
      List<double> doubleList2 = new List<double>();
      this.Invoke((Delegate) (() => this.clearCombobox()));
      int num = this.objdash.objinfo.usertype - 1;
      while (true)
      {
        try
        {
          if (conn.State == ConnectionState.Open)
          {
            SqlCommand sqlCommand1 = new SqlCommand("GetRTOrders", conn);
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            using (SqlCommand sqlCommand2 = sqlCommand1)
            {
              sqlCommand2.Parameters.AddWithValue("@DAcode", (object) this.objdash.objinfo.clientcode);
              sqlCommand2.Parameters.AddWithValue("@lastupdatetime", (object) dateTime);
              sqlCommand2.Parameters.AddWithValue("@type", (object) num);
              using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  Orders objord = new Orders();
                  string exch = string.Empty;
                  string empty1 = string.Empty;
                  string BuySell = string.Empty;
                  string empty2 = string.Empty;
                  string status = string.Empty;
                  if (!sqlDataReader.IsDBNull(0))
                    objord.accountNo = sqlDataReader.GetString(0);
                  if (!sqlDataReader.IsDBNull(14))
                    objord.AccName = sqlDataReader.GetString(14);
                  if (!sqlDataReader.IsDBNull(1))
                    exch = sqlDataReader.GetString(1);
                  if (!sqlDataReader.IsDBNull(2))
                    objord.symbol = sqlDataReader.GetString(2);
                  if (!sqlDataReader.IsDBNull(3))
                    empty1 = sqlDataReader.GetString(3);
                  if (!sqlDataReader.IsDBNull(4))
                    BuySell = sqlDataReader.GetString(4);
                  if (!sqlDataReader.IsDBNull(5))
                    objord.Ordeqty = sqlDataReader.GetInt32(5);
                  if (!sqlDataReader.IsDBNull(6))
                    objord.OrdePrice = Convert.ToDecimal(sqlDataReader.GetValue(6));
                  if (!sqlDataReader.IsDBNull(7))
                    empty2 = sqlDataReader.GetString(7);
                  if (!sqlDataReader.IsDBNull(8))
                    objord.TraderId = sqlDataReader.GetString(8);
                  if (!sqlDataReader.IsDBNull(9))
                    objord.Orderstatus = sqlDataReader.GetInt32(9);
                  if (!sqlDataReader.IsDBNull(10))
                    objord.UserRemark = sqlDataReader.GetString(10);
                  if (!sqlDataReader.IsDBNull(11))
                    objord.CreatedOn = Convert.ToDateTime(sqlDataReader.GetValue(11));
                  if (!sqlDataReader.IsDBNull(12))
                    objord.LastModified = Convert.ToDateTime(sqlDataReader.GetValue(12));
                  if (!sqlDataReader.IsDBNull(13))
                    objord.OrderNo = Convert.ToDouble(sqlDataReader.GetValue(13));
                  objord.ipAddress = !sqlDataReader.IsDBNull(15) ? sqlDataReader.GetString(15).Trim() : string.Empty;
                  if (this.objdash.objinfo.usertype == 3 || this.objdash._lstAccounts.Contains(objord.accountNo))
                  {
                    dateTime = objord.LastModified;
                    if (objord.Orderstatus == 2 && objord.CreatedOn == objord.LastModified)
                      status = "PENDING";
                    else if (objord.Orderstatus == 2 && objord.CreatedOn < objord.LastModified)
                      status = "MODIFIED";
                    else if (objord.Orderstatus == 3)
                      status = "CANCELLED";
                    string traderId = objord.TraderId;
                    string[] strArray = objord.symbol.Split(' ');
                    if (!doubleList1.Contains(objord.OrderNo) && objord.Orderstatus == 2)
                    {
                      object[] rows = new object[17]
                      {
                        (object) objord.accountNo,
                        (object) objord.AccName,
                        (object) exch,
                        (object) strArray[0],
                        (object) strArray[1],
                        (object) empty1,
                        (object) BuySell.Substring(0, 1),
                        (object) objord.Ordeqty,
                        (object) objord.OrdePrice,
                        (object) empty2,
                        (object) traderId,
                        (object) status,
                        (object) objord.UserRemark,
                        (object) objord.LastModified.ToString("HH:mm:ss"),
                        (object) objord.OrderNo,
                        null,
                        (object) objord.ipAddress
                      };
                      this.Invoke((Delegate) (() =>
                      {
                        this.FillCombobox(objord, exch);
                        this.dgvOrdersList.Rows.Insert(0, rows);
                        if (BuySell == "BUY")
                          this.dgvOrdersList.Rows[0].DefaultCellStyle.BackColor = Color.LightBlue;
                        else
                          this.dgvOrdersList.Rows[0].DefaultCellStyle.BackColor = Color.Pink;
                        this.findOrdNO1();
                      }));
                      doubleList1.Add(objord.OrderNo);
                    }
                    else
                      this.UpdateOrders(objord.OrderNo, status, objord.Orderstatus, objord);
                  }
                }
              }
            }
          }
          Thread.Sleep(3000);
        }
        catch
        {
          Thread.Sleep(5000);
        }
      }
    }

    private void clearCombobox()
    {
      this.cmbclientcode.Items.Clear();
      this.cmbclientcode.Items.Add((object) "");
      this.cmbExch.Items.Clear();
      this.cmbExch.Items.Add((object) "");
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "");
      this.cmbTraderid.Items.Clear();
      this.cmbTraderid.Items.Add((object) "");
    }

    private void FillCombobox(Orders objord, string exch)
    {
      if (!this.cmbclientcode.Items.Contains((object) objord.accountNo))
        this.cmbclientcode.Items.Add((object) objord.accountNo);
      if (!this.cmbExch.Items.Contains((object) exch))
        this.cmbExch.Items.Add((object) exch);
      if (!this.cmbSymbol.Items.Contains((object) objord.symbol))
        this.cmbSymbol.Items.Add((object) objord.symbol);
      if (this.cmbTraderid.Items.Contains((object) objord.TraderId))
        return;
      this.cmbTraderid.Items.Add((object) objord.TraderId);
    }

    private void UpdateOrders(double orderno, string status, int stat, Orders objord)
    {
      foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
      {
        if (Convert.ToDouble(row.Cells[14].Value) == orderno)
        {
          if (stat == 1 || stat == 3)
          {
            row.Visible = false;
          }
          else
          {
            row.Cells[7].Value = (object) objord.Ordeqty;
            row.Cells[8].Value = (object) objord.OrdePrice;
            row.Cells[13].Value = (object) objord.LastModified.ToString("HH:mm:ss");
          }
        }
      }
      if (this.dgvOrdersList.Rows.Count <= 0)
        return;
      this.dgvOrdersList.Rows[0].Selected = true;
    }

    private void dgvOrdersList_MouseClick(object sender, MouseEventArgs e)
    {
      if (this.dgvOrdersList.Rows.Count > 0)
      {
        int rowIndex = this.dgvOrdersList.HitTest(e.X, e.Y).RowIndex;
        if (rowIndex > -1)
          this.dgvOrdersList.Rows[rowIndex].Selected = true;
      }
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvOrdersList.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvOrdersList, client.X, client.Y);
    }

    private void executeMarketToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvOrdersList.Rows.Count <= 0)
        return;
      DataGridView dgvOrdersList = this.dgvOrdersList;
      if (dgvOrdersList != null)
      {
        int index = dgvOrdersList.CurrentRow.Index;
        string account = this.dgvOrdersList.Rows[index].Cells[0].Value.ToString();
        string exch = this.dgvOrdersList.Rows[index].Cells[2].Value.ToString();
        string key = string.Format("{0} {1}", (object) this.dgvOrdersList.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrdersList.Rows[index].Cells[4].Value.ToString());
        string str1 = this.dgvOrdersList.Rows[index].Cells[6].Value.ToString();
        int num1 = 1;
        if (str1 == "S")
          num1 = 2;
        int int32 = Convert.ToInt32(this.dgvOrdersList.Rows[index].Cells[7].Value.ToString());
        double num2 = Convert.ToDouble(this.dgvOrdersList.Rows[index].Cells[14].Value.ToString());
        string empty = string.Empty;
        DateTime dtnow = new DateTime();
        if (!this.objdash.ValidateMarketTime(exch, ref dtnow))
        {
          this.objdash.DisplayMessage(string.Format(" {0} Market is closed!!", (object) exch), 2);
          this.objdash.insertSurveillanceMessages(account, string.Format(" {0} Market is closed!!", (object) exch), dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
        }
        else if (this.objdash._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objdash._Symconctracts[key];
          DateTime serverTime = this.objdash.GetServerTime();
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.objdash.getFeed(symbol);
          Trades trades = new Trades()
          {
            Symbol = key,
            clientcode = account,
            qty = int32,
            orderno = num2,
            Createon = serverTime,
            Lastmodified = serverTime,
            buysell = num1,
            exch = (int) Enum.Parse(typeof (Exch), exch),
            traderid = "Admin",
            exectype = 2
          };
          trades.price = num1 != 1 ? feed.bid : feed.ask;
          if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.InsertPendingTrade(trades, this.objdash))
          {
            string str2 = " TRADE: " + Utils.GetExch(trades.exch) + ": ";
            string str3 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1}   N {2} LOTS/{3} LOTS  AT Rs. {4} FOR CLI {5} TRADE", (object) trades.orderno, (object) symconctract.symbol, (object) trades.qty, (object) trades.qty, (object) trades.price, (object) trades.clientcode);
            this.objdash.clearMsgBoard();
            switch (trades.buysell)
            {
              case 1:
                string str4 = string.Format("{0} BOUGHT : {1}", (object) str2, (object) str3);
                this.objdash.InsertMsgBoard(str4, 1);
                this.objdash.SaveMessageLogs(str4, trades);
                this.objdash.InsertMessage(trades.clientcode, " Order Executed by Admin: " + str4, 5);
                this.dgvOrdersList.Rows.Remove(this.dgvOrdersList.Rows[index]);
                break;
              case 2:
                string str5 = string.Format("{0} SOLD : {1}", (object) str2, (object) str3);
                this.objdash.InsertMsgBoard(str5, 1);
                this.objdash.SaveMessageLogs(str5, trades);
                this.objdash.InsertMessage(trades.clientcode, " Order Executed by Admin: " + str5, 5);
                this.dgvOrdersList.Rows.Remove(this.dgvOrdersList.Rows[index]);
                break;
            }
          }
        }
      }
    }

    private void executeAllMarketToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvOrdersList.Rows.Count <= 0 || this.dgvOrdersList == null)
        return;
      for (int index1 = 0; index1 < this.dgvOrdersList.Rows.Count; ++index1)
      {
        int index2 = index1;
        string str1 = this.dgvOrdersList.Rows[index2].Cells[0].Value.ToString();
        string exch = this.dgvOrdersList.Rows[index2].Cells[2].Value.ToString();
        string key = string.Format("{0} {1}", (object) this.dgvOrdersList.Rows[index2].Cells[3].Value.ToString(), (object) this.dgvOrdersList.Rows[index2].Cells[4].Value.ToString());
        string str2 = this.dgvOrdersList.Rows[index2].Cells[6].Value.ToString();
        int num1 = 1;
        if (str2 == "S")
          num1 = 2;
        int int32 = Convert.ToInt32(this.dgvOrdersList.Rows[index2].Cells[7].Value.ToString());
        double num2 = Convert.ToDouble(this.dgvOrdersList.Rows[index2].Cells[14].Value.ToString());
        string empty = string.Empty;
        DateTime dtnow = new DateTime();
        if (this.objdash.ValidateMarketTime(exch, ref dtnow) && this.objdash._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objdash._Symconctracts[key];
          DateTime serverTime = this.objdash.GetServerTime();
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.objdash.getFeed(symbol);
          Trades trades = new Trades()
          {
            Symbol = key,
            clientcode = str1,
            qty = int32,
            orderno = num2,
            Createon = serverTime,
            Lastmodified = serverTime,
            buysell = num1,
            exch = (int) Enum.Parse(typeof (Exch), exch),
            traderid = "Admin",
            exectype = 2
          };
          trades.price = num1 != 1 ? feed.bid : feed.ask;
          if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.InsertPendingTrade(trades, this.objdash))
          {
            string str3 = " TRADE: " + Utils.GetExch(trades.exch) + ": ";
            string str4 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1}   N {2} LOTS/{3} LOTS  AT Rs. {4} FOR CLI {5} TRADE", (object) trades.orderno, (object) symconctract.symbol, (object) trades.qty, (object) trades.qty, (object) trades.price, (object) trades.clientcode);
            this.objdash.clearMsgBoard();
            switch (trades.buysell)
            {
              case 1:
                string str5 = string.Format("{0} BOUGHT : {1}", (object) str3, (object) str4);
                this.objdash.InsertMsgBoard(str5, 1);
                this.objdash.SaveMessageLogs(str5, trades);
                this.objdash.InsertMessage(trades.clientcode, " Order Executed by Admin: " + str5, 5);
                this.dgvOrdersList.Rows.Remove(this.dgvOrdersList.Rows[index2]);
                break;
              case 2:
                string str6 = string.Format("{0} SOLD : {1}", (object) str3, (object) str4);
                this.objdash.InsertMsgBoard(str6, 1);
                this.objdash.SaveMessageLogs(str6, trades);
                this.objdash.InsertMessage(trades.clientcode, " Order Executed by Admin: " + str6, 5);
                this.dgvOrdersList.Rows.Remove(this.dgvOrdersList.Rows[index2]);
                break;
            }
          }
        }
      }
    }

    private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
    {
      DataGridView dgvOrdersList = this.dgvOrdersList;
      if (dgvOrdersList == null)
        return;
      try
      {
        if (MessageBox.Show("Do you really want to Cancel this Order?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
        {
          DataGridViewRow currentRow = dgvOrdersList.CurrentRow;
          int index = currentRow.Index;
          string exch = dgvOrdersList.Rows[currentRow.Index].Cells[2].Value.ToString();
          string symbol = string.Format("{0} {1}", (object) this.dgvOrdersList.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrdersList.Rows[index].Cells[4].Value.ToString());
          string buysell = !(dgvOrdersList.Rows[currentRow.Index].Cells[6].Value.ToString() == "B") ? "SELL" : "BUY";
          string qty = dgvOrdersList.Rows[currentRow.Index].Cells[7].Value.ToString();
          string price = dgvOrdersList.Rows[currentRow.Index].Cells[8].Value.ToString();
          double orderno = Convert.ToDouble(dgvOrdersList.Rows[currentRow.Index].Cells[14].Value);
          if (!this.ValidatePendingOrder(orderno))
          {
            this.objdash.DisplayMessage("Order already executed, cannot cancel this order", 2);
          }
          else
          {
            string str = dgvOrdersList.Rows[currentRow.Index].Cells[0].Value.ToString();
            DateTime dtnow = new DateTime();
            if (!this.objdash.ValidateMarketTime(exch, ref dtnow))
            {
              this.objdash.DisplayMessage(string.Format(" {0} Market is closed!!", (object) exch), 2);
              this.objdash.insertSurveillanceMessages(str, string.Format(" {0} Market is closed!!", (object) exch), dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
            }
            else
            {
              this.CancelOrder(orderno, str, exch, buysell, qty, symbol, price);
              this.dgvOrdersList.Rows.Remove(this.dgvOrdersList.Rows[index]);
            }
          }
        }
      }
      catch
      {
      }
    }

    private void CancelOrder(
      double orderno,
      string regulationcode,
      string exch,
      string buysell,
      string qty,
      string symbol,
      string price)
    {
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      SqlCommand sqlCommand1 = new SqlCommand("CancelOrders", conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@Orderno", (object) orderno);
        sqlCommand2.Parameters.AddWithValue("@accountno", (object) regulationcode);
        try
        {
          sqlCommand2.ExecuteNonQuery();
          this.DisplayConfirmation(exch, buysell, orderno.ToString(), qty, symbol, price, regulationcode, 2);
        }
        catch
        {
          this.objdash.DisplayMessage("Unable to Cancel Order", 3);
        }
      }
    }

    private void DisplayConfirmation(
      string exch,
      string buysell,
      string OrderNo,
      string Ordeqty,
      string symbol,
      string OrdePrice,
      string accountNo,
      int flag)
    {
      string empty1 = string.Empty;
      string str;
      if (flag == 1)
        str = string.Format("  ORDER : {0} FUT, {1}  {2}  CarryForWard {3} {4}  N at Rs. {5} VALIDITY: DAY For CLI {6} MODIFY CONFIRMED", (object) exch, (object) OrderNo, (object) buysell, (object) Ordeqty, (object) symbol, (object) OrdePrice, (object) accountNo);
      else
        str = string.Format("  ORDER : {0} FUT, {1}   {2}  CarryForWard  {3}  {4}  N at Rs. {5}  VALIDITY: DAY For CLI {6}  CANCELLED", (object) exch, (object) OrderNo, (object) buysell, (object) Ordeqty, (object) symbol, (object) OrdePrice, (object) accountNo);
      this.objdash.clearMsgBoard();
      this.objdash.InsertMsgBoard(str, 1);
      string empty2 = string.Empty;
      Trades objord = new Trades()
      {
        clientcode = accountNo,
        Lastmodified = this.objdash.GetServerTime()
      };
      this.objdash.SaveMessageLogs(str, objord);
    }

    private void cancelAllToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvOrdersList.Rows.Count > 0)
      {
        if (MessageBox.Show("Do you really want to Cancel All the Orders?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
          return;
        for (int index = 0; index < this.dgvOrdersList.Rows.Count; ++index)
        {
          string exch = this.dgvOrdersList.Rows[index].Cells[2].Value.ToString();
          string symbol = string.Format("{0} {1}", (object) this.dgvOrdersList.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrdersList.Rows[index].Cells[4].Value.ToString());
          string buysell = !(this.dgvOrdersList.Rows[index].Cells[6].Value.ToString() == "B") ? "SELL" : "BUY";
          string qty = this.dgvOrdersList.Rows[index].Cells[7].Value.ToString();
          string price = this.dgvOrdersList.Rows[index].Cells[8].Value.ToString();
          double orderno = Convert.ToDouble(this.dgvOrdersList.Rows[index].Cells[14].Value);
          if (this.ValidatePendingOrder(orderno))
          {
            string regulationcode = this.dgvOrdersList.Rows[index].Cells[0].Value.ToString();
            DateTime now = DateTime.Now;
            if (!this.objdash.ValidateMarketTime(exch, ref now))
              return;
            this.CancelOrder(orderno, regulationcode, exch, buysell, qty, symbol, price);
          }
        }
        this.dgvOrdersList.Rows.Clear();
      }
      else
        this.objdash.DisplayMessage("No Orders to Cancel", 2);
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvOrdersList.Rows)
          row.Visible = true;
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && (str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text) && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(this.cmbclientcode.Text == string.Empty) || !(this.cmbExch.Text == string.Empty) || (!(this.cmbSymbol.Text == string.Empty) || !(this.cmbBuySell.Text == string.Empty)) || !(this.cmbTraderid.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
        {
          if (row.Cells[10].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    private void frmRTOrderBook_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.C)
        this.cmbclientcode.Focus();
      else if (e.KeyCode == Keys.E)
        this.cmbExch.Focus();
      else if (e.KeyCode == Keys.S)
        this.cmbSymbol.Focus();
      else if (e.KeyCode == Keys.T)
      {
        this.cmbTraderid.Focus();
      }
      else
      {
        if (e.KeyCode != Keys.Escape)
          return;
        Settings.Default.RTOrdbookLocation = this.Location;
        Settings.Default.Save();
        this.Close();
      }
    }

    private void exportToCsvToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Export.ExportToExcel(this.dgvOrdersList, false);
    }

    private void copyToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Clipboard.SetDataObject((object) this.dgvOrdersList.GetClipboardContent());
    }

    private void frmRTOrderBook_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (this.threadObjRT_Orders == null)
        return;
      this.threadObjRT_Orders.Abort();
    }

    private bool ValidatePendingOrder(double orderno)
    {
      SqlConnection conn = this.objdash.getConn();
      if (conn.State == ConnectionState.Open)
      {
        using (SqlCommand sqlCommand = new SqlCommand("Select Count(ID) from Orders where Orderno = " + (object) orderno + " and OrdStatus = 2", conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(0))
                return sqlDataReader.GetInt32(0) >= 1;
            }
          }
        }
      }
      return true;
    }

    private void dgvOrdersList_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      this.dgvrowindex = e.RowIndex;
      if (this.dgvrowindex <= -1)
        return;
      this.dgvOrdersList.Rows[this.dgvrowindex].Selected = true;
      if (this.dgvOrdersList.Rows[e.RowIndex].Cells[17].Value == null)
      {
        int index = this.dgvOrdersList.Rows[e.RowIndex].Index;
        string str = this.dgvOrdersList.Rows[e.RowIndex].Cells[14].Value.ToString();
        this.dgvOrdersList.Rows[e.RowIndex].Cells[17].Value = (object) true;
        Settings.Default.ordindex = index;
        Settings.Default.OrdordNo = str;
        Settings.Default.Save();
        this.findOrdNO();
      }
      else if ((bool) this.dgvOrdersList.Rows[e.RowIndex].Cells[17].Value)
      {
        this.index = this.dgvOrdersList.Rows[e.RowIndex].Index;
        string str = this.index != this.dgvOrdersList.Rows.Count - 1 ? this.dgvOrdersList.Rows[e.RowIndex + 1].Cells[14].Value.ToString() : this.dgvOrdersList.Rows[e.RowIndex].Cells[14].Value.ToString();
        this.dgvOrdersList.Rows[e.RowIndex].Cells[17].Value = (object) false;
        Settings.Default.OrdordNo = str;
        Settings.Default.ordindex = this.index + 1;
        this.untick();
      }
      else
      {
        int index = this.dgvOrdersList.Rows[e.RowIndex].Index;
        string str = this.dgvOrdersList.Rows[e.RowIndex].Cells[14].Value.ToString();
        this.dgvOrdersList.Rows[e.RowIndex].Cells[17].Value = (object) true;
        Settings.Default.ordindex = index;
        Settings.Default.OrdordNo = str;
        Settings.Default.Save();
        this.findOrdNO();
      }
    }

    public void untick()
    {
      if (this.index <= -1)
        return;
      for (int index = this.index; index >= 0; --index)
        this.dgvOrdersList.Rows[index].Cells[17].Value = (object) false;
    }

    public void findOrdNO()
    {
      foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
      {
        if (row.Cells[1].Value != null)
        {
          string str = row.Cells[14].Value.ToString();
          int ordindex = Settings.Default.ordindex;
          if (str == Settings.Default.OrdordNo)
          {
            int count = this.dgvOrdersList.Rows.Count;
            if (ordindex >= 0)
            {
              for (int index = ordindex; index < count; ++index)
                this.dgvOrdersList.Rows[index].Cells[17].Value = (object) true;
            }
            else
              this.dgvOrdersList.Rows[row.Index].Cells[17].Value = (object) false;
          }
        }
      }
    }

    public void findOrdNO1()
    {
      foreach (DataGridViewRow row in (IEnumerable) this.dgvOrdersList.Rows)
      {
        if (row.Cells[1].Value != null && row.Cells[14].Value.ToString() == Settings.Default.OrdordNo)
        {
          int index1 = row.Index;
          int count = this.dgvOrdersList.Rows.Count;
          if (index1 >= 0)
          {
            for (int index2 = index1; index2 < count; ++index2)
              this.dgvOrdersList.Rows[index2].Cells[17].Value = (object) true;
          }
          else
            this.dgvOrdersList.Rows[row.Index].Cells[17].Value = (object) false;
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      DataGridViewCellStyle gridViewCellStyle = new DataGridViewCellStyle();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (frmRTOrderBook));
      this.dgvOrdersList = new DataGridView();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.executeMarketToolStripMenuItem = new ToolStripMenuItem();
      this.executeAllMarketToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator1 = new ToolStripSeparator();
      this.cancelToolStripMenuItem = new ToolStripMenuItem();
      this.cancelAllToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator2 = new ToolStripSeparator();
      this.exportToCsvToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator3 = new ToolStripSeparator();
      this.copyToolStripMenuItem = new ToolStripMenuItem();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.toolStripLabel1 = new ToolStripLabel();
      this.cmbExch = new ToolStripComboBox();
      this.toolStripLabel4 = new ToolStripLabel();
      this.cmbSymbol = new ToolStripComboBox();
      this.toolStripLabel5 = new ToolStripLabel();
      this.cmbBuySell = new ToolStripComboBox();
      this.toolStripLabel3 = new ToolStripLabel();
      this.cmbTraderid = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      this.regulationcode = new DataGridViewTextBoxColumn();
      this.ColName = new DataGridViewTextBoxColumn();
      this.Exchange = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.ColExpiry = new DataGridViewTextBoxColumn();
      this.ProductType = new DataGridViewTextBoxColumn();
      this.Buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Orderby = new DataGridViewTextBoxColumn();
      this.Status = new DataGridViewTextBoxColumn();
      this.UserRemarks = new DataGridViewTextBoxColumn();
      this.LastModified = new DataGridViewTextBoxColumn();
      this.colOrderno = new DataGridViewTextBoxColumn();
      this.colDacode = new DataGridViewTextBoxColumn();
      this.colIp = new DataGridViewTextBoxColumn();
      this.read = new DataGridViewCheckBoxColumn();
      ((ISupportInitialize) this.dgvOrdersList).BeginInit();
      this.contextMenuStrip1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvOrdersList.AllowUserToAddRows = false;
      this.dgvOrdersList.AllowUserToDeleteRows = false;
      this.dgvOrdersList.AllowUserToOrderColumns = true;
      this.dgvOrdersList.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvOrdersList.BackgroundColor = Color.White;
      this.dgvOrdersList.CellBorderStyle = DataGridViewCellBorderStyle.None;
      this.dgvOrdersList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvOrdersList.Columns.AddRange((DataGridViewColumn) this.regulationcode, (DataGridViewColumn) this.ColName, (DataGridViewColumn) this.Exchange, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.ColExpiry, (DataGridViewColumn) this.ProductType, (DataGridViewColumn) this.Buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Orderby, (DataGridViewColumn) this.Status, (DataGridViewColumn) this.UserRemarks, (DataGridViewColumn) this.LastModified, (DataGridViewColumn) this.colOrderno, (DataGridViewColumn) this.colDacode, (DataGridViewColumn) this.colIp, (DataGridViewColumn) this.read);
      gridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle.BackColor = SystemColors.Window;
      gridViewCellStyle.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle.ForeColor = SystemColors.ControlText;
      gridViewCellStyle.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle.WrapMode = DataGridViewTriState.False;
      this.dgvOrdersList.DefaultCellStyle = gridViewCellStyle;
      this.dgvOrdersList.Location = new Point(0, 28);
      this.dgvOrdersList.MultiSelect = false;
      this.dgvOrdersList.Name = "dgvOrdersList";
      this.dgvOrdersList.ReadOnly = true;
      this.dgvOrdersList.RowHeadersVisible = false;
      this.dgvOrdersList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvOrdersList.Size = new Size(1016, 262);
      this.dgvOrdersList.TabIndex = 1;
      this.dgvOrdersList.CellClick += new DataGridViewCellEventHandler(this.dgvOrdersList_CellClick);
      this.dgvOrdersList.MouseClick += new MouseEventHandler(this.dgvOrdersList_MouseClick);
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[9]
      {
        (ToolStripItem) this.executeMarketToolStripMenuItem,
        (ToolStripItem) this.executeAllMarketToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator1,
        (ToolStripItem) this.cancelToolStripMenuItem,
        (ToolStripItem) this.cancelAllToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator2,
        (ToolStripItem) this.exportToCsvToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator3,
        (ToolStripItem) this.copyToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(172, 154);
      this.executeMarketToolStripMenuItem.Name = "executeMarketToolStripMenuItem";
      this.executeMarketToolStripMenuItem.Size = new Size(171, 22);
      this.executeMarketToolStripMenuItem.Text = "Execute Market";
      this.executeMarketToolStripMenuItem.Click += new EventHandler(this.executeMarketToolStripMenuItem_Click);
      this.executeAllMarketToolStripMenuItem.Name = "executeAllMarketToolStripMenuItem";
      this.executeAllMarketToolStripMenuItem.Size = new Size(171, 22);
      this.executeAllMarketToolStripMenuItem.Text = "Execute All Market";
      this.executeAllMarketToolStripMenuItem.Click += new EventHandler(this.executeAllMarketToolStripMenuItem_Click);
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new Size(168, 6);
      this.cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
      this.cancelToolStripMenuItem.Size = new Size(171, 22);
      this.cancelToolStripMenuItem.Text = "Cancel";
      this.cancelToolStripMenuItem.Click += new EventHandler(this.cancelToolStripMenuItem_Click);
      this.cancelAllToolStripMenuItem.Name = "cancelAllToolStripMenuItem";
      this.cancelAllToolStripMenuItem.Size = new Size(171, 22);
      this.cancelAllToolStripMenuItem.Text = "Cancel All";
      this.cancelAllToolStripMenuItem.Click += new EventHandler(this.cancelAllToolStripMenuItem_Click);
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new Size(168, 6);
      this.exportToCsvToolStripMenuItem.Name = "exportToCsvToolStripMenuItem";
      this.exportToCsvToolStripMenuItem.Size = new Size(171, 22);
      this.exportToCsvToolStripMenuItem.Text = "Export to Csv";
      this.exportToCsvToolStripMenuItem.Click += new EventHandler(this.exportToCsvToolStripMenuItem_Click);
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new Size(168, 6);
      this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
      this.copyToolStripMenuItem.Size = new Size(171, 22);
      this.copyToolStripMenuItem.Text = "Copy";
      this.copyToolStripMenuItem.Click += new EventHandler(this.copyToolStripMenuItem_Click);
      this.toolStrip1.Items.AddRange(new ToolStripItem[11]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.toolStripLabel1,
        (ToolStripItem) this.cmbExch,
        (ToolStripItem) this.toolStripLabel4,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.toolStripLabel5,
        (ToolStripItem) this.cmbBuySell,
        (ToolStripItem) this.toolStripLabel3,
        (ToolStripItem) this.cmbTraderid,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1016, 25);
      this.toolStrip1.TabIndex = 2;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.toolStripLabel1.Name = "toolStripLabel1";
      this.toolStripLabel1.Size = new Size(57, 22);
      this.toolStripLabel1.Text = "Exchange";
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(121, 25);
      this.toolStripLabel4.Name = "toolStripLabel4";
      this.toolStripLabel4.Size = new Size(47, 22);
      this.toolStripLabel4.Text = "Symbol";
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(160, 25);
      this.cmbSymbol.Sorted = true;
      this.toolStripLabel5.Name = "toolStripLabel5";
      this.toolStripLabel5.Size = new Size(25, 22);
      this.toolStripLabel5.Text = "B/S";
      this.cmbBuySell.Items.AddRange(new object[2]
      {
        (object) "B",
        (object) "S"
      });
      this.cmbBuySell.Name = "cmbBuySell";
      this.cmbBuySell.Size = new Size(121, 25);
      this.toolStripLabel3.Name = "toolStripLabel3";
      this.toolStripLabel3.Size = new Size(51, 22);
      this.toolStripLabel3.Text = "Traderid";
      this.cmbTraderid.Name = "cmbTraderid";
      this.cmbTraderid.Size = new Size(121, 25);
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.regulationcode.HeaderText = "ClientCode";
      this.regulationcode.Name = "regulationcode";
      this.regulationcode.ReadOnly = true;
      this.regulationcode.Width = 90;
      this.ColName.HeaderText = "Name";
      this.ColName.Name = "ColName";
      this.ColName.ReadOnly = true;
      this.ColName.Width = 90;
      this.Exchange.HeaderText = "Exchange";
      this.Exchange.Name = "Exchange";
      this.Exchange.ReadOnly = true;
      this.Exchange.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.ColExpiry.HeaderText = "Expiry";
      this.ColExpiry.Name = "ColExpiry";
      this.ColExpiry.ReadOnly = true;
      this.ColExpiry.Width = 80;
      this.ProductType.HeaderText = "ProductType";
      this.ProductType.Name = "ProductType";
      this.ProductType.ReadOnly = true;
      this.ProductType.Width = 40;
      this.Buysell.HeaderText = "B/S";
      this.Buysell.Name = "Buysell";
      this.Buysell.ReadOnly = true;
      this.Buysell.Width = 50;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 50;
      this.Price.HeaderText = "Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 60;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 70;
      this.Orderby.HeaderText = "Orderedby";
      this.Orderby.Name = "Orderby";
      this.Orderby.ReadOnly = true;
      this.Status.HeaderText = "Status";
      this.Status.Name = "Status";
      this.Status.ReadOnly = true;
      this.Status.Width = 70;
      this.UserRemarks.HeaderText = "UserRemarks";
      this.UserRemarks.Name = "UserRemarks";
      this.UserRemarks.ReadOnly = true;
      this.LastModified.HeaderText = "LastModified";
      this.LastModified.Name = "LastModified";
      this.LastModified.ReadOnly = true;
      this.LastModified.Width = 60;
      this.colOrderno.HeaderText = "OrderNo";
      this.colOrderno.Name = "colOrderno";
      this.colOrderno.ReadOnly = true;
      this.colDacode.HeaderText = "DACode";
      this.colDacode.Name = "colDacode";
      this.colDacode.ReadOnly = true;
      this.colDacode.Visible = false;
      this.colIp.HeaderText = "Ipaddress";
      this.colIp.Name = "colIp";
      this.colIp.ReadOnly = true;
      this.read.HeaderText = "Bookmark";
      this.read.Name = "read";
      this.read.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1016, 290);
      this.Controls.Add((Control) this.toolStrip1);
      this.Controls.Add((Control) this.dgvOrdersList);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.Name = nameof (frmRTOrderBook);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "View Orders";
      this.FormClosing += new FormClosingEventHandler(this.frmRTOrderBook_FormClosing);
      this.KeyUp += new KeyEventHandler(this.frmRTOrderBook_KeyUp);
      ((ISupportInitialize) this.dgvOrdersList).EndInit();
      this.contextMenuStrip1.ResumeLayout(false);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
