﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmholydaymngt
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmholydaymngt : Form
  {
    public int rd = 0;
    public string time = string.Empty;
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    private GroupBox groupBox1;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private GroupBox groupBox3;
    private ComboBox cmbsSS;
    private ComboBox cmbsMM;
    private ComboBox cmbsHH;
    private GroupBox groupBox2;
    private ComboBox cmbeSS;
    private ComboBox cmbeMM;
    private ComboBox cmbeHH;
    private Button button_Submit;
    private GroupBox groupBox4;
    private Button button_ActivateMobile;
    private TextBox textBox1;

    public frmholydaymngt(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
    }

    private void button_ActivateMobile_Click(object sender, EventArgs e)
    {
      SqlConnection conn = this.objmain.getConn();
      int num = 0;
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("ActivateMobileApp", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.textBox1.Text);
          try
          {
            num = sqlCommand2.ExecuteNonQuery();
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to Activate: " + ex.Message ?? "", 3);
          }
        }
      }
      if (num <= 0)
        return;
      Utils.DisplayMessage("Activate Successfully", 1);
    }

    private void button_Submit_Click(object sender, EventArgs e)
    {
      int num = 0;
      this.time = this.cmbsHH.Text + this.cmbsMM.Text + this.cmbsSS.Text + "-" + this.cmbeHH.Text + this.cmbeMM.Text + this.cmbeSS.Text;
      if (this.rdoMcx.Checked)
        this.rd = 1;
      if (this.rdoNseFut.Checked)
        this.rd = 2;
      if (this.rdoncdex.Checked)
        this.rd = 3;
      if (this.rdoNsecurr.Checked)
        this.rd = 4;
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("SetMarketTiming", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@exch", (object) this.rd);
          sqlCommand2.Parameters.AddWithValue("@timing", (object) this.time);
          try
          {
            num = sqlCommand2.ExecuteNonQuery();
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to submit time: " + ex.Message ?? "", 3);
          }
        }
      }
      if (num <= 0)
        return;
      Utils.DisplayMessage("Submit timeSuccessfully", 1);
    }

    private void rdoMcx_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoMcx.Checked)
        return;
      this.rd = 1;
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("GetMarketTiming", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@exch", (object) this.rd);
          try
          {
            using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
            {
              int ordinal = 0;
              while (sqlDataReader.Read())
              {
                this.time = sqlDataReader.GetString(ordinal);
                ++ordinal;
              }
            }
            string[] strArray = this.time.Split('-');
            string str1 = strArray[0];
            string str2 = strArray[1];
            string str3 = str1.Substring(0, 2);
            string str4 = str1.Substring(3, 2);
            string str5 = str1.Substring(4, 2);
            string str6 = str2.Substring(0, 2);
            string str7 = str2.Substring(2, 2);
            string str8 = str2.Substring(4, 2);
            this.cmbsHH.Text = str3;
            this.cmbsMM.Text = str4;
            this.cmbsSS.Text = str5;
            this.cmbeHH.Text = str6;
            this.cmbeMM.Text = str7;
            this.cmbeSS.Text = str8;
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to get MCX time: " + ex.Message ?? "", 3);
          }
        }
      }
    }

    private void rdoNseFut_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoNseFut.Checked)
        return;
      this.rd = 2;
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("GetMarketTiming", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@exch", (object) this.rd);
          try
          {
            using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
            {
              int ordinal = 0;
              while (sqlDataReader.Read())
              {
                this.time = sqlDataReader.GetString(ordinal);
                ++ordinal;
              }
            }
            string[] strArray = this.time.Split('-');
            string str1 = strArray[0];
            string str2 = strArray[1];
            string str3 = str1.Substring(0, 2);
            string str4 = str1.Substring(3, 2);
            string str5 = str1.Substring(4, 2);
            string str6 = str2.Substring(0, 2);
            string str7 = str2.Substring(2, 2);
            string str8 = str2.Substring(4, 2);
            this.cmbsHH.Text = str3;
            this.cmbsMM.Text = str4;
            this.cmbsSS.Text = str5;
            this.cmbeHH.Text = str6;
            this.cmbeMM.Text = str7;
            this.cmbeSS.Text = str8;
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to get NSCFUT time: " + ex.Message ?? "", 3);
          }
        }
      }
    }

    private void rdoncdex_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoncdex.Checked)
        return;
      this.rd = 3;
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("GetMarketTiming", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@exch", (object) this.rd);
          try
          {
            using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
            {
              int ordinal = 0;
              while (sqlDataReader.Read())
              {
                this.time = sqlDataReader.GetString(ordinal);
                ++ordinal;
              }
            }
            string[] strArray = this.time.Split('-');
            string str1 = strArray[0];
            string str2 = strArray[1];
            string str3 = str1.Substring(0, 2);
            string str4 = str1.Substring(3, 2);
            string str5 = str1.Substring(4, 2);
            string str6 = str2.Substring(0, 2);
            string str7 = str2.Substring(2, 2);
            string str8 = str2.Substring(4, 2);
            this.cmbsHH.Text = str3;
            this.cmbsMM.Text = str4;
            this.cmbsSS.Text = str5;
            this.cmbeHH.Text = str6;
            this.cmbeMM.Text = str7;
            this.cmbeSS.Text = str8;
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to get NCDEX time" + ex.Message ?? "", 3);
          }
        }
      }
    }

    private void rdoNsecurr_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoNsecurr.Checked)
        return;
      this.rd = 4;
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("GetMarketTiming", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@exch", (object) this.rd);
          try
          {
            using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
            {
              int ordinal = 0;
              while (sqlDataReader.Read())
              {
                this.time = sqlDataReader.GetString(ordinal);
                ++ordinal;
              }
            }
            string[] strArray = this.time.Split('-');
            string str1 = strArray[0];
            string str2 = strArray[1];
            string str3 = str1.Substring(0, 2);
            string str4 = str1.Substring(3, 2);
            string str5 = str1.Substring(4, 2);
            string str6 = str2.Substring(0, 2);
            string str7 = str2.Substring(2, 2);
            string str8 = str2.Substring(4, 2);
            this.cmbsHH.Text = str3;
            this.cmbsMM.Text = str4;
            this.cmbsSS.Text = str5;
            this.cmbeHH.Text = str6;
            this.cmbeMM.Text = str7;
            this.cmbeSS.Text = str8;
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to get NSECURR time" + ex.Message ?? "", 3);
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.groupBox3 = new GroupBox();
      this.cmbsSS = new ComboBox();
      this.cmbsMM = new ComboBox();
      this.cmbsHH = new ComboBox();
      this.groupBox2 = new GroupBox();
      this.cmbeSS = new ComboBox();
      this.cmbeMM = new ComboBox();
      this.cmbeHH = new ComboBox();
      this.button_Submit = new Button();
      this.groupBox4 = new GroupBox();
      this.button_ActivateMobile = new Button();
      this.textBox1 = new TextBox();
      this.groupBox1.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoncdex);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(8, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(284, 60);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchanges";
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(202, 16);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 7;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.CheckedChanged += new EventHandler(this.rdoNsecurr_CheckedChanged);
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(134, 16);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 6;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoncdex.CheckedChanged += new EventHandler(this.rdoncdex_CheckedChanged);
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(60, 16);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 5;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.CheckedChanged += new EventHandler(this.rdoNseFut_CheckedChanged);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(6, 16);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 4;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.CheckedChanged += new EventHandler(this.rdoMcx_CheckedChanged);
      this.groupBox3.Controls.Add((Control) this.cmbsSS);
      this.groupBox3.Controls.Add((Control) this.cmbsMM);
      this.groupBox3.Controls.Add((Control) this.cmbsHH);
      this.groupBox3.Location = new Point(8, 88);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(152, 54);
      this.groupBox3.TabIndex = 66;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Start Time";
      this.cmbsSS.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbsSS.FormattingEnabled = true;
      this.cmbsSS.Items.AddRange(new object[60]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23",
        (object) "24",
        (object) "25",
        (object) "26",
        (object) "27",
        (object) "28",
        (object) "29",
        (object) "30",
        (object) "31",
        (object) "32",
        (object) "33",
        (object) "34",
        (object) "35",
        (object) "36",
        (object) "37",
        (object) "38",
        (object) "39",
        (object) "40",
        (object) "41",
        (object) "42",
        (object) "43",
        (object) "44",
        (object) "45",
        (object) "46",
        (object) "47",
        (object) "48",
        (object) "49",
        (object) "50",
        (object) "51",
        (object) "52",
        (object) "53",
        (object) "54",
        (object) "55",
        (object) "56",
        (object) "57",
        (object) "58",
        (object) "59"
      });
      this.cmbsSS.Location = new Point(103, 18);
      this.cmbsSS.Name = "cmbsSS";
      this.cmbsSS.Size = new Size(41, 21);
      this.cmbsSS.TabIndex = 5;
      this.cmbsMM.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbsMM.FormattingEnabled = true;
      this.cmbsMM.Items.AddRange(new object[60]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23",
        (object) "24",
        (object) "25",
        (object) "26",
        (object) "27",
        (object) "28",
        (object) "29",
        (object) "30",
        (object) "31",
        (object) "32",
        (object) "33",
        (object) "34",
        (object) "35",
        (object) "36",
        (object) "37",
        (object) "38",
        (object) "39",
        (object) "40",
        (object) "41",
        (object) "42",
        (object) "43",
        (object) "44",
        (object) "45",
        (object) "46",
        (object) "47",
        (object) "48",
        (object) "49",
        (object) "50",
        (object) "51",
        (object) "52",
        (object) "53",
        (object) "54",
        (object) "55",
        (object) "56",
        (object) "57",
        (object) "58",
        (object) "59"
      });
      this.cmbsMM.Location = new Point(59, 18);
      this.cmbsMM.Name = "cmbsMM";
      this.cmbsMM.Size = new Size(41, 21);
      this.cmbsMM.TabIndex = 4;
      this.cmbsHH.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbsHH.FormattingEnabled = true;
      this.cmbsHH.Items.AddRange(new object[24]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23"
      });
      this.cmbsHH.Location = new Point(16, 18);
      this.cmbsHH.Name = "cmbsHH";
      this.cmbsHH.Size = new Size(41, 21);
      this.cmbsHH.TabIndex = 3;
      this.groupBox2.Controls.Add((Control) this.cmbeSS);
      this.groupBox2.Controls.Add((Control) this.cmbeMM);
      this.groupBox2.Controls.Add((Control) this.cmbeHH);
      this.groupBox2.Location = new Point(166, 88);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(152, 54);
      this.groupBox2.TabIndex = 67;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "End Time";
      this.cmbeSS.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbeSS.FormattingEnabled = true;
      this.cmbeSS.Items.AddRange(new object[60]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23",
        (object) "24",
        (object) "25",
        (object) "26",
        (object) "27",
        (object) "28",
        (object) "29",
        (object) "30",
        (object) "31",
        (object) "32",
        (object) "33",
        (object) "34",
        (object) "35",
        (object) "36",
        (object) "37",
        (object) "38",
        (object) "39",
        (object) "40",
        (object) "41",
        (object) "42",
        (object) "43",
        (object) "44",
        (object) "45",
        (object) "46",
        (object) "47",
        (object) "48",
        (object) "49",
        (object) "50",
        (object) "51",
        (object) "52",
        (object) "53",
        (object) "54",
        (object) "55",
        (object) "56",
        (object) "57",
        (object) "58",
        (object) "59"
      });
      this.cmbeSS.Location = new Point(103, 18);
      this.cmbeSS.Name = "cmbeSS";
      this.cmbeSS.Size = new Size(41, 21);
      this.cmbeSS.TabIndex = 5;
      this.cmbeMM.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbeMM.FormattingEnabled = true;
      this.cmbeMM.Items.AddRange(new object[60]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23",
        (object) "24",
        (object) "25",
        (object) "26",
        (object) "27",
        (object) "28",
        (object) "29",
        (object) "30",
        (object) "31",
        (object) "32",
        (object) "33",
        (object) "34",
        (object) "35",
        (object) "36",
        (object) "37",
        (object) "38",
        (object) "39",
        (object) "40",
        (object) "41",
        (object) "42",
        (object) "43",
        (object) "44",
        (object) "45",
        (object) "46",
        (object) "47",
        (object) "48",
        (object) "49",
        (object) "50",
        (object) "51",
        (object) "52",
        (object) "53",
        (object) "54",
        (object) "55",
        (object) "56",
        (object) "57",
        (object) "58",
        (object) "59"
      });
      this.cmbeMM.Location = new Point(59, 18);
      this.cmbeMM.Name = "cmbeMM";
      this.cmbeMM.Size = new Size(41, 21);
      this.cmbeMM.TabIndex = 4;
      this.cmbeHH.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbeHH.FormattingEnabled = true;
      this.cmbeHH.Items.AddRange(new object[24]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23"
      });
      this.cmbeHH.Location = new Point(16, 18);
      this.cmbeHH.Name = "cmbeHH";
      this.cmbeHH.Size = new Size(41, 21);
      this.cmbeHH.TabIndex = 3;
      this.button_Submit.Location = new Point(129, 157);
      this.button_Submit.Name = "button_Submit";
      this.button_Submit.Size = new Size(75, 23);
      this.button_Submit.TabIndex = 68;
      this.button_Submit.Text = "Submit";
      this.button_Submit.UseVisualStyleBackColor = true;
      this.button_Submit.Click += new EventHandler(this.button_Submit_Click);
      this.groupBox4.Controls.Add((Control) this.button_ActivateMobile);
      this.groupBox4.Controls.Add((Control) this.textBox1);
      this.groupBox4.Location = new Point(8, 186);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new Size(310, 78);
      this.groupBox4.TabIndex = 69;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Mobile Activation";
      this.button_ActivateMobile.Location = new Point(174, 31);
      this.button_ActivateMobile.Name = "button_ActivateMobile";
      this.button_ActivateMobile.Size = new Size(75, 23);
      this.button_ActivateMobile.TabIndex = 1;
      this.button_ActivateMobile.Text = "Activate";
      this.button_ActivateMobile.UseVisualStyleBackColor = true;
      this.button_ActivateMobile.Click += new EventHandler(this.button_ActivateMobile_Click);
      this.textBox1.Location = new Point(32, 33);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new Size(136, 20);
      this.textBox1.TabIndex = 0;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(325, 276);
      this.Controls.Add((Control) this.groupBox4);
      this.Controls.Add((Control) this.button_Submit);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (frmholydaymngt);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "holyday management";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox4.ResumeLayout(false);
      this.groupBox4.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
