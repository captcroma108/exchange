﻿// Decompiled with JetBrains decompiler
// Type: DTS.Dashboard
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Media;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using wyDay.Controls;

namespace DTS
{
  public class Dashboard : Form
  {
    public Dictionary<string, Contracts> _Symconctracts = new Dictionary<string, Contracts>();
    public Dictionary<string, Dictionary<string, Contracts>> _SymNameconctracts = new Dictionary<string, Dictionary<string, Contracts>>();
    public Dictionary<string, Contracts> _ContractsHistory = new Dictionary<string, Contracts>();
    public Dictionary<int, SortedDictionary<string, Contracts>> _Exchconctracts = new Dictionary<int, SortedDictionary<string, Contracts>>();
    public Dictionary<string, Userinfo> _Userinformation = new Dictionary<string, Userinfo>();
    public Dictionary<string, Limits> _ClientLimits = new Dictionary<string, Limits>();
    public Dictionary<string, Feeds> _SymFeeds = new Dictionary<string, Feeds>();
    public Dictionary<string, Dictionary<string, SymbolMargin>> _ClientSymMrgn = new Dictionary<string, Dictionary<string, SymbolMargin>>();
    public Dictionary<string, SortedDictionary<string, double>> _ClientOffset = new Dictionary<string, SortedDictionary<string, double>>();
    public Dictionary<string, Dictionary<int, SortedDictionary<string, int>>> _ClientContractStatus = new Dictionary<string, Dictionary<int, SortedDictionary<string, int>>>();
    public Dictionary<string, List<string>> _GroupwiseClientList = new Dictionary<string, List<string>>();
    public Dictionary<string, Thread> _ExchFeedInstance = new Dictionary<string, Thread>();
    public Dictionary<string, List<string>> _UsertradeGrouping = new Dictionary<string, List<string>>();
    public Dictionary<string, double> _SymbolwiseDPRLimit = new Dictionary<string, double>();
    public Dictionary<string, DateTime> _SymbolwiseCommTiming = new Dictionary<string, DateTime>();
    public Dictionary<string, string> _ClientwiseLeverage = new Dictionary<string, string>();
    public Dictionary<string, Dictionary<int, Dictionary<string, TradeSettings>>> _ClientExchwiseTrdSettings = new Dictionary<string, Dictionary<int, Dictionary<string, TradeSettings>>>();
    public Dictionary<string, Dictionary<string, FXsettings>> _ClientFXsettings = new Dictionary<string, Dictionary<string, FXsettings>>();
    public Dictionary<string, BrkgType> _ClientBrokerageType = new Dictionary<string, BrkgType>();
    public Dictionary<string, buysellnetpospfls> _NetProftLoss = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _NetProftLossRMS = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _NetProftLossSuper = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _NetProftLossFIFO = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _NetMTMProftLoss = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _NetRMSMTMProftLoss = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _DAwiseProfitLoss = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, Dictionary<string, Userinfo>> _DAHierarchy = new Dictionary<string, Dictionary<string, Userinfo>>();
    public List<string> _AllGroupingCLients = new List<string>();
    public List<string> _AllTradeGroupingCLients = new List<string>();
    public List<string> _lstAccounts = new List<string>();
    public List<string> _lstDealers = new List<string>();
    public List<frmMarketWatch> _lstMktwatchObjs = new List<frmMarketWatch>();
    public List<string> _SubscribedSymbols = new List<string>();
    public List<string> _FxSymbols = new List<string>();
    public string SubscribedSymbols = string.Empty;
    public string NSETIME = string.Empty;
    public string MCXTIME = string.Empty;
    public string NCDEXTIME = string.Empty;
    public string NSECURRTIME = string.Empty;
    public string rtTradeLocation = Application.StartupPath + "\\Trades";
    private IContainer components = (IContainer) null;
    public int flag;
    public bool isLogin;
    public bool isTabCntrlVisible;
    public SqlConnection conn;
    public SqlConnection feedconn;
    public Login objlogin;
    public frmMarketWatch objmw;
    public Payin_Payoutt objpayinout;
    public ChangePwd objchngpwd;
    public frmTradeSettings objtrdSettings;
    public unlock objunlock;
    public frmUserprofile objuserprofle;
    public frmDownloadContrct objcontrcts;
    public frmContracts objfrmcontrct;
    public frmLimits objlimits;
    public frmOffsetMngmnt objOffset;
    public ModifyOrderTrade objmodordtrd;
    public frmGrouping objtrdGrouping;
    public frmDPRLimitfilter objDPRlimit;
    public frmNetPostionSymwise objNetPosSymbolwise;
    public frmDAMargin objDAmrgn;
    public frmSANetPfls objSAnetpfls;
    public frmDashSetting objdashSet;
    public frmTradeHistory objtrdHistory;
    public FrmPayout pay;
    private AboutBox1 objAboutUs;
    public frmFlushUserData objflushUserData;
    public AdminMessages objadmmsg;
    public frmAccMapping objaccmap;
    public frmPayoutGrouping objAccGrouping;
    public Margin objfrmmrgn;
    public Orderbook objordbook;
    public Orderlist objordlist;
    public frmAccountDetails objaccdetails;
    public MISReports objmis;
    public frmDefExchMrgn objDefExchMrgn;
    public Tradebook objtrdbook;
    public frmRTTrades objrttrdbook;
    public OpenPosition objopenPos;
    public NetPosition objnetpos;
    public ModifiedOrders objmodord;
    public CancelledOrders objcanOrd;
    public MessageLogs objmsglogs;
    public frmPayinout objpayinoutview;
    public frmContractStatusView objViewConStatus;
    public SurveillanceView objrejectMsg;
    public frmManageCntrctStatus objcontractStatus;
    public frmManageContrastStatussuper objcontractStatus1;
    public AdminMsgView objmsgview;
    public RMSClientwise objRMS;
    public frmRMS_DAwise objDA_Rms;
    public frmLedger objledger;
    public frmLedgerAVG objledgeravg;
    public frmRTOrderBook objRTordbook;
    public frmForexSettings objFxsettings;
    public frmRTSLTrades objRTSLtradebook;
    public frmIntraHistory objDataHistory;
    public frmPosGoinLive objPositivePos;
    public frmShortcutKeys objShortKeys;
    public frmShortcutKeyDA objDAShorcutKeys;
    public Maintenance objmaintenance;
    public frmBlastSystem objBlast;
    public ForcedSqOff objforcesqoff;
    public frmFeedSearch objsymSearch;
    public int lastid;
    public int lastMcxid;
    public int lastNcdexid;
    public int lastNsefutid;
    public int lastNsecurid;
    public int lastNseoptid;
    public int lastNsefut2id;
    public DateTime lastfeedupdate;
    public DateTime servertime;
    public bool isReconnectFeeds;
    public int MCXlots;
    public int NSEFUTlots;
    public int NSECURlots;
    public int NCDEXlots;
    public int NSEOPTlots;
    public bool isSaturdayTrading;
    public string claccounts;
    public string dlaccounts;
    public Thread threadObjRT_MSG;
    public Thread cThread_netpos;
    public Thread threadObjRT_MCX1;
    public Thread threadObjRT_UpdateID;
    public Thread threadObjUpdLoginTime;
    public Thread thread_RtTrades;
    public Thread threadObjRT_Feeds;
    public Thread threadObjRT_Feeds1;
    public Thread threadObjRT_Feeds2;
    public Thread threadObjRT_Feeds3;
    public Thread threadObjRT_Feeds4;
    public Thread threadObjRT_Feeds5;
    public Icon ico;
    private frmSpeedControl objspeedcontrol;
    private MenuStrip menuStrip;
    private ToolStrip toolStrip;
    private StatusStrip statusStrip;
    private ToolStripMenuItem tileHorizontalToolStripMenuItem;
    private ToolStripMenuItem fileMenu;
    private ToolStripMenuItem windowsMenu;
    private ToolStripMenuItem cascadeToolStripMenuItem;
    private ToolStripMenuItem tileVerticalToolStripMenuItem;
    private ToolStripMenuItem closeAllToolStripMenuItem;
    private ToolStripMenuItem helpMenu;
    private ToolTip toolTip;
    private ToolStripMenuItem LoginMenuItem;
    private ToolStripMenuItem LogOfftoolStripMenu;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripMenuItem ChngPassMenuItem;
    private ToolStripMenuItem LckWrkstationMenuItem;
    private ToolStripMenuItem ChkUpdatesMenuItem;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripMenuItem ExitMenuItem;
    private Panel panel1;
    private TableLayoutPanel PositionPanel;
    private Label lblMrgnBal;
    private Label label5;
    private Label lblMrgnUtilised;
    private Label label3;
    private Label lblCshMrgn;
    private Label label1;
    private Label label9;
    private Label lblNetmtm;
    private Label label11;
    private Label lblAvaiBal;
    private ToolStripMenuItem AdminMenuItem;
    private ToolStripMenuItem ViewMenuItem;
    private ToolStripMenuItem MarketMenuItem;
    private ToolStripMenuItem PivotsMenuItem;
    private ToolStripMenuItem UserPrflMenuItem;
    private ToolStripMenuItem AccMapMenuItem;
    private ToolStripMenuItem AdminMsgsMenuItem;
    private ToolStripSeparator toolStripSeparator4;
    private ToolStripMenuItem CntrctMnmgtMenuItem;
    private ToolStripMenuItem OffsetMnmgtMenuItem;
    private ToolStripMenuItem PayinOutMenuItem;
    private ToolStripMenuItem ModOrdTrdMenuItem;
    private ToolStripSeparator toolStripSeparator5;
    private ToolStripMenuItem LimitsMenuItem;
    private ToolStripMenuItem SymMargnRsMenuItem;
    private ToolStripMenuItem DefExchMrgnLotsMenuItem;
    private ToolStripMenuItem ForceSqOffMenuItem;
    private ToolStripSeparator toolStripSeparator6;
    private ToolStripMenuItem MisReportsMenuItem;
    private ToolStripMenuItem RMSMenuItem;
    private ToolStripMenuItem RejectionMsgMenuItem;
    private ToolStripSeparator toolStripSeparator7;
    private ToolStripMenuItem MaintenanceMenuItem;
    private ToolStripMenuItem OrderBookMenuItem;
    private ToolStripMenuItem TrdBookMenuItem;
    private ToolStripMenuItem NetPosMenuItem;
    private ToolStripMenuItem ModOrdMenuItem;
    private ToolStripMenuItem CanOrdMenuItem;
    private ToolStripSeparator toolStripSeparator9;
    private ToolStripMenuItem MsgLogsMenuItem;
    private ToolStripMenuItem AdmMsgsMenuItem;
    private ToolStripMenuItem ContrctStatusMenuItem;
    private ToolStripMenuItem MktWtchMenuItem;
    private ToolStripMenuItem FeedSourceMenuItem;
    private ToolStripMenuItem UserDetailsMenuItem;
    private ToolStripMenuItem AccDetailsMenuItem;
    private ToolStripMenuItem TotOrdersMenuItem;
    private ToolStripMenuItem OpenPosMenuItem;
    private ToolStripMenuItem LstPayinPayoutMenuItem;
    private ToolStripMenuItem LedgerMenuItem;
    private ToolStripSeparator toolStripSeparator10;
    private ToolStripMenuItem PosBarMenuItem;
    private ToolStripMenuItem StatusBarMenuItem;
    private ToolStripMenuItem PivotViewMenuItem;
    private ToolStripMenuItem RTPivotsMenuItem;
    private ToolStripMenuItem PivotsAchvdMenuItem;
    private ToolStripMenuItem PivotDashMenuItem;
    private ToolStripMenuItem StocksViewMenuItem;
    private ToolStripMenuItem HighLowMenuItem;
    private ToolStripMenuItem PerformancViewMenuItem;
    private ToolStripMenuItem TechChartsMenuItem;
    private ToolStripMenuItem FinancialNewsMenuItem;
    private ToolStripMenuItem AlertMenuItem;
    private ToolStripMenuItem SetAlertMenuItem;
    private ToolStripMenuItem ShowAlertMenuItem;
    private ToolStripMenuItem SetAlertOnMenuItem;
    private ToolStripMenuItem AlertHistoryMenuItem;
    private ToolStripMenuItem GetQuoteMenuItem;
    private ToolStripMenuItem IndicesMenuItem;
    private ToolStripMenuItem IntraDataHistoryMenuItem;
    private ToolStripMenuItem CalculatorMenuItem;
    private ToolStripMenuItem OptionCalcMenuItem;
    private ToolStripMenuItem FairvalueMenuItem;
    private WebBrowser webBrowser1;
    private ListBox lstMsgboard;
    private ToolStripMenuItem toolStripMngConStatus;
    private ToolStripMenuItem toolStripRMSView;
    private ToolStripSeparator toolStripSeparator11;
    private ToolStripMenuItem toolStripOrders;
    private ToolStripMenuItem toolStripTrades;
    private ToolStripMenuItem toolStripSLTrades;
    private ToolStripMenuItem toolStripPositivePos;
    private ToolStripMenuItem toolStripMenuItem1;
    private ToolStripMenuItem toolStripBlastSystem;
    private ToolStripMenuItem toolStripSymSearch;
    public ToolStripButton btnRefreshData;
    private ToolStripMenuItem defautMarketTradingToolStripMenuItem;
    private ToolStripMenuItem toolStrpMnuSpeedCntrl;
    private ToolStripButton btnReconnectFeeds;
    private AutomaticUpdater automaticUpdater1;
    private ToolStripMenuItem insertModifyOrdersTradesToolStripMenuItem;
    private ToolStripMenuItem AccGroupingMnuItm;
    private ToolStripMenuItem flushUserDataToolStripMenuItem;
    private ToolStripMenuItem aboutUsToolStripMenuItem;
    private ToolStripMenuItem MnuItmTradeGruping;
    private ToolStripMenuItem tradeHistoryToolStripMenuItem;
    private ToolStripMenuItem dPRLimitToolStripMenuItem;
    private ToolStripMenuItem toolstripSymbolPos;
    private ToolStripMenuItem toolStripDAPayinout;
    private ToolStripMenuItem toolStripCmpnyPfls;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem DashSettingMenuItem;
    public ToolStripStatusLabel lblStatus;
    private ToolStrip toolStrip1;
    private ToolStripButton btnLogin;
    private ToolStripButton btnLogout;
    private ToolStripButton btnChangePass;
    private ToolStripButton btnLockWorkstation;
    private ToolStripButton btnExit;
    private ToolStripSeparator toolStripSeparator8;
    private ToolStripButton btnBuyOrder;
    private ToolStripButton btnSellOrder;
    private ToolStripSeparator toolStripSeparator12;
    private ToolStripButton btnNetPosition;
    private ToolStripButton btnPendingOrders;
    private ToolStripButton btnCancOrders;
    private ToolStripSeparator toolStripSeparator14;
    private ToolStripMenuItem forexToolStripMenuItem;
    private ToolStripMenuItem settingsToolStripMenuItem;
    private ToolStripMenuItem tradeSettingsToolStripMenuItem;
    private ToolStripMenuItem showQuickAccessToolbarToolStripMenuItem;
    private ToolStripMenuItem dealeridpayout;
    private ToolStripMenuItem LedgerAVGMenuItem;

    public Userinfo objinfo { get; set; }

    public Dashboard()
    {
      this.InitializeComponent();
      this.isLogin = false;
      this.claccounts = string.Empty;
      if (File.Exists(Application.StartupPath + "\\logo.ico"))
        this.ico = new Icon(Application.StartupPath + "\\logo.ico");
      this.Icon = this.ico;
      this.MCXlots = 0;
      this.NSEFUTlots = 0;
      this.NSECURlots = 0;
      this.NCDEXlots = 0;
      this.NSEOPTlots = 0;
    }

    public void SubcribeSymbol(string symbol)
    {
      if (this._SubscribedSymbols.Contains(symbol))
        return;
      this._SubscribedSymbols.Add(symbol);
    }

    private void OpenFile(object sender, EventArgs e)
    {
      OpenFileDialog openFileDialog = new OpenFileDialog();
      openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
      openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
      if (openFileDialog.ShowDialog((IWin32Window) this) != DialogResult.OK)
        return;
      string fileName = openFileDialog.FileName;
    }

    private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      SaveFileDialog saveFileDialog = new SaveFileDialog();
      saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
      saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
      if (saveFileDialog.ShowDialog((IWin32Window) this) != DialogResult.OK)
        return;
      string fileName = saveFileDialog.FileName;
    }

    private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.LayoutMdi(MdiLayout.Cascade);
    }

    private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.LayoutMdi(MdiLayout.TileVertical);
    }

    private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.LayoutMdi(MdiLayout.TileHorizontal);
    }

    private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.LayoutMdi(MdiLayout.ArrangeIcons);
    }

    private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
    {
      foreach (Form mdiChild in this.MdiChildren)
        mdiChild.Close();
    }

    private void ExitMenuItem_Click(object sender, EventArgs e)
    {
      Environment.Exit(0);
    }

    private void PosBarMenuItem_Click(object sender, EventArgs e)
    {
      this.PositionPanel.Visible = this.PosBarMenuItem.Checked;
      if (this.PosBarMenuItem.Checked)
        this.panel1.Size = new Size(1026, 69);
      else
        this.panel1.Size = new Size(1026, 43);
    }

    private void StatusBarMenuItem_Click(object sender, EventArgs e)
    {
      this.statusStrip.Visible = this.StatusBarMenuItem.Checked;
    }

    private void Dashboard_Load(object sender, EventArgs e)
    {
      int num = (int) new Loading(this).ShowDialog();
    }

    public bool ValidateLogin(string username, string Password)
    {
      if (this.conn.State == ConnectionState.Closed)
        this.conn = this.getConn();
      this.objinfo = UserinfoMain.ValidateandGetUserinfo(username, Password, this.conn);
      return this.objinfo != null;
    }

    public bool InsertMessage(string clientcode, string msg, int flag)
    {
      if (this.conn.State != ConnectionState.Open)
        return false;
      SqlCommand sqlCommand1 = new SqlCommand("InsertMessages", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) clientcode);
        sqlCommand2.Parameters.AddWithValue("@msg", (object) msg);
        sqlCommand2.Parameters.AddWithValue("@flag", (object) flag);
        try
        {
          sqlCommand2.ExecuteNonQuery();
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    public void InsertMsgBoard(string msg, int displaytype)
    {
      string completeMsg = DateTime.Now.ToString("hh:mm:ss tt") + msg;
      try
      {
        if (displaytype == 1)
          this.lstMsgboard.Items.Insert(0, (object) completeMsg);
        if (displaytype != 2)
          return;
        this.Invoke((Delegate) (() => this.lstMsgboard.Items.Insert(0, (object) completeMsg)));
      }
      catch
      {
      }
    }

    public void insertSurveillanceMessages(string account, string message, string datetime)
    {
      SqlConnection conn = this.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      SqlCommand sqlCommand1 = new SqlCommand("SaveSurveillanceMsgs", conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) account);
        sqlCommand2.Parameters.AddWithValue("@message", (object) message);
        try
        {
          sqlCommand2.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    private static DateTime dtExchnageTime(string timestr)
    {
      string str1 = timestr.Substring(0, 2);
      string str2 = timestr.Substring(2, 2);
      string str3 = timestr.Substring(4, 2);
      DateTime dateTime;
      ref DateTime local = ref dateTime;
      DateTime now = DateTime.Now;
      int year = now.Year;
      now = DateTime.Now;
      int month = now.Month;
      now = DateTime.Now;
      int day = now.Day;
      int int32_1 = Convert.ToInt32(str1);
      int int32_2 = Convert.ToInt32(str2);
      int int32_3 = Convert.ToInt32(str3);
      local = new DateTime(year, month, day, int32_1, int32_2, int32_3);
      return dateTime;
    }

    public bool ValidateMarketTime(string exch, ref DateTime dtnow)
    {
      DateTime now1 = DateTime.Now;
      DateTime now2 = DateTime.Now;
      bool flag = true;
      string empty = string.Empty;
      DateTime serverTime = this.GetServerTime();
      dtnow = serverTime;
      int dayOfWeek = (int) serverTime.DayOfWeek;
      if (dayOfWeek != 6 && (uint) dayOfWeek > 0U)
      {
        string str = exch;
        if (!(str == "MCX"))
        {
          if (!(str == "NCDEX"))
          {
            if (!(str == "NSEFUT"))
            {
              if (str == "NSECURR")
              {
                string[] strArray = this.NSECURRTIME.Split('-');
                DateTime dateTime1 = Dashboard.dtExchnageTime(strArray[0]);
                DateTime dateTime2 = Dashboard.dtExchnageTime(strArray[1]);
                if (dtnow < dateTime1 || dtnow > dateTime2)
                  flag = false;
              }
            }
            else
            {
              string[] strArray = this.NSETIME.Split('-');
              DateTime dateTime1 = Dashboard.dtExchnageTime(strArray[0]);
              DateTime dateTime2 = Dashboard.dtExchnageTime(strArray[1]);
              if (dtnow < dateTime1 || dtnow > dateTime2)
                flag = false;
            }
          }
          else
          {
            string[] strArray = this.NCDEXTIME.Split('-');
            DateTime dateTime1 = Dashboard.dtExchnageTime(strArray[0]);
            DateTime dateTime2 = Dashboard.dtExchnageTime(strArray[1]);
            if (dtnow < dateTime1 || dtnow > dateTime2)
              flag = false;
          }
        }
        else
        {
          string[] strArray = this.MCXTIME.Split('-');
          DateTime dateTime1 = Dashboard.dtExchnageTime(strArray[0]);
          DateTime dateTime2 = Dashboard.dtExchnageTime(strArray[1]);
          if (dtnow < dateTime1 || dtnow > dateTime2)
            flag = false;
        }
      }
      else
      {
        switch (dayOfWeek)
        {
          case 0:
            flag = false;
            break;
          case 6:
            flag = false;
            break;
        }
      }
      return flag;
    }

    public bool ValidateMarketTimeSaturday(string exch, ref DateTime dtnow)
    {
      DateTime now1 = DateTime.Now;
      DateTime now2 = DateTime.Now;
      bool flag = true;
      string empty = string.Empty;
      DateTime serverTime = this.GetServerTime();
      dtnow = serverTime;
      int dayOfWeek = (int) serverTime.DayOfWeek;
      if (dayOfWeek != 6 && (uint) dayOfWeek > 0U)
        flag = true;
      else if (dayOfWeek == 0)
        flag = false;
      return flag;
    }

    public bool ValidateContractStatus(string symbol, int flag, string clientcode, int exch)
    {
      switch (this.objinfo.usertype)
      {
        case 1:
          SortedDictionary<string, int> contractStatus1 = this.GetContractStatus(clientcode, exch);
          if (contractStatus1.ContainsKey(symbol) && contractStatus1[symbol] == flag)
            return false;
          break;
        case 2:
          SortedDictionary<string, int> contractStatus2 = this.GetContractStatus(clientcode, exch);
          if (contractStatus2.ContainsKey(symbol) && contractStatus2[symbol] == flag)
            return false;
          break;
        case 3:
          this.GetContractStatus(clientcode, exch);
          SortedDictionary<string, int> contractStatus3 = this.GetContractStatus(clientcode, exch);
          if (contractStatus3.ContainsKey(symbol) && contractStatus3[symbol] == flag)
            return false;
          break;
        case 4:
          SortedDictionary<string, int> contractStatus4 = this.GetContractStatus(clientcode, exch);
          if (contractStatus4.ContainsKey(symbol) && contractStatus4[symbol] == flag)
            return false;
          break;
      }
      return true;
    }

    public SortedDictionary<string, int> GetContractStatus(
      string clientcode,
      int exch)
    {
      if (this._ClientContractStatus.ContainsKey(clientcode))
      {
        Dictionary<int, SortedDictionary<string, int>> clientContractStatu = this._ClientContractStatus[clientcode];
        if (clientContractStatu.ContainsKey(exch))
          return clientContractStatu[exch];
      }
      else if (this._ClientContractStatus.ContainsKey(this.objinfo.createdby))
      {
        Dictionary<int, SortedDictionary<string, int>> clientContractStatu = this._ClientContractStatus[this.objinfo.createdby];
        if (clientContractStatu.ContainsKey(exch))
          return clientContractStatu[exch];
      }
      return new SortedDictionary<string, int>();
    }

    public DateTime GetServerTime()
    {
      DateTime dateTime = DateTime.Now;
      if (this.conn.State == ConnectionState.Closed)
        this.conn = this.getConn();
      SqlCommand sqlCommand1 = new SqlCommand("GetTime", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        try
        {
          using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(0))
                dateTime = Convert.ToDateTime(sqlDataReader.GetValue(0));
            }
          }
        }
        catch
        {
        }
      }
      return dateTime;
    }

    public void DisplayConfirmationMsg(Trades objord)
    {
      Decimal num = objord.price;
      if (objord.price == Decimal.Zero)
        num = objord.Ordprice;
      int qty = objord.qty;
      string str1 = "LOTS";
      if (objord.exch == 2 || objord.exch == 5)
        str1 = "QTY";
      string str2 = string.Format("  ORDER: {0} FUT, {1} ", (object) Utils.GetExch(objord.exch), (object) objord.orderno);
      string str3 = string.Format(" CARRYFORWARD {0}  {1}  {2} {3}  at Rs. {4} VALIDITY: {5} FOR CLI  {6} CONFIRMED", (object) Utils.GetProductType(objord.producttype), (object) qty, (object) str1, (object) objord.Symbol, (object) num, (object) Utils.GetValidity(objord.validity), (object) objord.clientcode);
      string str4 = string.Format("  TRADE: {0} FUT: ", (object) Utils.GetExch(objord.exch));
      string str5 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1} {2}  {3} {4}/{5} {4}  AT Rs. {6} FOR CLI {7} TRADE", (object) objord.orderno, (object) objord.Lastmodified.ToString("hh:mm:ss tt"), (object) objord.Symbol, (object) qty, (object) str1, (object) qty, (object) num, (object) objord.clientcode);
      string str6;
      string str7;
      if (objord.buysell == 1)
      {
        str6 = string.Format("{0} BUY:    {1}", (object) str2, (object) str3);
        str7 = string.Format("{0}  BOUGHT:  {1}", (object) str4, (object) str5);
      }
      else
      {
        str6 = string.Format("{0} SELL:   {1}", (object) str2, (object) str3);
        str7 = string.Format("{0}  SOLD:   {1}", (object) str4, (object) str5);
      }
      this.clearMsgBoard();
      if (objord.ordstatus == 2)
      {
        this.InsertMsgBoard(str6, 1);
        this.SaveMessageLogs(str6, objord);
      }
      else
      {
        this.InsertMsgBoard(str6, 1);
        this.InsertMsgBoard(str7, 1);
        this.SaveMessageLogs(str6, objord);
        this.SaveMessageLogs(str7, objord);
      }
    }

    public void clearMsgBoard()
    {
      this.Invoke((Delegate) (() => this.lstMsgboard.Items.Clear()));
    }

    public void SaveMessageLogs(string message, Trades objord)
    {
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Insert into MessageLogs (ClientCode, LogMsg,LogTime) Values ('{0}','{1}','{2}')", (object) objord.clientcode, (object) message, (object) objord.Lastmodified.ToString("yyyy-MM-dd HH:mm:ss")), this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
          this.DisplayMessage("Unable to Save Logs, please contact admin.", 3);
        }
      }
    }

    public void DisplayMessage(string msg, int level)
    {
      switch (level)
      {
        case 1:
          int num1 = (int) MessageBox.Show(msg, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
          break;
        case 2:
          int num2 = (int) MessageBox.Show(msg, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
          break;
        case 3:
          int num3 = (int) MessageBox.Show(msg, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          break;
      }
    }

    public static string Decryptdata(string encryptpwd)
    {
      string empty = string.Empty;
      Decoder decoder = new UTF8Encoding().GetDecoder();
      byte[] bytes = Convert.FromBase64String(encryptpwd);
      char[] chars = new char[decoder.GetCharCount(bytes, 0, bytes.Length)];
      decoder.GetChars(bytes, 0, bytes.Length, chars, 0);
      return new string(chars);
    }

    public string Encryptdata(string password)
    {
      string empty = string.Empty;
      byte[] numArray = new byte[password.Length];
      return Convert.ToBase64String(Encoding.UTF8.GetBytes(password));
    }

    public static string Encryptdata1(string password)
    {
      string empty = string.Empty;
      byte[] numArray = new byte[password.Length];
      return Convert.ToBase64String(Encoding.UTF8.GetBytes(password));
    }

    private void Dashboard_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.Escape && (this.ActiveControl != null && this.ActiveControl != this.lstMsgboard && !(this.ActiveControl is frmMarketWatch) && !(this.ActiveControl is TableLayoutPanel)))
        this.ActiveControl.Hide();
      if (!e.Control || e.KeyCode != Keys.Z)
        return;
      if (this.isLogin)
      {
        if (this.objinfo.usertype == 2 && (uint) this.objinfo.isModTrd > 0U)
        {
          if (this.objmodordtrd == null || this.objmodordtrd.IsDisposed)
          {
            ModifyOrderTrade modifyOrderTrade = new ModifyOrderTrade(this, this.conn);
            modifyOrderTrade.MdiParent = (Form) this;
            this.objmodordtrd = modifyOrderTrade;
            this.objmodordtrd.Show();
          }
          else
          {
            this.objmodordtrd.MdiParent = (Form) this;
            this.objmodordtrd.Show();
          }
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void LoginMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
        return;
      if (this.objlogin == null || this.objlogin.IsDisposed)
      {
        Login login = new Login(this, this.conn);
        login.MdiParent = (Form) this;
        this.objlogin = login;
        this.objlogin.Loadwindow();
        this.objlogin.Show();
      }
      else
      {
        this.objlogin.Loadwindow();
        this.objlogin.MdiParent = (Form) this;
        this.objlogin.Show();
      }
    }

    private void MktWtchMenuItem_Click(object sender, EventArgs e)
    {
      if (!this.isLogin)
        return;
      frmMarketWatch frmMarketWatch = new frmMarketWatch(this);
      frmMarketWatch.MdiParent = (Form) this;
      frmMarketWatch.Location = new Point(0, 0);
      this.objmw = frmMarketWatch;
      this.objmw.LayoutMdi(MdiLayout.TileHorizontal);
      this.objmw.LoadMarketWatch();
      this.objmw.Show();
      this._lstMktwatchObjs.Add(this.objmw);
    }

    public static void UpdateColumns(DataGridView objgridview, Dictionary<string, int> _ColumnOnOff)
    {
      foreach (KeyValuePair<string, int> keyValuePair in _ColumnOnOff)
      {
        string key = keyValuePair.Key;
        int num = keyValuePair.Value;
        for (int index = 0; index < objgridview.Columns.Count; ++index)
        {
          if (objgridview.Columns[index].HeaderText.ToLower() == key.ToLower())
          {
            if (num == 1)
              objgridview.Columns[index].Visible = true;
            else
              objgridview.Columns[index].Visible = false;
          }
        }
      }
    }

    public void UpdateLoginStatus(Userinfo objinfo)
    {
      this.isLogin = true;
      this.objinfo = objinfo;
      this.Text = string.Format("{0}   [{1} - {2}]", (object) objinfo.AppName, (object) this.GetUsertype(objinfo.usertype), (object) objinfo.clientcode);
      this.InsertMsgBoard(" Login Successfull!!", 2);
      if ((objinfo.usertype == 3 || objinfo.usertype == 2) && objinfo.isModTrd == 1)
        this.insertModifyOrdersTradesToolStripMenuItem.Visible = true;
      else
        this.insertModifyOrdersTradesToolStripMenuItem.Visible = false;
      int num = 0;
      if (objinfo.usertype == 3 && objinfo.isModTrd == 1)
      {
        this.conn = new SqlConnection(Utils.Getconnsss());
        try
        {
          this.conn.Open();
          using (SqlCommand sqlCommand = new SqlCommand("Select [isModTrdOpt] from [DTS1].[dbo].[Userinformation] where Clientcode = '" + objinfo.createdby + "';", this.conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                if (!sqlDataReader.IsDBNull(0))
                  num = Convert.ToInt32(sqlDataReader.GetValue(0));
              }
            }
          }
          if (num == 1)
            this.insertModifyOrdersTradesToolStripMenuItem.Visible = true;
          else
            this.insertModifyOrdersTradesToolStripMenuItem.Visible = false;
        }
        catch
        {
        }
      }
      if (Settings.Default.RTTradesLocation != null && Settings.Default.RTTradesLocation.Length > 0)
        this.rtTradeLocation = Settings.Default.RTTradesLocation;
      this.rtTradeLocation += string.Format("\\{0}-{1:ddMMyyyy}.txt", (object) objinfo.clientcode, (object) DateTime.Now);
      this.MenuVisibleInvisible(objinfo.usertype);
      this.ManageUserinformation(objinfo);
      this.GetStatusLabelMsg();
      Dashboard.PlaySound(1);
      this.btnRefreshData.Enabled = false;
      new Thread(new ThreadStart(((ThreadStart) (() => this.AutoContracts())).Invoke)).Start();
      this.cThread_netpos = new Thread((ThreadStart) (() => this.GetProfitLossPosition()));
      this.cThread_netpos.Start();
      new Thread(new ThreadStart(((ThreadStart) (() => this.GetDefaultData())).Invoke)).Start();
      this.threadObjRT_MSG = new Thread(new ThreadStart(((ThreadStart) (() => this.ReadMessages())).Invoke));
      this.threadObjRT_MSG.Start();
      this.threadObjUpdLoginTime = new Thread(new ThreadStart(((ThreadStart) (() => this.UpdateLoginTime())).Invoke));
      this.threadObjUpdLoginTime.Start();
      this.btnReconnectFeeds.Enabled = true;
      this.thread_RtTrades = new Thread((ThreadStart) (() => this.LoadRTTrades()));
      this.thread_RtTrades.Start();
    }

    private void GetStatusLabelMsg()
    {
      string str = this.objinfo.clientcode;
      if (this.objinfo.usertype > 2)
        str = this.objinfo.createdby;
      using (SqlCommand sqlCommand = new SqlCommand("Select StatusMsg from Userinformation where Clientcode = '" + str + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              this.lblStatus.Text = sqlDataReader.GetString(0);
          }
        }
      }
    }

    private void UpdateLoginTime()
    {
      while (true)
      {
        if (this.conn.State == ConnectionState.Open)
        {
          SqlCommand sqlCommand1 = new SqlCommand(nameof (UpdateLoginTime), this.conn);
          sqlCommand1.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand2 = sqlCommand1)
          {
            try
            {
              sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.objinfo.clientcode);
              sqlCommand2.ExecuteNonQuery();
            }
            catch
            {
            }
          }
        }
        Thread.Sleep(30000);
      }
    }

    private void GetDefaultData()
    {
      Thread.Sleep(5000);
      foreach (KeyValuePair<string, Contracts> symconctract in this._Symconctracts)
      {
        if (this.feedconn.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,0,GetDate(),Volume,OI from Marketview where Description = '" + symconctract.Key + "'", this.feedconn))
          {
            try
            {
              using (SqlDataReader reader = sqlCommand.ExecuteReader())
              {
                while (reader.Read())
                  this.ManageFeeds(this.GetMarketData(reader, false));
              }
            }
            catch
            {
            }
          }
        }
      }
    }

    private void ReadMessages()
    {
      Thread.Sleep(5000);
      string empty1 = string.Empty;
      string str = this.claccounts.Length <= 0 ? string.Format("'{0}'", (object) this.objinfo.clientcode) : string.Format("{0},'{1}'", (object) this.claccounts, (object) this.objinfo.clientcode);
      while (true)
      {
        try
        {
          if (this.conn.State == ConnectionState.Open && str.Length > 0)
          {
            using (SqlCommand sqlCommand1 = new SqlCommand("Select * from MessageBoard where ClientCode in (" + str + ") and ReadStatus = 0", this.conn))
            {
              using (SqlDataReader sqlDataReader = sqlCommand1.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  int num1 = 0;
                  int num2 = 0;
                  bool flag = false;
                  string empty2 = string.Empty;
                  string empty3 = string.Empty;
                  if (!sqlDataReader.IsDBNull(0))
                    num1 = sqlDataReader.GetInt32(0);
                  if (!sqlDataReader.IsDBNull(1))
                    empty3 = sqlDataReader.GetString(1);
                  if (!sqlDataReader.IsDBNull(2))
                    empty2 = sqlDataReader.GetString(2);
                  if (!sqlDataReader.IsDBNull(5))
                    num2 = sqlDataReader.GetInt32(5);
                  switch (num2)
                  {
                    case 0:
                      if (this.objinfo.clientcode == empty3)
                      {
                        this.DisplayMessage(" Admin Message: " + empty2, 1);
                        this.InsertMsgBoard(" Admin Message: " + empty2, 2);
                        flag = true;
                        break;
                      }
                      continue;
                    case 1:
                      if (this.objinfo.usertype == 3 || this.objinfo.usertype == 4)
                      {
                        if (this.objcontrcts != null)
                        {
                          this.objcontrcts.DownloadLimitMargin();
                        }
                        else
                        {
                          this.objcontrcts = new frmDownloadContrct(this.conn, this);
                          this.objcontrcts.DownloadLimitMargin();
                        }
                        this.clearMsgBoard();
                        if (this.objinfo.usertype == 3)
                          this.InsertMsgBoard(" Funds Updated by Admin for Client ID: " + empty3 ?? "", 2);
                        else
                          this.InsertMsgBoard(" Funds Updated by Admin", 2);
                        flag = true;
                        break;
                      }
                      break;
                    case 5:
                      if (this.objinfo.usertype == 3 || this.objinfo.usertype == 4)
                      {
                        this.clearMsgBoard();
                        this.InsertMsgBoard(empty2, 2);
                        Dashboard.PlaySound(2);
                        flag = true;
                        break;
                      }
                      continue;
                    case 10:
                      if (empty3 == this.objinfo.clientcode)
                      {
                        this.LogOff(false);
                        using (SqlCommand sqlCommand2 = new SqlCommand("Update MessageBoard Set ReadStatus = 1 where ClientCode = '" + this.objinfo.clientcode + "' and Flag = 10", this.conn))
                        {
                          try
                          {
                            sqlCommand2.ExecuteNonQuery();
                          }
                          catch
                          {
                          }
                        }
                        this._lstAccounts.Clear();
                        this.clearMsgBoard();
                        flag = true;
                        this.InsertMsgBoard(" LogOff Successfull!!", 2);
                        break;
                      }
                      continue;
                  }
                  if (flag)
                  {
                    using (SqlCommand sqlCommand2 = new SqlCommand("Update MessageBoard Set ReadStatus = 1 where ID = " + (object) num1 ?? "", this.conn))
                    {
                      try
                      {
                        sqlCommand2.ExecuteNonQuery();
                      }
                      catch
                      {
                      }
                    }
                  }
                }
              }
            }
          }
          Thread.Sleep(5000);
        }
        catch
        {
        }
      }
    }

    public void StartMarketFeeds()
    {
    }

    private void AutoContracts()
    {
      Application.DoEvents();
      Thread.Sleep(500);
      if (!this.isLogin)
        return;
      this.Invoke((Delegate) (() =>
      {
        if (this.objcontrcts == null || this.objcontrcts.IsDisposed)
        {
          this.objcontrcts = new frmDownloadContrct(this.conn, this)
          {
            MdiParent = (Form) this
          };
          this.objcontrcts.StartDownloadContracts();
          this.objcontrcts.Show();
        }
        else
        {
          this.objcontrcts.StartDownloadContracts();
          this.objcontrcts.Show();
        }
      }));
    }

    private void MenuVisibleInvisible(int level)
    {
      switch (level)
      {
        case 0:
          this.AdminMenuItem.Visible = true;
          this.MarketMenuItem.Visible = true;
          this.ViewMenuItem.Enabled = false;
          this.helpMenu.Visible = false;
          this.forexToolStripMenuItem.Visible = false;
          for (int index = 0; index < 36; ++index)
            this.AdminMenuItem.DropDownItems[index].Visible = false;
          this.toolStripSeparator11.Visible = true;
          this.toolStripOrders.Visible = true;
          this.toolStripTrades.Visible = true;
          this.toolStripSLTrades.Visible = true;
          this.toolStripSeparator4.Visible = true;
          this.RMSMenuItem.Visible = true;
          this.windowsMenu.Visible = true;
          this.PositionPanel.Visible = false;
          this.MaintenanceMenuItem.Visible = false;
          this.panel1.Size = new Size(1026, 43);
          this.toolstripSymbolPos.Visible = true;
          this.toolStripDAPayinout.Visible = true;
          this.toolStripCmpnyPfls.Visible = true;
          this.toolStripSeparator7.Visible = true;
          this.DashSettingMenuItem.Visible = true;
          this.UserPrflMenuItem.Visible = true;
          this.RejectionMsgMenuItem.Visible = true;
          this.MisReportsMenuItem.Visible = true;
          break;
        case 1:
          this.AdminMenuItem.Visible = true;
          this.MarketMenuItem.Visible = true;
          this.ViewMenuItem.Enabled = false;
          this.helpMenu.Visible = false;
          this.forexToolStripMenuItem.Visible = false;
          for (int index = 0; index < 36; ++index)
            this.AdminMenuItem.DropDownItems[index].Visible = false;
          this.toolStripSeparator11.Visible = true;
          this.toolStripOrders.Visible = true;
          this.toolStripTrades.Visible = true;
          this.toolStripSLTrades.Visible = true;
          this.toolStripSeparator4.Visible = true;
          this.RMSMenuItem.Visible = true;
          this.windowsMenu.Visible = true;
          this.PositionPanel.Visible = false;
          this.MaintenanceMenuItem.Visible = false;
          this.panel1.Size = new Size(1026, 43);
          this.toolstripSymbolPos.Visible = true;
          this.toolStripDAPayinout.Visible = true;
          this.toolStripCmpnyPfls.Visible = true;
          this.toolStripSeparator7.Visible = true;
          this.DashSettingMenuItem.Visible = true;
          this.UserPrflMenuItem.Visible = true;
          this.RejectionMsgMenuItem.Visible = true;
          this.MisReportsMenuItem.Visible = true;
          break;
        case 2:
          this.ViewMenuItem.Enabled = false;
          this.AdminMenuItem.Visible = true;
          this.MarketMenuItem.Visible = true;
          this.forexToolStripMenuItem.Visible = false;
          this.dealeridpayout.Visible = true;
          this.helpMenu.Visible = true;
          for (int index = 0; index < 29; ++index)
            this.AdminMenuItem.DropDownItems[index].Visible = true;
          for (int index = 29; index < 36; ++index)
            this.AdminMenuItem.DropDownItems[index].Visible = false;
          this.windowsMenu.Visible = true;
          this.PositionPanel.Visible = false;
          this.toolStripBlastSystem.Visible = false;
          this.panel1.Size = new Size(1026, 43);
          this.DashSettingMenuItem.Visible = true;
          if (this.objinfo.isModTrd != 0)
            break;
          this.ModOrdTrdMenuItem.Visible = false;
          break;
        case 3:
          this.ViewMenuItem.Enabled = true;
          this.CommonOnOff();
          this.toolStripRMSView.Visible = true;
          this.PositionPanel.Visible = false;
          this.helpMenu.Visible = true;
          this.LedgerMenuItem.Visible = true;
          this.panel1.Size = new Size(1026, 43);
          this.forexToolStripMenuItem.Visible = false;
          break;
        case 4:
          this.ViewMenuItem.Enabled = true;
          this.CommonOnOff();
          this.toolStripRMSView.Visible = false;
          this.PositionPanel.Visible = true;
          this.helpMenu.Visible = true;
          this.LedgerMenuItem.Visible = true;
          this.panel1.Size = new Size(1026, 69);
          this.forexToolStripMenuItem.Visible = false;
          break;
      }
    }

    private void CommonOnOff()
    {
      this.AdminMenuItem.Visible = false;
      this.MarketMenuItem.Visible = true;
      this.ViewMenuItem.Visible = true;
      this.UserDetailsMenuItem.Visible = true;
      if (this.objinfo.pivots == 1)
        this.PivotsMenuItem.Visible = true;
      else
        this.PivotsMenuItem.Visible = false;
      if (this.objinfo.stockperform == 1)
        this.StocksViewMenuItem.Visible = true;
      else
        this.StocksViewMenuItem.Visible = false;
      if (this.objinfo.charts == 1)
        this.TechChartsMenuItem.Visible = true;
      else
        this.TechChartsMenuItem.Visible = false;
      this.windowsMenu.Visible = true;
    }

    private void fileMenu_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        this.LoginMenuItem.Enabled = false;
        this.LogOfftoolStripMenu.Enabled = true;
      }
      else
      {
        this.LoginMenuItem.Enabled = true;
        this.LogOfftoolStripMenu.Enabled = false;
      }
    }

    public string GetUsertype(int level)
    {
      switch (level)
      {
        case 0:
          return "Master Admin";
        case 1:
          return "Super Admin";
        case 2:
          return "Dealer Admin";
        case 3:
          return "Dealer";
        case 4:
          return "Client";
        default:
          return string.Empty;
      }
    }

    private void LogOfftoolStripMenu_Click(object sender, EventArgs e)
    {
      if (!this.isLogin)
        return;
      this.LogOff(true);
      this._lstAccounts.Clear();
      this.clearMsgBoard();
      this.DisplayMessage("LogOff Successfully!!", 1);
      this.InsertMsgBoard(" LogOff Successfull!!", 2);
    }

    private void CloseChildforms()
    {
      foreach (Form mdiChild in this.MdiChildren)
        mdiChild.Close();
      for (int index = 1; index < 8; ++index)
        this.menuStrip.Items[index].Visible = false;
    }

    public void LogOff(bool flag)
    {
      this.btnReconnectFeeds.Enabled = false;
      this.CloseChildforms();
      this.isLogin = false;
      this.claccounts = "";
      if (flag)
      {
        if (this.threadObjRT_MSG != null)
          this.threadObjRT_MSG.Abort();
        if (this.threadObjUpdLoginTime != null)
          this.threadObjUpdLoginTime.Abort();
      }
      if (this.cThread_netpos != null)
        this.cThread_netpos.Abort();
      if (this.threadObjRT_UpdateID != null)
        this.threadObjRT_UpdateID.Abort();
      if (this.threadObjRT_MCX1 != null)
        this.threadObjRT_MCX1.Abort();
      this.Invoke((Delegate) (() =>
      {
        this.lblCshMrgn.Text = "0";
        this.lblMrgnUtilised.Text = "0";
        this.lblMrgnBal.Text = "0";
        this.lblNetmtm.Text = "0";
        this.lblAvaiBal.Text = "0";
      }));
      if (this.conn.State != ConnectionState.Open)
        return;
      UserinfoMain.UpdateLogoff(this.objinfo.username, this.conn);
    }

    private void ChngPassMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objchngpwd == null || this.objchngpwd.IsDisposed)
        {
          ChangePwd changePwd = new ChangePwd(this.objinfo, this.conn, this);
          changePwd.MdiParent = (Form) this;
          this.objchngpwd = changePwd;
          this.objchngpwd.Loadwindow();
          this.objchngpwd.Show();
        }
        else
        {
          this.objchngpwd.Loadwindow();
          this.objchngpwd.MdiParent = (Form) this;
          this.objchngpwd.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void LckWrkstationMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objunlock == null || this.objunlock.IsDisposed)
        {
          this.objunlock = new unlock(this);
          int num = (int) this.objunlock.ShowDialog();
        }
        else
        {
          int num1 = (int) this.objunlock.ShowDialog();
        }
        this.clearMsgBoard();
        this.InsertMsgBoard(" Lock Workstation Successfull!!", 2);
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void UserPrflMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2 && this.objinfo.usertype != 1)
          return;
        if (this.objuserprofle == null || this.objuserprofle.IsDisposed)
        {
          frmUserprofile frmUserprofile = new frmUserprofile(this, this.conn);
          frmUserprofile.MdiParent = (Form) this;
          this.objuserprofle = frmUserprofile;
          this.objuserprofle.LoadWindow(this.objinfo.usertype);
          this.objuserprofle.Show();
        }
        else
        {
          this.objuserprofle.LoadWindow(this.objinfo.usertype);
          this.objuserprofle.MdiParent = (Form) this;
          this.objuserprofle.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public string GetUserExch()
    {
      if (!this.objinfo.exchange.Contains(","))
        return Convert.ToString((int) Enum.Parse(typeof (Exch), this.objinfo.exchange.ToUpper()));
      string empty = string.Empty;
      string exchange = this.objinfo.exchange;
      char[] chArray = new char[1]{ ',' };
      foreach (string str in exchange.Split(chArray))
        empty += string.Format("{0},", (object) (int) Enum.Parse(typeof (Exch), str.ToUpper()));
      return empty.Substring(0, empty.Length - 1).Trim();
    }

    public string GetStringExch(int exch)
    {
      switch (exch)
      {
        case 1:
          return "MCX";
        case 2:
          return "NSEFUT";
        case 3:
          return "NCDEX";
        case 4:
          return "NSECURR";
        default:
          return "MCX";
      }
    }

    public void ManageContracts(Contracts objcon)
    {
      if (!this._Symconctracts.ContainsKey(objcon.SymDesp))
        this._Symconctracts.Add(objcon.SymDesp, objcon);
      if (!this._Exchconctracts.ContainsKey(objcon.exch))
      {
        this._Exchconctracts.Add(objcon.exch, new SortedDictionary<string, Contracts>()
        {
          {
            objcon.SymDesp,
            objcon
          }
        });
      }
      else
      {
        SortedDictionary<string, Contracts> exchconctract = this._Exchconctracts[objcon.exch];
        if (!exchconctract.ContainsKey(objcon.SymDesp))
          exchconctract.Add(objcon.SymDesp, objcon);
        this._Exchconctracts[objcon.exch] = exchconctract;
      }
      if (!this._SymNameconctracts.ContainsKey(objcon.symbol))
        this._SymNameconctracts.Add(objcon.symbol, new Dictionary<string, Contracts>()
        {
          {
            objcon.SymDesp,
            objcon
          }
        });
      else if (!this._SymNameconctracts[objcon.symbol].ContainsKey(objcon.SymDesp))
        this._SymNameconctracts[objcon.symbol].Add(objcon.SymDesp, objcon);
    }

    public void ManageContractStatus(string clientcode, string symbol, int status, int exch)
    {
      if (!this._ClientContractStatus.ContainsKey(clientcode))
      {
        Dictionary<int, SortedDictionary<string, int>> dictionary = new Dictionary<int, SortedDictionary<string, int>>();
        SortedDictionary<string, int> sortedDictionary = new SortedDictionary<string, int>();
        if (status == 1)
          return;
        sortedDictionary.Add(symbol, status);
        dictionary.Add(exch, sortedDictionary);
        this._ClientContractStatus.Add(clientcode, dictionary);
      }
      else
      {
        Dictionary<int, SortedDictionary<string, int>> clientContractStatu1 = this._ClientContractStatus[clientcode];
        if (clientContractStatu1.ContainsKey(exch))
        {
          SortedDictionary<string, int> sortedDictionary = clientContractStatu1[exch];
          if (!sortedDictionary.ContainsKey(symbol) && status != 1)
            sortedDictionary.Add(symbol, status);
          else if (status == 1)
            sortedDictionary.Remove(symbol);
          else
            sortedDictionary[symbol] = status;
          clientContractStatu1[exch] = sortedDictionary;
          this._ClientContractStatus[clientcode] = clientContractStatu1;
        }
        else
        {
          SortedDictionary<string, int> sortedDictionary1 = new SortedDictionary<string, int>();
          if (status != 1)
          {
            if (this._ClientContractStatus.ContainsKey(clientcode))
            {
              Dictionary<int, SortedDictionary<string, int>> clientContractStatu2 = this._ClientContractStatus[clientcode];
              if (clientContractStatu2.ContainsKey(exch))
              {
                SortedDictionary<string, int> sortedDictionary2 = clientContractStatu2[exch];
                if (sortedDictionary2.ContainsKey(symbol))
                  sortedDictionary2[symbol] = status;
                else
                  sortedDictionary2.Add(symbol, status);
                clientContractStatu2[exch] = sortedDictionary2;
              }
              else
              {
                sortedDictionary1.Add(symbol, status);
                clientContractStatu2.Add(exch, sortedDictionary1);
              }
              this._ClientContractStatus[clientcode] = clientContractStatu2;
            }
            else
            {
              sortedDictionary1.Add(symbol, status);
              clientContractStatu1.Add(exch, sortedDictionary1);
              this._ClientContractStatus[clientcode] = clientContractStatu1;
            }
          }
        }
      }
    }

    public void ManageUserinformation(Userinfo objinfo)
    {
      if (objinfo.clientcode != this.objinfo.clientcode)
      {
        if (!this._Userinformation.ContainsKey(objinfo.clientcode))
          this._Userinformation.Add(objinfo.clientcode, objinfo);
        else
          this._Userinformation[objinfo.clientcode] = objinfo;
      }
      switch (objinfo.usertype)
      {
        case 3:
          if (!this._lstDealers.Contains(objinfo.clientcode))
            this._lstDealers.Add(objinfo.clientcode);
          if (this.dlaccounts == string.Empty || this.dlaccounts == null)
          {
            this.dlaccounts = string.Format("'{0}'", (object) objinfo.clientcode);
            break;
          }
          this.dlaccounts += string.Format(",'{0}'", (object) objinfo.clientcode);
          break;
        case 4:
          if (!this._lstAccounts.Contains(objinfo.clientcode))
            this._lstAccounts.Add(objinfo.clientcode);
          if (this.claccounts == string.Empty || this.claccounts == null)
          {
            this.claccounts = string.Format("'{0}'", (object) objinfo.clientcode);
            break;
          }
          this.claccounts += string.Format(",'{0}'", (object) objinfo.clientcode);
          break;
      }
    }

    public void ManageOffset(string clientcode, string symbol, double offset)
    {
      if (this._ClientOffset.ContainsKey(clientcode))
      {
        SortedDictionary<string, double> sortedDictionary = this._ClientOffset[clientcode];
        if (sortedDictionary.ContainsKey(symbol))
          sortedDictionary[symbol] = offset;
        else
          sortedDictionary.Add(symbol, offset);
        this._ClientOffset[clientcode] = sortedDictionary;
      }
      else
        this._ClientOffset.Add(clientcode, new SortedDictionary<string, double>()
        {
          {
            symbol,
            offset
          }
        });
    }

    public void ManageLimitset(Limits objlimits)
    {
      if (!this._ClientLimits.ContainsKey(objlimits.clientcode))
        this._ClientLimits.Add(objlimits.clientcode, objlimits);
      else
        this._ClientLimits[objlimits.clientcode] = objlimits;
    }

    public void ManageFeeds(Feeds objfeeds)
    {
      if (!this._SymFeeds.ContainsKey(objfeeds.symbol))
        this._SymFeeds.Add(objfeeds.symbol, objfeeds);
      else
        this._SymFeeds[objfeeds.symbol] = objfeeds;
    }

    private int GetMaxID(int tabletype)
    {
      int num = 0;
label_1:
      try
      {
        SqlCommand sqlCommand1 = new SqlCommand("GetFeedIDNEW", this.feedconn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@tabletype", (object) tabletype);
          using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(0))
                num = sqlDataReader.GetInt32(0);
              if (num == 0)
                goto label_1;
            }
          }
        }
      }
      catch
      {
        if (num == 0)
          goto label_1;
      }
      return num;
    }

    private void CheckFeedUpdate()
    {
      while (true)
      {
        try
        {
          if ((int) (this.servertime - this.lastfeedupdate).TotalSeconds <= 35)
            ;
        }
        catch
        {
        }
        Thread.Sleep(25000);
      }
    }

    public Feeds GetMarketData(SqlDataReader reader, bool flag)
    {
      Feeds feeds = new Feeds();
      if (!reader.IsDBNull(0))
        feeds.symbol = reader.GetString(0);
      if (!reader.IsDBNull(1))
        feeds.bidqty = reader.GetInt32(1);
      if (!reader.IsDBNull(2))
        feeds.bid = Convert.ToDecimal(reader.GetValue(2));
      if (!reader.IsDBNull(3))
        feeds.ask = Convert.ToDecimal(reader.GetValue(3));
      if (!reader.IsDBNull(4))
        feeds.askqty = reader.GetInt32(4);
      if (!reader.IsDBNull(5))
        feeds.ltp = Convert.ToDecimal(reader.GetValue(5));
      if (!reader.IsDBNull(6))
        feeds.open = Convert.ToDecimal(reader.GetValue(6));
      if (!reader.IsDBNull(7))
        feeds.high = Convert.ToDecimal(reader.GetValue(7));
      if (!reader.IsDBNull(8))
        feeds.low = Convert.ToDecimal(reader.GetValue(8));
      if (!reader.IsDBNull(9))
        feeds.close = Convert.ToDecimal(reader.GetValue(9));
      if (!reader.IsDBNull(10))
        feeds.netchange = Convert.ToDecimal(reader.GetValue(10));
      if (!reader.IsDBNull(11))
        feeds.perchange = Convert.ToDecimal(reader.GetValue(11));
      if (!reader.IsDBNull(12))
      {
        feeds.ltt = Convert.ToDateTime(reader.GetValue(12));
        this.lastfeedupdate = feeds.ltt;
      }
      if (!reader.IsDBNull(13) & flag)
        this.lastid = reader.GetInt32(13);
      if (!reader.IsDBNull(14))
        this.servertime = Convert.ToDateTime(reader.GetValue(14));
      if (!reader.IsDBNull(15))
        feeds.vol = Convert.ToDouble(reader.GetValue(15));
      if (!reader.IsDBNull(16))
        feeds.OI = Convert.ToDecimal(reader.GetValue(16));
      return feeds;
    }

    public void FetchMarketFeeds1()
    {
      this.lastid = this.GetMaxID(0);
      while (true)
      {
        if (this.lastid == 0)
        {
          Thread.Sleep(5000);
        }
        else
        {
          try
          {
            using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from MarketViewHistory where ID > " + (object) this.lastid ?? "", this.feedconn))
            {
              using (SqlDataReader reader = sqlCommand.ExecuteReader())
              {
                while (reader.Read())
                {
                  if (!this.isReconnectFeeds)
                  {
                    Feeds marketData = this.GetMarketData(reader, true);
                    if (marketData.symbol != null)
                      this.ManageFeeds(marketData);
                  }
                  else
                    break;
                }
              }
            }
            Thread.Sleep(85);
            Application.DoEvents();
          }
          catch
          {
            if (this.feedconn.State == ConnectionState.Closed)
            {
              this.feedconn = this.flag != 1 ? new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3)) : new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstringNEW));
              try
              {
                this.feedconn.Open();
              }
              catch
              {
                this.LogOff(true);
              }
            }
          }
        }
      }
    }

    public void FetchMarketFeedsMCX()
    {
      this.lastMcxid = this.GetMaxID(1);
      while (true)
      {
        try
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from MCXHistory where ID > " + (object) this.lastMcxid ?? "", this.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                if (!this.isReconnectFeeds)
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (!reader.IsDBNull(13))
                    this.lastMcxid = reader.GetInt32(13);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                }
                else
                  break;
              }
            }
          }
          Thread.Sleep(85);
          Application.DoEvents();
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
      }
    }

    public void FetchMarketFeedsNCDEX()
    {
      this.lastNcdexid = this.GetMaxID(2);
      while (true)
      {
        try
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from NCDEXHistory where ID > " + (object) this.lastNcdexid ?? "", this.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                if (!this.isReconnectFeeds)
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (!reader.IsDBNull(13))
                    this.lastNcdexid = reader.GetInt32(13);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                }
                else
                  break;
              }
            }
          }
          Thread.Sleep(85);
          Application.DoEvents();
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
      }
    }

    public void FetchMarketFeedsNSECUR()
    {
      this.lastNsecurid = this.GetMaxID(3);
      while (true)
      {
        try
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from NSECURHistory where ID > " + (object) this.lastNsecurid ?? "", this.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                if (!this.isReconnectFeeds)
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (!reader.IsDBNull(13))
                    this.lastNsecurid = reader.GetInt32(13);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                }
                else
                  break;
              }
            }
          }
          Thread.Sleep(85);
          Application.DoEvents();
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
      }
    }

    public void FetchMarketFeedsNSEFUT()
    {
      this.lastNsefutid = this.GetMaxID(4);
      while (true)
      {
        try
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from NSEFUTHistory where ID > " + (object) this.lastNsefutid ?? "", this.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                if (!this.isReconnectFeeds)
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (!reader.IsDBNull(13))
                    this.lastNsefutid = reader.GetInt32(13);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                }
                else
                  break;
              }
            }
          }
          Thread.Sleep(85);
          Application.DoEvents();
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
      }
    }

    public void FetchMarketFeedsNSEFUT2()
    {
      this.lastNsefut2id = this.GetMaxID(6);
      while (true)
      {
        try
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from NSEFUT2History where ID > " + (object) this.lastNsefut2id ?? "", this.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                if (!this.isReconnectFeeds)
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (!reader.IsDBNull(13))
                    this.lastNsefut2id = reader.GetInt32(13);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                }
                else
                  break;
              }
            }
          }
          Thread.Sleep(85);
          Application.DoEvents();
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
      }
    }

    public void FetchMarketFeedsNSEOPT()
    {
      this.lastNseoptid = this.GetMaxID(5);
      while (true)
      {
        try
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,ID,GetDate(),Volume,OI  from NSEOPTHistory where ID > " + (object) this.lastNseoptid ?? "", this.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                if (!this.isReconnectFeeds)
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (!reader.IsDBNull(13))
                    this.lastNseoptid = reader.GetInt32(13);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                }
                else
                  break;
              }
            }
          }
          Thread.Sleep(85);
          Application.DoEvents();
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
      }
    }

    private void FetchMarketFeeds2()
    {
      while (true)
      {
        List<string> stringList = new List<string>();
        List<string> subscribedSymbols = this._SubscribedSymbols;
        try
        {
          foreach (string str in subscribedSymbols)
          {
            using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,0,GetDate(),Volume,OI  from MarketView where Description = '" + str + "'", this.feedconn))
            {
              using (SqlDataReader reader = sqlCommand.ExecuteReader())
              {
                while (reader.Read())
                {
                  Feeds marketData = this.GetMarketData(reader, true);
                  if (marketData.symbol != null)
                    this.ManageFeeds(marketData);
                  Application.DoEvents();
                }
              }
            }
          }
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring3));
            try
            {
              this.feedconn.Open();
            }
            catch
            {
              this.LogOff(true);
            }
          }
        }
        Thread.Sleep(100);
        Application.DoEvents();
      }
    }

    private void PeriodicReconnectFeeds()
    {
      while (true)
      {
        if (this.threadObjRT_MCX1 != null && this.threadObjRT_MCX1.ThreadState == ThreadState.Running)
        {
          this.threadObjRT_MCX1.Abort();
          this.StartMarketFeeds();
        }
        Thread.Sleep(900000);
      }
    }

    public List<Orders> GetTradeOrders(int type)
    {
      List<Orders> ordersList = new List<Orders>();
      string claccounts = this.claccounts;
      if (claccounts == string.Empty)
        return ordersList;
      string cmdText = string.Format("select Clientcode, Exch ,Symbol, Productype, BuySell,Qty, Validity,  LastModified, Userremarks,Traderid,OrderNo,OrdStatus, CreateOn, Price,ExecType,OrdPrice,Ipaddress from  Orders  where  Clientcode in ({0}) and OrdStatus = {1}  and CreateOn > '{2}' Order by LastModified", (object) claccounts, (object) type, (object) DateTime.Now.ToString("yyyy-MM-dd 09:00:00"));
      if (type == 1)
        cmdText = string.Format("select Clientcode, Exch ,Symbol, Productype, BuySell,Qty, Validity,  LastModified, Userremarks,Traderid,OrderNo,OrdStatus, CreateOn, Price,ExecType,OrdPrice,Ipaddress from  Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6)  and CreateOn > '{1}' Order by LastModified", (object) claccounts, (object) DateTime.Now.ToString("yyyy-MM-dd 09:00:00"));
      try
      {
        if (this.conn.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand(cmdText, this.conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                Orders orders = new Orders();
                if (!sqlDataReader.IsDBNull(0))
                  orders.accountNo = sqlDataReader.GetString(0);
                if (!sqlDataReader.IsDBNull(1))
                  orders.ExchangeTypeID = sqlDataReader.GetInt32(1);
                if (!sqlDataReader.IsDBNull(2))
                  orders.symbol = sqlDataReader.GetString(2);
                if (!sqlDataReader.IsDBNull(3))
                  orders.ProductType = sqlDataReader.GetInt32(3);
                if (!sqlDataReader.IsDBNull(4))
                  orders.BuySell = sqlDataReader.GetInt32(4);
                if (!sqlDataReader.IsDBNull(5))
                  orders.Ordeqty = sqlDataReader.GetInt32(5);
                if (!sqlDataReader.IsDBNull(6))
                  orders.ValidityType = sqlDataReader.GetInt32(6);
                if (!sqlDataReader.IsDBNull(7))
                  orders.LastModified = Convert.ToDateTime(sqlDataReader.GetValue(7));
                if (!sqlDataReader.IsDBNull(8))
                  orders.UserRemark = sqlDataReader.GetString(8);
                if (!sqlDataReader.IsDBNull(9))
                  orders.TraderId = sqlDataReader.GetString(9);
                if (!sqlDataReader.IsDBNull(10))
                  orders.OrderNo = Convert.ToDouble(sqlDataReader.GetValue(10));
                if (!sqlDataReader.IsDBNull(11))
                  orders.Orderstatus = sqlDataReader.GetInt32(11);
                if (!sqlDataReader.IsDBNull(12))
                  orders.CreatedOn = Convert.ToDateTime(sqlDataReader.GetValue(12));
                if (!sqlDataReader.IsDBNull(13))
                  orders.ExecPrice = Convert.ToDecimal(sqlDataReader.GetValue(13));
                if (!sqlDataReader.IsDBNull(14))
                  orders.Exectype = Convert.ToInt32(sqlDataReader.GetValue(14));
                if (!sqlDataReader.IsDBNull(15))
                  orders.OrdePrice = Convert.ToDecimal(sqlDataReader.GetValue(15));
                orders.ipAddress = !sqlDataReader.IsDBNull(16) ? sqlDataReader.GetString(16).Trim() : string.Empty;
                ordersList.Add(orders);
              }
            }
          }
        }
      }
      catch
      {
        if (this.conn.State == ConnectionState.Open)
        {
          this.conn = new SqlConnection(Utils.Getconnsss());
          try
          {
            this.conn.Open();
          }
          catch
          {
          }
        }
      }
      return ordersList;
    }

    public Feeds getFeed(string symbol)
    {
      return !this._SymFeeds.ContainsKey(symbol) ? new Feeds() : this._SymFeeds[symbol];
    }

    private void CntrctMnmgtMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objfrmcontrct == null || this.objfrmcontrct.IsDisposed)
        {
          frmContracts frmContracts = new frmContracts(this, this.conn);
          frmContracts.MdiParent = (Form) this;
          this.objfrmcontrct = frmContracts;
          this.objfrmcontrct.LoadContracts();
          this.objfrmcontrct.Show();
        }
        else
        {
          this.objfrmcontrct.LoadContracts();
          this.objfrmcontrct.MdiParent = (Form) this;
          this.objfrmcontrct.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void LimitsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objlimits == null || this.objlimits.IsDisposed)
        {
          frmLimits frmLimits = new frmLimits(this, this.conn);
          frmLimits.MdiParent = (Form) this;
          this.objlimits = frmLimits;
          this.objlimits.Loadwindow();
          this.objlimits.Show();
        }
        else
        {
          this.objlimits.Loadwindow();
          this.objlimits.MdiParent = (Form) this;
          this.objlimits.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void OffsetMnmgtMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objOffset == null || this.objOffset.IsDisposed)
        {
          frmOffsetMngmnt frmOffsetMngmnt = new frmOffsetMngmnt(this);
          frmOffsetMngmnt.MdiParent = (Form) this;
          this.objOffset = frmOffsetMngmnt;
          this.objOffset.LoadControls();
          this.objOffset.Show();
        }
        else
        {
          this.objOffset.LoadControls();
          this.objOffset.MdiParent = (Form) this;
          this.objOffset.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void ModOrdTrdMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objmodordtrd == null || this.objmodordtrd.IsDisposed)
        {
          ModifyOrderTrade modifyOrderTrade = new ModifyOrderTrade(this, this.conn);
          modifyOrderTrade.MdiParent = (Form) this;
          this.objmodordtrd = modifyOrderTrade;
          this.objmodordtrd.Show();
        }
        else
        {
          this.objmodordtrd.MdiParent = (Form) this;
          this.objmodordtrd.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public void ManageMargin(SymbolMargin objmrgn)
    {
      if (this._ClientSymMrgn.ContainsKey(objmrgn.clientcode))
      {
        Dictionary<string, SymbolMargin> dictionary = this._ClientSymMrgn[objmrgn.clientcode];
        if (dictionary.ContainsKey(objmrgn.symbol))
          dictionary[objmrgn.symbol] = objmrgn;
        else
          dictionary.Add(objmrgn.symbol, objmrgn);
        this._ClientSymMrgn[objmrgn.clientcode] = dictionary;
      }
      else
        this._ClientSymMrgn.Add(objmrgn.clientcode, new Dictionary<string, SymbolMargin>()
        {
          {
            objmrgn.symbol,
            objmrgn
          }
        });
    }

    public void ManageDPRLimit(string symbol, double DPR)
    {
      if (!this._SymbolwiseDPRLimit.ContainsKey(symbol))
        this._SymbolwiseDPRLimit.Add(symbol, DPR);
      else
        this._SymbolwiseDPRLimit[symbol] = DPR;
    }

    public double GetDPRLimit(string symbol)
    {
      return this._SymbolwiseDPRLimit.ContainsKey(symbol) ? this._SymbolwiseDPRLimit[symbol] : 0.0;
    }

    private void SymMargnRsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objfrmmrgn == null || this.objfrmmrgn.IsDisposed)
        {
          Margin margin = new Margin(this, this.conn);
          margin.MdiParent = (Form) this;
          this.objfrmmrgn = margin;
          this.objfrmmrgn.LoadMarginWindow();
          this.objfrmmrgn.Show();
        }
        else
        {
          this.objfrmmrgn.LoadMarginWindow();
          this.objfrmmrgn.MdiParent = (Form) this;
          this.objfrmmrgn.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void AccMapMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objaccmap == null || this.objaccmap.IsDisposed)
        {
          frmAccMapping frmAccMapping = new frmAccMapping(this);
          frmAccMapping.MdiParent = (Form) this;
          this.objaccmap = frmAccMapping;
          this.objaccmap.LoadControls();
          this.objaccmap.Show();
        }
        else
        {
          this.objaccmap.LoadControls();
          this.objaccmap.MdiParent = (Form) this;
          this.objaccmap.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void AdminMsgsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objadmmsg == null || this.objadmmsg.IsDisposed)
        {
          AdminMessages adminMessages = new AdminMessages(this, this.conn);
          adminMessages.MdiParent = (Form) this;
          this.objadmmsg = adminMessages;
          this.objadmmsg.Loadwindow();
          this.objadmmsg.Show();
        }
        else
        {
          this.objadmmsg.Loadwindow();
          this.objadmmsg.MdiParent = (Form) this;
          this.objadmmsg.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void PayinOutMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objpayinout == null || this.objpayinout.IsDisposed)
        {
          Payin_Payoutt payinPayoutt = new Payin_Payoutt(this, this.conn);
          payinPayoutt.MdiParent = (Form) this;
          this.objpayinout = payinPayoutt;
          this.objpayinout.LoadWindow();
          this.objpayinout.Show();
        }
        else
        {
          this.objpayinout.LoadWindow();
          this.objlimits.MdiParent = (Form) this;
          this.objpayinout.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void OrderBookMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objordbook == null || this.objordbook.IsDisposed)
        {
          Orderbook orderbook = new Orderbook(this);
          orderbook.MdiParent = (Form) this;
          this.objordbook = orderbook;
          this.objordbook.LoadOrders();
          this.objordbook.Show();
        }
        else
        {
          this.objordbook.LoadOrders();
          this.objordbook.MdiParent = (Form) this;
          this.objordbook.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void ForceSqOffMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objforcesqoff == null || this.objforcesqoff.IsDisposed)
        {
          ForcedSqOff forcedSqOff = new ForcedSqOff(this.conn, this);
          forcedSqOff.MdiParent = (Form) this;
          this.objforcesqoff = forcedSqOff;
          this.objforcesqoff.CreateTree();
          this.objforcesqoff.Show();
        }
        else
        {
          this.objforcesqoff.CreateTree();
          this.objforcesqoff.MdiParent = (Form) this;
          this.objforcesqoff.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void RMSMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype == 2)
        {
          if (this.objRMS == null || this.objRMS.IsDisposed)
          {
            RMSClientwise rmsClientwise = new RMSClientwise(this);
            rmsClientwise.MdiParent = (Form) this;
            this.objRMS = rmsClientwise;
            this.objRMS.LoadRMS();
            this.objRMS.Show();
          }
          else
          {
            this.objRMS.LoadRMS();
            this.objRMS.MdiParent = (Form) this;
            this.objRMS.Show();
          }
        }
        else
        {
          if (this.objinfo.usertype != 1)
            return;
          if (this.objDA_Rms == null || this.objDA_Rms.IsDisposed)
          {
            frmRMS_DAwise frmRmsDawise = new frmRMS_DAwise(this);
            frmRmsDawise.MdiParent = (Form) this;
            this.objDA_Rms = frmRmsDawise;
            this.objDA_Rms.LoadRMS();
            this.objDA_Rms.Show();
          }
          else
          {
            this.objDA_Rms.LoadRMS();
            this.objDA_Rms.MdiParent = (Form) this;
            this.objDA_Rms.Show();
          }
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void AdmMsgsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objmsgview == null || this.objmsgview.IsDisposed)
        {
          AdminMsgView adminMsgView = new AdminMsgView(this, this.conn);
          adminMsgView.MdiParent = (Form) this;
          this.objmsgview = adminMsgView;
          this.objmsgview.LoadAdminMsgs();
          this.objmsgview.Show();
        }
        else
        {
          this.objmsgview.LoadAdminMsgs();
          this.objmsgview.MdiParent = (Form) this;
          this.objmsgview.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void Dashboard_FormClosing(object sender, FormClosingEventArgs e)
    {
      Environment.Exit(0);
    }

    private void SymMrgnLotsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objDefExchMrgn == null || this.objDefExchMrgn.IsDisposed)
        {
          frmDefExchMrgn frmDefExchMrgn = new frmDefExchMrgn(this);
          frmDefExchMrgn.MdiParent = (Form) this;
          this.objDefExchMrgn = frmDefExchMrgn;
          this.objDefExchMrgn.Loadwindow();
          this.objDefExchMrgn.Show();
        }
        else
        {
          this.objDefExchMrgn.Loadwindow();
          this.objDefExchMrgn.MdiParent = (Form) this;
          this.objDefExchMrgn.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void MisReportsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2 && this.objinfo.usertype != 1)
          return;
        if (this.objmis == null || this.objmis.IsDisposed)
        {
          MISReports misReports = new MISReports(this);
          misReports.MdiParent = (Form) this;
          this.objmis = misReports;
          this.objmis.LoadHierarchy();
          this.objmis.Show();
        }
        else
        {
          this.objmis.LoadHierarchy();
          this.objmis.MdiParent = (Form) this;
          this.objmis.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void AccDetailsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objaccdetails == null || this.objaccdetails.IsDisposed)
        {
          frmAccountDetails frmAccountDetails = new frmAccountDetails(this);
          frmAccountDetails.MdiParent = (Form) this;
          this.objaccdetails = frmAccountDetails;
          this.objaccdetails.Loadwindow();
          this.objaccdetails.Show();
        }
        else
        {
          this.objaccdetails.Loadwindow();
          this.objaccdetails.MdiParent = (Form) this;
          this.objaccdetails.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void TotOrdersMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objordlist == null || this.objordlist.IsDisposed)
        {
          Orderlist orderlist = new Orderlist(this);
          orderlist.MdiParent = (Form) this;
          this.objordlist = orderlist;
          this.objordlist.LoadWindow();
          this.objordlist.Show();
        }
        else
        {
          this.objordlist.LoadWindow();
          this.objordlist.MdiParent = (Form) this;
          this.objordlist.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void OpenPosMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objopenPos == null || this.objopenPos.IsDisposed)
        {
          OpenPosition openPosition = new OpenPosition(this, this.conn);
          openPosition.MdiParent = (Form) this;
          this.objopenPos = openPosition;
          this.objopenPos.LoadNetPositions();
          this.objopenPos.Show();
        }
        else
        {
          this.objopenPos.LoadNetPositions();
          this.objopenPos.MdiParent = (Form) this;
          this.objopenPos.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void TrdBookMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objrttrdbook == null || this.objrttrdbook.IsDisposed)
        {
          frmRTTrades frmRtTrades = new frmRTTrades(this);
          frmRtTrades.MdiParent = (Form) this;
          this.objrttrdbook = frmRtTrades;
          this.objrttrdbook.LoadTrades();
          this.objrttrdbook.Show();
        }
        else
        {
          this.objrttrdbook.LoadTrades();
          this.objrttrdbook.MdiParent = (Form) this;
          this.objrttrdbook.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void NetPosMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objnetpos == null || this.objnetpos.IsDisposed)
        {
          NetPosition netPosition = new NetPosition(this);
          netPosition.MdiParent = (Form) this;
          this.objnetpos = netPosition;
          this.objnetpos.LoadNetPositions(false);
          this.objnetpos.Show();
        }
        else
        {
          this.objnetpos.LoadNetPositions(false);
          this.objnetpos.MdiParent = (Form) this;
          this.objnetpos.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void ModOrdMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objmodord == null || this.objmodord.IsDisposed)
        {
          ModifiedOrders modifiedOrders = new ModifiedOrders(this, this.conn);
          modifiedOrders.MdiParent = (Form) this;
          this.objmodord = modifiedOrders;
          this.objmodord.LoadModified();
          this.objmodord.Show();
        }
        else
        {
          this.objmodord.LoadModified();
          this.objmodord.MdiParent = (Form) this;
          this.objmodord.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void CanOrdMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objcanOrd == null || this.objcanOrd.IsDisposed)
        {
          CancelledOrders cancelledOrders = new CancelledOrders(this, this.conn);
          cancelledOrders.MdiParent = (Form) this;
          this.objcanOrd = cancelledOrders;
          this.objcanOrd.LoadOrders();
          this.objcanOrd.Show();
        }
        else
        {
          this.objcanOrd.LoadOrders();
          this.objcanOrd.MdiParent = (Form) this;
          this.objcanOrd.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void MsgLogsMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objmsglogs == null || this.objmsglogs.IsDisposed)
        {
          MessageLogs messageLogs = new MessageLogs(this, this.conn);
          messageLogs.MdiParent = (Form) this;
          this.objmsglogs = messageLogs;
          this.objmsglogs.LoadMessageLogs();
          this.objmsglogs.Show();
        }
        else
        {
          this.objmsglogs.LoadMessageLogs();
          this.objmsglogs.MdiParent = (Form) this;
          this.objmsglogs.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void ContrctStatusMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objViewConStatus == null || this.objViewConStatus.IsDisposed)
        {
          frmContractStatusView contractStatusView = new frmContractStatusView(this);
          contractStatusView.MdiParent = (Form) this;
          this.objViewConStatus = contractStatusView;
          this.objViewConStatus.LoadWindow();
          this.objViewConStatus.Show();
        }
        else
        {
          this.objViewConStatus.LoadWindow();
          this.objViewConStatus.MdiParent = (Form) this;
          this.objViewConStatus.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void LstPayinPayoutMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objpayinoutview == null || this.objpayinoutview.IsDisposed)
        {
          frmPayinout frmPayinout = new frmPayinout(this);
          frmPayinout.MdiParent = (Form) this;
          this.objpayinoutview = frmPayinout;
          this.objpayinoutview.LoadPayinOut("1,2");
          this.objpayinoutview.Show();
        }
        else
        {
          this.objpayinoutview.LoadPayinOut("1,2");
          this.objpayinoutview.MdiParent = (Form) this;
          this.objpayinoutview.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public SqlConnection getConn()
    {
      if (this.conn.State == ConnectionState.Open)
        return this.conn;
      this.conn = new SqlConnection(Utils.Getconnsss());
      try
      {
        this.conn.Open();
      }
      catch
      {
      }
      return this.conn;
    }

    private void RejectionMsgMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objrejectMsg == null || this.objrejectMsg.IsDisposed)
        {
          SurveillanceView surveillanceView = new SurveillanceView(this);
          surveillanceView.MdiParent = (Form) this;
          this.objrejectMsg = surveillanceView;
          this.objrejectMsg.LoadWindow();
          this.objrejectMsg.Show();
        }
        else
        {
          this.objrejectMsg.LoadWindow();
          this.objrejectMsg.MdiParent = (Form) this;
          this.objrejectMsg.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripMngConStatus_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 1 && this.objinfo.usertype != 2)
          return;
        if (this.objcontractStatus == null || this.objcontractStatus.IsDisposed)
        {
          frmManageCntrctStatus manageCntrctStatus = new frmManageCntrctStatus(this);
          manageCntrctStatus.MdiParent = (Form) this;
          this.objcontractStatus = manageCntrctStatus;
          this.objcontractStatus.LoadControls();
          this.objcontractStatus.Show();
        }
        else
        {
          this.objcontractStatus.LoadControls();
          this.objcontractStatus.MdiParent = (Form) this;
          this.objcontractStatus.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public SymbolMargin GetSymbolwiseMrgn(string clientcode, string symbol)
    {
      if (this._ClientSymMrgn.ContainsKey(clientcode))
      {
        Dictionary<string, SymbolMargin> dictionary1 = this._ClientSymMrgn[clientcode];
        if (dictionary1.ContainsKey(symbol))
          return dictionary1[symbol];
        if (this._ClientSymMrgn.ContainsKey(this.objinfo.createdby))
        {
          Dictionary<string, SymbolMargin> dictionary2 = this._ClientSymMrgn[this.objinfo.createdby];
          if (dictionary2.ContainsKey(symbol))
            return dictionary2[symbol];
        }
      }
      else if (this.objinfo.usertype == 2)
      {
        if (this._ClientSymMrgn.ContainsKey(this.objinfo.clientcode))
        {
          Dictionary<string, SymbolMargin> dictionary = this._ClientSymMrgn[this.objinfo.clientcode];
          if (dictionary.ContainsKey(symbol))
            return dictionary[symbol];
        }
      }
      else if (this._ClientSymMrgn.ContainsKey(this.objinfo.createdby))
      {
        Dictionary<string, SymbolMargin> dictionary = this._ClientSymMrgn[this.objinfo.createdby];
        if (dictionary.ContainsKey(symbol))
          return dictionary[symbol];
      }
      return new SymbolMargin();
    }

    public SymbolMargin symbolwisemrgn(string clientcode, string symbol)
    {
      string empty = string.Empty;
      using (SqlCommand sqlCommand = new SqlCommand("select createdby from userinformation where  Clientcode='" + clientcode + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              empty = sqlDataReader.GetString(0);
          }
        }
      }
      Dictionary<string, SymbolMargin> dictionary = new Dictionary<string, SymbolMargin>();
      SymbolMargin symbolMargin = new SymbolMargin();
      SqlCommand sqlCommand1 = new SqlCommand("GetSymbolwiseMargin", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@createdby", (object) empty);
        sqlCommand2.Parameters.AddWithValue("@Clientcode", (object) clientcode);
        sqlCommand2.Parameters.AddWithValue("@symbol", (object) symbol);
        using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(1))
              symbolMargin.symbol = sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
              symbolMargin.intramrgn = sqlDataReader.GetInt32(2);
            if (!sqlDataReader.IsDBNull(3))
              symbolMargin.intrabrkg = sqlDataReader.GetInt32(3);
            if (!sqlDataReader.IsDBNull(4))
              symbolMargin.delvmrgn = sqlDataReader.GetInt32(4);
            if (!sqlDataReader.IsDBNull(5))
              symbolMargin.delvbrkg = sqlDataReader.GetInt32(5);
            if (!sqlDataReader.IsDBNull(6))
              symbolMargin.totlots = sqlDataReader.GetInt32(6);
            if (!sqlDataReader.IsDBNull(7))
              symbolMargin.clientcode = sqlDataReader.GetString(7);
            if (!sqlDataReader.IsDBNull(8))
              symbolMargin.brkupQty = sqlDataReader.GetInt32(8);
            if (symbolMargin.clientcode == clientcode)
            {
              dictionary.Add(symbolMargin.clientcode, symbolMargin);
              break;
            }
          }
        }
      }
      return symbolMargin;
    }

    private void GetProfitLossPosition()
    {
      while (true)
      {
        Dictionary<string, buysellPos> _BuySellAvgPos1 = new Dictionary<string, buysellPos>();
        Dictionary<string, buysellPos> _BuySellAvgPos2 = new Dictionary<string, buysellPos>();
        this.GetTradePosition(ref _BuySellAvgPos1, this.claccounts, false);
        this.GetRMSTradePosition(ref _BuySellAvgPos2, this.claccounts, false);
        this._NetProftLoss = this.ProcessProfitLoss(_BuySellAvgPos1);
        this._NetProftLossRMS = this.ProcessRMSProfitLoss(_BuySellAvgPos2);
        this.GetNetPrfLoss(this._NetProftLoss);
        this.GetRMSPrfLoss(this._NetProftLossRMS);
        Thread.Sleep(3000);
      }
    }

    public Dictionary<string, buysellnetpospfls> GetNetPos(
      string account,
      string symbol,
      DateTime timestamp,
      int postype)
    {
      Dictionary<string, buysellPos> _BuySellAvgPos = new Dictionary<string, buysellPos>();
      this.GetSymbolTimewiseTradePosition(ref _BuySellAvgPos, this.claccounts, symbol, timestamp, postype);
      return this.ProcessProfitLoss(_BuySellAvgPos);
    }

    public Dictionary<string, buysellnetpospfls> GetNetPrfLoss(
      Dictionary<string, buysellnetpospfls> __NetProftLoss)
    {
      this._NetMTMProftLoss = new Dictionary<string, buysellnetpospfls>();
      this._DAwiseProfitLoss = new Dictionary<string, buysellnetpospfls>();
      buysellnetpospfls objnetposs = new buysellnetpospfls();
      try
      {
        foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this._NetProftLoss)
        {
          string[] strArray = keyValuePair.Key.Split('_');
          string index = strArray[1].Trim();
          Convert.ToInt32(strArray[2]);
          buysellnetpospfls buysellnetpospfls1 = keyValuePair.Value;
          if (!this._NetMTMProftLoss.ContainsKey(index))
          {
            objnetposs = buysellnetpospfls1;
            this._NetMTMProftLoss.Add(index, objnetposs);
          }
          else
          {
            objnetposs = this._NetMTMProftLoss[index];
            objnetposs.p_l += Decimal.Round(buysellnetpospfls1.p_l, 2);
            objnetposs.Commision += buysellnetpospfls1.Commision;
            objnetposs.UnrealisedP_l += Decimal.Round(buysellnetpospfls1.UnrealisedP_l, 2);
            objnetposs.margin += buysellnetpospfls1.margin;
            objnetposs.TurnoverUtilised += buysellnetpospfls1.TurnoverUtilised;
            this._NetMTMProftLoss[index] = objnetposs;
          }
          if (this.objinfo.usertype == 1)
          {
            buysellnetpospfls buysellnetpospfls2 = keyValuePair.Value;
            Userinfo userinfo = this.GetUserinfo(index);
            if (!this._DAwiseProfitLoss.ContainsKey(userinfo.createdby))
            {
              this._DAwiseProfitLoss.Add(userinfo.createdby, buysellnetpospfls2);
            }
            else
            {
              buysellnetpospfls buysellnetpospfls3 = this._DAwiseProfitLoss[userinfo.createdby];
              buysellnetpospfls3.p_l += Decimal.Round(buysellnetpospfls1.p_l, 2);
              buysellnetpospfls3.Commision += buysellnetpospfls1.Commision;
              buysellnetpospfls3.UnrealisedP_l += Decimal.Round(buysellnetpospfls1.UnrealisedP_l, 2);
              buysellnetpospfls3.margin += buysellnetpospfls1.margin;
              buysellnetpospfls3.TurnoverUtilised += buysellnetpospfls1.TurnoverUtilised;
              this._DAwiseProfitLoss[userinfo.createdby] = buysellnetpospfls3;
            }
          }
        }
        if (this.objinfo.usertype == 4)
          this.Invoke((Delegate) (() =>
          {
            if (!this._ClientLimits.ContainsKey(this.objinfo.clientcode))
              return;
            Limits clientLimit = this._ClientLimits[this.objinfo.clientcode];
            this.lblCshMrgn.Text = clientLimit.cashmrgn.ToString();
            this.lblMrgnUtilised.Text = objnetposs.margin.ToString();
            this.lblNetmtm.Text = Convert.ToString(Decimal.Round(objnetposs.p_l - objnetposs.Commision + objnetposs.UnrealisedP_l, 2));
            this.lblMrgnBal.Text = Convert.ToString(Decimal.Round(Convert.ToDecimal(clientLimit.cashmrgn) + (objnetposs.p_l - objnetposs.Commision + objnetposs.UnrealisedP_l), 2));
          }));
      }
      catch
      {
      }
      return this._NetMTMProftLoss;
    }

    public Dictionary<string, buysellnetpospfls> GetRMSPrfLoss(
      Dictionary<string, buysellnetpospfls> __NetProftLoss)
    {
      this._NetRMSMTMProftLoss = new Dictionary<string, buysellnetpospfls>();
      this._DAwiseProfitLoss = new Dictionary<string, buysellnetpospfls>();
      buysellnetpospfls objnetposs = new buysellnetpospfls();
      try
      {
        foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in __NetProftLoss)
        {
          string[] strArray = keyValuePair.Key.Split('_');
          string index = strArray[1].Trim();
          Convert.ToInt32(strArray[2]);
          buysellnetpospfls buysellnetpospfls1 = keyValuePair.Value;
          if (!this._NetRMSMTMProftLoss.ContainsKey(index))
          {
            objnetposs = buysellnetpospfls1;
            this._NetRMSMTMProftLoss.Add(index, objnetposs);
          }
          else
          {
            objnetposs = this._NetRMSMTMProftLoss[index];
            objnetposs.p_l += Decimal.Round(buysellnetpospfls1.p_l, 2);
            objnetposs.Commision += buysellnetpospfls1.Commision;
            objnetposs.UnrealisedP_l += Decimal.Round(buysellnetpospfls1.UnrealisedP_l, 2);
            objnetposs.margin += buysellnetpospfls1.margin;
            objnetposs.TurnoverUtilised += buysellnetpospfls1.TurnoverUtilised;
            this._NetRMSMTMProftLoss[index] = objnetposs;
          }
          if (this.objinfo.usertype == 1)
          {
            buysellnetpospfls buysellnetpospfls2 = keyValuePair.Value;
            Userinfo userinfo = this.GetUserinfo(index);
            if (!this._DAwiseProfitLoss.ContainsKey(userinfo.createdby))
            {
              this._DAwiseProfitLoss.Add(userinfo.createdby, buysellnetpospfls2);
            }
            else
            {
              buysellnetpospfls buysellnetpospfls3 = this._DAwiseProfitLoss[userinfo.createdby];
              buysellnetpospfls3.p_l += Decimal.Round(buysellnetpospfls1.p_l, 2);
              buysellnetpospfls3.Commision += buysellnetpospfls1.Commision;
              buysellnetpospfls3.UnrealisedP_l += Decimal.Round(buysellnetpospfls1.UnrealisedP_l, 2);
              buysellnetpospfls3.margin += buysellnetpospfls1.margin;
              buysellnetpospfls3.TurnoverUtilised += buysellnetpospfls1.TurnoverUtilised;
              this._DAwiseProfitLoss[userinfo.createdby] = buysellnetpospfls3;
            }
          }
        }
        if (this.objinfo.usertype == 4)
          this.Invoke((Delegate) (() =>
          {
            if (!this._ClientLimits.ContainsKey(this.objinfo.clientcode))
              return;
            Limits clientLimit = this._ClientLimits[this.objinfo.clientcode];
            this.lblCshMrgn.Text = clientLimit.cashmrgn.ToString();
            this.lblMrgnUtilised.Text = objnetposs.margin.ToString();
            this.lblNetmtm.Text = Convert.ToString(Decimal.Round(objnetposs.p_l - objnetposs.Commision + objnetposs.UnrealisedP_l, 2));
            this.lblMrgnBal.Text = Convert.ToString(Decimal.Round(Convert.ToDecimal(clientLimit.cashmrgn) + (objnetposs.p_l - objnetposs.Commision + objnetposs.UnrealisedP_l), 2));
          }));
      }
      catch
      {
      }
      return this._NetRMSMTMProftLoss;
    }

    public Dictionary<string, Dictionary<int, List<Trades>>> GetTradePosition(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      string account,
      bool isIntraday)
    {
      Dictionary<string, Dictionary<int, List<Trades>>> dictionary = new Dictionary<string, Dictionary<int, List<Trades>>>();
      if (this.claccounts == null || this.claccounts.Length == 0)
        return dictionary;
      string empty = string.Empty;
      string cmdText = this.objinfo.usertype != 1 ? (!isIntraday ? string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where T.Clientcode in ({0}) and T.OrderNo = O.OrderNo  ", (object) account) : string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where T.Clientcode in ({0}) and T.OrderNo = O.OrderNo and O.IsMaintenance = 0  ", (object) account)) : (!isIntraday ? string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where T.OrderNo = O.OrderNo and T.Clientcode in ({0})  ", (object) account) : string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where  T.OrderNo = O.OrderNo and O.IsMaintenance = 0 and T.Clientcode in ({0})  ", (object) account));
      using (DataSet dataSet = new DataSet())
      {
        try
        {
          using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter()
          {
            SelectCommand = new SqlCommand(cmdText, this.conn)
          })
          {
            sqlDataAdapter.Fill(dataSet);
            for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
            {
              Trades objtrd = new Trades()
              {
                Symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString(),
                qty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[1]),
                buysell = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2]),
                Lastmodified = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[3]),
                price = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[4]),
                clientcode = dataSet.Tables[0].Rows[index].ItemArray[5].ToString(),
                validity = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[6]),
                isMaintenance = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[7])
              };
              if (objtrd.validity == 3)
                objtrd.validity = 1;
              if (this._Symconctracts.ContainsKey(objtrd.Symbol))
              {
                Contracts symconctract = this._Symconctracts[objtrd.Symbol];
                this.SubcribeSymbol(objtrd.Symbol);
                if (!this._ExchFeedInstance.ContainsKey(Utils.GetExch(symconctract.exch)))
                  this.SubsribeExchFeeds(Utils.GetExch(symconctract.exch));
                Dashboard.ManagePositions(ref _BuySellAvgPos, objtrd);
              }
            }
          }
        }
        catch
        {
        }
      }
      return dictionary;
    }

    public Dictionary<string, Dictionary<int, List<Trades>>> GetRMSTradePosition(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      string account,
      bool isIntraday)
    {
      Dictionary<string, Dictionary<int, List<Trades>>> dictionary = new Dictionary<string, Dictionary<int, List<Trades>>>();
      if (this.claccounts == null || this.claccounts.Length == 0)
        return dictionary;
      string empty = string.Empty;
      string cmdText = this.objinfo.usertype != 1 ? (!isIntraday ? string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where T.Clientcode in ({0}) and T.OrderNo = O.OrderNo  ", (object) account) : string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where T.Clientcode in ({0}) and T.OrderNo = O.OrderNo and O.IsMaintenance = 0  ", (object) account)) : (!isIntraday ? string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where T.OrderNo = O.OrderNo and T.Clientcode in ({0})  ", (object) account) : string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.IsMaintenance from Trade T , Orders O where  T.OrderNo = O.OrderNo and O.IsMaintenance = 0 and T.Clientcode in ({0})  ", (object) account));
      using (DataSet dataSet = new DataSet())
      {
        try
        {
          using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter()
          {
            SelectCommand = new SqlCommand(cmdText, this.conn)
          })
          {
            sqlDataAdapter.Fill(dataSet);
            for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
            {
              Trades objtrd = new Trades()
              {
                Symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString(),
                qty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[1]),
                buysell = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2]),
                Lastmodified = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[3]),
                price = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[4]),
                clientcode = dataSet.Tables[0].Rows[index].ItemArray[5].ToString(),
                validity = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[6]),
                isMaintenance = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[7])
              };
              if (objtrd.validity == 3)
                objtrd.validity = 1;
              if (this._Symconctracts.ContainsKey(objtrd.Symbol))
              {
                Contracts symconctract = this._Symconctracts[objtrd.Symbol];
                this.SubcribeSymbol(objtrd.Symbol);
                if (!this._ExchFeedInstance.ContainsKey(Utils.GetExch(symconctract.exch)))
                  this.SubsribeExchFeeds(Utils.GetExch(symconctract.exch));
                Dashboard.ManageRMSPositions(ref _BuySellAvgPos, objtrd);
              }
            }
          }
        }
        catch
        {
        }
      }
      return dictionary;
    }

    public Dictionary<string, Dictionary<int, List<Trades>>> GetSymbolTimewiseTradePosition(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      string account,
      string symbol,
      DateTime timestamp,
      int postype)
    {
      Dictionary<string, Dictionary<int, List<Trades>>> dictionary = new Dictionary<string, Dictionary<int, List<Trades>>>();
      if (this.claccounts == null || this.claccounts.Length == 0)
        return dictionary;
      string cmdText = string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity from Trade T , Orders O where T.Clientcode in ({0}) and T.Symbol = '{1}' and T.OrderNo = O.OrderNo  ", (object) account, (object) symbol);
      using (DataSet dataSet = new DataSet())
      {
        try
        {
          using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter()
          {
            SelectCommand = new SqlCommand(cmdText, this.conn)
          })
          {
            sqlDataAdapter.Fill(dataSet);
            for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
            {
              Trades objtrd = new Trades()
              {
                Symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString(),
                qty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[1]),
                buysell = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2]),
                Lastmodified = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[3]),
                price = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[4]),
                clientcode = dataSet.Tables[0].Rows[index].ItemArray[5].ToString(),
                validity = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[6])
              };
              if (objtrd.validity == 3)
                objtrd.validity = 1;
              if ((!(objtrd.Lastmodified > timestamp) || objtrd.buysell != postype) && this._Symconctracts.ContainsKey(objtrd.Symbol))
              {
                Contracts symconctract = this._Symconctracts[objtrd.Symbol];
                this.SubcribeSymbol(objtrd.Symbol);
                if (!this._ExchFeedInstance.ContainsKey(Utils.GetExch(symconctract.exch)))
                  this.SubsribeExchFeeds(Utils.GetExch(symconctract.exch));
                Dashboard.ManagePositions(ref _BuySellAvgPos, objtrd);
              }
            }
          }
        }
        catch
        {
        }
      }
      return dictionary;
    }

    public static void ManagePositions(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      Trades objtrd)
    {
      string key = string.Format("{0}_{1}_{2}", (object) objtrd.Symbol, (object) objtrd.clientcode, (object) objtrd.validity);
      if (_BuySellAvgPos.ContainsKey(key))
      {
        buysellPos buysellPos = _BuySellAvgPos[key];
        if (objtrd.buysell == 1)
        {
          double num = (buysellPos.buyprice * (double) buysellPos.BQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.BQty + objtrd.qty);
          buysellPos.BQty += objtrd.qty;
          buysellPos.buyprice = Math.Round(num, 2);
        }
        else
        {
          double num = (buysellPos.sellprice * (double) buysellPos.SQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.SQty + objtrd.qty);
          buysellPos.SQty += objtrd.qty;
          buysellPos.sellprice = Math.Round(num, 2);
        }
        _BuySellAvgPos[key] = buysellPos;
      }
      else
      {
        buysellPos buysellPos = new buysellPos();
        buysellPos.symbol = objtrd.Symbol;
        if (objtrd.buysell == 1)
        {
          buysellPos.BQty = objtrd.qty;
          buysellPos.SQty = 0;
          buysellPos.buyprice = Convert.ToDouble(objtrd.price);
        }
        else
        {
          buysellPos.BQty = 0;
          buysellPos.SQty = objtrd.qty;
          buysellPos.sellprice = Convert.ToDouble(objtrd.price);
        }
        _BuySellAvgPos.Add(key, buysellPos);
      }
    }

    public static void ManageRMSPositions(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      Trades objtrd)
    {
      string key = string.Format("{0}_{1}_{2}_{3}", (object) objtrd.Symbol, (object) objtrd.clientcode, (object) objtrd.validity, (object) objtrd.isMaintenance);
      if (_BuySellAvgPos.ContainsKey(key))
      {
        buysellPos buysellPos = _BuySellAvgPos[key];
        if (objtrd.buysell == 1)
        {
          double num = (buysellPos.buyprice * (double) buysellPos.BQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.BQty + objtrd.qty);
          buysellPos.BQty += objtrd.qty;
          buysellPos.buyprice = Math.Round(num, 2);
          buysellPos.Ismaintaince = objtrd.isMaintenance;
        }
        else
        {
          double num = (buysellPos.sellprice * (double) buysellPos.SQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.SQty + objtrd.qty);
          buysellPos.SQty += objtrd.qty;
          buysellPos.sellprice = Math.Round(num, 2);
          buysellPos.Ismaintaince = objtrd.isMaintenance;
        }
        _BuySellAvgPos[key] = buysellPos;
      }
      else
      {
        buysellPos buysellPos = new buysellPos();
        buysellPos.symbol = objtrd.Symbol;
        if (objtrd.buysell == 1)
        {
          buysellPos.BQty = objtrd.qty;
          buysellPos.SQty = 0;
          buysellPos.buyprice = Convert.ToDouble(objtrd.price);
          buysellPos.Ismaintaince = objtrd.isMaintenance;
        }
        else
        {
          buysellPos.BQty = 0;
          buysellPos.SQty = objtrd.qty;
          buysellPos.sellprice = Convert.ToDouble(objtrd.price);
          buysellPos.Ismaintaince = objtrd.isMaintenance;
        }
        _BuySellAvgPos.Add(key, buysellPos);
      }
    }

    public Decimal GetTurnoverBrkg(Contracts objcon, Limits objlimits, int postype)
    {
      switch (objcon.exch)
      {
        case 1:
          return postype == 1 ? objlimits.mcxCnfbrkg : objlimits.mcxIntrdybrkg;
        case 2:
          return postype == 1 ? objlimits.nsefutCnfbrkg : objlimits.nsefutIntrdybrkg;
        case 3:
          return postype == 1 ? objlimits.ncdexCnfbrkg : objlimits.ncdexIntrdybrkg;
        case 4:
          return postype == 1 ? objlimits.nsecurrCnfbrkg : objlimits.nsecurrIntrdybrkg;
        case 5:
          return postype == 1 ? objlimits.nsefutCnfbrkg : objlimits.nsefutIntrdybrkg;
        default:
          return Decimal.Zero;
      }
    }

    public Dictionary<string, buysellnetpospfls> ProcessProfitLoss(
      Dictionary<string, buysellPos> _BuySellAvgPos)
    {
      this._NetProftLoss = new Dictionary<string, buysellnetpospfls>();
      foreach (KeyValuePair<string, buysellPos> buySellAvgPo in _BuySellAvgPos)
      {
        buysellnetpospfls buysellnetpospfls = new buysellnetpospfls();
        string key = buySellAvgPo.Key;
        string[] strArray = buySellAvgPo.Key.Split('_');
        string clientcode = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        buysellPos buysellPos = buySellAvgPo.Value;
        if (this._Symconctracts.ContainsKey(buysellPos.symbol))
        {
          Contracts symconctract = this._Symconctracts[buysellPos.symbol];
          SymbolMargin symbolMargin1 = new SymbolMargin();
          SymbolMargin symbolMargin2 = this.objinfo.usertype != 1 ? this.GetSymbolwiseMrgn(clientcode, symconctract.symbol) : this.symbolwisemrgn(clientcode, symconctract.symbol);
          Limits limits = this.GetLimits(clientcode);
          int brkgType = this.GetBrkgType(clientcode, symconctract.exch);
          Decimal turnoverBrkg = this.GetTurnoverBrkg(symconctract, limits, int32);
          int num1 = buysellPos.BQty + buysellPos.SQty;
          if (symconctract.exch == 2 || symconctract.exch == 5)
            num1 /= symconctract.lotsize;
          buysellnetpospfls.symbol = buysellPos.symbol;
          buysellnetpospfls.BQty = buysellPos.BQty;
          buysellnetpospfls.SQty = buysellPos.SQty;
          buysellnetpospfls.buyprice = Decimal.Round(Convert.ToDecimal(buysellPos.buyprice), 2);
          buysellnetpospfls.sellprice = Decimal.Round(Convert.ToDecimal(buysellPos.sellprice), 2);
          buysellnetpospfls.symbol.Split('(');
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.getFeed(symbol);
          if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
          {
            int num2 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
            int num3 = num2;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              num3 = num2 / symconctract.lotsize;
            Decimal num4 = feed.ltp - buysellnetpospfls.buyprice;
            if (feed.ltp > Decimal.Zero)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.UnrealisedP_l = num5 == 0 ? Decimal.Round(num4 * (Decimal) num2 * (Decimal) symconctract.lotsize, 2) : Decimal.Round(num4 * (Decimal) num2, 2);
            }
            buysellnetpospfls.buy_sell = 1;
            buysellnetpospfls.Qty = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.buyprice));
            else
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.buyprice) * (double) symconctract.lotsize);
            if (int32 == 1)
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.delvmrgn);
              if (brkgType == 2)
              {
                buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
              }
              else
              {
                if (buysellnetpospfls.SQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            else
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.intramrgn);
              if (brkgType == 2)
              {
                buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.intrabrkg);
              }
              else
              {
                if (buysellnetpospfls.SQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            if (buysellnetpospfls.SQty > 0)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.SQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.SQty, 2);
            }
          }
          else if (buysellnetpospfls.SQty > buysellnetpospfls.BQty)
          {
            int num2 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            int num3 = num2;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              num3 = num2 / symconctract.lotsize;
            Decimal num4 = buysellnetpospfls.sellprice - feed.ltp;
            if (feed.ltp > Decimal.Zero)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.UnrealisedP_l = num5 == 0 ? Decimal.Round(num4 * (Decimal) num2 * (Decimal) symconctract.lotsize, 2) : Decimal.Round(num4 * (Decimal) num2, 2);
            }
            buysellnetpospfls.buy_sell = 2;
            buysellnetpospfls.Qty = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.sellprice));
            else
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.sellprice) * (double) symconctract.lotsize);
            if (int32 == 1)
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.delvmrgn);
              if (brkgType == 2)
              {
                buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
              }
              else
              {
                if (buysellnetpospfls.BQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            else
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.intramrgn);
              if (brkgType == 2)
              {
                buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.intrabrkg);
              }
              else
              {
                if (buysellnetpospfls.BQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            if (buysellnetpospfls.BQty > 0)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty, 2);
            }
          }
          else
          {
            double num2 = Math.Round((Convert.ToDouble(buysellnetpospfls.buyprice) + Convert.ToDouble(buysellnetpospfls.sellprice)) / 2.0, 2);
            if (brkgType == 2)
            {
              buysellnetpospfls.Commision = int32 != 2 ? Convert.ToDecimal(num1 * symbolMargin2.intrabrkg) : Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
            }
            else
            {
              int num3 = buysellnetpospfls.BQty + buysellnetpospfls.SQty;
              int num4 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.Commision = num4 == 0 ? Decimal.Round((Decimal) num3 * Convert.ToDecimal(num2) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) num3 * Convert.ToDecimal(num2) * turnoverBrkg / new Decimal(100), 2);
            }
            int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
            buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty, 2);
          }
          try
          {
            if (!this._NetProftLoss.ContainsKey(key))
              this._NetProftLoss.Add(key, buysellnetpospfls);
          }
          catch
          {
          }
        }
      }
      return this._NetProftLoss;
    }

    public Dictionary<string, buysellnetpospfls> ProcessRMSProfitLoss(
      Dictionary<string, buysellPos> _BuySellAvgPos)
    {
      this._NetProftLossRMS = new Dictionary<string, buysellnetpospfls>();
      foreach (KeyValuePair<string, buysellPos> buySellAvgPo in _BuySellAvgPos)
      {
        buysellnetpospfls buysellnetpospfls = new buysellnetpospfls();
        string key = buySellAvgPo.Key;
        string[] strArray = buySellAvgPo.Key.Split('_');
        string clientcode = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        buysellPos buysellPos = buySellAvgPo.Value;
        if (this._Symconctracts.ContainsKey(buysellPos.symbol))
        {
          Contracts symconctract = this._Symconctracts[buysellPos.symbol];
          SymbolMargin symbolMargin1 = new SymbolMargin();
          SymbolMargin symbolMargin2 = this.objinfo.usertype != 1 ? this.GetSymbolwiseMrgn(clientcode, symconctract.symbol) : this.symbolwisemrgn(clientcode, symconctract.symbol);
          Limits limits = this.GetLimits(clientcode);
          int brkgType = this.GetBrkgType(clientcode, symconctract.exch);
          Decimal turnoverBrkg = this.GetTurnoverBrkg(symconctract, limits, int32);
          int num1 = buysellPos.BQty + buysellPos.SQty;
          if (symconctract.exch == 2 || symconctract.exch == 5)
            num1 /= symconctract.lotsize;
          buysellnetpospfls.symbol = buysellPos.symbol;
          buysellnetpospfls.BQty = buysellPos.BQty;
          buysellnetpospfls.SQty = buysellPos.SQty;
          buysellnetpospfls.buyprice = Decimal.Round(Convert.ToDecimal(buysellPos.buyprice), 2);
          buysellnetpospfls.sellprice = Decimal.Round(Convert.ToDecimal(buysellPos.sellprice), 2);
          buysellnetpospfls.symbol.Split('(');
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.getFeed(symbol);
          if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
          {
            int num2 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
            int num3 = num2;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              num3 = num2 / symconctract.lotsize;
            Decimal num4 = feed.ltp - buysellnetpospfls.buyprice;
            if (feed.ltp > Decimal.Zero)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.UnrealisedP_l = num5 == 0 ? Decimal.Round(num4 * (Decimal) num2 * (Decimal) symconctract.lotsize, 2) : Decimal.Round(num4 * (Decimal) num2, 2);
            }
            buysellnetpospfls.buy_sell = 1;
            buysellnetpospfls.Qty = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.buyprice));
            else
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.buyprice) * (double) symconctract.lotsize);
            if (int32 == 1)
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.delvmrgn);
              if (buysellPos.Ismaintaince == 0)
              {
                if (brkgType == 2)
                {
                  buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
                }
                else
                {
                  if (buysellnetpospfls.SQty > 0)
                  {
                    int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                    buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                  }
                  if (symconctract.exch == 2 || symconctract.exch == 5)
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                  else
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
                }
              }
            }
            else
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.intramrgn);
              if (buysellPos.Ismaintaince == 0)
              {
                if (brkgType == 2)
                {
                  buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
                }
                else
                {
                  if (buysellnetpospfls.SQty > 0)
                  {
                    int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                    buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                  }
                  if (symconctract.exch == 2 || symconctract.exch == 5)
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                  else
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
                }
              }
            }
            if (buysellnetpospfls.SQty > 0)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.SQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.SQty, 2);
            }
          }
          else if (buysellnetpospfls.SQty > buysellnetpospfls.BQty)
          {
            int num2 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            int num3 = num2;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              num3 = num2 / symconctract.lotsize;
            Decimal num4 = buysellnetpospfls.sellprice - feed.ltp;
            if (feed.ltp > Decimal.Zero)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.UnrealisedP_l = num5 == 0 ? Decimal.Round(num4 * (Decimal) num2 * (Decimal) symconctract.lotsize, 2) : Decimal.Round(num4 * (Decimal) num2, 2);
            }
            buysellnetpospfls.buy_sell = 2;
            buysellnetpospfls.Qty = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.sellprice));
            else
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num2 * Convert.ToDouble(buysellnetpospfls.sellprice) * (double) symconctract.lotsize);
            if (int32 == 1)
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.delvmrgn);
              if (buysellPos.Ismaintaince == 0)
              {
                if (brkgType == 2)
                {
                  buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
                }
                else
                {
                  if (buysellnetpospfls.SQty > 0)
                  {
                    int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                    buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                  }
                  if (symconctract.exch == 2 || symconctract.exch == 5)
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                  else
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
                }
              }
            }
            else
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolMargin2.intramrgn);
              if (buysellPos.Ismaintaince == 0)
              {
                if (brkgType == 2)
                {
                  buysellnetpospfls.Commision = Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
                }
                else
                {
                  if (buysellnetpospfls.SQty > 0)
                  {
                    int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                    buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellnetpospfls.SQty * buysellnetpospfls.sellprice * turnoverBrkg / new Decimal(100), 2);
                  }
                  if (symconctract.exch == 2 || symconctract.exch == 5)
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * turnoverBrkg / new Decimal(100), 2);
                  else
                    buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellnetpospfls.BQty * buysellnetpospfls.buyprice * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
                }
              }
            }
            if (buysellnetpospfls.BQty > 0)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty, 2);
            }
          }
          else
          {
            double num2 = Math.Round((Convert.ToDouble(buysellnetpospfls.buyprice) + Convert.ToDouble(buysellnetpospfls.sellprice)) / 2.0, 2);
            if (buysellPos.Ismaintaince == 0)
            {
              if (brkgType == 2)
              {
                buysellnetpospfls.Commision = int32 != 2 ? Convert.ToDecimal(num1 * symbolMargin2.intrabrkg) : Convert.ToDecimal(num1 * symbolMargin2.delvbrkg);
              }
              else
              {
                int num3 = buysellnetpospfls.BQty + buysellnetpospfls.SQty;
                int num4 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                buysellnetpospfls.Commision = num4 == 0 ? Decimal.Round((Decimal) num3 * Convert.ToDecimal(num2) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) num3 * Convert.ToDecimal(num2) * turnoverBrkg / new Decimal(100), 2);
              }
            }
            int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
            buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty, 2);
          }
          try
          {
            if (!this._NetProftLossRMS.ContainsKey(key))
              this._NetProftLossRMS.Add(key, buysellnetpospfls);
          }
          catch
          {
          }
        }
      }
      return this._NetProftLossRMS;
    }

    private void LedgerMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 4 && this.objinfo.usertype != 3)
          return;
        if (this.objledger == null || this.objledger.IsDisposed)
        {
          frmLedger frmLedger = new frmLedger(this);
          frmLedger.MdiParent = (Form) this;
          this.objledger = frmLedger;
          this.objledger.Loadwindow();
          this.objledger.Show();
        }
        else
        {
          this.objledger.MdiParent = (Form) this;
          this.objledger.Loadwindow();
          this.objledger.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public Contracts GetContract(string symbol)
    {
      if (this._Symconctracts.ContainsKey(symbol))
        return this._Symconctracts[symbol];
      return this._ContractsHistory.ContainsKey(symbol) ? this._ContractsHistory[symbol] : new Contracts();
    }

    public Limits GetLimits(string clientcode)
    {
      return this._ClientLimits.ContainsKey(clientcode) ? this._ClientLimits[clientcode] : new Limits();
    }

    public Userinfo GetUserinfo(string clientcode)
    {
      return this._Userinformation.ContainsKey(clientcode) ? this._Userinformation[clientcode] : this.objinfo;
    }

    private void lstMsgboard_DrawItem(object sender, DrawItemEventArgs e)
    {
      if (e.Index <= -1)
        return;
      e.DrawBackground();
      Brush red = Brushes.Red;
      Brush blue = Brushes.Blue;
      Brush green = Brushes.Green;
      if (this.lstMsgboard.Items[e.Index].ToString().ToLower().IndexOf("buy") > -1 || this.lstMsgboard.Items[e.Index].ToString().ToLower().IndexOf("bought") > -1)
      {
        Font font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
        e.Graphics.DrawString(this.lstMsgboard.Items[e.Index].ToString(), font, blue, (RectangleF) e.Bounds, StringFormat.GenericDefault);
        e.DrawFocusRectangle();
      }
      else if (this.lstMsgboard.Items[e.Index].ToString().ToLower().IndexOf("sell") > -1 || this.lstMsgboard.Items[e.Index].ToString().ToLower().IndexOf("sold") > -1)
      {
        Font font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
        e.Graphics.DrawString(this.lstMsgboard.Items[e.Index].ToString(), font, red, (RectangleF) e.Bounds, StringFormat.GenericDefault);
        e.DrawFocusRectangle();
      }
      else if (this.lstMsgboard.Items[e.Index].ToString().ToLower().IndexOf("admin") > -1)
      {
        Font font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
        e.Graphics.DrawString(this.lstMsgboard.Items[e.Index].ToString(), font, green, (RectangleF) e.Bounds, StringFormat.GenericDefault);
        e.DrawFocusRectangle();
      }
      else
      {
        Brush black = Brushes.Black;
        Font font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
        e.Graphics.DrawString(this.lstMsgboard.Items[e.Index].ToString(), font, black, (RectangleF) e.Bounds, StringFormat.GenericDefault);
        e.DrawFocusRectangle();
      }
    }

    private void toolStripRMSView_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3)
          return;
        if (this.objRMS == null || this.objRMS.IsDisposed)
        {
          RMSClientwise rmsClientwise = new RMSClientwise(this);
          rmsClientwise.MdiParent = (Form) this;
          this.objRMS = rmsClientwise;
          this.objRMS.LoadRMS();
          this.objRMS.Show();
        }
        else
        {
          this.objRMS.LoadRMS();
          this.objRMS.MdiParent = (Form) this;
          this.objRMS.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripOrders_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2 && this.objinfo.usertype != 1)
          return;
        if (this.objRTordbook == null || this.objRTordbook.IsDisposed)
        {
          frmRTOrderBook frmRtOrderBook = new frmRTOrderBook(this);
          frmRtOrderBook.MdiParent = (Form) this;
          this.objRTordbook = frmRtOrderBook;
          this.objRTordbook.LoadWindow();
          this.objRTordbook.Show();
        }
        else
        {
          this.objRTordbook.LoadWindow();
          this.objRTordbook.MdiParent = (Form) this;
          this.objRTordbook.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripTrades_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2 && this.objinfo.usertype != 1)
          return;
        if (this.objrttrdbook == null || this.objrttrdbook.IsDisposed)
        {
          frmRTTrades frmRtTrades = new frmRTTrades(this);
          frmRtTrades.MdiParent = (Form) this;
          this.objrttrdbook = frmRtTrades;
          this.objrttrdbook.LoadTrades();
          this.objrttrdbook.Show();
        }
        else
        {
          this.objrttrdbook.LoadTrades();
          this.objrttrdbook.MdiParent = (Form) this;
          this.objrttrdbook.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripSLTrades_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2 && this.objinfo.usertype != 1)
          return;
        if (this.objRTSLtradebook == null || this.objRTSLtradebook.IsDisposed)
        {
          frmRTSLTrades frmRtslTrades = new frmRTSLTrades(this);
          frmRtslTrades.MdiParent = (Form) this;
          this.objRTSLtradebook = frmRtslTrades;
          this.objRTSLtradebook.LoadWindow();
          this.objRTSLtradebook.Show();
        }
        else
        {
          this.objRTSLtradebook.LoadWindow();
          this.objRTSLtradebook.MdiParent = (Form) this;
          this.objRTSLtradebook.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void IntraDataHistoryMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objDataHistory == null || this.objDataHistory.IsDisposed)
        {
          frmIntraHistory frmIntraHistory = new frmIntraHistory(this);
          frmIntraHistory.MdiParent = (Form) this;
          this.objDataHistory = frmIntraHistory;
          this.objDataHistory.LoadControls();
          this.objDataHistory.Show();
        }
        else
        {
          this.objDataHistory.LoadControls();
          this.objDataHistory.MdiParent = (Form) this;
          this.objDataHistory.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripPositivePos_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objPositivePos == null || this.objPositivePos.IsDisposed)
        {
          frmPosGoinLive frmPosGoinLive = new frmPosGoinLive(this);
          frmPosGoinLive.MdiParent = (Form) this;
          this.objPositivePos = frmPosGoinLive;
          this.objPositivePos.Loadwindow();
          this.objPositivePos.Show();
        }
        else
        {
          this.objPositivePos.Loadwindow();
          this.objPositivePos.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripMenuItem1_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype == 3 || this.objinfo.usertype == 4)
        {
          if (this.objShortKeys == null || this.objShortKeys.IsDisposed)
          {
            frmShortcutKeys frmShortcutKeys = new frmShortcutKeys(this);
            frmShortcutKeys.MdiParent = (Form) this;
            this.objShortKeys = frmShortcutKeys;
            this.objShortKeys.Show();
          }
          else
            this.objShortKeys.Show();
        }
        else
        {
          if (this.objinfo.usertype != 2)
            return;
          if (this.objDAShorcutKeys == null || this.objDAShorcutKeys.IsDisposed)
          {
            frmShortcutKeyDA frmShortcutKeyDa = new frmShortcutKeyDA(this);
            frmShortcutKeyDa.MdiParent = (Form) this;
            this.objDAShorcutKeys = frmShortcutKeyDa;
            this.objDAShorcutKeys.Show();
          }
          else
            this.objDAShorcutKeys.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void MaintenanceMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 1)
          return;
        if (this.objmaintenance == null || this.objmaintenance.IsDisposed)
        {
          Maintenance maintenance = new Maintenance(this);
          maintenance.MdiParent = (Form) this;
          this.objmaintenance = maintenance;
          this.objmaintenance.LoadMaintenance();
          this.objmaintenance.Show();
        }
        else
        {
          this.objmaintenance.LoadMaintenance();
          this.objmaintenance.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripBlastSystem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objBlast == null || this.objBlast.IsDisposed)
        {
          frmBlastSystem frmBlastSystem = new frmBlastSystem(this);
          frmBlastSystem.MdiParent = (Form) this;
          this.objBlast = frmBlastSystem;
          this.objBlast.Show();
        }
        else
          this.objBlast.Show();
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripSymSearch_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objsymSearch == null || this.objsymSearch.IsDisposed)
        {
          frmFeedSearch frmFeedSearch = new frmFeedSearch(this);
          frmFeedSearch.MdiParent = (Form) this;
          this.objsymSearch = frmFeedSearch;
          this.objsymSearch.LoadWindow();
          this.objsymSearch.Show();
        }
        else
        {
          this.objsymSearch.LoadWindow();
          this.objsymSearch.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public static void PlaySound(int flag)
    {
      try
      {
        if (flag == 1)
        {
          using (SoundPlayer soundPlayer = new SoundPlayer(Application.StartupPath + "\\sounds\\OrderOk.wav"))
            soundPlayer.Play();
        }
        else
        {
          using (SoundPlayer soundPlayer = new SoundPlayer(Application.StartupPath + "\\sounds\\notify.wav"))
            soundPlayer.Play();
        }
      }
      catch
      {
      }
    }

    private void btnRefreshData_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.AutoContracts())).Invoke)).Start();
    }

    private void toolStrpMnuSpeedCntrl_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objspeedcontrol == null || this.objspeedcontrol.IsDisposed)
        {
          frmSpeedControl frmSpeedControl = new frmSpeedControl();
          frmSpeedControl.MdiParent = (Form) this;
          this.objspeedcontrol = frmSpeedControl;
          this.objspeedcontrol.Show();
        }
        else
        {
          this.objspeedcontrol.MdiParent = (Form) this;
          this.objspeedcontrol.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void btnReconnectFeeds_Click(object sender, EventArgs e)
    {
      this.isReconnectFeeds = true;
      if (!this._ExchFeedInstance.ContainsKey("MCX"))
        ;
      Thread.Sleep(250);
      this.lastNcdexid = this.GetMaxID(2);
      Thread.Sleep(250);
      this.lastNsecurid = this.GetMaxID(3);
      Thread.Sleep(250);
      this.lastNsefutid = this.GetMaxID(4);
      Thread.Sleep(250);
      this.lastNseoptid = this.GetMaxID(5);
      Thread.Sleep(250);
      this.lastNseoptid = this.GetMaxID(6);
      Thread.Sleep(250);
      this.isReconnectFeeds = false;
    }

    private void ChkUpdatesMenuItem_Click(object sender, EventArgs e)
    {
    }

    public Feeds GetDBFeed(string symbol)
    {
      if (this.feedconn.State == ConnectionState.Closed)
        this.feedconn = this.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,0,GetDate(),Volume,OI  from MarketView where Description = '" + symbol + "'", this.feedconn))
      {
        using (SqlDataReader reader = sqlCommand.ExecuteReader())
        {
          if (reader.Read())
            return this.GetMarketData(reader, false);
        }
      }
      return new Feeds();
    }

    public Dictionary<string, Ledger> GetLedger(
      string accounts,
      string startdate,
      string endate)
    {
      return this.ProcessLedgerPosition(this.GetHistoryTradePosition(accounts, startdate, endate, false));
    }

    public Dictionary<string, LedgerAVG> GetLedgerAVG(
      string accounts,
      string startdate,
      string endate)
    {
      return this.ProcessLedgerPositionAVG(this.GetHistoryTradePositionAVG(accounts, startdate, endate, false));
    }

    public Dictionary<string, Ledger> GetIntraLedger(
      string accounts,
      string startdate,
      string endate)
    {
      return this.ProcessLedgerPosition(this.GetHistoryTradePosition(accounts, startdate, endate, true));
    }

    private Dictionary<string, Dictionary<int, List<Trades>>> GetHistoryTradePosition(
      string accountno,
      string startdate,
      string enddate,
      bool isintra)
    {
      Dictionary<string, Dictionary<int, List<Trades>>> _BuySellAvgPos = new Dictionary<string, Dictionary<int, List<Trades>>>();
      if (accountno.Length > 0)
      {
        string cmdText = string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.ClientCode,O.Validity,T.Orderno from Trade_History T, Orders_History O where T.ClientCode in ('{0}') and T.OrderNo = O.OrderNo and T.Timestamp between '{1}' and '{2}' order by T.Timestamp ", (object) accountno, (object) startdate, (object) enddate);
        if (isintra)
          cmdText = string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.ClientCode,O.Validity,T.Orderno from Trade T, Orders O where T.ClientCode in ('{0}') and T.OrderNo = O.OrderNo and T.Timestamp between '{1}' and '{2}' order by T.Timestamp ", (object) accountno, (object) startdate, (object) enddate);
        using (DataSet dataSet = new DataSet())
        {
          try
          {
            using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter()
            {
              SelectCommand = new SqlCommand(cmdText, this.conn)
            })
            {
              sqlDataAdapter.Fill(dataSet);
              for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
              {
                Trades objtrade = new Trades()
                {
                  Symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString(),
                  qty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[1]),
                  buysell = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2]),
                  Lastmodified = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[3]),
                  price = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[4]),
                  clientcode = dataSet.Tables[0].Rows[index].ItemArray[5].ToString(),
                  validity = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[6]),
                  orderno = Convert.ToDouble(dataSet.Tables[0].Rows[index].ItemArray[7])
                };
                if (objtrade.validity == 3)
                  objtrade.validity = 2;
                if (this._Symconctracts.ContainsKey(objtrade.Symbol))
                  this.SubcribeSymbol(this._Symconctracts[objtrade.Symbol].SymDesp);
                this.ManageLedgerPos(ref _BuySellAvgPos, objtrade);
              }
            }
          }
          catch
          {
          }
        }
      }
      return _BuySellAvgPos;
    }

    private Dictionary<string, Dictionary<int, List<Proftloss>>> GetHistoryTradePositionAVG(
      string accountno,
      string startdate,
      string enddate,
      bool isintra)
    {
      Dictionary<string, Dictionary<int, List<Proftloss>>> _BuySellAvgPos = new Dictionary<string, Dictionary<int, List<Proftloss>>>();
      if (accountno.Length > 0)
      {
        string cmdText = string.Format("Select Symbol,BQty,Sqty,TimeStamp,BAvgPrice,SAvgPrice,ClientCode,Validity,RealisedPL,Brkg,NetMTMPL from Profit_Loss_Archive where ClientCode in ('{0}') and  Timestamp between '{1}' and '{2}' order by Timestamp", (object) accountno, (object) startdate, (object) enddate);
        using (DataSet dataSet = new DataSet())
        {
          try
          {
            using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter()
            {
              SelectCommand = new SqlCommand(cmdText, this.conn)
            })
            {
              sqlDataAdapter.Fill(dataSet);
              for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
              {
                Proftloss objtrade = new Proftloss()
                {
                  Symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString(),
                  Bqty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[1]),
                  Sqty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2]),
                  timestamp = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[3]),
                  Bavgprice = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[4]),
                  Savgprice = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[5]),
                  clientcode = dataSet.Tables[0].Rows[index].ItemArray[6].ToString(),
                  validity = dataSet.Tables[0].Rows[index].ItemArray[7].ToString(),
                  RealisedPL = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[8]),
                  Brkg = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[9]),
                  NetMTMPL = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[10])
                };
                if (this._Symconctracts.ContainsKey(objtrade.Symbol))
                  this.SubcribeSymbol(this._Symconctracts[objtrade.Symbol].SymDesp);
                this.ManageLedgerPosAVG(ref _BuySellAvgPos, objtrade);
              }
            }
          }
          catch
          {
          }
        }
      }
      return _BuySellAvgPos;
    }

    private void ManageLedgerPos(
      ref Dictionary<string, Dictionary<int, List<Trades>>> _BuySellAvgPos,
      Trades objtrade)
    {
      string key = string.Format("{0}_{1}_{2}", (object) objtrade.Symbol, (object) objtrade.clientcode, (object) objtrade.validity);
      if (!_BuySellAvgPos.ContainsKey(key))
      {
        _BuySellAvgPos.Add(key, new Dictionary<int, List<Trades>>()
        {
          {
            objtrade.buysell,
            new List<Trades>() { objtrade }
          }
        });
      }
      else
      {
        Dictionary<int, List<Trades>> dictionary = _BuySellAvgPos[key];
        if (dictionary.ContainsKey(objtrade.buysell))
        {
          List<Trades> tradesList = dictionary[objtrade.buysell];
          tradesList.Add(objtrade);
          dictionary[objtrade.buysell] = tradesList;
        }
        else
          dictionary.Add(objtrade.buysell, new List<Trades>()
          {
            objtrade
          });
        _BuySellAvgPos[key] = dictionary;
      }
    }

    private void ManageLedgerPosAVG(
      ref Dictionary<string, Dictionary<int, List<Proftloss>>> _BuySellAvgPos,
      Proftloss objtrade)
    {
      string key = string.Format("{0}_{1}_{2}", (object) objtrade.Symbol, (object) objtrade.clientcode, (object) objtrade.validity);
      if (!_BuySellAvgPos.ContainsKey(key))
      {
        _BuySellAvgPos.Add(key, new Dictionary<int, List<Proftloss>>()
        {
          {
            objtrade.buysell,
            new List<Proftloss>() { objtrade }
          }
        });
      }
      else
      {
        Dictionary<int, List<Proftloss>> dictionary = _BuySellAvgPos[key];
        if (dictionary.ContainsKey(objtrade.buysell))
        {
          List<Proftloss> proftlossList = dictionary[objtrade.buysell];
          proftlossList.Add(objtrade);
          dictionary[objtrade.buysell] = proftlossList;
        }
        else
          dictionary.Add(objtrade.buysell, new List<Proftloss>()
          {
            objtrade
          });
        _BuySellAvgPos[key] = dictionary;
      }
    }

    private Dictionary<string, Ledger> ProcessLedgerPosition(
      Dictionary<string, Dictionary<int, List<Trades>>> _BuySellAvgPos)
    {
      Dictionary<string, Ledger> dictionary1 = new Dictionary<string, Ledger>();
      int num1 = 0;
      using (Dictionary<string, Dictionary<int, List<Trades>>>.Enumerator enumerator = _BuySellAvgPos.GetEnumerator())
      {
label_108:
        while (enumerator.MoveNext())
        {
          KeyValuePair<string, Dictionary<int, List<Trades>>> current = enumerator.Current;
          string[] strArray = current.Key.Split('_');
          string key1 = strArray[0];
          string index = strArray[1];
          int int32 = Convert.ToInt32(strArray[2]);
          Dictionary<int, List<Trades>> dictionary2 = current.Value;
          List<Trades> tradesList1 = new List<Trades>();
          if (dictionary2.ContainsKey(1))
          {
            List<Trades> tradesList2 = dictionary2[1];
            List<Trades> tradesList3 = new List<Trades>();
            if (dictionary2.ContainsKey(2))
            {
              List<Trades> tradesList4 = dictionary2[2];
              while (true)
              {
                if (tradesList2.Count > 0 && tradesList4.Count > 0)
                {
                  Ledger ledger = new Ledger();
                  Trades trades1 = tradesList2[0];
                  Trades trades2 = tradesList4[0];
                  if (trades1.qty > trades2.qty)
                  {
                    ledger.buyqty = trades2.qty;
                    ledger.sellqty = trades2.qty;
                    ledger.buyprice = Convert.ToDouble(trades1.price);
                    ledger.sellprice = Convert.ToDouble(trades2.price);
                    trades1.qty -= trades2.qty;
                    trades2.qty = 0;
                    tradesList2[0] = trades1;
                    tradesList4.RemoveAt(0);
                  }
                  else if (trades1.qty < trades2.qty)
                  {
                    ledger.buyqty = trades1.qty;
                    ledger.sellqty = trades1.qty;
                    ledger.buyprice = Convert.ToDouble(trades1.price);
                    ledger.sellprice = Convert.ToDouble(trades2.price);
                    trades2.qty -= trades1.qty;
                    trades1.qty = 0;
                    tradesList4[0] = trades2;
                    tradesList2.RemoveAt(0);
                  }
                  else
                  {
                    ledger.buyqty = trades1.qty;
                    ledger.sellqty = trades2.qty;
                    ledger.buyprice = Convert.ToDouble(trades1.price);
                    ledger.sellprice = Convert.ToDouble(trades2.price);
                    tradesList2.RemoveAt(0);
                    tradesList4.RemoveAt(0);
                  }
                  ledger.symbol = key1;
                  ledger.accountno = index;
                  if (trades1.Lastmodified > trades2.Lastmodified)
                  {
                    ledger.orderno = trades1.qty >= trades2.qty ? trades1.orderno : trades2.orderno;
                    if (trades1.Lastmodified.Hour == 23 && trades1.Lastmodified.Minute == 55 && trades1.Lastmodified.Second == 0)
                      ledger.orderno = trades2.orderno;
                    ledger.OpenTime = trades2.Lastmodified;
                    ledger.CloseTime = trades1.Lastmodified;
                  }
                  else
                  {
                    ledger.orderno = trades1.qty >= trades2.qty ? trades2.orderno : trades1.orderno;
                    if (trades1.Lastmodified.Hour == 23 && trades1.Lastmodified.Minute == 55 && trades1.Lastmodified.Second == 0)
                      ledger.orderno = trades1.orderno;
                    ledger.OpenTime = trades1.Lastmodified;
                    ledger.CloseTime = trades2.Lastmodified;
                  }
                  try
                  {
                    if (this._ClientLimits.ContainsKey(index))
                    {
                      Contracts contracts = new Contracts();
                      Contracts symconctract;
                      if (this._Symconctracts.ContainsKey(key1))
                        symconctract = this._Symconctracts[key1];
                      else if (this._ContractsHistory.ContainsKey(key1))
                        symconctract = this._ContractsHistory[key1];
                      else
                        continue;
                      Limits clientLimit = this._ClientLimits[index];
                      Decimal turnoverBrkg = this.GetTurnoverBrkg(symconctract, clientLimit, int32);
                      int brkgType = this.GetBrkgType(clientLimit.clientcode, symconctract.exch);
                      SymbolMargin symbolMargin1 = new SymbolMargin();
                      SymbolMargin symbolMargin2 = this.objinfo.usertype != 1 ? this.GetSymbolwiseMrgn(index, symconctract.symbol) : this.symbolwisemrgn(index, symconctract.symbol);
                      if (ledger.buyqty == ledger.sellqty)
                      {
                        if (ledger.CloseTime.Day == symconctract.expiry.Day && ledger.CloseTime.Month == symconctract.expiry.Month || (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (ledger.OpenTime.Second != 0 || ledger.CloseTime.Hour != 23) || (ledger.CloseTime.Minute != 55 || ledger.CloseTime.Second != 0)) && ledger.OpenTime.Day == ledger.CloseTime.Day)
                        {
                          int num2 = ledger.buyqty + ledger.sellqty;
                          double num3 = Math.Round(ledger.sellprice - ledger.buyprice, 2);
                          double num4 = Math.Round(num3 * (double) symconctract.lotsize * (double) ledger.buyqty, 2);
                          if (symconctract.exch == 2)
                            num4 = Math.Round(num3 * (double) ledger.buyqty, 2);
                          Decimal num5 = new Decimal();
                          if (ledger.CloseTime.Day == symconctract.expiry.Day && ledger.CloseTime.Month == symconctract.expiry.Month || (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (ledger.OpenTime.Second != 0 || ledger.CloseTime.Hour != 23) || (ledger.CloseTime.Minute != 55 || ledger.CloseTime.Second != 0)) && ledger.OpenTime.Day == ledger.CloseTime.Day)
                          {
                            if (brkgType == 2)
                            {
                              if (symconctract.exch == 2 || symconctract.exch == 5)
                              {
                                if (this.objinfo.oddlot == 0)
                                {
                                  if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                                    num5 = int32 != 1 ? (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.intrabrkg * 2) : (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.delvbrkg);
                                  if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                                    num5 = int32 != 1 ? (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.intrabrkg * 2) : (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.delvbrkg);
                                  if (ledger.CloseTime.Day == symconctract.expiry.Day && ledger.CloseTime.Month == symconctract.expiry.Month && (ledger.CloseTime.Hour == 23 && ledger.CloseTime.Minute == 55 && ledger.CloseTime.Second == 0))
                                    num5 = int32 != 1 ? (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.intrabrkg * 2) : (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.delvbrkg);
                                }
                                else
                                  num5 = new Decimal();
                              }
                              else
                              {
                                if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                                  num5 = int32 != 1 ? (Decimal) (ledger.buyqty * symbolMargin2.intrabrkg * 2) : (Decimal) (ledger.buyqty * symbolMargin2.delvbrkg);
                                if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                                {
                                  if (int32 == 1)
                                    num5 += (Decimal) (ledger.sellqty * symbolMargin2.delvbrkg);
                                  else
                                    num5 = (Decimal) (ledger.buyqty * symbolMargin2.intrabrkg * 2);
                                }
                                if (ledger.CloseTime.Day == symconctract.expiry.Day && ledger.CloseTime.Month == symconctract.expiry.Month && (ledger.CloseTime.Hour == 23 && ledger.CloseTime.Minute == 55 && ledger.CloseTime.Second == 0))
                                {
                                  if (int32 == 1)
                                    num5 += (Decimal) (ledger.sellqty * symbolMargin2.delvbrkg);
                                  else
                                    num5 = (Decimal) (ledger.buyqty * symbolMargin2.intrabrkg);
                                }
                              }
                            }
                            else if (symconctract.exch == 2 || symconctract.exch == 5)
                            {
                              if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                                num5 = int32 != 1 ? Decimal.Round((Decimal) ledger.buyqty * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) ledger.sellqty * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) ledger.buyqty * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2);
                              if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                              {
                                if (int32 == 1)
                                  num5 += Decimal.Round((Decimal) ledger.sellqty * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                                else
                                  num5 = Decimal.Round((Decimal) ledger.buyqty * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) ledger.sellqty * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                              }
                              if (ledger.CloseTime.Day == symconctract.expiry.Day && ledger.CloseTime.Month == symconctract.expiry.Month && (ledger.CloseTime.Hour == 23 && ledger.CloseTime.Minute == 55 && ledger.CloseTime.Second == 0))
                                num5 += Decimal.Round((Decimal) ledger.sellqty * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                            }
                            else
                            {
                              if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                                num5 = int32 != 1 ? Decimal.Round((Decimal) (ledger.buyqty * symconctract.lotsize) * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) (ledger.sellqty * symconctract.lotsize) * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) (ledger.buyqty * symconctract.lotsize) * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2);
                              if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                              {
                                if (int32 == 1)
                                  num5 += Decimal.Round((Decimal) (ledger.sellqty * symconctract.lotsize) * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                                else
                                  num5 = Decimal.Round((Decimal) (ledger.buyqty * symconctract.lotsize) * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) (ledger.sellqty * symconctract.lotsize) * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                              }
                              if (ledger.CloseTime.Day == symconctract.expiry.Day && ledger.CloseTime.Month == symconctract.expiry.Month && (ledger.CloseTime.Hour == 23 && ledger.CloseTime.Minute == 55 && ledger.CloseTime.Second == 0))
                                num5 += Decimal.Round((Decimal) (ledger.sellqty * symconctract.lotsize) * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                            }
                          }
                          ledger.comm = num5;
                          ledger.profitLoss = num4;
                          ledger.NettPl = Decimal.Round(Convert.ToDecimal(num4) - num5, 2);
                        }
                        else
                        {
                          int num2 = ledger.buyqty + ledger.sellqty;
                          double num3 = Math.Round(ledger.sellprice - ledger.buyprice, 2);
                          double num4 = Math.Round(num3 * (double) symconctract.lotsize * (double) ledger.buyqty, 2);
                          if (symconctract.exch == 2)
                            num4 = Math.Round(num3 * (double) ledger.buyqty, 2);
                          Decimal num5 = new Decimal();
                          if (brkgType == 2)
                          {
                            if (symconctract.exch == 2 || symconctract.exch == 5)
                            {
                              if (this.objinfo.oddlot == 0)
                              {
                                if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                                  num5 = (Decimal) (ledger.buyqty / symconctract.lotsize * symbolMargin2.delvbrkg);
                                if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                                {
                                  int num6 = ledger.sellqty / symconctract.lotsize;
                                  num5 += (Decimal) (num6 * symbolMargin2.delvbrkg);
                                }
                              }
                              else
                                num5 = new Decimal();
                            }
                            else
                            {
                              if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                                num5 = (Decimal) (ledger.buyqty * symbolMargin2.delvbrkg);
                              if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                                num5 += (Decimal) (ledger.sellqty * symbolMargin2.delvbrkg);
                            }
                          }
                          else if (symconctract.exch == 2 || symconctract.exch == 5)
                          {
                            if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                              num5 = Decimal.Round((Decimal) ledger.buyqty * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2);
                            if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                              num5 += Decimal.Round((Decimal) ledger.sellqty * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                          }
                          else
                          {
                            if (ledger.OpenTime.Hour != 9 || ledger.OpenTime.Minute != 0 || (uint) ledger.OpenTime.Second > 0U)
                              num5 = Decimal.Round((Decimal) (ledger.buyqty * symconctract.lotsize) * Convert.ToDecimal(ledger.buyprice) * turnoverBrkg / new Decimal(100), 2);
                            if (ledger.CloseTime.Hour != 23 || ledger.CloseTime.Minute != 55 || (uint) ledger.CloseTime.Second > 0U)
                              num5 += Decimal.Round((Decimal) (ledger.sellqty * symconctract.lotsize) * Convert.ToDecimal(ledger.sellprice) * turnoverBrkg / new Decimal(100), 2);
                          }
                          int num7 = ledger.OpenTime.Hour == 9 && ledger.OpenTime.Minute == 0 && ledger.OpenTime.Second == 0 || ledger.CloseTime.Hour == 23 && ledger.CloseTime.Minute == 55 && ledger.CloseTime.Second == 0 ? (ledger.OpenTime.Day == ledger.CloseTime.Day ? 1 : 0) : 0;
                          ledger.comm = num7 == 0 ? num5 : new Decimal();
                          ledger.profitLoss = num4;
                          ledger.NettPl = Decimal.Round(Convert.ToDecimal(num4) - ledger.comm, 2);
                        }
                      }
                      string key2 = string.Format("{0}_{1}_{2}", (object) ledger.symbol, (object) ledger.orderno, (object) num1);
                      if (!dictionary1.ContainsKey(key2))
                        dictionary1.Add(key2, ledger);
                      ++num1;
                    }
                  }
                  catch
                  {
                  }
                }
                else
                  goto label_108;
              }
            }
          }
        }
      }
      return dictionary1;
    }

    private Dictionary<string, LedgerAVG> ProcessLedgerPositionAVG(
      Dictionary<string, Dictionary<int, List<Proftloss>>> _BuySellAvgPos)
    {
      Dictionary<string, LedgerAVG> dictionary = new Dictionary<string, LedgerAVG>();
      int num = 0;
      foreach (KeyValuePair<string, Dictionary<int, List<Proftloss>>> buySellAvgPo in _BuySellAvgPos)
      {
        string[] strArray = buySellAvgPo.Key.Split('_');
        string str1 = strArray[0];
        string str2 = strArray[1];
        strArray[2].ToString();
        foreach (KeyValuePair<int, List<Proftloss>> keyValuePair in buySellAvgPo.Value)
        {
          foreach (Proftloss proftloss in keyValuePair.Value)
          {
            LedgerAVG ledgerAvg = new LedgerAVG();
            ledgerAvg.accountno = proftloss.clientcode;
            ledgerAvg.buyprice = Convert.ToDouble(proftloss.Bavgprice);
            ledgerAvg.sellprice = Convert.ToDouble(proftloss.Savgprice);
            ledgerAvg.buyqty = proftloss.Bqty;
            ledgerAvg.sellqty = proftloss.Sqty;
            ledgerAvg.CloseTime = proftloss.timestamp;
            ledgerAvg.symbol = proftloss.Symbol;
            ledgerAvg.RealisedPL = proftloss.RealisedPL;
            ledgerAvg.comm = proftloss.Brkg;
            ledgerAvg.NettPl = proftloss.NetMTMPL;
            string key = string.Format("{0}_{1}_{2}", (object) ledgerAvg.symbol, (object) proftloss.validity.Trim(), (object) num);
            if (!dictionary.ContainsKey(key))
              dictionary.Add(key, ledgerAvg);
            ++num;
          }
        }
      }
      return dictionary;
    }

    private void insertModifyOrdersTradesToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3)
          return;
        if (this.objmodordtrd == null || this.objmodordtrd.IsDisposed)
        {
          ModifyOrderTrade modifyOrderTrade = new ModifyOrderTrade(this, this.conn);
          modifyOrderTrade.MdiParent = (Form) this;
          this.objmodordtrd = modifyOrderTrade;
          this.objmodordtrd.Show();
        }
        else
        {
          this.objmodordtrd.MdiParent = (Form) this;
          this.objmodordtrd.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public SortedDictionary<DateTime, payinoutDetails> GetPayinPayout(
      string clientcode,
      string fromdate,
      string todate)
    {
      SortedDictionary<DateTime, payinoutDetails> sortedDictionary = new SortedDictionary<DateTime, payinoutDetails>();
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Select ClientCode, Amount,case PayinPayout WHEN 1 THEN 'PAYIN' WHEN 2 THEN 'PAYOUT' END as Payin_OUT, TimeStamp,comments from Payin_Payout where ClientCode = '{0}' and TimeStamp between '{1}' and '{2}'", (object) clientcode, (object) fromdate, (object) todate), this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          DateTime now = DateTime.Now;
          while (sqlDataReader.Read())
          {
            payinoutDetails payinoutDetails = new payinoutDetails();
            if (!sqlDataReader.IsDBNull(0))
              payinoutDetails.clientcode = sqlDataReader.GetString(0);
            if (!sqlDataReader.IsDBNull(1))
              payinoutDetails.amount = Convert.ToDouble(sqlDataReader.GetValue(1));
            if (!sqlDataReader.IsDBNull(2))
              payinoutDetails.payinout = sqlDataReader.GetString(2);
            if (!sqlDataReader.IsDBNull(3))
            {
              payinoutDetails.timestamp = sqlDataReader.GetDateTime(3);
              if (!sqlDataReader.IsDBNull(4))
                payinoutDetails.comments = sqlDataReader.GetString(4);
              if (!sortedDictionary.ContainsKey(payinoutDetails.timestamp))
                sortedDictionary.Add(payinoutDetails.timestamp, payinoutDetails);
            }
          }
        }
      }
      return sortedDictionary;
    }

    public void SubsribeExchFeeds(string exch)
    {
      DateTime serverTime = this.GetServerTime();
      if (this._ExchFeedInstance.ContainsKey(exch))
        return;
      string upper = exch.ToUpper();
      if (!(upper == "MCX"))
      {
        if (!(upper == "NSEFUT"))
        {
          if (!(upper == "NCDEX"))
          {
            if (!(upper == "NSECURR"))
            {
              if (upper == "NSEOPT" && this.ValidateMarketTime("NSEFUT", ref serverTime))
              {
                this.threadObjRT_Feeds4 = new Thread(new ThreadStart(((ThreadStart) (() => this.FetchMarketFeedsNSEOPT())).Invoke));
                this.threadObjRT_Feeds4.Start();
                this._ExchFeedInstance.Add(exch, this.threadObjRT_Feeds4);
              }
            }
            else if (this.ValidateMarketTime("NSECURR", ref serverTime))
            {
              this.threadObjRT_Feeds3 = new Thread(new ThreadStart(((ThreadStart) (() => this.FetchMarketFeedsNSECUR())).Invoke));
              this.threadObjRT_Feeds3.Start();
              this._ExchFeedInstance.Add(exch, this.threadObjRT_Feeds3);
            }
          }
          else if (this.ValidateMarketTime("NCDEX", ref serverTime))
          {
            this.threadObjRT_Feeds2 = new Thread(new ThreadStart(((ThreadStart) (() => this.FetchMarketFeedsNCDEX())).Invoke));
            this.threadObjRT_Feeds2.Start();
            this._ExchFeedInstance.Add(exch, this.threadObjRT_Feeds2);
          }
        }
        else if (this.ValidateMarketTime("NSEFUT", ref serverTime))
        {
          this.threadObjRT_Feeds1 = new Thread(new ThreadStart(((ThreadStart) (() => this.FetchMarketFeedsNSEFUT())).Invoke));
          this.threadObjRT_Feeds1.Start();
          this._ExchFeedInstance.Add(exch, this.threadObjRT_Feeds1);
          if (this.NseSecondExpiryStatus())
          {
            this.threadObjRT_Feeds5 = new Thread(new ThreadStart(((ThreadStart) (() => this.FetchMarketFeedsNSEFUT2())).Invoke));
            this.threadObjRT_Feeds5.Start();
          }
        }
      }
      else if (this.ValidateMarketTime("MCX", ref serverTime))
      {
        this.threadObjRT_Feeds = new Thread(new ThreadStart(((ThreadStart) (() => this.FetchMarketFeedsMCX())).Invoke));
        this.threadObjRT_Feeds.Start();
        this._ExchFeedInstance.Add(exch, this.threadObjRT_Feeds);
      }
    }

    private void AccGroupingMnuItm_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objAccGrouping == null || this.objAccGrouping.IsDisposed)
        {
          frmPayoutGrouping frmPayoutGrouping = new frmPayoutGrouping(this);
          frmPayoutGrouping.MdiParent = (Form) this;
          this.objAccGrouping = frmPayoutGrouping;
          this.objAccGrouping.LoadControls();
          this.objAccGrouping.Show();
        }
        else
        {
          this.objAccGrouping.LoadControls();
          this.objAccGrouping.MdiParent = (Form) this;
          this.objAccGrouping.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public Decimal GetBegningBal(string regucode, DateTime startdate, string enddate)
    {
      Decimal num = new Decimal();
      DateTime dateTime = startdate;
      DateTime serverTime = this.GetServerTime();
      switch (startdate.DayOfWeek)
      {
        case DayOfWeek.Sunday:
          dateTime = startdate.AddDays(-1.0);
          break;
        case DayOfWeek.Monday:
          dateTime = startdate.AddDays(-2.0);
          break;
      }
      while (true)
      {
        SqlConnection conn = this.getConn();
        if (conn.State == ConnectionState.Open)
        {
          string cmdText = "select Top 1 Cashmrgn from Limitset_History where ClientCode = '" + regucode + "' and Timestamp between '" + dateTime.ToString("yyyy-MM-dd 00:00:00") + "' and '" + enddate + "' order by Timestamp";
          if ((serverTime - startdate).Days == 0)
            cmdText = "select Cashmrgn from Limitset where ClientCode = '" + regucode + "' ";
          using (SqlCommand sqlCommand = new SqlCommand(cmdText, conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                if (!sqlDataReader.IsDBNull(0))
                  num = Convert.ToDecimal(sqlDataReader.GetValue(0)) / new Decimal(100);
              }
              if (num == Decimal.Zero)
              {
                dateTime = dateTime.AddDays(-1.0);
                Thread.Sleep(500);
              }
              else
                break;
            }
          }
        }
        else
          break;
      }
      return num;
    }

    public string GetClientCodes(int flag, string createby)
    {
      string str1 = string.Empty;
      string str2 = createby;
      if (this.objinfo.usertype == 1 && flag == 1)
      {
        foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this._DAHierarchy)
          str2 += string.Format("'{0}',", (object) keyValuePair.Key);
        if (str2.Length > 0)
          str2.Substring(0, str2.Length - 1);
      }
      using (SqlCommand sqlCommand = new SqlCommand("Select Clientcode from Userinformation where Createdby in ('" + createby + "')", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              str1 += string.Format("'{0}',", (object) sqlDataReader.GetString(0));
          }
        }
      }
      if (str1.Length > 0)
        str1 = str1.Substring(0, str1.Length - 1);
      return str1;
    }

    public string GetClientCodes1(int flag, string createby)
    {
      string str1 = string.Empty;
      string str2 = createby;
      if (this.objinfo.usertype == 1 && flag == 1)
      {
        foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this._DAHierarchy)
          str2 += string.Format("{0},", (object) keyValuePair.Key);
        if (str2.Length > 0)
          str2.Substring(0, str2.Length - 1);
      }
      using (SqlCommand sqlCommand = new SqlCommand("Select Clientcode from Userinformation where Createdby in ('" + createby + "')", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              str1 += string.Format("{0},", (object) sqlDataReader.GetString(0));
          }
        }
      }
      if (str1.Length > 0)
        str1 = str1.Substring(0, str1.Length - 1);
      return str1;
    }

    private void flushUserDataToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 1)
          return;
        if (this.objflushUserData == null || this.objflushUserData.IsDisposed)
        {
          frmFlushUserData frmFlushUserData = new frmFlushUserData(this, this.conn);
          frmFlushUserData.MdiParent = (Form) this;
          this.objflushUserData = frmFlushUserData;
          this.objflushUserData.LoadWindow();
          this.objflushUserData.Show();
        }
        else
        {
          this.objflushUserData.MdiParent = (Form) this;
          this.objflushUserData.LoadWindow();
          this.objflushUserData.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objAboutUs == null || this.objAboutUs.IsDisposed)
        {
          AboutBox1 aboutBox1 = new AboutBox1(this);
          aboutBox1.MdiParent = (Form) this;
          this.objAboutUs = aboutBox1;
          this.objAboutUs.Show();
        }
        else
        {
          this.objAboutUs.MdiParent = (Form) this;
          this.objAboutUs.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public void GetOrdernowiseDatetime(
      ref DateTime createon,
      ref DateTime lastmodified,
      string orderno)
    {
      using (SqlCommand sqlCommand = new SqlCommand("Select Createon, Lastmodified from Orders where Orderno = '" + orderno + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              createon = Convert.ToDateTime(sqlDataReader.GetValue(0));
            if (!sqlDataReader.IsDBNull(1))
              lastmodified = Convert.ToDateTime(sqlDataReader.GetValue(1));
          }
        }
      }
    }

    public bool NseSecondExpiryStatus()
    {
      using (SqlCommand sqlCommand = new SqlCommand("Select isNSESecondExp from MarketTimings", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
            {
              if (sqlDataReader.GetInt32(0) == 0)
                return false;
              if (sqlDataReader.GetInt32(0) == 1)
                return true;
            }
          }
        }
      }
      return false;
    }

    private void MnuItmTradeGruping_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objtrdGrouping == null || this.objtrdGrouping.IsDisposed)
        {
          frmGrouping frmGrouping = new frmGrouping(this);
          frmGrouping.MdiParent = (Form) this;
          this.objtrdGrouping = frmGrouping;
          this.objtrdGrouping.LoadControls();
          this.objtrdGrouping.Show();
        }
        else
        {
          this.objtrdGrouping.MdiParent = (Form) this;
          this.objtrdGrouping.LoadControls();
          this.objtrdGrouping.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void tradeHistoryToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objtrdHistory == null || this.objtrdHistory.IsDisposed)
        {
          frmTradeHistory frmTradeHistory = new frmTradeHistory(this);
          frmTradeHistory.MdiParent = (Form) this;
          this.objtrdHistory = frmTradeHistory;
          this.objtrdHistory.Loadwindow();
          this.objtrdHistory.Show();
        }
        else
        {
          this.objtrdHistory.MdiParent = (Form) this;
          this.objtrdHistory.Loadwindow();
          this.objtrdHistory.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void dPRLimitToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objDPRlimit == null || this.objDPRlimit.IsDisposed)
        {
          frmDPRLimitfilter frmDprLimitfilter = new frmDPRLimitfilter(this);
          frmDprLimitfilter.MdiParent = (Form) this;
          this.objDPRlimit = frmDprLimitfilter;
          this.objDPRlimit.LoadControls();
          this.objDPRlimit.Show();
        }
        else
        {
          this.objDPRlimit.MdiParent = (Form) this;
          this.objDPRlimit.LoadControls();
          this.objDPRlimit.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolstripSymbolPos_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objNetPosSymbolwise == null || this.objNetPosSymbolwise.IsDisposed)
        {
          frmNetPostionSymwise netPostionSymwise = new frmNetPostionSymwise(this);
          netPostionSymwise.MdiParent = (Form) this;
          this.objNetPosSymbolwise = netPostionSymwise;
          this.objNetPosSymbolwise.Loadwindow();
          this.objNetPosSymbolwise.Show();
        }
        else
        {
          this.objNetPosSymbolwise.MdiParent = (Form) this;
          this.objNetPosSymbolwise.Loadwindow();
          this.objNetPosSymbolwise.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripDAPayinout_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 1)
          return;
        if (this.objDAmrgn == null || this.objDAmrgn.IsDisposed)
        {
          frmDAMargin frmDaMargin = new frmDAMargin(this);
          frmDaMargin.MdiParent = (Form) this;
          this.objDAmrgn = frmDaMargin;
          this.objDAmrgn.LoadMargin();
          this.objDAmrgn.Show();
        }
        else
        {
          this.objDAmrgn.MdiParent = (Form) this;
          this.objDAmrgn.LoadMargin();
          this.objDAmrgn.Show();
          this.objDAmrgn.BringToFront();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void toolStripCmpnyPfls_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 1)
          return;
        if (this.objSAnetpfls == null || this.objSAnetpfls.IsDisposed)
        {
          frmSANetPfls frmSaNetPfls = new frmSANetPfls(this);
          frmSaNetPfls.MdiParent = (Form) this;
          this.objSAnetpfls = frmSaNetPfls;
          this.objSAnetpfls.LoadSAPfls();
          this.objSAnetpfls.Show();
        }
        else
        {
          this.objSAnetpfls.MdiParent = (Form) this;
          this.objSAnetpfls.LoadSAPfls();
          this.objSAnetpfls.Show();
          this.objSAnetpfls.BringToFront();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void DashSettingMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype > 2)
          return;
        if (this.objdashSet == null || this.objdashSet.IsDisposed)
        {
          frmDashSetting frmDashSetting = new frmDashSetting(this, this.conn);
          frmDashSetting.MdiParent = (Form) this;
          this.objdashSet = frmDashSetting;
          this.objdashSet.Show();
        }
        else
        {
          this.objdashSet.MdiParent = (Form) this;
          this.objdashSet.Show();
          this.objdashSet.BringToFront();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void btnLogin_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
        return;
      if (this.objlogin == null || this.objlogin.IsDisposed)
      {
        Login login = new Login(this, this.conn);
        login.MdiParent = (Form) this;
        this.objlogin = login;
        this.objlogin.Loadwindow();
        this.objlogin.Show();
      }
      else
      {
        this.objlogin.Loadwindow();
        this.objlogin.MdiParent = (Form) this;
        this.objlogin.Show();
      }
    }

    private void btnLogout_Click(object sender, EventArgs e)
    {
      if (!this.isLogin)
        return;
      this.LogOff(true);
      this._lstAccounts.Clear();
      this.clearMsgBoard();
      this.DisplayMessage("LogOff Successfully!!", 1);
      this.InsertMsgBoard(" LogOff Successfull!!", 2);
    }

    private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.objFxsettings == null || this.objFxsettings.IsDisposed)
        {
          frmForexSettings frmForexSettings = new frmForexSettings(this);
          frmForexSettings.MdiParent = (Form) this;
          this.objFxsettings = frmForexSettings;
          this.objFxsettings.LoadWindow();
          this.objFxsettings.Show();
        }
        else
        {
          this.objFxsettings.LoadWindow();
          this.objFxsettings.MdiParent = (Form) this;
          this.objFxsettings.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void btnChangePass_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objchngpwd == null || this.objchngpwd.IsDisposed)
        {
          ChangePwd changePwd = new ChangePwd(this.objinfo, this.conn, this);
          changePwd.MdiParent = (Form) this;
          this.objchngpwd = changePwd;
          this.objchngpwd.Loadwindow();
          this.objchngpwd.Show();
        }
        else
        {
          this.objchngpwd.Loadwindow();
          this.objchngpwd.MdiParent = (Form) this;
          this.objchngpwd.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void tradeSettingsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objtrdSettings == null || this.objtrdSettings.IsDisposed)
        {
          frmTradeSettings frmTradeSettings = new frmTradeSettings(this);
          frmTradeSettings.MdiParent = (Form) this;
          this.objtrdSettings = frmTradeSettings;
          this.objtrdSettings.LoadControls();
          this.objtrdSettings.Show();
        }
        else
        {
          this.objtrdSettings.LoadControls();
          this.objtrdSettings.MdiParent = (Form) this;
          this.objtrdSettings.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void btnLockWorkstation_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objunlock == null || this.objunlock.IsDisposed)
        {
          this.objunlock = new unlock(this);
          int num = (int) this.objunlock.ShowDialog();
        }
        else
        {
          int num1 = (int) this.objunlock.ShowDialog();
        }
        this.clearMsgBoard();
        this.InsertMsgBoard(" Lock Workstation Successfull!!", 2);
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
    }

    private void btnBuyOrder_Click(object sender, EventArgs e)
    {
    }

    private void btnNetPosition_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objnetpos == null || this.objnetpos.IsDisposed)
        {
          NetPosition netPosition = new NetPosition(this);
          netPosition.MdiParent = (Form) this;
          this.objnetpos = netPosition;
          this.objnetpos.LoadNetPositions(false);
          this.objnetpos.Show();
        }
        else
        {
          this.objnetpos.LoadNetPositions(false);
          this.objnetpos.MdiParent = (Form) this;
          this.objnetpos.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void btnPendingOrders_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objordbook == null || this.objordbook.IsDisposed)
        {
          Orderbook orderbook = new Orderbook(this);
          orderbook.MdiParent = (Form) this;
          this.objordbook = orderbook;
          this.objordbook.LoadOrders();
          this.objordbook.Show();
        }
        else
        {
          this.objordbook.LoadOrders();
          this.objordbook.MdiParent = (Form) this;
          this.objordbook.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void showQuickAccessToolbarToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.toolStrip1.Visible)
      {
        this.toolStrip1.Visible = false;
        this.showQuickAccessToolbarToolStripMenuItem.CheckState = CheckState.Unchecked;
      }
      else
      {
        this.toolStrip1.Visible = true;
        this.showQuickAccessToolbarToolStripMenuItem.CheckState = CheckState.Checked;
      }
    }

    private void showFundsToolbarToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.toolStrip1.Visible)
      {
        this.toolStrip1.Visible = false;
        this.showQuickAccessToolbarToolStripMenuItem.CheckState = CheckState.Unchecked;
      }
      else
      {
        this.toolStrip1.Visible = true;
        this.showQuickAccessToolbarToolStripMenuItem.CheckState = CheckState.Checked;
      }
    }

    private void btnCancOrders_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 3 && this.objinfo.usertype != 4)
          return;
        if (this.objcanOrd == null || this.objcanOrd.IsDisposed)
        {
          CancelledOrders cancelledOrders = new CancelledOrders(this, this.conn);
          cancelledOrders.MdiParent = (Form) this;
          this.objcanOrd = cancelledOrders;
          this.objcanOrd.LoadOrders();
          this.objcanOrd.Show();
        }
        else
        {
          this.objcanOrd.LoadOrders();
          this.objcanOrd.MdiParent = (Form) this;
          this.objcanOrd.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void dealeridpayout_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 2)
          return;
        if (this.pay == null || this.pay.IsDisposed)
        {
          FrmPayout frmPayout = new FrmPayout(this, this.conn);
          frmPayout.MdiParent = (Form) this;
          this.pay = frmPayout;
          this.pay.loaddata();
          this.pay.Show();
        }
        else
        {
          this.pay.loaddata();
          this.pay.MdiParent = (Form) this;
          this.pay.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    private void LedgerAVGMenuItem_Click(object sender, EventArgs e)
    {
      if (this.isLogin)
      {
        if (this.objinfo.usertype != 4 && this.objinfo.usertype != 3)
          return;
        if (this.objledgeravg == null || this.objledgeravg.IsDisposed)
        {
          frmLedgerAVG frmLedgerAvg = new frmLedgerAVG(this);
          frmLedgerAvg.MdiParent = (Form) this;
          this.objledgeravg = frmLedgerAvg;
          this.objledgeravg.Loadwindow();
          this.objledgeravg.Show();
        }
        else
        {
          this.objledgeravg.MdiParent = (Form) this;
          this.objledgeravg.Loadwindow();
          this.objledgeravg.Show();
        }
      }
      else
        this.DisplayMessage("Please make a Login.", 2);
    }

    public void ManageClientFXSettingsData(FXsettings _data)
    {
      if (!this._ClientFXsettings.ContainsKey(_data.clientcode))
      {
        this._ClientFXsettings.Add(_data.clientcode, new Dictionary<string, FXsettings>()
        {
          {
            _data.symbol,
            _data
          }
        });
      }
      else
      {
        Dictionary<string, FXsettings> clientFxsetting = this._ClientFXsettings[_data.clientcode];
        if (!clientFxsetting.ContainsKey(_data.symbol))
          clientFxsetting.Add(_data.symbol, _data);
        this._ClientFXsettings[_data.clientcode] = clientFxsetting;
      }
    }

    public void ManageTradeSettings(TradeSettings _settings)
    {
      if (!this._ClientExchwiseTrdSettings.ContainsKey(_settings.clientCode))
      {
        this._ClientExchwiseTrdSettings.Add(_settings.clientCode, new Dictionary<int, Dictionary<string, TradeSettings>>()
        {
          {
            _settings.exch,
            new Dictionary<string, TradeSettings>()
            {
              {
                _settings.symbol,
                _settings
              }
            }
          }
        });
      }
      else
      {
        Dictionary<int, Dictionary<string, TradeSettings>> exchwiseTrdSetting = this._ClientExchwiseTrdSettings[_settings.clientCode];
        if (exchwiseTrdSetting.ContainsKey(_settings.exch))
        {
          Dictionary<string, TradeSettings> dictionary = exchwiseTrdSetting[_settings.exch];
          if (!dictionary.ContainsKey(_settings.symbol))
            dictionary.Add(_settings.symbol, _settings);
          else
            dictionary[_settings.symbol] = _settings;
          exchwiseTrdSetting[_settings.exch] = dictionary;
          this._ClientExchwiseTrdSettings[_settings.clientCode] = exchwiseTrdSetting;
        }
        else
        {
          exchwiseTrdSetting.Add(_settings.exch, new Dictionary<string, TradeSettings>()
          {
            {
              _settings.symbol,
              _settings
            }
          });
          this._ClientExchwiseTrdSettings[_settings.clientCode] = exchwiseTrdSetting;
        }
      }
    }

    public TradeSettings GetTradeSettings(string clientcode, int exch, string symbol)
    {
      if (this._ClientExchwiseTrdSettings.ContainsKey(clientcode))
      {
        Dictionary<int, Dictionary<string, TradeSettings>> exchwiseTrdSetting = this._ClientExchwiseTrdSettings[clientcode];
        if (exchwiseTrdSetting.ContainsKey(exch))
        {
          Dictionary<string, TradeSettings> dictionary = exchwiseTrdSetting[exch];
          if (dictionary.ContainsKey(symbol))
            return dictionary[symbol];
        }
      }
      return (TradeSettings) null;
    }

    public int GetAllowedTradeableQty(
      string clientcode,
      string symbol,
      int postype,
      DateTime timestamp)
    {
      using (Dictionary<string, buysellnetpospfls>.Enumerator enumerator = this.GetNetPos(clientcode, symbol, timestamp, postype).GetEnumerator())
      {
        if (enumerator.MoveNext())
        {
          buysellnetpospfls buysellnetpospfls = enumerator.Current.Value;
          return postype == 1 ? buysellnetpospfls.BQty - buysellnetpospfls.SQty : buysellnetpospfls.SQty - buysellnetpospfls.BQty;
        }
      }
      return 0;
    }

    public void ManageBrokerageType(BrkgType _data)
    {
      if (!this._ClientBrokerageType.ContainsKey(_data.clientCode))
        this._ClientBrokerageType.Add(_data.clientCode, _data);
      else
        this._ClientBrokerageType[_data.clientCode] = _data;
    }

    public int GetBrkgType(string clientcode, int exch)
    {
      if (!this._ClientBrokerageType.ContainsKey(clientcode))
        return this.GetLimits(clientcode).brkgtype;
      BrkgType brkgType = this._ClientBrokerageType[clientcode];
      switch (exch)
      {
        case 1:
          return brkgType.mcx;
        case 2:
          return brkgType.nsefut;
        case 3:
          return brkgType.ncdex;
        case 4:
          return brkgType.nsecurr;
        default:
          return 0;
      }
    }

    public DateTime GetServerTimeRTTRADE()
    {
      return Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd 09:00:00"));
    }

    private void LoadRTTrades()
    {
      Thread.Sleep(10000);
      SqlConnection conn = this.getConn();
      DateTime serverTimeRttrade = this.GetServerTimeRTTRADE();
      string empty1 = string.Empty;
      int num = this.objinfo.usertype - 1;
      List<double> doubleList = new List<double>();
      string str1 = this.objinfo.createdby;
      if (this.objinfo.usertype == 4 || this.objinfo.usertype == 2)
        str1 = this.objinfo.clientcode;
      while (true)
      {
        try
        {
          if (conn.State == ConnectionState.Closed)
            conn.Open();
          if (conn.State == ConnectionState.Open)
          {
            SqlCommand sqlCommand1 = new SqlCommand("GetRTTrades", conn);
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            using (SqlCommand sqlCommand2 = sqlCommand1)
            {
              sqlCommand2.Parameters.AddWithValue("@DAcode", (object) str1);
              sqlCommand2.Parameters.AddWithValue("@lastupdatetime", (object) serverTimeRttrade);
              sqlCommand2.Parameters.AddWithValue("@type", (object) num);
              using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  Orders orders = new Orders();
                  string empty2 = string.Empty;
                  string empty3 = string.Empty;
                  string empty4 = string.Empty;
                  string empty5 = string.Empty;
                  if (!sqlDataReader.IsDBNull(0))
                    orders.accountNo = sqlDataReader.GetString(0);
                  if (!sqlDataReader.IsDBNull(12))
                    orders.AccName = sqlDataReader.GetString(12);
                  if (!sqlDataReader.IsDBNull(1))
                    empty2 = sqlDataReader.GetString(1);
                  if (!sqlDataReader.IsDBNull(2))
                    orders.symbol = sqlDataReader.GetString(2);
                  if (!sqlDataReader.IsDBNull(3))
                    empty3 = sqlDataReader.GetString(3);
                  if (!sqlDataReader.IsDBNull(4))
                    empty4 = sqlDataReader.GetString(4);
                  if (!sqlDataReader.IsDBNull(5))
                    orders.Ordeqty = sqlDataReader.GetInt32(5);
                  if (!sqlDataReader.IsDBNull(6))
                    orders.ExecPrice = Convert.ToDecimal(sqlDataReader.GetValue(6));
                  if (!sqlDataReader.IsDBNull(7))
                    empty5 = sqlDataReader.GetString(7);
                  if (!sqlDataReader.IsDBNull(8))
                    orders.LastModified = Convert.ToDateTime(sqlDataReader.GetValue(8));
                  if (!sqlDataReader.IsDBNull(9))
                    orders.UserRemark = sqlDataReader.GetString(9);
                  if (!sqlDataReader.IsDBNull(10))
                    orders.TraderId = sqlDataReader.GetString(10);
                  if (!sqlDataReader.IsDBNull(11))
                    orders.OrderNo = Convert.ToDouble(sqlDataReader.GetValue(11));
                  if (!sqlDataReader.IsDBNull(13))
                    orders.OrdePrice = Convert.ToDecimal(sqlDataReader.GetValue(13));
                  if (!sqlDataReader.IsDBNull(14))
                    orders.Exectype = sqlDataReader.GetInt32(14);
                  if (this.objinfo.usertype == 4 || this._lstAccounts.Contains(orders.accountNo))
                  {
                    string traderId = orders.TraderId;
                    if (this.objinfo.usertype != 3 || this._lstAccounts.Contains(orders.accountNo))
                    {
                      string[] strArray = orders.symbol.Split(' ');
                      string str2 = "LMT";
                      if (orders.Exectype == 2)
                        str2 = "MKT";
                      if (!empty1.Contains(orders.OrderNo.ToString()))
                      {
                        Export.ExportRTTradesText(this.rtTradeLocation, string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15}", (object) orders.accountNo, (object) orders.AccName, (object) empty2, (object) strArray[0], (object) strArray[1], (object) empty3, (object) str2, (object) empty4.Substring(0, 1), (object) orders.Ordeqty, (object) orders.OrdePrice, (object) orders.ExecPrice, (object) empty5, (object) orders.LastModified.ToString("yyyy-MM-dd HH:mm:ss"), (object) orders.UserRemark, (object) traderId, (object) orders.OrderNo));
                        empty1 += orders.OrderNo.ToString();
                      }
                    }
                  }
                }
              }
              Thread.Sleep(500);
            }
          }
          Thread.Sleep(3000);
        }
        catch (Exception ex)
        {
          Thread.Sleep(5000);
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Dashboard));
      this.menuStrip = new MenuStrip();
      this.fileMenu = new ToolStripMenuItem();
      this.LoginMenuItem = new ToolStripMenuItem();
      this.LogOfftoolStripMenu = new ToolStripMenuItem();
      this.toolStripSeparator2 = new ToolStripSeparator();
      this.ChngPassMenuItem = new ToolStripMenuItem();
      this.LckWrkstationMenuItem = new ToolStripMenuItem();
      this.ChkUpdatesMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator3 = new ToolStripSeparator();
      this.ExitMenuItem = new ToolStripMenuItem();
      this.AdminMenuItem = new ToolStripMenuItem();
      this.UserPrflMenuItem = new ToolStripMenuItem();
      this.AccMapMenuItem = new ToolStripMenuItem();
      this.AccGroupingMnuItm = new ToolStripMenuItem();
      this.AdminMsgsMenuItem = new ToolStripMenuItem();
      this.DashSettingMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator11 = new ToolStripSeparator();
      this.toolStripOrders = new ToolStripMenuItem();
      this.toolStripTrades = new ToolStripMenuItem();
      this.toolStripSLTrades = new ToolStripMenuItem();
      this.toolStripSeparator4 = new ToolStripSeparator();
      this.CntrctMnmgtMenuItem = new ToolStripMenuItem();
      this.toolStripMngConStatus = new ToolStripMenuItem();
      this.OffsetMnmgtMenuItem = new ToolStripMenuItem();
      this.dPRLimitToolStripMenuItem = new ToolStripMenuItem();
      this.PayinOutMenuItem = new ToolStripMenuItem();
      this.ModOrdTrdMenuItem = new ToolStripMenuItem();
      this.MnuItmTradeGruping = new ToolStripMenuItem();
      this.toolStripSeparator5 = new ToolStripSeparator();
      this.LimitsMenuItem = new ToolStripMenuItem();
      this.tradeSettingsToolStripMenuItem = new ToolStripMenuItem();
      this.SymMargnRsMenuItem = new ToolStripMenuItem();
      this.DefExchMrgnLotsMenuItem = new ToolStripMenuItem();
      this.ForceSqOffMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator6 = new ToolStripSeparator();
      this.MisReportsMenuItem = new ToolStripMenuItem();
      this.RMSMenuItem = new ToolStripMenuItem();
      this.toolStripPositivePos = new ToolStripMenuItem();
      this.RejectionMsgMenuItem = new ToolStripMenuItem();
      this.toolstripSymbolPos = new ToolStripMenuItem();
      this.toolStripSeparator7 = new ToolStripSeparator();
      this.toolStripDAPayinout = new ToolStripMenuItem();
      this.toolStripCmpnyPfls = new ToolStripMenuItem();
      this.toolStripSeparator1 = new ToolStripSeparator();
      this.MaintenanceMenuItem = new ToolStripMenuItem();
      this.toolStripBlastSystem = new ToolStripMenuItem();
      this.flushUserDataToolStripMenuItem = new ToolStripMenuItem();
      this.dealeridpayout = new ToolStripMenuItem();
      this.forexToolStripMenuItem = new ToolStripMenuItem();
      this.settingsToolStripMenuItem = new ToolStripMenuItem();
      this.ViewMenuItem = new ToolStripMenuItem();
      this.OrderBookMenuItem = new ToolStripMenuItem();
      this.TrdBookMenuItem = new ToolStripMenuItem();
      this.NetPosMenuItem = new ToolStripMenuItem();
      this.ModOrdMenuItem = new ToolStripMenuItem();
      this.CanOrdMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator9 = new ToolStripSeparator();
      this.MsgLogsMenuItem = new ToolStripMenuItem();
      this.AdmMsgsMenuItem = new ToolStripMenuItem();
      this.ContrctStatusMenuItem = new ToolStripMenuItem();
      this.toolStripRMSView = new ToolStripMenuItem();
      this.toolStripSeparator10 = new ToolStripSeparator();
      this.PosBarMenuItem = new ToolStripMenuItem();
      this.StatusBarMenuItem = new ToolStripMenuItem();
      this.MarketMenuItem = new ToolStripMenuItem();
      this.MktWtchMenuItem = new ToolStripMenuItem();
      this.AlertMenuItem = new ToolStripMenuItem();
      this.SetAlertMenuItem = new ToolStripMenuItem();
      this.ShowAlertMenuItem = new ToolStripMenuItem();
      this.SetAlertOnMenuItem = new ToolStripMenuItem();
      this.AlertHistoryMenuItem = new ToolStripMenuItem();
      this.GetQuoteMenuItem = new ToolStripMenuItem();
      this.IndicesMenuItem = new ToolStripMenuItem();
      this.IntraDataHistoryMenuItem = new ToolStripMenuItem();
      this.CalculatorMenuItem = new ToolStripMenuItem();
      this.OptionCalcMenuItem = new ToolStripMenuItem();
      this.FairvalueMenuItem = new ToolStripMenuItem();
      this.FeedSourceMenuItem = new ToolStripMenuItem();
      this.toolStripSymSearch = new ToolStripMenuItem();
      this.defautMarketTradingToolStripMenuItem = new ToolStripMenuItem();
      this.toolStrpMnuSpeedCntrl = new ToolStripMenuItem();
      this.insertModifyOrdersTradesToolStripMenuItem = new ToolStripMenuItem();
      this.UserDetailsMenuItem = new ToolStripMenuItem();
      this.AccDetailsMenuItem = new ToolStripMenuItem();
      this.TotOrdersMenuItem = new ToolStripMenuItem();
      this.OpenPosMenuItem = new ToolStripMenuItem();
      this.LstPayinPayoutMenuItem = new ToolStripMenuItem();
      this.LedgerMenuItem = new ToolStripMenuItem();
      this.LedgerAVGMenuItem = new ToolStripMenuItem();
      this.tradeHistoryToolStripMenuItem = new ToolStripMenuItem();
      this.PivotsMenuItem = new ToolStripMenuItem();
      this.PivotViewMenuItem = new ToolStripMenuItem();
      this.RTPivotsMenuItem = new ToolStripMenuItem();
      this.PivotsAchvdMenuItem = new ToolStripMenuItem();
      this.PivotDashMenuItem = new ToolStripMenuItem();
      this.StocksViewMenuItem = new ToolStripMenuItem();
      this.HighLowMenuItem = new ToolStripMenuItem();
      this.PerformancViewMenuItem = new ToolStripMenuItem();
      this.TechChartsMenuItem = new ToolStripMenuItem();
      this.FinancialNewsMenuItem = new ToolStripMenuItem();
      this.windowsMenu = new ToolStripMenuItem();
      this.cascadeToolStripMenuItem = new ToolStripMenuItem();
      this.tileVerticalToolStripMenuItem = new ToolStripMenuItem();
      this.tileHorizontalToolStripMenuItem = new ToolStripMenuItem();
      this.closeAllToolStripMenuItem = new ToolStripMenuItem();
      this.helpMenu = new ToolStripMenuItem();
      this.toolStripMenuItem1 = new ToolStripMenuItem();
      this.aboutUsToolStripMenuItem = new ToolStripMenuItem();
      this.showQuickAccessToolbarToolStripMenuItem = new ToolStripMenuItem();
      this.toolStrip = new ToolStrip();
      this.btnRefreshData = new ToolStripButton();
      this.btnReconnectFeeds = new ToolStripButton();
      this.statusStrip = new StatusStrip();
      this.lblStatus = new ToolStripStatusLabel();
      this.toolTip = new ToolTip(this.components);
      this.panel1 = new Panel();
      this.lstMsgboard = new ListBox();
      this.webBrowser1 = new WebBrowser();
      this.PositionPanel = new TableLayoutPanel();
      this.lblMrgnBal = new Label();
      this.label5 = new Label();
      this.lblMrgnUtilised = new Label();
      this.label3 = new Label();
      this.lblCshMrgn = new Label();
      this.label1 = new Label();
      this.label9 = new Label();
      this.lblNetmtm = new Label();
      this.label11 = new Label();
      this.lblAvaiBal = new Label();
      this.automaticUpdater1 = new AutomaticUpdater();
      this.toolStrip1 = new ToolStrip();
      this.btnLogin = new ToolStripButton();
      this.btnLogout = new ToolStripButton();
      this.btnChangePass = new ToolStripButton();
      this.btnLockWorkstation = new ToolStripButton();
      this.btnExit = new ToolStripButton();
      this.toolStripSeparator8 = new ToolStripSeparator();
      this.btnBuyOrder = new ToolStripButton();
      this.btnSellOrder = new ToolStripButton();
      this.toolStripSeparator12 = new ToolStripSeparator();
      this.btnNetPosition = new ToolStripButton();
      this.btnPendingOrders = new ToolStripButton();
      this.btnCancOrders = new ToolStripButton();
      this.toolStripSeparator14 = new ToolStripSeparator();
      this.menuStrip.SuspendLayout();
      this.toolStrip.SuspendLayout();
      this.statusStrip.SuspendLayout();
      this.panel1.SuspendLayout();
      this.PositionPanel.SuspendLayout();
      ((ISupportInitialize) this.automaticUpdater1).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      this.menuStrip.Items.AddRange(new ToolStripItem[10]
      {
        (ToolStripItem) this.fileMenu,
        (ToolStripItem) this.AdminMenuItem,
        (ToolStripItem) this.forexToolStripMenuItem,
        (ToolStripItem) this.ViewMenuItem,
        (ToolStripItem) this.MarketMenuItem,
        (ToolStripItem) this.UserDetailsMenuItem,
        (ToolStripItem) this.PivotsMenuItem,
        (ToolStripItem) this.StocksViewMenuItem,
        (ToolStripItem) this.windowsMenu,
        (ToolStripItem) this.helpMenu
      });
      this.menuStrip.Location = new Point(0, 0);
      this.menuStrip.MdiWindowListItem = this.windowsMenu;
      this.menuStrip.Name = "menuStrip";
      this.menuStrip.Size = new Size(1026, 24);
      this.menuStrip.TabIndex = 0;
      this.menuStrip.Text = "MenuStrip";
      this.fileMenu.DropDownItems.AddRange(new ToolStripItem[8]
      {
        (ToolStripItem) this.LoginMenuItem,
        (ToolStripItem) this.LogOfftoolStripMenu,
        (ToolStripItem) this.toolStripSeparator2,
        (ToolStripItem) this.ChngPassMenuItem,
        (ToolStripItem) this.LckWrkstationMenuItem,
        (ToolStripItem) this.ChkUpdatesMenuItem,
        (ToolStripItem) this.toolStripSeparator3,
        (ToolStripItem) this.ExitMenuItem
      });
      this.fileMenu.ImageTransparentColor = SystemColors.ActiveBorder;
      this.fileMenu.Name = "fileMenu";
      this.fileMenu.Size = new Size(37, 20);
      this.fileMenu.Text = "&File";
      this.fileMenu.Click += new EventHandler(this.fileMenu_Click);
      this.LoginMenuItem.Name = "LoginMenuItem";
      this.LoginMenuItem.Size = new Size(233, 22);
      this.LoginMenuItem.Text = "Login...";
      this.LoginMenuItem.Click += new EventHandler(this.LoginMenuItem_Click);
      this.LogOfftoolStripMenu.Name = "LogOfftoolStripMenu";
      this.LogOfftoolStripMenu.Size = new Size(233, 22);
      this.LogOfftoolStripMenu.Text = "Log Off...";
      this.LogOfftoolStripMenu.Click += new EventHandler(this.LogOfftoolStripMenu_Click);
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new Size(230, 6);
      this.ChngPassMenuItem.Name = "ChngPassMenuItem";
      this.ChngPassMenuItem.ShortcutKeys = Keys.C | Keys.Control | Keys.Alt;
      this.ChngPassMenuItem.Size = new Size(233, 22);
      this.ChngPassMenuItem.Text = "Change Password";
      this.ChngPassMenuItem.Click += new EventHandler(this.ChngPassMenuItem_Click);
      this.LckWrkstationMenuItem.Name = "LckWrkstationMenuItem";
      this.LckWrkstationMenuItem.ShortcutKeys = Keys.W | Keys.Alt;
      this.LckWrkstationMenuItem.Size = new Size(233, 22);
      this.LckWrkstationMenuItem.Text = "Lock Workstation";
      this.LckWrkstationMenuItem.Click += new EventHandler(this.LckWrkstationMenuItem_Click);
      this.ChkUpdatesMenuItem.Name = "ChkUpdatesMenuItem";
      this.ChkUpdatesMenuItem.Size = new Size(233, 22);
      this.ChkUpdatesMenuItem.Text = "Check For Updates";
      this.ChkUpdatesMenuItem.Click += new EventHandler(this.ChkUpdatesMenuItem_Click);
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new Size(230, 6);
      this.ExitMenuItem.Name = "ExitMenuItem";
      this.ExitMenuItem.ShortcutKeys = Keys.X | Keys.Alt;
      this.ExitMenuItem.Size = new Size(233, 22);
      this.ExitMenuItem.Text = "Exit";
      this.ExitMenuItem.Click += new EventHandler(this.ExitMenuItem_Click);
      this.AdminMenuItem.DropDownItems.AddRange(new ToolStripItem[37]
      {
        (ToolStripItem) this.UserPrflMenuItem,
        (ToolStripItem) this.AccMapMenuItem,
        (ToolStripItem) this.AccGroupingMnuItm,
        (ToolStripItem) this.AdminMsgsMenuItem,
        (ToolStripItem) this.DashSettingMenuItem,
        (ToolStripItem) this.toolStripSeparator11,
        (ToolStripItem) this.toolStripOrders,
        (ToolStripItem) this.toolStripTrades,
        (ToolStripItem) this.toolStripSLTrades,
        (ToolStripItem) this.toolStripSeparator4,
        (ToolStripItem) this.CntrctMnmgtMenuItem,
        (ToolStripItem) this.toolStripMngConStatus,
        (ToolStripItem) this.OffsetMnmgtMenuItem,
        (ToolStripItem) this.dPRLimitToolStripMenuItem,
        (ToolStripItem) this.PayinOutMenuItem,
        (ToolStripItem) this.ModOrdTrdMenuItem,
        (ToolStripItem) this.MnuItmTradeGruping,
        (ToolStripItem) this.toolStripSeparator5,
        (ToolStripItem) this.LimitsMenuItem,
        (ToolStripItem) this.tradeSettingsToolStripMenuItem,
        (ToolStripItem) this.SymMargnRsMenuItem,
        (ToolStripItem) this.DefExchMrgnLotsMenuItem,
        (ToolStripItem) this.ForceSqOffMenuItem,
        (ToolStripItem) this.toolStripSeparator6,
        (ToolStripItem) this.MisReportsMenuItem,
        (ToolStripItem) this.RMSMenuItem,
        (ToolStripItem) this.toolStripPositivePos,
        (ToolStripItem) this.RejectionMsgMenuItem,
        (ToolStripItem) this.toolstripSymbolPos,
        (ToolStripItem) this.toolStripSeparator7,
        (ToolStripItem) this.toolStripDAPayinout,
        (ToolStripItem) this.toolStripCmpnyPfls,
        (ToolStripItem) this.toolStripSeparator1,
        (ToolStripItem) this.MaintenanceMenuItem,
        (ToolStripItem) this.toolStripBlastSystem,
        (ToolStripItem) this.flushUserDataToolStripMenuItem,
        (ToolStripItem) this.dealeridpayout
      });
      this.AdminMenuItem.Name = "AdminMenuItem";
      this.AdminMenuItem.Size = new Size(55, 20);
      this.AdminMenuItem.Text = "Admin";
      this.AdminMenuItem.Visible = false;
      this.UserPrflMenuItem.Name = "UserPrflMenuItem";
      this.UserPrflMenuItem.ShortcutKeys = Keys.U | Keys.Control;
      this.UserPrflMenuItem.Size = new Size(274, 22);
      this.UserPrflMenuItem.Text = "User Profile";
      this.UserPrflMenuItem.Click += new EventHandler(this.UserPrflMenuItem_Click);
      this.AccMapMenuItem.Name = "AccMapMenuItem";
      this.AccMapMenuItem.ShortcutKeys = Keys.M | Keys.Control;
      this.AccMapMenuItem.Size = new Size(274, 22);
      this.AccMapMenuItem.Text = "Account Mapping";
      this.AccMapMenuItem.Click += new EventHandler(this.AccMapMenuItem_Click);
      this.AccGroupingMnuItm.Name = "AccGroupingMnuItm";
      this.AccGroupingMnuItm.ShortcutKeys = Keys.G | Keys.Control;
      this.AccGroupingMnuItm.Size = new Size(274, 22);
      this.AccGroupingMnuItm.Text = "Account Grouping";
      this.AccGroupingMnuItm.Click += new EventHandler(this.AccGroupingMnuItm_Click);
      this.AdminMsgsMenuItem.Name = "AdminMsgsMenuItem";
      this.AdminMsgsMenuItem.ShortcutKeys = Keys.A | Keys.Control;
      this.AdminMsgsMenuItem.Size = new Size(274, 22);
      this.AdminMsgsMenuItem.Text = "Admin Messages";
      this.AdminMsgsMenuItem.Click += new EventHandler(this.AdminMsgsMenuItem_Click);
      this.DashSettingMenuItem.Name = "DashSettingMenuItem";
      this.DashSettingMenuItem.Size = new Size(274, 22);
      this.DashSettingMenuItem.Text = "Dashboard Setting";
      this.DashSettingMenuItem.Click += new EventHandler(this.DashSettingMenuItem_Click);
      this.toolStripSeparator11.Name = "toolStripSeparator11";
      this.toolStripSeparator11.Size = new Size(271, 6);
      this.toolStripOrders.Name = "toolStripOrders";
      this.toolStripOrders.ShortcutKeys = Keys.O | Keys.Control;
      this.toolStripOrders.Size = new Size(274, 22);
      this.toolStripOrders.Text = "View Orders";
      this.toolStripOrders.Click += new EventHandler(this.toolStripOrders_Click);
      this.toolStripTrades.Name = "toolStripTrades";
      this.toolStripTrades.ShortcutKeys = Keys.T | Keys.Control;
      this.toolStripTrades.Size = new Size(274, 22);
      this.toolStripTrades.Text = "View Trades";
      this.toolStripTrades.Click += new EventHandler(this.toolStripTrades_Click);
      this.toolStripSLTrades.Name = "toolStripSLTrades";
      this.toolStripSLTrades.ShortcutKeys = Keys.S | Keys.Control;
      this.toolStripSLTrades.Size = new Size(274, 22);
      this.toolStripSLTrades.Text = "View StopLoss Trades";
      this.toolStripSLTrades.Click += new EventHandler(this.toolStripSLTrades_Click);
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new Size(271, 6);
      this.CntrctMnmgtMenuItem.Name = "CntrctMnmgtMenuItem";
      this.CntrctMnmgtMenuItem.ShortcutKeys = Keys.C | Keys.Control;
      this.CntrctMnmgtMenuItem.Size = new Size(274, 22);
      this.CntrctMnmgtMenuItem.Text = "Contract Management";
      this.CntrctMnmgtMenuItem.Click += new EventHandler(this.CntrctMnmgtMenuItem_Click);
      this.toolStripMngConStatus.Name = "toolStripMngConStatus";
      this.toolStripMngConStatus.ShortcutKeys = Keys.Q | Keys.Control;
      this.toolStripMngConStatus.Size = new Size(274, 22);
      this.toolStripMngConStatus.Text = "Manage Contract Status";
      this.toolStripMngConStatus.Click += new EventHandler(this.toolStripMngConStatus_Click);
      this.OffsetMnmgtMenuItem.Name = "OffsetMnmgtMenuItem";
      this.OffsetMnmgtMenuItem.ShortcutKeys = Keys.W | Keys.Control;
      this.OffsetMnmgtMenuItem.Size = new Size(274, 22);
      this.OffsetMnmgtMenuItem.Text = "Offset Management";
      this.OffsetMnmgtMenuItem.Click += new EventHandler(this.OffsetMnmgtMenuItem_Click);
      this.dPRLimitToolStripMenuItem.Name = "dPRLimitToolStripMenuItem";
      this.dPRLimitToolStripMenuItem.Size = new Size(274, 22);
      this.dPRLimitToolStripMenuItem.Text = "DPR Limit";
      this.dPRLimitToolStripMenuItem.Click += new EventHandler(this.dPRLimitToolStripMenuItem_Click);
      this.PayinOutMenuItem.Name = "PayinOutMenuItem";
      this.PayinOutMenuItem.ShortcutKeys = Keys.P | Keys.Control;
      this.PayinOutMenuItem.Size = new Size(274, 22);
      this.PayinOutMenuItem.Text = "Payin/Payout";
      this.PayinOutMenuItem.Click += new EventHandler(this.PayinOutMenuItem_Click);
      this.ModOrdTrdMenuItem.Name = "ModOrdTrdMenuItem";
      this.ModOrdTrdMenuItem.Size = new Size(274, 22);
      this.ModOrdTrdMenuItem.Text = "Modify Order/Trade";
      this.ModOrdTrdMenuItem.Click += new EventHandler(this.ModOrdTrdMenuItem_Click);
      this.MnuItmTradeGruping.Name = "MnuItmTradeGruping";
      this.MnuItmTradeGruping.Size = new Size(274, 22);
      this.MnuItmTradeGruping.Text = "Trade Grouping";
      this.MnuItmTradeGruping.Click += new EventHandler(this.MnuItmTradeGruping_Click);
      this.toolStripSeparator5.Name = "toolStripSeparator5";
      this.toolStripSeparator5.Size = new Size(271, 6);
      this.LimitsMenuItem.Name = "LimitsMenuItem";
      this.LimitsMenuItem.ShortcutKeys = Keys.L | Keys.Control;
      this.LimitsMenuItem.Size = new Size(274, 22);
      this.LimitsMenuItem.Text = "Limits";
      this.LimitsMenuItem.Click += new EventHandler(this.LimitsMenuItem_Click);
      this.tradeSettingsToolStripMenuItem.Name = "tradeSettingsToolStripMenuItem";
      this.tradeSettingsToolStripMenuItem.Size = new Size(274, 22);
      this.tradeSettingsToolStripMenuItem.Text = "Trade Settings";
      this.tradeSettingsToolStripMenuItem.Click += new EventHandler(this.tradeSettingsToolStripMenuItem_Click);
      this.SymMargnRsMenuItem.Name = "SymMargnRsMenuItem";
      this.SymMargnRsMenuItem.ShortcutKeys = Keys.S | Keys.Shift | Keys.Control;
      this.SymMargnRsMenuItem.Size = new Size(274, 22);
      this.SymMargnRsMenuItem.Text = "Symbolwise Margin";
      this.SymMargnRsMenuItem.Click += new EventHandler(this.SymMargnRsMenuItem_Click);
      this.DefExchMrgnLotsMenuItem.Name = "DefExchMrgnLotsMenuItem";
      this.DefExchMrgnLotsMenuItem.Size = new Size(274, 22);
      this.DefExchMrgnLotsMenuItem.Text = "Default Exchangewise Margin(Lots)";
      this.DefExchMrgnLotsMenuItem.Visible = false;
      this.DefExchMrgnLotsMenuItem.Click += new EventHandler(this.SymMrgnLotsMenuItem_Click);
      this.ForceSqOffMenuItem.Name = "ForceSqOffMenuItem";
      this.ForceSqOffMenuItem.ShortcutKeys = Keys.F | Keys.Control;
      this.ForceSqOffMenuItem.Size = new Size(274, 22);
      this.ForceSqOffMenuItem.Text = "Force Square Off";
      this.ForceSqOffMenuItem.Click += new EventHandler(this.ForceSqOffMenuItem_Click);
      this.toolStripSeparator6.Name = "toolStripSeparator6";
      this.toolStripSeparator6.Size = new Size(271, 6);
      this.MisReportsMenuItem.Name = "MisReportsMenuItem";
      this.MisReportsMenuItem.ShortcutKeys = Keys.R | Keys.Control;
      this.MisReportsMenuItem.Size = new Size(274, 22);
      this.MisReportsMenuItem.Text = "MIS Reports";
      this.MisReportsMenuItem.Click += new EventHandler(this.MisReportsMenuItem_Click);
      this.RMSMenuItem.Name = "RMSMenuItem";
      this.RMSMenuItem.ShortcutKeys = Keys.X | Keys.Control;
      this.RMSMenuItem.Size = new Size(274, 22);
      this.RMSMenuItem.Text = "RMS";
      this.RMSMenuItem.Click += new EventHandler(this.RMSMenuItem_Click);
      this.toolStripPositivePos.Name = "toolStripPositivePos";
      this.toolStripPositivePos.ShortcutKeys = Keys.P | Keys.Shift | Keys.Control;
      this.toolStripPositivePos.Size = new Size(274, 22);
      this.toolStripPositivePos.Text = "Positions Going Positive";
      this.toolStripPositivePos.Click += new EventHandler(this.toolStripPositivePos_Click);
      this.RejectionMsgMenuItem.Name = "RejectionMsgMenuItem";
      this.RejectionMsgMenuItem.ShortcutKeys = Keys.R | Keys.Shift | Keys.Control;
      this.RejectionMsgMenuItem.Size = new Size(274, 22);
      this.RejectionMsgMenuItem.Text = "Rejection Messages";
      this.RejectionMsgMenuItem.Click += new EventHandler(this.RejectionMsgMenuItem_Click);
      this.toolstripSymbolPos.Name = "toolstripSymbolPos";
      this.toolstripSymbolPos.Size = new Size(274, 22);
      this.toolstripSymbolPos.Text = "Symbolwise Position";
      this.toolstripSymbolPos.Click += new EventHandler(this.toolstripSymbolPos_Click);
      this.toolStripSeparator7.Name = "toolStripSeparator7";
      this.toolStripSeparator7.Size = new Size(271, 6);
      this.toolStripDAPayinout.Name = "toolStripDAPayinout";
      this.toolStripDAPayinout.Size = new Size(274, 22);
      this.toolStripDAPayinout.Text = "DA Payin/Payout";
      this.toolStripDAPayinout.Click += new EventHandler(this.toolStripDAPayinout_Click);
      this.toolStripCmpnyPfls.Name = "toolStripCmpnyPfls";
      this.toolStripCmpnyPfls.Size = new Size(274, 22);
      this.toolStripCmpnyPfls.Text = "Company Profit/Loss";
      this.toolStripCmpnyPfls.Click += new EventHandler(this.toolStripCmpnyPfls_Click);
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new Size(271, 6);
      this.MaintenanceMenuItem.Name = "MaintenanceMenuItem";
      this.MaintenanceMenuItem.ShortcutKeys = Keys.M | Keys.Shift | Keys.Control;
      this.MaintenanceMenuItem.Size = new Size(274, 22);
      this.MaintenanceMenuItem.Text = "Maintenance";
      this.MaintenanceMenuItem.Click += new EventHandler(this.MaintenanceMenuItem_Click);
      this.toolStripBlastSystem.Name = "toolStripBlastSystem";
      this.toolStripBlastSystem.ShortcutKeys = Keys.X | Keys.Control | Keys.Alt;
      this.toolStripBlastSystem.Size = new Size(274, 22);
      this.toolStripBlastSystem.Text = "Blast System";
      this.toolStripBlastSystem.Click += new EventHandler(this.toolStripBlastSystem_Click);
      this.flushUserDataToolStripMenuItem.Name = "flushUserDataToolStripMenuItem";
      this.flushUserDataToolStripMenuItem.Size = new Size(274, 22);
      this.flushUserDataToolStripMenuItem.Text = "Flush User Data";
      this.flushUserDataToolStripMenuItem.Click += new EventHandler(this.flushUserDataToolStripMenuItem_Click);
      this.dealeridpayout.Name = "dealeridpayout";
      this.dealeridpayout.Size = new Size(274, 22);
      this.dealeridpayout.Text = "DealerID Payout";
      this.dealeridpayout.Visible = false;
      this.dealeridpayout.Click += new EventHandler(this.dealeridpayout_Click);
      this.forexToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[1]
      {
        (ToolStripItem) this.settingsToolStripMenuItem
      });
      this.forexToolStripMenuItem.Name = "forexToolStripMenuItem";
      this.forexToolStripMenuItem.Size = new Size(47, 20);
      this.forexToolStripMenuItem.Text = "Forex";
      this.forexToolStripMenuItem.Visible = false;
      this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
      this.settingsToolStripMenuItem.Size = new Size(116, 22);
      this.settingsToolStripMenuItem.Text = "Settings";
      this.settingsToolStripMenuItem.Click += new EventHandler(this.settingsToolStripMenuItem_Click);
      this.ViewMenuItem.DropDownItems.AddRange(new ToolStripItem[13]
      {
        (ToolStripItem) this.OrderBookMenuItem,
        (ToolStripItem) this.TrdBookMenuItem,
        (ToolStripItem) this.NetPosMenuItem,
        (ToolStripItem) this.ModOrdMenuItem,
        (ToolStripItem) this.CanOrdMenuItem,
        (ToolStripItem) this.toolStripSeparator9,
        (ToolStripItem) this.MsgLogsMenuItem,
        (ToolStripItem) this.AdmMsgsMenuItem,
        (ToolStripItem) this.ContrctStatusMenuItem,
        (ToolStripItem) this.toolStripRMSView,
        (ToolStripItem) this.toolStripSeparator10,
        (ToolStripItem) this.PosBarMenuItem,
        (ToolStripItem) this.StatusBarMenuItem
      });
      this.ViewMenuItem.Name = "ViewMenuItem";
      this.ViewMenuItem.Size = new Size(44, 20);
      this.ViewMenuItem.Text = "View";
      this.ViewMenuItem.Visible = false;
      this.OrderBookMenuItem.Name = "OrderBookMenuItem";
      this.OrderBookMenuItem.ShortcutKeys = Keys.F3 | Keys.Control;
      this.OrderBookMenuItem.Size = new Size(215, 22);
      this.OrderBookMenuItem.Text = "Order Book";
      this.OrderBookMenuItem.Click += new EventHandler(this.OrderBookMenuItem_Click);
      this.TrdBookMenuItem.Name = "TrdBookMenuItem";
      this.TrdBookMenuItem.ShortcutKeys = Keys.F8 | Keys.Control;
      this.TrdBookMenuItem.Size = new Size(215, 22);
      this.TrdBookMenuItem.Text = "Trade Book";
      this.TrdBookMenuItem.Click += new EventHandler(this.TrdBookMenuItem_Click);
      this.NetPosMenuItem.Name = "NetPosMenuItem";
      this.NetPosMenuItem.ShortcutKeys = Keys.F6 | Keys.Alt;
      this.NetPosMenuItem.Size = new Size(215, 22);
      this.NetPosMenuItem.Text = "Net Position";
      this.NetPosMenuItem.Click += new EventHandler(this.NetPosMenuItem_Click);
      this.ModOrdMenuItem.Name = "ModOrdMenuItem";
      this.ModOrdMenuItem.ShortcutKeys = Keys.F4 | Keys.Shift;
      this.ModOrdMenuItem.Size = new Size(215, 22);
      this.ModOrdMenuItem.Text = "Modified Orders";
      this.ModOrdMenuItem.Click += new EventHandler(this.ModOrdMenuItem_Click);
      this.CanOrdMenuItem.Name = "CanOrdMenuItem";
      this.CanOrdMenuItem.ShortcutKeys = Keys.F5 | Keys.Shift;
      this.CanOrdMenuItem.Size = new Size(215, 22);
      this.CanOrdMenuItem.Text = "Cancelled Orders";
      this.CanOrdMenuItem.Click += new EventHandler(this.CanOrdMenuItem_Click);
      this.toolStripSeparator9.Name = "toolStripSeparator9";
      this.toolStripSeparator9.Size = new Size(212, 6);
      this.MsgLogsMenuItem.Name = "MsgLogsMenuItem";
      this.MsgLogsMenuItem.ShortcutKeys = Keys.F10;
      this.MsgLogsMenuItem.Size = new Size(215, 22);
      this.MsgLogsMenuItem.Text = "Message Logs";
      this.MsgLogsMenuItem.Click += new EventHandler(this.MsgLogsMenuItem_Click);
      this.AdmMsgsMenuItem.Name = "AdmMsgsMenuItem";
      this.AdmMsgsMenuItem.ShortcutKeys = Keys.M | Keys.Alt;
      this.AdmMsgsMenuItem.Size = new Size(215, 22);
      this.AdmMsgsMenuItem.Text = "Admin Messages";
      this.AdmMsgsMenuItem.Click += new EventHandler(this.AdmMsgsMenuItem_Click);
      this.ContrctStatusMenuItem.Name = "ContrctStatusMenuItem";
      this.ContrctStatusMenuItem.ShortcutKeys = Keys.C | Keys.Alt;
      this.ContrctStatusMenuItem.Size = new Size(215, 22);
      this.ContrctStatusMenuItem.Text = "Contract Status";
      this.ContrctStatusMenuItem.Click += new EventHandler(this.ContrctStatusMenuItem_Click);
      this.toolStripRMSView.Name = "toolStripRMSView";
      this.toolStripRMSView.ShortcutKeys = Keys.R | Keys.Alt;
      this.toolStripRMSView.Size = new Size(215, 22);
      this.toolStripRMSView.Text = "RMS View";
      this.toolStripRMSView.Click += new EventHandler(this.toolStripRMSView_Click);
      this.toolStripSeparator10.Name = "toolStripSeparator10";
      this.toolStripSeparator10.Size = new Size(212, 6);
      this.PosBarMenuItem.Checked = true;
      this.PosBarMenuItem.CheckOnClick = true;
      this.PosBarMenuItem.CheckState = CheckState.Checked;
      this.PosBarMenuItem.Name = "PosBarMenuItem";
      this.PosBarMenuItem.Size = new Size(215, 22);
      this.PosBarMenuItem.Text = "Positions Bar";
      this.PosBarMenuItem.Click += new EventHandler(this.PosBarMenuItem_Click);
      this.StatusBarMenuItem.Checked = true;
      this.StatusBarMenuItem.CheckOnClick = true;
      this.StatusBarMenuItem.CheckState = CheckState.Checked;
      this.StatusBarMenuItem.Name = "StatusBarMenuItem";
      this.StatusBarMenuItem.Size = new Size(215, 22);
      this.StatusBarMenuItem.Text = "Status Bar";
      this.StatusBarMenuItem.Click += new EventHandler(this.StatusBarMenuItem_Click);
      this.MarketMenuItem.DropDownItems.AddRange(new ToolStripItem[11]
      {
        (ToolStripItem) this.MktWtchMenuItem,
        (ToolStripItem) this.AlertMenuItem,
        (ToolStripItem) this.GetQuoteMenuItem,
        (ToolStripItem) this.IndicesMenuItem,
        (ToolStripItem) this.IntraDataHistoryMenuItem,
        (ToolStripItem) this.CalculatorMenuItem,
        (ToolStripItem) this.FeedSourceMenuItem,
        (ToolStripItem) this.toolStripSymSearch,
        (ToolStripItem) this.defautMarketTradingToolStripMenuItem,
        (ToolStripItem) this.toolStrpMnuSpeedCntrl,
        (ToolStripItem) this.insertModifyOrdersTradesToolStripMenuItem
      });
      this.MarketMenuItem.Name = "MarketMenuItem";
      this.MarketMenuItem.Size = new Size(56, 20);
      this.MarketMenuItem.Text = "Market";
      this.MarketMenuItem.Visible = false;
      this.MktWtchMenuItem.Name = "MktWtchMenuItem";
      this.MktWtchMenuItem.ShortcutKeys = Keys.F4;
      this.MktWtchMenuItem.Size = new Size(224, 22);
      this.MktWtchMenuItem.Text = "Market Watch";
      this.MktWtchMenuItem.Click += new EventHandler(this.MktWtchMenuItem_Click);
      this.AlertMenuItem.DropDownItems.AddRange(new ToolStripItem[4]
      {
        (ToolStripItem) this.SetAlertMenuItem,
        (ToolStripItem) this.ShowAlertMenuItem,
        (ToolStripItem) this.SetAlertOnMenuItem,
        (ToolStripItem) this.AlertHistoryMenuItem
      });
      this.AlertMenuItem.Name = "AlertMenuItem";
      this.AlertMenuItem.Size = new Size(224, 22);
      this.AlertMenuItem.Text = "Alerts";
      this.AlertMenuItem.Visible = false;
      this.SetAlertMenuItem.Name = "SetAlertMenuItem";
      this.SetAlertMenuItem.Size = new Size(140, 22);
      this.SetAlertMenuItem.Text = "Set Alert";
      this.ShowAlertMenuItem.Name = "ShowAlertMenuItem";
      this.ShowAlertMenuItem.Size = new Size(140, 22);
      this.ShowAlertMenuItem.Text = "Show Alerts";
      this.SetAlertOnMenuItem.Checked = true;
      this.SetAlertOnMenuItem.CheckState = CheckState.Checked;
      this.SetAlertOnMenuItem.Name = "SetAlertOnMenuItem";
      this.SetAlertOnMenuItem.Size = new Size(140, 22);
      this.SetAlertOnMenuItem.Text = "Set Alert ON";
      this.AlertHistoryMenuItem.Name = "AlertHistoryMenuItem";
      this.AlertHistoryMenuItem.Size = new Size(140, 22);
      this.AlertHistoryMenuItem.Text = "Alert History";
      this.GetQuoteMenuItem.Name = "GetQuoteMenuItem";
      this.GetQuoteMenuItem.Size = new Size(224, 22);
      this.GetQuoteMenuItem.Text = "Get Quote";
      this.GetQuoteMenuItem.Visible = false;
      this.IndicesMenuItem.Name = "IndicesMenuItem";
      this.IndicesMenuItem.Size = new Size(224, 22);
      this.IndicesMenuItem.Text = "Indices";
      this.IndicesMenuItem.Visible = false;
      this.IntraDataHistoryMenuItem.Name = "IntraDataHistoryMenuItem";
      this.IntraDataHistoryMenuItem.ShortcutKeys = Keys.H | Keys.Alt;
      this.IntraDataHistoryMenuItem.Size = new Size(224, 22);
      this.IntraDataHistoryMenuItem.Text = "Intraday Data History";
      this.IntraDataHistoryMenuItem.Click += new EventHandler(this.IntraDataHistoryMenuItem_Click);
      this.CalculatorMenuItem.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.OptionCalcMenuItem,
        (ToolStripItem) this.FairvalueMenuItem
      });
      this.CalculatorMenuItem.Name = "CalculatorMenuItem";
      this.CalculatorMenuItem.Size = new Size(224, 22);
      this.CalculatorMenuItem.Text = "Calculators";
      this.CalculatorMenuItem.Visible = false;
      this.OptionCalcMenuItem.Name = "OptionCalcMenuItem";
      this.OptionCalcMenuItem.Size = new Size(125, 22);
      this.OptionCalcMenuItem.Text = "Options";
      this.FairvalueMenuItem.Name = "FairvalueMenuItem";
      this.FairvalueMenuItem.Size = new Size(125, 22);
      this.FairvalueMenuItem.Text = "Fair Value";
      this.FeedSourceMenuItem.Name = "FeedSourceMenuItem";
      this.FeedSourceMenuItem.ShortcutKeys = Keys.F | Keys.Alt;
      this.FeedSourceMenuItem.Size = new Size(224, 22);
      this.FeedSourceMenuItem.Text = "Feed Sources";
      this.FeedSourceMenuItem.Visible = false;
      this.toolStripSymSearch.Name = "toolStripSymSearch";
      this.toolStripSymSearch.ShortcutKeys = Keys.F5;
      this.toolStripSymSearch.Size = new Size(224, 22);
      this.toolStripSymSearch.Text = "Symbol Search";
      this.toolStripSymSearch.Click += new EventHandler(this.toolStripSymSearch_Click);
      this.defautMarketTradingToolStripMenuItem.Name = "defautMarketTradingToolStripMenuItem";
      this.defautMarketTradingToolStripMenuItem.Size = new Size(224, 22);
      this.defautMarketTradingToolStripMenuItem.Text = "Defaut Market Trading";
      this.defautMarketTradingToolStripMenuItem.Visible = false;
      this.toolStrpMnuSpeedCntrl.Name = "toolStrpMnuSpeedCntrl";
      this.toolStrpMnuSpeedCntrl.Size = new Size(224, 22);
      this.toolStrpMnuSpeedCntrl.Text = "Feed Speed Control";
      this.toolStrpMnuSpeedCntrl.Visible = false;
      this.toolStrpMnuSpeedCntrl.Click += new EventHandler(this.toolStrpMnuSpeedCntrl_Click);
      this.insertModifyOrdersTradesToolStripMenuItem.Name = "insertModifyOrdersTradesToolStripMenuItem";
      this.insertModifyOrdersTradesToolStripMenuItem.Size = new Size(224, 22);
      this.insertModifyOrdersTradesToolStripMenuItem.Text = "Insert/Modify Orders/Trades";
      this.insertModifyOrdersTradesToolStripMenuItem.Visible = false;
      this.insertModifyOrdersTradesToolStripMenuItem.Click += new EventHandler(this.insertModifyOrdersTradesToolStripMenuItem_Click);
      this.UserDetailsMenuItem.DropDownItems.AddRange(new ToolStripItem[7]
      {
        (ToolStripItem) this.AccDetailsMenuItem,
        (ToolStripItem) this.TotOrdersMenuItem,
        (ToolStripItem) this.OpenPosMenuItem,
        (ToolStripItem) this.LstPayinPayoutMenuItem,
        (ToolStripItem) this.LedgerMenuItem,
        (ToolStripItem) this.LedgerAVGMenuItem,
        (ToolStripItem) this.tradeHistoryToolStripMenuItem
      });
      this.UserDetailsMenuItem.Name = "UserDetailsMenuItem";
      this.UserDetailsMenuItem.Size = new Size(80, 20);
      this.UserDetailsMenuItem.Text = "User Details";
      this.UserDetailsMenuItem.Visible = false;
      this.AccDetailsMenuItem.Name = "AccDetailsMenuItem";
      this.AccDetailsMenuItem.ShortcutKeys = Keys.A | Keys.Alt;
      this.AccDetailsMenuItem.Size = new Size(256, 22);
      this.AccDetailsMenuItem.Text = "Account Details";
      this.AccDetailsMenuItem.Click += new EventHandler(this.AccDetailsMenuItem_Click);
      this.TotOrdersMenuItem.Name = "TotOrdersMenuItem";
      this.TotOrdersMenuItem.ShortcutKeys = Keys.O | Keys.Shift | Keys.Control;
      this.TotOrdersMenuItem.Size = new Size(256, 22);
      this.TotOrdersMenuItem.Text = "No. Of Orders";
      this.TotOrdersMenuItem.Click += new EventHandler(this.TotOrdersMenuItem_Click);
      this.OpenPosMenuItem.Name = "OpenPosMenuItem";
      this.OpenPosMenuItem.ShortcutKeys = Keys.O | Keys.Shift | Keys.Alt;
      this.OpenPosMenuItem.Size = new Size(256, 22);
      this.OpenPosMenuItem.Text = "Open Positions";
      this.OpenPosMenuItem.Click += new EventHandler(this.OpenPosMenuItem_Click);
      this.LstPayinPayoutMenuItem.Name = "LstPayinPayoutMenuItem";
      this.LstPayinPayoutMenuItem.ShortcutKeys = Keys.P | Keys.Alt;
      this.LstPayinPayoutMenuItem.Size = new Size(256, 22);
      this.LstPayinPayoutMenuItem.Text = "Last Payin/Payout";
      this.LstPayinPayoutMenuItem.Click += new EventHandler(this.LstPayinPayoutMenuItem_Click);
      this.LedgerMenuItem.Name = "LedgerMenuItem";
      this.LedgerMenuItem.ShortcutKeys = Keys.L | Keys.Shift | Keys.Control;
      this.LedgerMenuItem.Size = new Size(256, 22);
      this.LedgerMenuItem.Text = "Ledger";
      this.LedgerMenuItem.Click += new EventHandler(this.LedgerMenuItem_Click);
      this.LedgerAVGMenuItem.Name = "LedgerAVGMenuItem";
      this.LedgerAVGMenuItem.ShortcutKeys = Keys.L | Keys.Shift | Keys.Control | Keys.Alt;
      this.LedgerAVGMenuItem.Size = new Size(256, 22);
      this.LedgerAVGMenuItem.Text = "Ledger(Average)";
      this.LedgerAVGMenuItem.Click += new EventHandler(this.LedgerAVGMenuItem_Click);
      this.tradeHistoryToolStripMenuItem.Name = "tradeHistoryToolStripMenuItem";
      this.tradeHistoryToolStripMenuItem.Size = new Size(256, 22);
      this.tradeHistoryToolStripMenuItem.Text = "Trade History";
      this.tradeHistoryToolStripMenuItem.Click += new EventHandler(this.tradeHistoryToolStripMenuItem_Click);
      this.PivotsMenuItem.DropDownItems.AddRange(new ToolStripItem[4]
      {
        (ToolStripItem) this.PivotViewMenuItem,
        (ToolStripItem) this.RTPivotsMenuItem,
        (ToolStripItem) this.PivotsAchvdMenuItem,
        (ToolStripItem) this.PivotDashMenuItem
      });
      this.PivotsMenuItem.Name = "PivotsMenuItem";
      this.PivotsMenuItem.Size = new Size(51, 20);
      this.PivotsMenuItem.Text = "Pivots";
      this.PivotsMenuItem.Visible = false;
      this.PivotViewMenuItem.Name = "PivotViewMenuItem";
      this.PivotViewMenuItem.Size = new Size(166, 22);
      this.PivotViewMenuItem.Text = "Pivots View";
      this.RTPivotsMenuItem.Name = "RTPivotsMenuItem";
      this.RTPivotsMenuItem.Size = new Size(166, 22);
      this.RTPivotsMenuItem.Text = "Real Time Pivots";
      this.PivotsAchvdMenuItem.Name = "PivotsAchvdMenuItem";
      this.PivotsAchvdMenuItem.Size = new Size(166, 22);
      this.PivotsAchvdMenuItem.Text = "Pivots Achieved";
      this.PivotDashMenuItem.Name = "PivotDashMenuItem";
      this.PivotDashMenuItem.Size = new Size(166, 22);
      this.PivotDashMenuItem.Text = "Pivots Dashboard";
      this.StocksViewMenuItem.DropDownItems.AddRange(new ToolStripItem[4]
      {
        (ToolStripItem) this.HighLowMenuItem,
        (ToolStripItem) this.PerformancViewMenuItem,
        (ToolStripItem) this.TechChartsMenuItem,
        (ToolStripItem) this.FinancialNewsMenuItem
      });
      this.StocksViewMenuItem.Name = "StocksViewMenuItem";
      this.StocksViewMenuItem.Size = new Size(53, 20);
      this.StocksViewMenuItem.Text = "Stocks";
      this.StocksViewMenuItem.Visible = false;
      this.HighLowMenuItem.Name = "HighLowMenuItem";
      this.HighLowMenuItem.Size = new Size(181, 22);
      this.HighLowMenuItem.Text = "New High/New Low";
      this.PerformancViewMenuItem.Name = "PerformancViewMenuItem";
      this.PerformancViewMenuItem.Size = new Size(181, 22);
      this.PerformancViewMenuItem.Text = "Performance View";
      this.TechChartsMenuItem.Name = "TechChartsMenuItem";
      this.TechChartsMenuItem.Size = new Size(181, 22);
      this.TechChartsMenuItem.Text = "Technical Charts";
      this.FinancialNewsMenuItem.Name = "FinancialNewsMenuItem";
      this.FinancialNewsMenuItem.Size = new Size(181, 22);
      this.FinancialNewsMenuItem.Text = "Financial News";
      this.windowsMenu.DropDownItems.AddRange(new ToolStripItem[4]
      {
        (ToolStripItem) this.cascadeToolStripMenuItem,
        (ToolStripItem) this.tileVerticalToolStripMenuItem,
        (ToolStripItem) this.tileHorizontalToolStripMenuItem,
        (ToolStripItem) this.closeAllToolStripMenuItem
      });
      this.windowsMenu.Name = "windowsMenu";
      this.windowsMenu.Size = new Size(68, 20);
      this.windowsMenu.Text = "&Windows";
      this.windowsMenu.Visible = false;
      this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
      this.cascadeToolStripMenuItem.Size = new Size(151, 22);
      this.cascadeToolStripMenuItem.Text = "&Cascade";
      this.cascadeToolStripMenuItem.Click += new EventHandler(this.CascadeToolStripMenuItem_Click);
      this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
      this.tileVerticalToolStripMenuItem.Size = new Size(151, 22);
      this.tileVerticalToolStripMenuItem.Text = "Tile &Vertical";
      this.tileVerticalToolStripMenuItem.Click += new EventHandler(this.TileVerticalToolStripMenuItem_Click);
      this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
      this.tileHorizontalToolStripMenuItem.Size = new Size(151, 22);
      this.tileHorizontalToolStripMenuItem.Text = "Tile &Horizontal";
      this.tileHorizontalToolStripMenuItem.Click += new EventHandler(this.TileHorizontalToolStripMenuItem_Click);
      this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
      this.closeAllToolStripMenuItem.Size = new Size(151, 22);
      this.closeAllToolStripMenuItem.Text = "C&lose All";
      this.closeAllToolStripMenuItem.Click += new EventHandler(this.CloseAllToolStripMenuItem_Click);
      this.helpMenu.DropDownItems.AddRange(new ToolStripItem[3]
      {
        (ToolStripItem) this.toolStripMenuItem1,
        (ToolStripItem) this.aboutUsToolStripMenuItem,
        (ToolStripItem) this.showQuickAccessToolbarToolStripMenuItem
      });
      this.helpMenu.Name = "helpMenu";
      this.helpMenu.Size = new Size(44, 20);
      this.helpMenu.Text = "&Help";
      this.helpMenu.Visible = false;
      this.toolStripMenuItem1.Name = "toolStripMenuItem1";
      this.toolStripMenuItem1.Size = new Size(220, 22);
      this.toolStripMenuItem1.Text = "Shortcut Keys";
      this.toolStripMenuItem1.Click += new EventHandler(this.toolStripMenuItem1_Click);
      this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
      this.aboutUsToolStripMenuItem.Size = new Size(220, 22);
      this.aboutUsToolStripMenuItem.Text = "About Us";
      this.aboutUsToolStripMenuItem.Click += new EventHandler(this.aboutUsToolStripMenuItem_Click);
      this.showQuickAccessToolbarToolStripMenuItem.Checked = true;
      this.showQuickAccessToolbarToolStripMenuItem.CheckOnClick = true;
      this.showQuickAccessToolbarToolStripMenuItem.CheckState = CheckState.Checked;
      this.showQuickAccessToolbarToolStripMenuItem.Name = "showQuickAccessToolbarToolStripMenuItem";
      this.showQuickAccessToolbarToolStripMenuItem.Size = new Size(220, 22);
      this.showQuickAccessToolbarToolStripMenuItem.Text = "Show Quick Access Toolbar";
      this.showQuickAccessToolbarToolStripMenuItem.Click += new EventHandler(this.showQuickAccessToolbarToolStripMenuItem_Click);
      this.toolStrip.Items.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.btnRefreshData,
        (ToolStripItem) this.btnReconnectFeeds
      });
      this.toolStrip.Location = new Point(0, 24);
      this.toolStrip.Name = "toolStrip";
      this.toolStrip.Size = new Size(1026, 25);
      this.toolStrip.TabIndex = 1;
      this.toolStrip.Text = "ToolStrip";
      this.btnRefreshData.Image = (Image) componentResourceManager.GetObject("btnRefreshData.Image");
      this.btnRefreshData.ImageTransparentColor = Color.Magenta;
      this.btnRefreshData.Name = "btnRefreshData";
      this.btnRefreshData.Size = new Size(93, 22);
      this.btnRefreshData.Text = "Refresh Data";
      this.btnRefreshData.Click += new EventHandler(this.btnRefreshData_Click);
      this.btnReconnectFeeds.Enabled = false;
      this.btnReconnectFeeds.Image = (Image) componentResourceManager.GetObject("btnReconnectFeeds.Image");
      this.btnReconnectFeeds.ImageTransparentColor = Color.Magenta;
      this.btnReconnectFeeds.Name = "btnReconnectFeeds";
      this.btnReconnectFeeds.Size = new Size(116, 22);
      this.btnReconnectFeeds.Text = "Reconnect Feeds";
      this.btnReconnectFeeds.Click += new EventHandler(this.btnReconnectFeeds_Click);
      this.statusStrip.Items.AddRange(new ToolStripItem[1]
      {
        (ToolStripItem) this.lblStatus
      });
      this.statusStrip.Location = new Point(0, 711);
      this.statusStrip.Name = "statusStrip";
      this.statusStrip.Size = new Size(1026, 22);
      this.statusStrip.TabIndex = 2;
      this.statusStrip.Text = "StatusStrip";
      this.lblStatus.Font = new Font("Segoe UI", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new Size(12, 17);
      this.lblStatus.Text = ".";
      this.panel1.Controls.Add((Control) this.lstMsgboard);
      this.panel1.Controls.Add((Control) this.webBrowser1);
      this.panel1.Controls.Add((Control) this.PositionPanel);
      this.panel1.Dock = DockStyle.Bottom;
      this.panel1.Location = new Point(0, 619);
      this.panel1.Name = "panel1";
      this.panel1.Size = new Size(1026, 92);
      this.panel1.TabIndex = 4;
      this.lstMsgboard.BackColor = Color.White;
      this.lstMsgboard.Dock = DockStyle.Top;
      this.lstMsgboard.DrawMode = DrawMode.OwnerDrawFixed;
      this.lstMsgboard.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.lstMsgboard.ForeColor = Color.Black;
      this.lstMsgboard.ItemHeight = 15;
      this.lstMsgboard.Location = new Point(0, 26);
      this.lstMsgboard.Name = "lstMsgboard";
      this.lstMsgboard.SelectionMode = SelectionMode.None;
      this.lstMsgboard.Size = new Size(1026, 49);
      this.lstMsgboard.TabIndex = 3;
      this.lstMsgboard.DrawItem += new DrawItemEventHandler(this.lstMsgboard_DrawItem);
      this.webBrowser1.AccessibleRole = AccessibleRole.TitleBar;
      this.webBrowser1.Dock = DockStyle.Bottom;
      this.webBrowser1.Location = new Point(0, 72);
      this.webBrowser1.Margin = new Padding(0);
      this.webBrowser1.MinimumSize = new Size(20, 20);
      this.webBrowser1.Name = "webBrowser1";
      this.webBrowser1.ScrollBarsEnabled = false;
      this.webBrowser1.Size = new Size(1026, 20);
      this.webBrowser1.TabIndex = 2;
      this.webBrowser1.Visible = false;
      this.PositionPanel.CellBorderStyle = TableLayoutPanelCellBorderStyle.OutsetDouble;
      this.PositionPanel.ColumnCount = 10;
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 9.999999f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20f));
      this.PositionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20f));
      this.PositionPanel.Controls.Add((Control) this.lblMrgnBal, 5, 0);
      this.PositionPanel.Controls.Add((Control) this.label5, 4, 0);
      this.PositionPanel.Controls.Add((Control) this.lblMrgnUtilised, 3, 0);
      this.PositionPanel.Controls.Add((Control) this.label3, 2, 0);
      this.PositionPanel.Controls.Add((Control) this.lblCshMrgn, 1, 0);
      this.PositionPanel.Controls.Add((Control) this.label1, 0, 0);
      this.PositionPanel.Controls.Add((Control) this.label9, 6, 0);
      this.PositionPanel.Controls.Add((Control) this.lblNetmtm, 7, 0);
      this.PositionPanel.Controls.Add((Control) this.label11, 8, 0);
      this.PositionPanel.Controls.Add((Control) this.lblAvaiBal, 9, 0);
      this.PositionPanel.Dock = DockStyle.Top;
      this.PositionPanel.Location = new Point(0, 0);
      this.PositionPanel.Name = "PositionPanel";
      this.PositionPanel.RowCount = 1;
      this.PositionPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
      this.PositionPanel.Size = new Size(1026, 26);
      this.PositionPanel.TabIndex = 1;
      this.lblMrgnBal.AutoSize = true;
      this.lblMrgnBal.Location = new Point(516, 3);
      this.lblMrgnBal.Name = "lblMrgnBal";
      this.lblMrgnBal.Size = new Size(13, 13);
      this.lblMrgnBal.TabIndex = 5;
      this.lblMrgnBal.Text = "0";
      this.label5.AutoSize = true;
      this.label5.Location = new Point(414, 3);
      this.label5.Name = "label5";
      this.label5.Size = new Size(81, 13);
      this.label5.TabIndex = 4;
      this.label5.Text = "Margin Balance";
      this.lblMrgnUtilised.AutoSize = true;
      this.lblMrgnUtilised.Location = new Point(312, 3);
      this.lblMrgnUtilised.Name = "lblMrgnUtilised";
      this.lblMrgnUtilised.Size = new Size(13, 13);
      this.lblMrgnUtilised.TabIndex = 3;
      this.lblMrgnUtilised.Text = "0";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(210, 3);
      this.label3.Name = "label3";
      this.label3.Size = new Size(76, 13);
      this.label3.TabIndex = 2;
      this.label3.Text = "Margin Utilised";
      this.lblCshMrgn.AutoSize = true;
      this.lblCshMrgn.Location = new Point(108, 3);
      this.lblCshMrgn.Name = "lblCshMrgn";
      this.lblCshMrgn.Size = new Size(13, 13);
      this.lblCshMrgn.TabIndex = 1;
      this.lblCshMrgn.Text = "0";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(6, 3);
      this.label1.Name = "label1";
      this.label1.Size = new Size(69, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Cash Margin:";
      this.label9.AutoSize = true;
      this.label9.Location = new Point(618, 3);
      this.label9.Name = "label9";
      this.label9.Size = new Size(78, 13);
      this.label9.TabIndex = 8;
      this.label9.Text = "NET MTM P/L";
      this.lblNetmtm.AutoSize = true;
      this.lblNetmtm.Location = new Point(720, 3);
      this.lblNetmtm.Name = "lblNetmtm";
      this.lblNetmtm.Size = new Size(13, 13);
      this.lblNetmtm.TabIndex = 9;
      this.lblNetmtm.Text = "0";
      this.label11.AutoSize = true;
      this.label11.Location = new Point(822, 3);
      this.label11.Name = "label11";
      this.label11.Size = new Size(54, 13);
      this.label11.TabIndex = 10;
      this.label11.Text = "Avail. Bal.";
      this.lblAvaiBal.AutoSize = true;
      this.lblAvaiBal.Location = new Point(924, 3);
      this.lblAvaiBal.Name = "lblAvaiBal";
      this.lblAvaiBal.Size = new Size(13, 13);
      this.lblAvaiBal.TabIndex = 11;
      this.lblAvaiBal.Text = "0";
      this.automaticUpdater1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.automaticUpdater1.ContainerForm = (Form) this;
      this.automaticUpdater1.GUID = "feea0a99-3326-4c41-8e0b-e106a82c77ce";
      this.automaticUpdater1.Location = new Point(998, 27);
      this.automaticUpdater1.Name = "automaticUpdater1";
      this.automaticUpdater1.Size = new Size(16, 16);
      this.automaticUpdater1.TabIndex = 6;
      this.automaticUpdater1.ToolStripItem = (ToolStripItem) this.ChkUpdatesMenuItem;
      this.automaticUpdater1.wyUpdateCommandline = (string) null;
      this.toolStrip1.Items.AddRange(new ToolStripItem[13]
      {
        (ToolStripItem) this.btnLogin,
        (ToolStripItem) this.btnLogout,
        (ToolStripItem) this.btnChangePass,
        (ToolStripItem) this.btnLockWorkstation,
        (ToolStripItem) this.btnExit,
        (ToolStripItem) this.toolStripSeparator8,
        (ToolStripItem) this.btnBuyOrder,
        (ToolStripItem) this.btnSellOrder,
        (ToolStripItem) this.toolStripSeparator12,
        (ToolStripItem) this.btnNetPosition,
        (ToolStripItem) this.btnPendingOrders,
        (ToolStripItem) this.btnCancOrders,
        (ToolStripItem) this.toolStripSeparator14
      });
      this.toolStrip1.Location = new Point(0, 49);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1026, 25);
      this.toolStrip1.TabIndex = 9;
      this.toolStrip1.Text = "toolStrip1";
      this.btnLogin.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnLogin.Image = (Image) componentResourceManager.GetObject("btnLogin.Image");
      this.btnLogin.ImageTransparentColor = Color.Magenta;
      this.btnLogin.Name = "btnLogin";
      this.btnLogin.Size = new Size(23, 22);
      this.btnLogin.Text = "Login";
      this.btnLogin.Click += new EventHandler(this.btnLogin_Click);
      this.btnLogout.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnLogout.Image = (Image) componentResourceManager.GetObject("btnLogout.Image");
      this.btnLogout.ImageTransparentColor = Color.Magenta;
      this.btnLogout.Name = "btnLogout";
      this.btnLogout.Size = new Size(23, 22);
      this.btnLogout.Text = "Logout";
      this.btnLogout.Click += new EventHandler(this.btnLogout_Click);
      this.btnChangePass.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnChangePass.Image = (Image) componentResourceManager.GetObject("btnChangePass.Image");
      this.btnChangePass.ImageTransparentColor = Color.Magenta;
      this.btnChangePass.Name = "btnChangePass";
      this.btnChangePass.Size = new Size(23, 22);
      this.btnChangePass.Text = "Change Password";
      this.btnChangePass.Click += new EventHandler(this.btnChangePass_Click);
      this.btnLockWorkstation.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnLockWorkstation.Image = (Image) componentResourceManager.GetObject("btnLockWorkstation.Image");
      this.btnLockWorkstation.ImageTransparentColor = Color.Magenta;
      this.btnLockWorkstation.Name = "btnLockWorkstation";
      this.btnLockWorkstation.Size = new Size(23, 22);
      this.btnLockWorkstation.Text = "Lock Workstation";
      this.btnLockWorkstation.Click += new EventHandler(this.btnLockWorkstation_Click);
      this.btnExit.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnExit.Image = (Image) componentResourceManager.GetObject("btnExit.Image");
      this.btnExit.ImageTransparentColor = Color.Magenta;
      this.btnExit.Name = "btnExit";
      this.btnExit.Size = new Size(23, 22);
      this.btnExit.Text = "Exit";
      this.btnExit.Click += new EventHandler(this.btnExit_Click);
      this.toolStripSeparator8.Name = "toolStripSeparator8";
      this.toolStripSeparator8.Size = new Size(6, 25);
      this.btnBuyOrder.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnBuyOrder.Image = (Image) componentResourceManager.GetObject("btnBuyOrder.Image");
      this.btnBuyOrder.ImageTransparentColor = Color.Magenta;
      this.btnBuyOrder.Name = "btnBuyOrder";
      this.btnBuyOrder.Size = new Size(23, 22);
      this.btnBuyOrder.Text = "Buy";
      this.btnBuyOrder.Click += new EventHandler(this.btnBuyOrder_Click);
      this.btnSellOrder.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSellOrder.Image = (Image) componentResourceManager.GetObject("btnSellOrder.Image");
      this.btnSellOrder.ImageTransparentColor = Color.Magenta;
      this.btnSellOrder.Name = "btnSellOrder";
      this.btnSellOrder.Size = new Size(23, 22);
      this.btnSellOrder.Text = "Sell";
      this.toolStripSeparator12.Name = "toolStripSeparator12";
      this.toolStripSeparator12.Size = new Size(6, 25);
      this.btnNetPosition.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnNetPosition.Image = (Image) componentResourceManager.GetObject("btnNetPosition.Image");
      this.btnNetPosition.ImageTransparentColor = Color.Magenta;
      this.btnNetPosition.Name = "btnNetPosition";
      this.btnNetPosition.Size = new Size(23, 22);
      this.btnNetPosition.Text = "Net Position";
      this.btnNetPosition.Click += new EventHandler(this.btnNetPosition_Click);
      this.btnPendingOrders.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnPendingOrders.Image = (Image) componentResourceManager.GetObject("btnPendingOrders.Image");
      this.btnPendingOrders.ImageTransparentColor = Color.Magenta;
      this.btnPendingOrders.Name = "btnPendingOrders";
      this.btnPendingOrders.Size = new Size(23, 22);
      this.btnPendingOrders.Text = "Pending Orders";
      this.btnPendingOrders.Click += new EventHandler(this.btnPendingOrders_Click);
      this.btnCancOrders.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnCancOrders.Image = (Image) componentResourceManager.GetObject("btnCancOrders.Image");
      this.btnCancOrders.ImageTransparentColor = Color.Magenta;
      this.btnCancOrders.Name = "btnCancOrders";
      this.btnCancOrders.Size = new Size(23, 22);
      this.btnCancOrders.Text = "Cancelled Orders";
      this.btnCancOrders.Click += new EventHandler(this.btnCancOrders_Click);
      this.toolStripSeparator14.Name = "toolStripSeparator14";
      this.toolStripSeparator14.Size = new Size(6, 25);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1026, 733);
      this.Controls.Add((Control) this.toolStrip1);
      this.Controls.Add((Control) this.automaticUpdater1);
      this.Controls.Add((Control) this.panel1);
      this.Controls.Add((Control) this.statusStrip);
      this.Controls.Add((Control) this.toolStrip);
      this.Controls.Add((Control) this.menuStrip);
      this.IsMdiContainer = true;
      this.KeyPreview = true;
      this.MainMenuStrip = this.menuStrip;
      this.Name = nameof (Dashboard);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.WindowState = FormWindowState.Maximized;
      this.FormClosing += new FormClosingEventHandler(this.Dashboard_FormClosing);
      this.Load += new EventHandler(this.Dashboard_Load);
      this.KeyUp += new KeyEventHandler(this.Dashboard_KeyUp);
      this.menuStrip.ResumeLayout(false);
      this.menuStrip.PerformLayout();
      this.toolStrip.ResumeLayout(false);
      this.toolStrip.PerformLayout();
      this.statusStrip.ResumeLayout(false);
      this.statusStrip.PerformLayout();
      this.panel1.ResumeLayout(false);
      this.PositionPanel.ResumeLayout(false);
      this.PositionPanel.PerformLayout();
      ((ISupportInitialize) this.automaticUpdater1).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
