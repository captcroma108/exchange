﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmContracts
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmContracts : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public SqlConnection conn;
    private DataGridView dgvContracts;
    private GroupBox groupBox1;
    private TextBox txtSymDescp;
    private Label label6;
    private TextBox txtStatus;
    private Label label5;
    private TextBox txtLotsize;
    private Label label4;
    private TextBox txtExp;
    private Label label3;
    private TextBox txtSym;
    private Label label2;
    private TextBox txtExch;
    private Label label1;
    private TextBox txtDPR;
    private Label label7;
    private GroupBox groupBox2;
    private Button btnView;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private Button btnUpload;
    private CheckBox chkSelectall;
    private GroupBox groupBox3;
    private Button btnSaveIntraTiming;
    private Button btnViewIntraTiming;
    private ComboBox cmbSS;
    private ComboBox cmbMM;
    private ComboBox cmbHH;
    private RadioButton rdoNseOpt;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Expiry;
    private DataGridViewTextBoxColumn Lotsize;
    private DataGridViewTextBoxColumn DPR;
    private DataGridViewTextBoxColumn Status;
    private DataGridViewTextBoxColumn SymbolDesp;
    private DataGridViewCheckBoxColumn ColSelect;

    public frmContracts(Dashboard dash, SqlConnection db)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = db;
      this.Icon = this.objdash.ico;
    }

    public void LoadContracts()
    {
      this.dgvContracts.Rows.Clear();
      this.cmbHH.SelectedIndex = 0;
      this.cmbMM.SelectedIndex = 0;
      this.cmbSS.SelectedIndex = 0;
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.rdoMcx.Visible = true;
            break;
          case 2:
            this.rdoNseFut.Visible = true;
            break;
          case 3:
            this.rdoncdex.Visible = true;
            break;
          case 4:
            this.rdoNsecurr.Visible = true;
            break;
          case 5:
            this.rdoNseOpt.Visible = true;
            break;
        }
      }
    }

    private void btnUpload_Click(object sender, EventArgs e)
    {
      bool flag = true;
      OpenFileDialog openFileDialog1 = new OpenFileDialog();
      openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      openFileDialog1.Title = "Upload File";
      openFileDialog1.FilterIndex = 1;
      using (OpenFileDialog openFileDialog2 = openFileDialog1)
      {
        if (openFileDialog2.ShowDialog() == DialogResult.Cancel)
          return;
        int num = 0;
        try
        {
          using (StreamReader streamReader = new StreamReader(openFileDialog2.FileName))
          {
            while (true)
            {
              string str1 = streamReader.ReadLine();
              if (flag)
                flag = false;
              else if (str1 != null)
              {
                string[] strArray = str1.Split(',');
                string str2 = strArray[0];
                DateTime dateTime = Convert.ToDateTime(strArray[1]);
                int int32_1 = Convert.ToInt32(strArray[2]);
                int int32_2 = Convert.ToInt32(strArray[3]);
                int int32_3 = Convert.ToInt32(strArray[4]);
                int int32_4 = Convert.ToInt32(strArray[5]);
                string key = strArray[6];
                Contracts contracts = new Contracts();
                if (!this.objdash._Symconctracts.ContainsKey(key))
                {
                  using (SqlCommand sqlCommand = new SqlCommand(string.Format("Insert into Contracts (Symbol,Expiry,Lotsize,Tickprice,Exch,Status,SymDescription) Values  ('{0}','{1}',{2},{3},{4},{5},'{6}')", (object) str2, (object) dateTime.ToString("yyyy-MM-dd"), (object) int32_1, (object) int32_2, (object) int32_3, (object) int32_4, (object) key), this.conn))
                    num += sqlCommand.ExecuteNonQuery();
                  this.objdash._Symconctracts.Add(key, contracts);
                }
                Thread.Sleep(50);
                Application.DoEvents();
              }
              else
                break;
            }
            this.objdash.DisplayMessage(string.Format("{0} Symbols Uploaded Successfully!!", (object) num), 1);
          }
        }
        catch
        {
        }
      }
    }

    private int GetExch()
    {
      if (this.rdoMcx.Checked)
        return 1;
      if (this.rdoNseFut.Checked)
        return 2;
      if (this.rdoncdex.Checked)
        return 3;
      return this.rdoNsecurr.Checked ? 4 : 1;
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      int exch = this.GetExch();
      this.dgvContracts.Rows.Clear();
      int index = 0;
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
      {
        Contracts contracts = keyValuePair.Value;
        this.dgvContracts.Rows.Add();
        this.dgvContracts.Rows[index].Cells[0].Value = (object) this.objdash.GetStringExch(contracts.exch);
        this.dgvContracts.Rows[index].Cells[1].Value = (object) contracts.symbol;
        this.dgvContracts.Rows[index].Cells[2].Value = (object) contracts.expiry;
        this.dgvContracts.Rows[index].Cells[3].Value = (object) contracts.lotsize;
        this.dgvContracts.Rows[index].Cells[4].Value = (object) 0;
        this.dgvContracts.Rows[index].Cells[5].Value = (object) contracts.status;
        this.dgvContracts.Rows[index].Cells[6].Value = (object) contracts.SymDesp;
        this.dgvContracts.Rows[index].Cells[7].Value = (object) false;
        ++index;
      }
    }

    private void dgvContracts_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
      if (e.ColumnIndex != 7)
        return;
      this.dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = !this.dgvContracts.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.Equals((object) false) ? (object) false : (object) true;
    }

    private void chkSelectall_CheckedChanged(object sender, EventArgs e)
    {
      if (this.dgvContracts.Rows.Count > 0)
      {
        if (this.chkSelectall.Checked)
        {
          for (int index = 0; index < this.dgvContracts.Rows.Count; ++index)
            this.dgvContracts.Rows[index].Cells[7].Value = (object) true;
        }
        else
        {
          for (int index = 0; index < this.dgvContracts.Rows.Count; ++index)
            this.dgvContracts.Rows[index].Cells[7].Value = (object) false;
        }
      }
      else
      {
        int num = (int) MessageBox.Show("No Contracts to Select.", "Contract Management", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
      }
    }

    private void btnViewIntraTiming_Click(object sender, EventArgs e)
    {
      int exch = this.GetExch();
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select * from IntraSqOffTiming where Clientcode = '" + this.objdash.objinfo.clientcode + "' and Exch = " + (object) exch ?? "", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(2))
            {
              DateTime dateTime = Convert.ToDateTime(sqlDataReader.GetValue(2));
              this.cmbHH.SelectedIndex = dateTime.Hour;
              this.cmbMM.SelectedIndex = dateTime.Minute;
              this.cmbSS.SelectedIndex = dateTime.Second;
            }
          }
        }
      }
    }

    private void btnSaveIntraTiming_Click(object sender, EventArgs e)
    {
      int exch = this.GetExch();
      DateTime dateTime;
      ref DateTime local = ref dateTime;
      DateTime now = DateTime.Now;
      int year = now.Year;
      now = DateTime.Now;
      int month = now.Month;
      now = DateTime.Now;
      int day = now.Day;
      int int32_1 = Convert.ToInt32(this.cmbHH.Text);
      int int32_2 = Convert.ToInt32(this.cmbMM.Text);
      int int32_3 = Convert.ToInt32(this.cmbSS.Text);
      local = new DateTime(year, month, day, int32_1, int32_2, int32_3);
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      SqlCommand sqlCommand1 = new SqlCommand("SaveIntraSqTime", conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.objdash.objinfo.clientcode);
        sqlCommand2.Parameters.AddWithValue("@exch", (object) exch);
        sqlCommand2.Parameters.AddWithValue("@timestamp", (object) dateTime);
        try
        {
          sqlCommand2.ExecuteNonQuery();
          this.objdash.DisplayMessage("Intraday Sq-Off Timing saved successfully!!", 1);
        }
        catch
        {
          this.objdash.DisplayMessage("Unable to save Intraday Sq-Off Timing", 3);
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvContracts = new DataGridView();
      this.Exch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Expiry = new DataGridViewTextBoxColumn();
      this.Lotsize = new DataGridViewTextBoxColumn();
      this.DPR = new DataGridViewTextBoxColumn();
      this.Status = new DataGridViewTextBoxColumn();
      this.SymbolDesp = new DataGridViewTextBoxColumn();
      this.ColSelect = new DataGridViewCheckBoxColumn();
      this.groupBox1 = new GroupBox();
      this.txtDPR = new TextBox();
      this.label7 = new Label();
      this.txtSymDescp = new TextBox();
      this.label6 = new Label();
      this.txtStatus = new TextBox();
      this.label5 = new Label();
      this.txtLotsize = new TextBox();
      this.label4 = new Label();
      this.txtExp = new TextBox();
      this.label3 = new Label();
      this.txtSym = new TextBox();
      this.label2 = new Label();
      this.txtExch = new TextBox();
      this.label1 = new Label();
      this.groupBox2 = new GroupBox();
      this.rdoNseOpt = new RadioButton();
      this.btnView = new Button();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.chkSelectall = new CheckBox();
      this.btnUpload = new Button();
      this.groupBox3 = new GroupBox();
      this.btnSaveIntraTiming = new Button();
      this.btnViewIntraTiming = new Button();
      this.cmbSS = new ComboBox();
      this.cmbMM = new ComboBox();
      this.cmbHH = new ComboBox();
      ((ISupportInitialize) this.dgvContracts).BeginInit();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      this.dgvContracts.AllowUserToAddRows = false;
      this.dgvContracts.AllowUserToDeleteRows = false;
      this.dgvContracts.AllowUserToOrderColumns = true;
      this.dgvContracts.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvContracts.BackgroundColor = Color.White;
      this.dgvContracts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvContracts.Columns.AddRange((DataGridViewColumn) this.Exch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Expiry, (DataGridViewColumn) this.Lotsize, (DataGridViewColumn) this.DPR, (DataGridViewColumn) this.Status, (DataGridViewColumn) this.SymbolDesp, (DataGridViewColumn) this.ColSelect);
      this.dgvContracts.Location = new Point(5, 84);
      this.dgvContracts.Name = "dgvContracts";
      this.dgvContracts.ReadOnly = true;
      this.dgvContracts.RowHeadersVisible = false;
      this.dgvContracts.Size = new Size(696, 451);
      this.dgvContracts.TabIndex = 0;
      this.dgvContracts.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgvContracts_CellMouseClick);
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Expiry.HeaderText = "Expiry";
      this.Expiry.Name = "Expiry";
      this.Expiry.ReadOnly = true;
      this.Lotsize.HeaderText = "Lotsize";
      this.Lotsize.Name = "Lotsize";
      this.Lotsize.ReadOnly = true;
      this.Lotsize.Width = 80;
      this.DPR.HeaderText = "DPR";
      this.DPR.Name = "DPR";
      this.DPR.ReadOnly = true;
      this.DPR.Width = 60;
      this.Status.HeaderText = "Status";
      this.Status.Name = "Status";
      this.Status.ReadOnly = true;
      this.Status.Width = 80;
      this.SymbolDesp.HeaderText = "SymbolDescription";
      this.SymbolDesp.Name = "SymbolDesp";
      this.SymbolDesp.ReadOnly = true;
      this.ColSelect.HeaderText = "Select";
      this.ColSelect.Name = "ColSelect";
      this.ColSelect.ReadOnly = true;
      this.ColSelect.Resizable = DataGridViewTriState.True;
      this.ColSelect.SortMode = DataGridViewColumnSortMode.Automatic;
      this.ColSelect.Width = 60;
      this.groupBox1.Controls.Add((Control) this.txtDPR);
      this.groupBox1.Controls.Add((Control) this.label7);
      this.groupBox1.Controls.Add((Control) this.txtSymDescp);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.txtStatus);
      this.groupBox1.Controls.Add((Control) this.label5);
      this.groupBox1.Controls.Add((Control) this.txtLotsize);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.txtExp);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.txtSym);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.txtExch);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(697, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(676, 57);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Contract Detail";
      this.groupBox1.Visible = false;
      this.txtDPR.Location = new Point(354, 29);
      this.txtDPR.Name = "txtDPR";
      this.txtDPR.Size = new Size(80, 20);
      this.txtDPR.TabIndex = 13;
      this.label7.AutoSize = true;
      this.label7.Location = new Point(351, 13);
      this.label7.Name = "label7";
      this.label7.Size = new Size(30, 13);
      this.label7.TabIndex = 12;
      this.label7.Text = "DPR";
      this.txtSymDescp.Location = new Point(526, 29);
      this.txtSymDescp.Name = "txtSymDescp";
      this.txtSymDescp.Size = new Size(80, 20);
      this.txtSymDescp.TabIndex = 11;
      this.label6.AutoSize = true;
      this.label6.Location = new Point(523, 13);
      this.label6.Name = "label6";
      this.label6.Size = new Size(97, 13);
      this.label6.TabIndex = 10;
      this.label6.Text = "Symbol Description";
      this.txtStatus.Location = new Point(440, 29);
      this.txtStatus.Name = "txtStatus";
      this.txtStatus.Size = new Size(80, 20);
      this.txtStatus.TabIndex = 9;
      this.label5.AutoSize = true;
      this.label5.Location = new Point(442, 13);
      this.label5.Name = "label5";
      this.label5.Size = new Size(37, 13);
      this.label5.TabIndex = 8;
      this.label5.Text = "Status";
      this.txtLotsize.Location = new Point(268, 29);
      this.txtLotsize.Name = "txtLotsize";
      this.txtLotsize.Size = new Size(80, 20);
      this.txtLotsize.TabIndex = 7;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(265, 13);
      this.label4.Name = "label4";
      this.label4.Size = new Size(40, 13);
      this.label4.TabIndex = 6;
      this.label4.Text = "Lotsize";
      this.txtExp.Location = new Point(182, 29);
      this.txtExp.Name = "txtExp";
      this.txtExp.Size = new Size(80, 20);
      this.txtExp.TabIndex = 5;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(179, 13);
      this.label3.Name = "label3";
      this.label3.Size = new Size(35, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Expiry";
      this.txtSym.Location = new Point(96, 29);
      this.txtSym.Name = "txtSym";
      this.txtSym.Size = new Size(80, 20);
      this.txtSym.TabIndex = 3;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(93, 13);
      this.label2.Name = "label2";
      this.label2.Size = new Size(41, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Symbol";
      this.txtExch.Location = new Point(10, 29);
      this.txtExch.Name = "txtExch";
      this.txtExch.Size = new Size(80, 20);
      this.txtExch.TabIndex = 1;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(7, 13);
      this.label1.Name = "label1";
      this.label1.Size = new Size(55, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Exchange";
      this.groupBox2.Controls.Add((Control) this.rdoNseOpt);
      this.groupBox2.Controls.Add((Control) this.btnView);
      this.groupBox2.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox2.Controls.Add((Control) this.rdoncdex);
      this.groupBox2.Controls.Add((Control) this.rdoNseFut);
      this.groupBox2.Controls.Add((Control) this.rdoMcx);
      this.groupBox2.Location = new Point(4, 7);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(431, 54);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Exchange";
      this.rdoNseOpt.AutoSize = true;
      this.rdoNseOpt.Location = new Point(282, 19);
      this.rdoNseOpt.Name = "rdoNseOpt";
      this.rdoNseOpt.Size = new Size(69, 17);
      this.rdoNseOpt.TabIndex = 5;
      this.rdoNseOpt.Text = "NSEOPT";
      this.rdoNseOpt.UseVisualStyleBackColor = true;
      this.rdoNseOpt.Visible = false;
      this.btnView.Location = new Point(358, 16);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(67, 23);
      this.btnView.TabIndex = 4;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(200, 19);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 3;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(134, 19);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 2;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoncdex.Visible = false;
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(62, 19);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 1;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(10, 19);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 0;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.chkSelectall.AutoSize = true;
      this.chkSelectall.Location = new Point(613, 65);
      this.chkSelectall.Name = "chkSelectall";
      this.chkSelectall.Size = new Size(37, 17);
      this.chkSelectall.TabIndex = 64;
      this.chkSelectall.Text = "All";
      this.chkSelectall.UseVisualStyleBackColor = true;
      this.chkSelectall.CheckedChanged += new EventHandler(this.chkSelectall_CheckedChanged);
      this.btnUpload.Location = new Point(687, 144);
      this.btnUpload.Name = "btnUpload";
      this.btnUpload.Size = new Size(75, 23);
      this.btnUpload.TabIndex = 5;
      this.btnUpload.Text = "Upload";
      this.btnUpload.UseVisualStyleBackColor = true;
      this.btnUpload.Visible = false;
      this.btnUpload.Click += new EventHandler(this.btnUpload_Click);
      this.groupBox3.Controls.Add((Control) this.btnSaveIntraTiming);
      this.groupBox3.Controls.Add((Control) this.btnViewIntraTiming);
      this.groupBox3.Controls.Add((Control) this.cmbSS);
      this.groupBox3.Controls.Add((Control) this.cmbMM);
      this.groupBox3.Controls.Add((Control) this.cmbHH);
      this.groupBox3.Location = new Point(438, 7);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(263, 54);
      this.groupBox3.TabIndex = 65;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Intraday Sq-off Timings(HH:MM:SS)";
      this.btnSaveIntraTiming.Location = new Point(207, 16);
      this.btnSaveIntraTiming.Name = "btnSaveIntraTiming";
      this.btnSaveIntraTiming.Size = new Size(54, 23);
      this.btnSaveIntraTiming.TabIndex = 6;
      this.btnSaveIntraTiming.Text = "Save";
      this.btnSaveIntraTiming.UseVisualStyleBackColor = true;
      this.btnSaveIntraTiming.Click += new EventHandler(this.btnSaveIntraTiming_Click);
      this.btnViewIntraTiming.Location = new Point(150, 16);
      this.btnViewIntraTiming.Name = "btnViewIntraTiming";
      this.btnViewIntraTiming.Size = new Size(54, 23);
      this.btnViewIntraTiming.TabIndex = 5;
      this.btnViewIntraTiming.Text = "View";
      this.btnViewIntraTiming.UseVisualStyleBackColor = true;
      this.btnViewIntraTiming.Click += new EventHandler(this.btnViewIntraTiming_Click);
      this.cmbSS.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSS.FormattingEnabled = true;
      this.cmbSS.Items.AddRange(new object[60]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23",
        (object) "24",
        (object) "25",
        (object) "26",
        (object) "27",
        (object) "28",
        (object) "29",
        (object) "30",
        (object) "31",
        (object) "32",
        (object) "33",
        (object) "34",
        (object) "35",
        (object) "36",
        (object) "37",
        (object) "38",
        (object) "39",
        (object) "40",
        (object) "41",
        (object) "42",
        (object) "43",
        (object) "44",
        (object) "45",
        (object) "46",
        (object) "47",
        (object) "48",
        (object) "49",
        (object) "50",
        (object) "51",
        (object) "52",
        (object) "53",
        (object) "54",
        (object) "55",
        (object) "56",
        (object) "57",
        (object) "58",
        (object) "59"
      });
      this.cmbSS.Location = new Point(103, 18);
      this.cmbSS.Name = "cmbSS";
      this.cmbSS.Size = new Size(41, 21);
      this.cmbSS.TabIndex = 5;
      this.cmbMM.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbMM.FormattingEnabled = true;
      this.cmbMM.Items.AddRange(new object[60]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23",
        (object) "24",
        (object) "25",
        (object) "26",
        (object) "27",
        (object) "28",
        (object) "29",
        (object) "30",
        (object) "31",
        (object) "32",
        (object) "33",
        (object) "34",
        (object) "35",
        (object) "36",
        (object) "37",
        (object) "38",
        (object) "39",
        (object) "40",
        (object) "41",
        (object) "42",
        (object) "43",
        (object) "44",
        (object) "45",
        (object) "46",
        (object) "47",
        (object) "48",
        (object) "49",
        (object) "50",
        (object) "51",
        (object) "52",
        (object) "53",
        (object) "54",
        (object) "55",
        (object) "56",
        (object) "57",
        (object) "58",
        (object) "59"
      });
      this.cmbMM.Location = new Point(59, 18);
      this.cmbMM.Name = "cmbMM";
      this.cmbMM.Size = new Size(41, 21);
      this.cmbMM.TabIndex = 4;
      this.cmbHH.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbHH.FormattingEnabled = true;
      this.cmbHH.Items.AddRange(new object[24]
      {
        (object) "00",
        (object) "01",
        (object) "02",
        (object) "03",
        (object) "04",
        (object) "05",
        (object) "06",
        (object) "07",
        (object) "08",
        (object) "09",
        (object) "10",
        (object) "11",
        (object) "12",
        (object) "13",
        (object) "14",
        (object) "15",
        (object) "16",
        (object) "17",
        (object) "18",
        (object) "19",
        (object) "20",
        (object) "21",
        (object) "22",
        (object) "23"
      });
      this.cmbHH.Location = new Point(16, 18);
      this.cmbHH.Name = "cmbHH";
      this.cmbHH.Size = new Size(41, 21);
      this.cmbHH.TabIndex = 3;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(706, 538);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.btnUpload);
      this.Controls.Add((Control) this.chkSelectall);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.dgvContracts);
      this.Name = nameof (frmContracts);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Contracts";
      ((ISupportInitialize) this.dgvContracts).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
