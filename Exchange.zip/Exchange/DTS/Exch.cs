﻿// Decompiled with JetBrains decompiler
// Type: DTS.Exch
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

namespace DTS
{
  public enum Exch
  {
    MCX = 1,
    NSEFUT = 2,
    NCDEX = 3,
    NSECURR = 4,
    NSEOPT = 5,
    NSECASH = 6,
    FOREX = 7,
  }
}
