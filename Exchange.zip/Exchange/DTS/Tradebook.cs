﻿// Decompiled with JetBrains decompiler
// Type: DTS.Tradebook
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class Tradebook : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public MWColumnProfile objColProfile;
    public DataGridView dgvTradeBook;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripLabel toolStripLabel1;
    private ToolStripComboBox cmbExch;
    private ToolStripLabel toolStripLabel4;
    private ToolStripComboBox cmbSymbol;
    private ToolStripLabel toolStripLabel5;
    private ToolStripComboBox cmbBuySell;
    private ToolStripLabel toolStripLabel3;
    private ToolStripComboBox cmbTraderid;
    private ToolStripButton btnSearch;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem exportToCsvToolStripMenuItem;
    private ToolStripMenuItem exportToTxtToolStripMenuItem;
    private ToolStripMenuItem copyToolStripMenuItem;
    private ToolStripMenuItem toolStripColPrfl;
    private ToolStripMenuItem toolStripSaveCols;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem toolStripGrid;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripMenuItem nSEFUTToolStripMenuItem;
    private ToolStripMenuItem nSEOPTToolStripMenuItem;
    private ToolStripMenuItem mCXToolStripMenuItem;
    private ToolStripMenuItem exportToSaudaToolStripMenuItem;
    private ToolStripMenuItem exportToLogicsToolStripMenuItem;
    private DataGridViewTextBoxColumn Clientcode;
    private DataGridViewTextBoxColumn ColName;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn ColExpiry;
    private DataGridViewTextBoxColumn Productype;
    private DataGridViewTextBoxColumn ColexeType;
    private DataGridViewTextBoxColumn Buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn ColOrdPrice;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn UserRemarks;
    private DataGridViewTextBoxColumn TradedBy;
    private DataGridViewTextBoxColumn Orderno;
    private DataGridViewTextBoxColumn colIp;

    public Tradebook(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
    }

    public void LoadTrades()
    {
      this.Location = Settings.Default.TrdbookLocation;
      this._ColumnOnOff = new Dictionary<string, int>();
      string trdColumnProfile = Settings.Default.TrdColumnProfile;
      if (trdColumnProfile != string.Empty)
      {
        string str1 = trdColumnProfile;
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ '_' };
          string[] strArray = str2.Split(chArray2);
          int int32 = Convert.ToInt32(strArray[1]);
          switch (Convert.ToInt32(strArray[2]))
          {
            case 0:
              this.dgvTradeBook.Columns[int32].Visible = false;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 0);
                break;
              }
              break;
            case 1:
              this.dgvTradeBook.Columns[int32].Visible = true;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 1);
                break;
              }
              break;
          }
        }
      }
      else
      {
        for (int index = 0; index < this.dgvTradeBook.Columns.Count; ++index)
        {
          if (!this._ColumnOnOff.ContainsKey(this.dgvTradeBook.Columns[index].HeaderText))
          {
            if (this.dgvTradeBook.Columns[index].Visible)
              this._ColumnOnOff.Add(this.dgvTradeBook.Columns[index].HeaderText, 1);
            else
              this._ColumnOnOff.Add(this.dgvTradeBook.Columns[index].HeaderText, 0);
          }
        }
      }
    }

    private void clearCombobox()
    {
      this.cmbclientcode.Items.Clear();
      this.cmbclientcode.Items.Add((object) "");
      this.cmbExch.Items.Clear();
      this.cmbExch.Items.Add((object) "");
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "");
      this.cmbTraderid.Items.Clear();
      this.cmbTraderid.Items.Add((object) "");
    }

    private void FillCombobox(Orders objord, string exch)
    {
      if (!this.cmbclientcode.Items.Contains((object) objord.accountNo))
        this.cmbclientcode.Items.Add((object) objord.accountNo);
      if (!this.cmbExch.Items.Contains((object) exch))
        this.cmbExch.Items.Add((object) exch);
      if (!this.cmbSymbol.Items.Contains((object) objord.symbol))
        this.cmbSymbol.Items.Add((object) objord.symbol);
      if (this.cmbTraderid.Items.Contains((object) objord.TraderId))
        return;
      this.cmbTraderid.Items.Add((object) objord.TraderId);
    }

    public void LoadSpecficSymbol(string symbol)
    {
      this.dgvTradeBook.Rows.Clear();
      List<Orders> tradeOrders = this.objmain.GetTradeOrders(1);
      this.clearCombobox();
      List<double> doubleList = new List<double>();
      foreach (Orders objord in tradeOrders)
      {
        if (!doubleList.Contains(objord.OrderNo))
        {
          doubleList.Add(objord.OrderNo);
          string str = objord.TraderId;
          if (this.objmain.GetUserinfo(objord.TraderId).name != null && str.ToUpper() != "ADMIN")
            str = this.objmain.GetUserinfo(objord.TraderId).name;
          string name = this.objmain.GetUserinfo(objord.accountNo).name;
          if (objord.symbol == symbol)
          {
            string[] strArray = objord.symbol.Split(' ');
            int index = this.dgvTradeBook.Rows.Add();
            this.FillCombobox(objord, Utils.GetExch(objord.ExchangeTypeID));
            this.dgvTradeBook.Rows[index].Cells[0].Value = (object) objord.accountNo;
            this.dgvTradeBook.Rows[index].Cells[1].Value = (object) name;
            this.dgvTradeBook.Rows[index].Cells[2].Value = (object) Utils.GetExch(objord.ExchangeTypeID);
            this.dgvTradeBook.Rows[index].Cells[3].Value = (object) strArray[0];
            this.dgvTradeBook.Rows[index].Cells[4].Value = (object) strArray[1];
            this.dgvTradeBook.Rows[index].Cells[5].Value = (object) Utils.GetProductType(objord.ProductType);
            this.dgvTradeBook.Rows[index].Cells[6].Value = objord.Exectype != 1 ? (object) "MKT" : (object) "LMT";
            this.dgvTradeBook.Rows[index].Cells[7].Value = (object) Utils.GetBuysell(objord.BuySell);
            this.dgvTradeBook.Rows[index].Cells[8].Value = (object) objord.Ordeqty;
            this.dgvTradeBook.Rows[index].Cells[9].Value = (object) objord.OrdePrice;
            this.dgvTradeBook.Rows[index].Cells[10].Value = (object) objord.ExecPrice;
            this.dgvTradeBook.Rows[index].Cells[11].Value = (object) Utils.GetValidity(objord.ValidityType);
            this.dgvTradeBook.Rows[index].Cells[12].Value = (object) objord.LastModified.ToString("HH:mm:ss");
            this.dgvTradeBook.Rows[index].Cells[13].Value = (object) objord.UserRemark;
            this.dgvTradeBook.Rows[index].Cells[14].Value = (object) str;
            this.dgvTradeBook.Rows[index].Cells[15].Value = (object) objord.OrderNo;
            this.dgvTradeBook.Rows[index].Cells[16].Value = (object) objord.ipAddress;
            if (objord.BuySell == 1)
              this.dgvTradeBook.Rows[index].DefaultCellStyle.BackColor = Color.LightBlue;
            else
              this.dgvTradeBook.Rows[index].DefaultCellStyle.BackColor = Color.Pink;
          }
        }
      }
    }

    private void dgvTradeBook_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvTradeBook.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvTradeBook, client.X, client.Y);
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvTradeBook.Rows)
          row.Visible = true;
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && (str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text) && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(this.cmbclientcode.Text == string.Empty) || !(this.cmbExch.Text == string.Empty) || (!(this.cmbSymbol.Text == string.Empty) || !(this.cmbBuySell.Text == string.Empty)) || !(this.cmbTraderid.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    private void Tradebook_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.C)
        this.cmbclientcode.Focus();
      else if (e.KeyCode == Keys.E)
        this.cmbExch.Focus();
      else if (e.KeyCode == Keys.S)
        this.cmbSymbol.Focus();
      else if (e.KeyCode == Keys.T)
      {
        this.cmbTraderid.Focus();
      }
      else
      {
        if (e.KeyCode != Keys.Escape)
          return;
        Settings.Default.TrdbookLocation = this.Location;
        Settings.Default.Save();
        this.Close();
      }
    }

    private void exportToCsvToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvTradeBook, false);
    }

    private void copyToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Clipboard.SetDataObject((object) this.dgvTradeBook.GetClipboardContent());
    }

    private void exportToTxtToolStripMenuItem_Click(object sender, EventArgs e)
    {
    }

    private void toolStripColPrfl_Click(object sender, EventArgs e)
    {
    }

    private void toolStripSaveCols_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvTradeBook.Columns.Count; ++index)
        str = !this.dgvTradeBook.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvTradeBook.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvTradeBook.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.TrdColumnProfile = str;
      Settings.Default.Save();
    }

    private void toolStripGrid_Click(object sender, EventArgs e)
    {
      if (this.toolStripGrid.Checked)
        this.dgvTradeBook.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
      else
        this.dgvTradeBook.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void nSEFUTToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExportText(this.dgvTradeBook, this.objmain, "NSEFUT", false);
    }

    private void nSEOPTToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExportText(this.dgvTradeBook, this.objmain, "NSEOPT", false);
    }

    private void mCXToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExportText(this.dgvTradeBook, this.objmain, "MCX", false);
    }

    private void exportToSaudaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExporttoSauda(this.dgvTradeBook, this.objmain, false);
    }

    private void exportToLogicsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExporttoLogics(this.dgvTradeBook, false, this.objmain);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Tradebook));
      this.dgvTradeBook = new DataGridView();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.toolStripLabel1 = new ToolStripLabel();
      this.cmbExch = new ToolStripComboBox();
      this.toolStripLabel4 = new ToolStripLabel();
      this.cmbSymbol = new ToolStripComboBox();
      this.toolStripLabel5 = new ToolStripLabel();
      this.cmbBuySell = new ToolStripComboBox();
      this.toolStripLabel3 = new ToolStripLabel();
      this.cmbTraderid = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.toolStripColPrfl = new ToolStripMenuItem();
      this.toolStripSaveCols = new ToolStripMenuItem();
      this.toolStripSeparator2 = new ToolStripSeparator();
      this.toolStripGrid = new ToolStripMenuItem();
      this.toolStripSeparator3 = new ToolStripSeparator();
      this.copyToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator1 = new ToolStripSeparator();
      this.exportToCsvToolStripMenuItem = new ToolStripMenuItem();
      this.exportToTxtToolStripMenuItem = new ToolStripMenuItem();
      this.nSEFUTToolStripMenuItem = new ToolStripMenuItem();
      this.nSEOPTToolStripMenuItem = new ToolStripMenuItem();
      this.mCXToolStripMenuItem = new ToolStripMenuItem();
      this.exportToSaudaToolStripMenuItem = new ToolStripMenuItem();
      this.exportToLogicsToolStripMenuItem = new ToolStripMenuItem();
      this.Clientcode = new DataGridViewTextBoxColumn();
      this.ColName = new DataGridViewTextBoxColumn();
      this.Exch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.ColExpiry = new DataGridViewTextBoxColumn();
      this.Productype = new DataGridViewTextBoxColumn();
      this.ColexeType = new DataGridViewTextBoxColumn();
      this.Buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.ColOrdPrice = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.UserRemarks = new DataGridViewTextBoxColumn();
      this.TradedBy = new DataGridViewTextBoxColumn();
      this.Orderno = new DataGridViewTextBoxColumn();
      this.colIp = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvTradeBook).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.contextMenuStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvTradeBook.AllowUserToAddRows = false;
      this.dgvTradeBook.AllowUserToDeleteRows = false;
      this.dgvTradeBook.AllowUserToOrderColumns = true;
      this.dgvTradeBook.AllowUserToResizeRows = false;
      this.dgvTradeBook.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvTradeBook.BackgroundColor = Color.White;
      this.dgvTradeBook.CellBorderStyle = DataGridViewCellBorderStyle.None;
      gridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle1.BackColor = SystemColors.Control;
      gridViewCellStyle1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle1.ForeColor = Color.Black;
      gridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle1.WrapMode = DataGridViewTriState.True;
      this.dgvTradeBook.ColumnHeadersDefaultCellStyle = gridViewCellStyle1;
      this.dgvTradeBook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvTradeBook.Columns.AddRange((DataGridViewColumn) this.Clientcode, (DataGridViewColumn) this.ColName, (DataGridViewColumn) this.Exch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.ColExpiry, (DataGridViewColumn) this.Productype, (DataGridViewColumn) this.ColexeType, (DataGridViewColumn) this.Buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.ColOrdPrice, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Time, (DataGridViewColumn) this.UserRemarks, (DataGridViewColumn) this.TradedBy, (DataGridViewColumn) this.Orderno, (DataGridViewColumn) this.colIp);
      gridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle2.BackColor = SystemColors.Window;
      gridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle2.ForeColor = Color.Black;
      gridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle2.WrapMode = DataGridViewTriState.False;
      this.dgvTradeBook.DefaultCellStyle = gridViewCellStyle2;
      this.dgvTradeBook.Location = new Point(0, 28);
      this.dgvTradeBook.MultiSelect = false;
      this.dgvTradeBook.Name = "dgvTradeBook";
      this.dgvTradeBook.ReadOnly = true;
      this.dgvTradeBook.RowHeadersVisible = false;
      this.dgvTradeBook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvTradeBook.Size = new Size(1028, 262);
      this.dgvTradeBook.TabIndex = 0;
      this.dgvTradeBook.MouseClick += new MouseEventHandler(this.dgvTradeBook_MouseClick);
      this.toolStrip1.Items.AddRange(new ToolStripItem[11]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.toolStripLabel1,
        (ToolStripItem) this.cmbExch,
        (ToolStripItem) this.toolStripLabel4,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.toolStripLabel5,
        (ToolStripItem) this.cmbBuySell,
        (ToolStripItem) this.toolStripLabel3,
        (ToolStripItem) this.cmbTraderid,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1028, 25);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.toolStripLabel1.Name = "toolStripLabel1";
      this.toolStripLabel1.Size = new Size(57, 22);
      this.toolStripLabel1.Text = "Exchange";
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(121, 25);
      this.toolStripLabel4.Name = "toolStripLabel4";
      this.toolStripLabel4.Size = new Size(47, 22);
      this.toolStripLabel4.Text = "Symbol";
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(160, 25);
      this.cmbSymbol.Sorted = true;
      this.toolStripLabel5.Name = "toolStripLabel5";
      this.toolStripLabel5.Size = new Size(25, 22);
      this.toolStripLabel5.Text = "B/S";
      this.cmbBuySell.Items.AddRange(new object[2]
      {
        (object) "B",
        (object) "S"
      });
      this.cmbBuySell.Name = "cmbBuySell";
      this.cmbBuySell.Size = new Size(121, 25);
      this.toolStripLabel3.Name = "toolStripLabel3";
      this.toolStripLabel3.Size = new Size(51, 22);
      this.toolStripLabel3.Text = "Traderid";
      this.cmbTraderid.Name = "cmbTraderid";
      this.cmbTraderid.Size = new Size(121, 25);
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[11]
      {
        (ToolStripItem) this.toolStripColPrfl,
        (ToolStripItem) this.toolStripSaveCols,
        (ToolStripItem) this.toolStripSeparator2,
        (ToolStripItem) this.toolStripGrid,
        (ToolStripItem) this.toolStripSeparator3,
        (ToolStripItem) this.copyToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator1,
        (ToolStripItem) this.exportToCsvToolStripMenuItem,
        (ToolStripItem) this.exportToTxtToolStripMenuItem,
        (ToolStripItem) this.exportToSaudaToolStripMenuItem,
        (ToolStripItem) this.exportToLogicsToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(182, 198);
      this.toolStripColPrfl.Name = "toolStripColPrfl";
      this.toolStripColPrfl.Size = new Size(181, 22);
      this.toolStripColPrfl.Text = "Column Profile";
      this.toolStripColPrfl.Visible = false;
      this.toolStripColPrfl.Click += new EventHandler(this.toolStripColPrfl_Click);
      this.toolStripSaveCols.Name = "toolStripSaveCols";
      this.toolStripSaveCols.Size = new Size(181, 22);
      this.toolStripSaveCols.Text = "Save Column Profile";
      this.toolStripSaveCols.Visible = false;
      this.toolStripSaveCols.Click += new EventHandler(this.toolStripSaveCols_Click);
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new Size(178, 6);
      this.toolStripSeparator2.Visible = false;
      this.toolStripGrid.CheckOnClick = true;
      this.toolStripGrid.Name = "toolStripGrid";
      this.toolStripGrid.Size = new Size(181, 22);
      this.toolStripGrid.Text = "Grid";
      this.toolStripGrid.Click += new EventHandler(this.toolStripGrid_Click);
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new Size(178, 6);
      this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
      this.copyToolStripMenuItem.Size = new Size(181, 22);
      this.copyToolStripMenuItem.Text = "Copy";
      this.copyToolStripMenuItem.Click += new EventHandler(this.copyToolStripMenuItem_Click);
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new Size(178, 6);
      this.exportToCsvToolStripMenuItem.Name = "exportToCsvToolStripMenuItem";
      this.exportToCsvToolStripMenuItem.Size = new Size(181, 22);
      this.exportToCsvToolStripMenuItem.Text = "Export to Csv";
      this.exportToCsvToolStripMenuItem.Click += new EventHandler(this.exportToCsvToolStripMenuItem_Click);
      this.exportToTxtToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[3]
      {
        (ToolStripItem) this.nSEFUTToolStripMenuItem,
        (ToolStripItem) this.nSEOPTToolStripMenuItem,
        (ToolStripItem) this.mCXToolStripMenuItem
      });
      this.exportToTxtToolStripMenuItem.Name = "exportToTxtToolStripMenuItem";
      this.exportToTxtToolStripMenuItem.Size = new Size(181, 22);
      this.exportToTxtToolStripMenuItem.Text = "Export to Txt";
      this.exportToTxtToolStripMenuItem.Click += new EventHandler(this.exportToTxtToolStripMenuItem_Click);
      this.nSEFUTToolStripMenuItem.Name = "nSEFUTToolStripMenuItem";
      this.nSEFUTToolStripMenuItem.Size = new Size(118, 22);
      this.nSEFUTToolStripMenuItem.Text = "NSEFUT";
      this.nSEFUTToolStripMenuItem.Click += new EventHandler(this.nSEFUTToolStripMenuItem_Click);
      this.nSEOPTToolStripMenuItem.Name = "nSEOPTToolStripMenuItem";
      this.nSEOPTToolStripMenuItem.Size = new Size(118, 22);
      this.nSEOPTToolStripMenuItem.Text = "NSEOPT";
      this.nSEOPTToolStripMenuItem.Click += new EventHandler(this.nSEOPTToolStripMenuItem_Click);
      this.mCXToolStripMenuItem.Name = "mCXToolStripMenuItem";
      this.mCXToolStripMenuItem.Size = new Size(118, 22);
      this.mCXToolStripMenuItem.Text = "MCX";
      this.mCXToolStripMenuItem.Click += new EventHandler(this.mCXToolStripMenuItem_Click);
      this.exportToSaudaToolStripMenuItem.Name = "exportToSaudaToolStripMenuItem";
      this.exportToSaudaToolStripMenuItem.Size = new Size(181, 22);
      this.exportToSaudaToolStripMenuItem.Text = "Export to Sauda";
      this.exportToSaudaToolStripMenuItem.Click += new EventHandler(this.exportToSaudaToolStripMenuItem_Click);
      this.exportToLogicsToolStripMenuItem.Name = "exportToLogicsToolStripMenuItem";
      this.exportToLogicsToolStripMenuItem.Size = new Size(181, 22);
      this.exportToLogicsToolStripMenuItem.Text = "Export to Logics";
      this.exportToLogicsToolStripMenuItem.Click += new EventHandler(this.exportToLogicsToolStripMenuItem_Click);
      this.Clientcode.HeaderText = "ClientCode";
      this.Clientcode.Name = "Clientcode";
      this.Clientcode.ReadOnly = true;
      this.Clientcode.Width = 90;
      this.ColName.HeaderText = "Name";
      this.ColName.Name = "ColName";
      this.ColName.ReadOnly = true;
      this.ColName.Width = 90;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.ColExpiry.HeaderText = "Expiry";
      this.ColExpiry.Name = "ColExpiry";
      this.ColExpiry.ReadOnly = true;
      this.ColExpiry.Width = 80;
      this.Productype.HeaderText = "ProductType";
      this.Productype.Name = "Productype";
      this.Productype.ReadOnly = true;
      this.Productype.Width = 60;
      this.ColexeType.HeaderText = "ExecType";
      this.ColexeType.Name = "ColexeType";
      this.ColexeType.ReadOnly = true;
      this.ColexeType.Width = 50;
      this.Buysell.HeaderText = "B/S";
      this.Buysell.Name = "Buysell";
      this.Buysell.ReadOnly = true;
      this.Buysell.Width = 40;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 50;
      this.ColOrdPrice.HeaderText = "Ord.Price";
      this.ColOrdPrice.Name = "ColOrdPrice";
      this.ColOrdPrice.ReadOnly = true;
      this.ColOrdPrice.Width = 60;
      this.Price.HeaderText = "Exec.Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 60;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 80;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 70;
      this.UserRemarks.HeaderText = "UserRemarks";
      this.UserRemarks.Name = "UserRemarks";
      this.UserRemarks.ReadOnly = true;
      this.UserRemarks.Width = 70;
      this.TradedBy.HeaderText = "TradedBy";
      this.TradedBy.Name = "TradedBy";
      this.TradedBy.ReadOnly = true;
      this.Orderno.HeaderText = "OrderNo";
      this.Orderno.Name = "Orderno";
      this.Orderno.ReadOnly = true;
      this.colIp.HeaderText = "IpAddress";
      this.colIp.Name = "colIp";
      this.colIp.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1028, 290);
      this.Controls.Add((Control) this.dgvTradeBook);
      this.Controls.Add((Control) this.toolStrip1);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (Tradebook);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "View Trades";
      this.KeyUp += new KeyEventHandler(this.Tradebook_KeyUp);
      ((ISupportInitialize) this.dgvTradeBook).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.contextMenuStrip1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
