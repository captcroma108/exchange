﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmContractStatusView
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmContractStatusView : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private SortedDictionary<string, int> _contractstatus;
    private GroupBox groupBox1;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private DataGridView dgvContractStatus;
    private DataGridViewTextBoxColumn colSymbol;
    private DataGridViewTextBoxColumn colStatus;
    private Label label1;
    private TextBox txtSearch;
    private Label label2;
    private ComboBox cmbClientcode;
    private Label clientcode;

    public frmContractStatusView(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
      this._contractstatus = new SortedDictionary<string, int>();
      this.cmbClientcode.Visible = false;
    }

    private void txtSearch_TextChanged(object sender, EventArgs e)
    {
      if (this.txtSearch.Text.Length > 0)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvContractStatus.Rows)
        {
          if (row.Cells[0].Value.ToString().StartsWith(this.txtSearch.Text))
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvContractStatus.Rows)
          row.Visible = true;
      }
    }

    private void LoadSymbols(int exch)
    {
      this.dgvContractStatus.Rows.Clear();
      List<string> stringList = new List<string>();
      if (this.objdash.objinfo.usertype == 4)
      {
        if (this.objdash._ClientContractStatus.ContainsKey(this.objdash.objinfo.clientcode))
        {
          this._contractstatus = this.objdash.GetContractStatus(this.objdash.objinfo.clientcode, exch);
          this.clientcode.Text = this.objdash.objinfo.clientcode;
        }
        else
        {
          this._contractstatus = this.objdash.GetContractStatus(this.objdash.objinfo.createdby, exch);
          this.clientcode.Text = "DEFAULT";
        }
      }
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
      {
        if (!stringList.Contains(keyValuePair.Value.SymDesp))
        {
          int index = this.dgvContractStatus.Rows.Add();
          this.dgvContractStatus.Rows[index].Cells[0].Value = (object) keyValuePair.Value.SymDesp;
          this.dgvContractStatus.Rows[index].Cells[1].Value = !this._contractstatus.ContainsKey(keyValuePair.Value.SymDesp) ? (object) "Active" : (object) Utils.GetStringStatus(this._contractstatus[keyValuePair.Value.SymDesp]);
          stringList.Add(keyValuePair.Value.SymDesp);
        }
      }
    }

    public void LoadWindow()
    {
      this.cmbClientcode.Items.Clear();
      if (this.objdash.objinfo.usertype == 3)
      {
        this.label2.Visible = true;
        this.cmbClientcode.Items.Add((object) "Default");
        this.cmbClientcode.Items.Add((object) this.objdash.objinfo.clientcode);
        foreach (object lstAccount in this.objdash._lstAccounts)
          this.cmbClientcode.Items.Add(lstAccount);
      }
      else
      {
        this.cmbClientcode.Items.Add((object) "Default");
        this.cmbClientcode.Items.Add((object) this.objdash.objinfo.clientcode);
        this.label2.Visible = true;
      }
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.rdoMcx.Visible = true;
            break;
          case 2:
            this.rdoNseFut.Visible = true;
            break;
          case 3:
            this.rdoncdex.Visible = true;
            break;
          case 4:
            this.rdoNsecurr.Visible = true;
            break;
        }
      }
    }

    private void rdoMcx_Click(object sender, EventArgs e)
    {
      this.rdoMcx.Checked = true;
      this.LoadSymbols(1);
    }

    private void rdoNseFut_Click(object sender, EventArgs e)
    {
      this.rdoNseFut.Checked = true;
      this.LoadSymbols(2);
    }

    private void rdoncdex_Click(object sender, EventArgs e)
    {
      this.rdoncdex.Checked = true;
      this.LoadSymbols(3);
    }

    private void rdoNsecurr_Click(object sender, EventArgs e)
    {
      this.rdoNsecurr.Checked = true;
      this.LoadSymbols(4);
    }

    private void cmbClientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmbClientcode.SelectedIndex <= -1)
        return;
      if (this.rdoMcx.Checked)
        this.LoadSymbols(1);
      else if (this.rdoNseFut.Checked)
        this.LoadSymbols(2);
      else if (this.rdoncdex.Checked)
        this.LoadSymbols(3);
      else
        this.LoadSymbols(4);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.dgvContractStatus = new DataGridView();
      this.colSymbol = new DataGridViewTextBoxColumn();
      this.colStatus = new DataGridViewTextBoxColumn();
      this.label1 = new Label();
      this.txtSearch = new TextBox();
      this.label2 = new Label();
      this.cmbClientcode = new ComboBox();
      this.clientcode = new Label();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgvContractStatus).BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoncdex);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(5, 7);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(269, 52);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchanges";
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(190, 21);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 7;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNsecurr.Click += new EventHandler(this.rdoNsecurr_Click);
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(126, 21);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 6;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoncdex.Visible = false;
      this.rdoncdex.Click += new EventHandler(this.rdoncdex_Click);
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(56, 21);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 5;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoNseFut.Click += new EventHandler(this.rdoNseFut_Click);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(5, 21);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 4;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.rdoMcx.Click += new EventHandler(this.rdoMcx_Click);
      this.dgvContractStatus.AllowUserToAddRows = false;
      this.dgvContractStatus.AllowUserToDeleteRows = false;
      this.dgvContractStatus.AllowUserToOrderColumns = true;
      this.dgvContractStatus.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvContractStatus.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvContractStatus.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvContractStatus.Columns.AddRange((DataGridViewColumn) this.colSymbol, (DataGridViewColumn) this.colStatus);
      this.dgvContractStatus.Location = new Point(5, 109);
      this.dgvContractStatus.MultiSelect = false;
      this.dgvContractStatus.Name = "dgvContractStatus";
      this.dgvContractStatus.ReadOnly = true;
      this.dgvContractStatus.RowHeadersVisible = false;
      this.dgvContractStatus.Size = new Size(269, 347);
      this.dgvContractStatus.TabIndex = 2;
      this.colSymbol.HeaderText = "Symbol";
      this.colSymbol.Name = "colSymbol";
      this.colSymbol.ReadOnly = true;
      this.colStatus.HeaderText = "Status";
      this.colStatus.Name = "colStatus";
      this.colStatus.ReadOnly = true;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(6, 91);
      this.label1.Name = "label1";
      this.label1.Size = new Size(44, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "Search:";
      this.txtSearch.CharacterCasing = CharacterCasing.Upper;
      this.txtSearch.Location = new Point(56, 88);
      this.txtSearch.Name = "txtSearch";
      this.txtSearch.Size = new Size(100, 20);
      this.txtSearch.TabIndex = 4;
      this.txtSearch.TextChanged += new EventHandler(this.txtSearch_TextChanged);
      this.label2.AutoSize = true;
      this.label2.Location = new Point(7, 65);
      this.label2.Name = "label2";
      this.label2.Size = new Size(61, 13);
      this.label2.TabIndex = 5;
      this.label2.Text = "ClientCode:";
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(173, 62);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(87, 21);
      this.cmbClientcode.TabIndex = 6;
      this.cmbClientcode.Visible = false;
      this.cmbClientcode.SelectedIndexChanged += new EventHandler(this.cmbClientcode_SelectedIndexChanged);
      this.clientcode.AutoSize = true;
      this.clientcode.Location = new Point(74, 65);
      this.clientcode.Name = "clientcode";
      this.clientcode.Size = new Size(32, 13);
      this.clientcode.TabIndex = 7;
      this.clientcode.Text = "client";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(281, 457);
      this.Controls.Add((Control) this.clientcode);
      this.Controls.Add((Control) this.cmbClientcode);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.txtSearch);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.dgvContractStatus);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmContractStatusView);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Contract Status View";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgvContractStatus).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
