﻿// Decompiled with JetBrains decompiler
// Type: DTS.ModifyOrderTrade
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class ModifyOrderTrade : Form
  {
    public Dashboard objdash = (Dashboard) null;
    public SqlConnection conn = (SqlConnection) null;
    private int rowindex = 0;
    private string cc = string.Empty;
    private IContainer components = (IContainer) null;
    private DataGridView dataGridView1;
    private TextBox txtorderno;
    private TextBox txtprice;
    private GroupBox groupBox1;
    private Button btnmodify;
    private Button btninsert;
    private Button btnclear;
    private Button btnrefresh;
    private ComboBox cmbSymbol;
    private ComboBox cmbexch;
    private Button btndelete;
    private ComboBox cmbclient;
    private NumericUpDown txtqty;
    private ComboBox txtbuysell;
    private GroupBox groupBox2;
    private RadioButton rdoTrades;
    private RadioButton rdoOrders;
    private TextBox txtName;
    private DateTimePicker dtTimestamp;
    private CheckBox chkGroupwise;
    private ComboBox cmbValidity;
    private DataGridViewTextBoxColumn Clientcode;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Expiry;
    private DataGridViewTextBoxColumn Orderno;
    private DataGridViewTextBoxColumn buy_sell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn TradeTime;
    private DataGridViewTextBoxColumn Validity;

    public ModifyOrderTrade(Dashboard objdash, SqlConnection conn)
    {
      this.InitializeComponent();
      this.objdash = objdash;
      this.conn = conn;
      this.Icon = objdash.ico;
    }

    private void ModifyOrderTrade_Load(object sender, EventArgs e)
    {
      this.txtbuysell.SelectedIndex = 0;
      this.cmbexch.Items.Clear();
      this.cmbexch.Items.Add((object) "--Exch--");
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
        this.cmbexch.Items.Add((object) Utils.GetExch(exchconctract.Key));
      this.ClearControls();
      if (this.objdash.objinfo.usertype == 3 || this.objdash.objinfo.usertype == 4)
      {
        this.btnmodify.Enabled = false;
        this.btndelete.Enabled = false;
      }
      else
      {
        this.btnmodify.Enabled = true;
        this.btndelete.Enabled = true;
      }
      this.dtTimestamp.Value = this.objdash.servertime;
      DateTime servertime = this.objdash.servertime;
      this.dtTimestamp.MinDate = servertime.AddMinutes(-600.0);
      this.dtTimestamp.MaxDate = servertime.AddMinutes(5.0);
    }

    private void cmbSymbol_Enter(object sender, EventArgs e)
    {
      this.cmbSymbol.Items.Clear();
      if (this.cmbexch.Text != string.Empty)
      {
        if (this.objdash._Exchconctracts.Count <= 0 || !this.objdash._Exchconctracts.ContainsKey(Utils.GetIntExch(this.cmbexch.Text)))
          return;
        SortedDictionary<string, Contracts> exchconctract = this.objdash._Exchconctracts[Utils.GetIntExch(this.cmbexch.Text)];
        this.cmbSymbol.Items.Add((object) "-- Symbol --");
        foreach (KeyValuePair<string, Contracts> keyValuePair in exchconctract)
          this.cmbSymbol.Items.Add((object) keyValuePair.Key);
        this.cmbSymbol.SelectedIndex = 0;
      }
      else
        this.objdash.DisplayMessage("Select Exch", 2);
    }

    private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1)
        return;
      this.rowindex = e.RowIndex;
      if (this.rdoOrders.Checked)
        this.btninsert.Enabled = true;
      this.cmbclient.Items.Clear();
      this.cmbclient.Items.Add((object) this.dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
      this.cmbclient.SelectedIndex = 0;
      this.cmbexch.Items.Clear();
      this.cmbexch.Items.Add((object) this.dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());
      this.cmbexch.SelectedIndex = 0;
      this.cmbSymbol.Items.Add((object) this.dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString());
      this.cmbSymbol.SelectedItem = (object) this.dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
      this.txtorderno.Text = this.dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
      this.txtbuysell.Text = this.dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
      this.txtqty.Text = this.dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
      this.txtprice.Text = this.dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
      this.dtTimestamp.Text = this.dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
      if (this.dataGridView1.Rows[e.RowIndex].Cells[9].Value != null)
        this.cmbValidity.Text = this.dataGridView1.Rows[e.RowIndex].Cells[9].Value.ToString();
      this.cmbclient.Enabled = false;
      this.cmbexch.Enabled = false;
      this.cmbSymbol.Enabled = true;
      this.txtorderno.ReadOnly = true;
      this.cmbValidity.Enabled = false;
    }

    private void ClearControls()
    {
      this.cmbclient.Enabled = true;
      this.cmbexch.Enabled = true;
      this.cmbSymbol.Enabled = true;
      this.txtorderno.Enabled = true;
      this.txtqty.Enabled = true;
      this.txtprice.Enabled = true;
      this.txtbuysell.Enabled = true;
      this.btnmodify.Enabled = true;
      this.btndelete.Enabled = true;
      this.rdoOrders.Enabled = true;
      this.txtqty.Value = Decimal.One;
      this.txtorderno.Text = string.Empty;
      this.txtprice.Text = string.Empty;
      this.cmbSymbol.Items.Clear();
      this.cmbclient.Items.Clear();
      this.cmbclient.Items.Add((object) "-- ALL --");
      for (int index = 0; index < this.objdash._lstAccounts.Count; ++index)
        this.cmbclient.Items.Add((object) this.objdash._lstAccounts[index]);
      if (this.cmbclient.Items.Count > -1)
        this.cmbclient.SelectedIndex = 0;
      this.cmbexch.Items.Clear();
      this.cmbexch.Items.Add((object) "--Exch--");
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
        this.cmbexch.Items.Add((object) Utils.GetExch(exchconctract.Key));
    }

    private void btnrefresh_Click(object sender, EventArgs e)
    {
      this.cmbValidity.Enabled = false;
      string cmdText = string.Empty;
      this.dataGridView1.Rows.Clear();
      if (this.cmbclient.Text == "-- ALL --")
      {
        if (this.rdoTrades.Checked)
        {
          if (this.objdash.claccounts.Length <= 0)
            return;
          cmdText = "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol, Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  Price, TimeStamp from Trade where Clientcode in (" + this.objdash.claccounts + ")";
        }
        else
        {
          if (this.objdash.claccounts.Length <= 0)
            return;
          cmdText = "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol, Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  OrdPrice, LastModified,Validity from Orders where Clientcode in (" + this.objdash.claccounts + ") and OrdStatus = 2";
        }
      }
      else if (this.cmbclient.Text != "-- ALL --")
      {
        string text = this.cmbclient.Text;
        cmdText = !this.rdoTrades.Checked ? "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol,Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  OrdPrice, LastModified,Validity from Orders where Clientcode in ('" + text + "')and OrdStatus = 2" : "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol, Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  Price, TimeStamp from Trade where Clientcode in ('" + text + "')";
      }
      int index = 0;
      if (cmdText.Length <= 0)
        return;
      using (SqlCommand sqlCommand = new SqlCommand(cmdText, this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            this.dataGridView1.Rows.Add();
            if (!sqlDataReader.IsDBNull(0))
              this.dataGridView1.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(0);
            if (!sqlDataReader.IsDBNull(1))
              this.dataGridView1.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
              this.dataGridView1.Rows[index].Cells[2].Value = (object) sqlDataReader.GetString(2);
            if (!sqlDataReader.IsDBNull(3))
              this.dataGridView1.Rows[index].Cells[4].Value = (object) sqlDataReader.GetValue(3).ToString();
            if (!sqlDataReader.IsDBNull(4))
              this.dataGridView1.Rows[index].Cells[5].Value = (object) sqlDataReader.GetValue(4).ToString();
            if (!sqlDataReader.IsDBNull(5))
              this.dataGridView1.Rows[index].Cells[6].Value = (object) sqlDataReader.GetInt32(5);
            if (!sqlDataReader.IsDBNull(6))
              this.dataGridView1.Rows[index].Cells[7].Value = (object) sqlDataReader.GetValue(6).ToString();
            if (!sqlDataReader.IsDBNull(7))
              this.dataGridView1.Rows[index].Cells[8].Value = (object) sqlDataReader.GetValue(7).ToString();
            if (!this.rdoTrades.Checked && !sqlDataReader.IsDBNull(8))
              this.dataGridView1.Rows[index].Cells[9].Value = sqlDataReader.GetInt32(8) != 1 ? (object) "Day" : (object) "Carryforward";
            ++index;
          }
        }
      }
    }

    private void btnmodify_Click(object sender, EventArgs e)
    {
      if (this.txtorderno.Text != string.Empty)
      {
        if (!this.ValidateControls())
          return;
        string text1 = this.cmbValidity.Text;
        this.cmbValidity.Enabled = false;
        int num1 = 1;
        string text2 = this.txtbuysell.Text;
        if (!(text2 == "BUY"))
        {
          if (text2 == "SELL")
            num1 = 2;
        }
        else
          num1 = 1;
        DateTime serverTime = this.objdash.GetServerTime();
        int num2 = !(text1 == "CARRYFORWARD") ? 2 : 1;
        object[] objArray1 = new object[6]
        {
          (object) this.txtprice.Text,
          (object) this.txtqty.Value,
          (object) num1,
          (object) this.cmbSymbol.Text,
          (object) this.txtorderno.Text,
          null
        };
        DateTime dateTime = this.dtTimestamp.Value;
        objArray1[5] = (object) dateTime.ToString("yyyy-MM-dd HH:mm:ss");
        string cmdText1 = string.Format("Update Trade SET Price = {0}, Qty = {1}, BuySell = {2},Symbol='{3}',TimeStamp='{5}' where OrderNo = {4}", objArray1);
        object[] objArray2 = new object[7]
        {
          (object) this.txtprice.Text,
          (object) this.txtprice.Text,
          (object) this.txtqty.Value,
          (object) num1,
          (object) this.cmbSymbol.Text,
          (object) this.txtorderno.Text,
          null
        };
        dateTime = this.dtTimestamp.Value;
        objArray2[6] = (object) dateTime.ToString("yyyy-MM-dd HH:mm:ss");
        string cmdText2 = string.Format("Update Orders SET OrdPrice = {0}, Price = {1}, Qty = {2}, BuySell = {3},Symbol='{4}',LastModified='{6}' where OrderNo = {5}", objArray2);
        string cmdText3 = string.Format("Update Orders SET OrdPrice = {0}, Qty = {1}, BuySell = {2},Lastmodified = '{3}',Symbol='{4}',Validity={6} where OrderNo = {5}", (object) this.txtprice.Text, (object) this.txtqty.Value, (object) num1, (object) serverTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text, (object) this.txtorderno.Text, (object) num2);
        if (this.rdoOrders.Checked)
        {
          using (SqlCommand sqlCommand = new SqlCommand(cmdText3, this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
            }
            catch
            {
            }
          }
        }
        else
        {
          using (SqlCommand sqlCommand = new SqlCommand(cmdText1, this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
            }
            catch
            {
            }
          }
          using (SqlCommand sqlCommand = new SqlCommand(cmdText2, this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
            }
            catch
            {
            }
          }
        }
        Trades objord = new Trades();
        objord.clientcode = this.cmbclient.Text;
        objord.Lastmodified = this.objdash.GetServerTime();
        this.dataGridView1.Rows[this.rowindex].Cells[5].Value = (object) this.txtbuysell.Text;
        this.dataGridView1.Rows[this.rowindex].Cells[6].Value = (object) this.txtqty.Value.ToString();
        this.dataGridView1.Rows[this.rowindex].Cells[7].Value = (object) this.txtprice.Text;
        string str = string.Format("  ORDER : {0} FUT, {1}  {2}  CarryForWard {3} {4}  N at Rs. {5} VALIDITY: CarryForward For CLI {6} MODIFY CONFIRMED", (object) this.cmbexch.Text, (object) this.txtorderno.Text, (object) this.txtbuysell.Text, (object) this.txtqty.Text, (object) this.cmbSymbol.Text, (object) this.txtprice.Text, (object) this.cmbclient.Text);
        this.objdash.clearMsgBoard();
        this.objdash.InsertMsgBoard(str, 1);
        this.objdash.SaveMessageLogs(str, objord);
        this.ClearControls();
      }
      else
        this.objdash.DisplayMessage("Select Trade to Modify.", 2);
      string cmdText = string.Empty;
      this.dataGridView1.Rows.Clear();
      if (this.cmbclient.Text == "-- ALL --")
      {
        if (this.rdoTrades.Checked)
        {
          if (this.objdash.claccounts.Length <= 0)
            return;
          cmdText = "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol, Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  Price, TimeStamp from Trade where Clientcode ='" + this.cc + "'";
        }
        else
        {
          if (this.objdash.claccounts.Length <= 0)
            return;
          cmdText = "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol, Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  OrdPrice, LastModified,Validity from Orders where Clientcode='" + this.cc + "'and OrdStatus = 2";
        }
      }
      else if (this.cmbclient.Text != "-- ALL --")
      {
        string text = this.cmbclient.Text;
        cmdText = !this.rdoTrades.Checked ? "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol,Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  OrdPrice, LastModified,Validity from Orders where Clientcode in ('" + text + "')and OrdStatus = 2" : "select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exch, Symbol, Orderno, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as buysell, Qty,  Price, TimeStamp from Trade where Clientcode in ('" + text + "')";
      }
      int index = 0;
      if (cmdText.Length <= 0)
        return;
      using (SqlCommand sqlCommand = new SqlCommand(cmdText, this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            this.dataGridView1.Rows.Add();
            if (!sqlDataReader.IsDBNull(0))
              this.dataGridView1.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(0);
            if (!sqlDataReader.IsDBNull(1))
              this.dataGridView1.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
              this.dataGridView1.Rows[index].Cells[2].Value = (object) sqlDataReader.GetString(2);
            if (!sqlDataReader.IsDBNull(3))
              this.dataGridView1.Rows[index].Cells[4].Value = (object) sqlDataReader.GetValue(3).ToString();
            if (!sqlDataReader.IsDBNull(4))
              this.dataGridView1.Rows[index].Cells[5].Value = (object) sqlDataReader.GetValue(4).ToString();
            if (!sqlDataReader.IsDBNull(5))
              this.dataGridView1.Rows[index].Cells[6].Value = (object) sqlDataReader.GetInt32(5);
            if (!sqlDataReader.IsDBNull(6))
              this.dataGridView1.Rows[index].Cells[7].Value = (object) sqlDataReader.GetValue(6).ToString();
            if (!sqlDataReader.IsDBNull(7))
              this.dataGridView1.Rows[index].Cells[8].Value = (object) sqlDataReader.GetValue(7).ToString();
            if (!this.rdoTrades.Checked && !sqlDataReader.IsDBNull(8))
              this.dataGridView1.Rows[this.rowindex].Cells[9].Value = sqlDataReader.GetInt32(8) != 1 ? (object) "Day" : (object) "Carryforward";
            ++index;
          }
        }
      }
      this.cmbexch.Items.Clear();
      this.cmbexch.Items.Add((object) "--Exch--");
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
        this.cmbexch.Items.Add((object) Utils.GetExch(exchconctract.Key));
    }

    private bool ValidateControls()
    {
      if (this.cmbclient.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Select Clientcode.", 2);
        return false;
      }
      if (this.cmbexch.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Select Exchange.", 2);
        return false;
      }
      if (this.cmbSymbol.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Select Symbol.", 2);
        return false;
      }
      if (this.txtbuysell.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter Buy/Sell.", 2);
        return false;
      }
      if (this.txtprice.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter Price.", 2);
        return false;
      }
      if (this.txtqty.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter Qty.", 2);
        return false;
      }
      if (this.chkGroupwise.Checked)
      {
        if (!this.objdash._UsertradeGrouping.ContainsKey(this.cmbclient.Text))
        {
          this.objdash.DisplayMessage("Group does not exists.", 2);
          return false;
        }
      }
      else if (!this.objdash._Userinformation.ContainsKey(this.cmbclient.Text))
      {
        this.objdash.DisplayMessage("Clientcode does not exists.", 2);
        return false;
      }
      return true;
    }

    private void btndelete_Click(object sender, EventArgs e)
    {
      if (this.txtorderno.Text != string.Empty)
      {
        if (this.rdoTrades.Checked)
        {
          SqlCommand sqlCommand1 = new SqlCommand("SaveDeleteTrade", this.conn);
          sqlCommand1.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand2 = sqlCommand1)
          {
            sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.cmbclient.Text);
            sqlCommand2.Parameters.AddWithValue("@symbol", (object) this.cmbSymbol.Text);
            sqlCommand2.Parameters.AddWithValue("@exch", (object) this.cmbexch.Text);
            sqlCommand2.Parameters.AddWithValue("@qty", (object) this.txtqty.Text);
            sqlCommand2.Parameters.AddWithValue("@price", (object) this.txtprice.Text);
            sqlCommand2.Parameters.AddWithValue("@orderno", (object) this.txtorderno.Text);
            sqlCommand2.Parameters.AddWithValue("@buysell", (object) this.txtbuysell.Text);
            sqlCommand2.Parameters.AddWithValue("@lastmodified", (object) DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff"));
            sqlCommand2.Parameters.AddWithValue("@ipaddress", (object) Utils.getPublicIPAddress());
            try
            {
              sqlCommand2.ExecuteNonQuery();
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to delete Trade", 3);
            }
          }
          using (SqlCommand sqlCommand2 = new SqlCommand(string.Format("Delete from Trade where OrderNo = {0}", (object) this.txtorderno.Text), this.conn))
          {
            try
            {
              sqlCommand2.ExecuteNonQuery();
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to delete Trade", 3);
            }
          }
        }
        string empty = string.Empty;
        using (SqlCommand sqlCommand = new SqlCommand(!this.rdoOrders.Checked ? string.Format("Delete from Orders where OrderNo = {0}", (object) this.txtorderno.Text) : string.Format("UPdate Orders SET OrdStatus = 3,LastModified = '{0}' where OrderNo = {1}", (object) DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.txtorderno.Text), this.conn))
        {
          try
          {
            sqlCommand.ExecuteNonQuery();
            this.dataGridView1.Rows.Remove(this.dataGridView1.Rows[this.rowindex]);
            this.ClearControls();
          }
          catch (Exception ex)
          {
            this.objdash.DisplayMessage("Unable to delete Trade", 3);
          }
        }
      }
      else
        this.objdash.DisplayMessage("Select Trade to delete.", 3);
    }

    private void btnclear_Click(object sender, EventArgs e)
    {
      this.ClearControls();
    }

    private void btninsert_Click(object sender, EventArgs e)
    {
      this.Validity.Visible = true;
      if (!this.ValidateControls())
        return;
      if (!this.chkGroupwise.Checked)
      {
        if (!this.objdash._ClientLimits.ContainsKey(this.cmbclient.Text))
        {
          this.objdash.DisplayMessage("Cash Margin not available to Insert offline Trade.", 2);
          return;
        }
        if (this.rdoTrades.Checked && this.cmbclient.Text == "")
        {
          this.objdash.DisplayMessage("Select Specific client code.", 2);
          return;
        }
        DateTime dtnow = new DateTime();
        if (!this.objdash.ValidateMarketTimeSaturday(this.cmbexch.Text, ref dtnow))
        {
          this.objdash.DisplayMessage(string.Format(" {0} Market is closed!!\n Cannot Insert trade on saturday", (object) this.cmbexch.Text), 2);
          this.objdash.insertSurveillanceMessages(this.cmbclient.Text, string.Format(" {0} Market is closed!! Cannot Insert trade on saturday", (object) this.cmbexch.Text), dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
          return;
        }
        Contracts contract = this.objdash.GetContract(this.cmbSymbol.Text);
        if (!this.objdash.ValidateContractStatus(contract.SymDesp, 2, this.cmbclient.Text, contract.exch))
        {
          this.objdash.DisplayMessage("Contract banned by Admin", 2);
          this.objdash.insertSurveillanceMessages(this.cmbclient.Text, "Contract " + this.cmbSymbol.Text + " banned, cannot trade in this Contract", dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
          return;
        }
        if (!this.objdash.ValidateContractStatus(contract.SymDesp, 3, this.cmbclient.Text, contract.exch))
        {
          this.objdash.DisplayMessage("Contract Suspended by Admin", 2);
          this.objdash.insertSurveillanceMessages(this.cmbclient.Text, "Contract " + this.cmbSymbol.Text + " Suspended, cannot trade in this Contract", dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
          return;
        }
        string empty1 = string.Empty;
        DateTime dateTime1;
        ref DateTime local = ref dateTime1;
        int year = this.dtTimestamp.Value.Year;
        int month = this.dtTimestamp.Value.Month;
        DateTime dateTime2 = this.dtTimestamp.Value;
        int day = dateTime2.Day;
        dateTime2 = this.dtTimestamp.Value;
        int hour = dateTime2.Hour;
        dateTime2 = this.dtTimestamp.Value;
        int minute = dateTime2.Minute;
        dateTime2 = this.dtTimestamp.Value;
        int second = dateTime2.Second;
        local = new DateTime(year, month, day, hour, minute, second);
        Trades trades = new Trades()
        {
          Symbol = this.cmbSymbol.Text,
          buysell = this.txtbuysell.SelectedIndex + 1,
          exch = (int) Enum.Parse(typeof (DTS.Exch), this.cmbexch.Text.ToUpper()),
          producttype = 1,
          qty = Convert.ToInt32(this.txtqty.Value),
          Ordprice = Convert.ToDecimal(this.txtprice.Text),
          price = Convert.ToDecimal(this.txtprice.Text),
          validity = (int) Enum.Parse(typeof (ValidityType), this.cmbValidity.Text.ToUpper()),
          userremarks = string.Empty,
          clientcode = this.cmbclient.Text,
          traderid = "Admin",
          Createon = dateTime1,
          Lastmodified = dateTime1,
          ordstatus = 1,
          isAdmin = 1
        };
        string empty2 = string.Empty;
        if (!this.rdoTrades.Checked)
        {
          trades.orderno = Convert.ToDouble(this.txtorderno.Text);
          try
          {
            Trades.InsertPendingTrade(trades, this.objdash);
            this.dataGridView1.Rows[this.rowindex].Visible = false;
            string str1 = " TRADE: " + Utils.GetExch(trades.exch) + ": ";
            string str2 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1}   N {2} LOTS/{3} LOTS  AT Rs. {4} FOR CLI {5} TRADE", (object) trades.orderno, (object) trades.Symbol, (object) trades.qty, (object) trades.qty, (object) trades.price, (object) trades.clientcode);
            this.objdash.clearMsgBoard();
            switch (trades.buysell)
            {
              case 1:
                string str3 = string.Format("{0} BOUGHT : {1}", (object) str1, (object) str2);
                this.objdash.InsertMsgBoard(str3, 1);
                this.objdash.SaveMessageLogs(str3, trades);
                break;
              case 2:
                string str4 = string.Format("{0} SOLD : {1}", (object) str1, (object) str2);
                this.objdash.InsertMsgBoard(str4, 1);
                this.objdash.SaveMessageLogs(str4, trades);
                break;
            }
          }
          catch
          {
            this.objdash.DisplayMessage("Unable to insert Trade", 3);
            return;
          }
          this.btninsert.Enabled = false;
        }
        else
        {
          try
          {
            trades.orderno = Trades.OrderNoGenerate();
            if (Trades.SaveOrder(trades, this.objdash.getConn()) & Trades.SaveTrade(trades, this.objdash.getConn()) & this.rdoTrades.Checked)
            {
              int index = this.dataGridView1.Rows.Add();
              this.dataGridView1.Rows[index].Cells[0].Value = (object) trades.clientcode;
              this.dataGridView1.Rows[index].Cells[1].Value = (object) this.cmbexch.Text;
              this.dataGridView1.Rows[index].Cells[2].Value = (object) trades.Symbol;
              this.dataGridView1.Rows[index].Cells[4].Value = (object) trades.orderno;
              this.dataGridView1.Rows[index].Cells[5].Value = (object) this.txtbuysell.Text;
              this.dataGridView1.Rows[index].Cells[6].Value = (object) this.txtqty.Value.ToString();
              this.dataGridView1.Rows[index].Cells[7].Value = (object) trades.price;
              this.dataGridView1.Rows[index].Cells[8].Value = (object) trades.Lastmodified;
              this.dataGridView1.Rows[index].Cells[9].Value = trades.validity != 1 ? (object) "Day" : (object) "Carryforward";
              this.objdash.DisplayConfirmationMsg(trades);
            }
          }
          catch
          {
            this.objdash.DisplayMessage("Unable to insert Trade", 3);
          }
        }
      }
      else if (this.objdash._UsertradeGrouping.ContainsKey(this.cmbclient.Text))
      {
        foreach (string key in this.objdash._UsertradeGrouping[this.cmbclient.Text])
        {
          if (this.objdash._ClientLimits.ContainsKey(key))
          {
            DateTime dateTime1;
            ref DateTime local = ref dateTime1;
            DateTime dateTime2 = this.dtTimestamp.Value;
            int year = dateTime2.Year;
            dateTime2 = this.dtTimestamp.Value;
            int month = dateTime2.Month;
            dateTime2 = this.dtTimestamp.Value;
            int day = dateTime2.Day;
            dateTime2 = this.dtTimestamp.Value;
            int hour = dateTime2.Hour;
            dateTime2 = this.dtTimestamp.Value;
            int minute = dateTime2.Minute;
            dateTime2 = this.dtTimestamp.Value;
            int second = dateTime2.Second;
            local = new DateTime(year, month, day, hour, minute, second);
            Trades trades = new Trades()
            {
              Symbol = this.cmbSymbol.Text,
              buysell = this.txtbuysell.SelectedIndex + 1,
              exch = (int) Enum.Parse(typeof (DTS.Exch), this.cmbexch.Text.ToUpper()),
              producttype = 1,
              qty = Convert.ToInt32(this.txtqty.Value),
              Ordprice = Convert.ToDecimal(this.txtprice.Text),
              price = Convert.ToDecimal(this.txtprice.Text),
              validity = 1,
              userremarks = string.Empty,
              clientcode = key,
              traderid = "Admin",
              Createon = dateTime1,
              Lastmodified = dateTime1,
              ordstatus = 1,
              isAdmin = 1
            };
            try
            {
              trades.orderno = Trades.OrderNoGenerate();
              if (Trades.SaveOrder(trades, this.objdash.getConn()) & Trades.SaveTrade(trades, this.objdash.getConn()) & this.rdoTrades.Checked)
              {
                int index = this.dataGridView1.Rows.Add();
                this.dataGridView1.Rows[index].Cells[0].Value = (object) trades.clientcode;
                this.dataGridView1.Rows[index].Cells[1].Value = (object) this.cmbexch.Text;
                this.dataGridView1.Rows[index].Cells[2].Value = (object) trades.Symbol;
                this.dataGridView1.Rows[index].Cells[4].Value = (object) trades.orderno;
                this.dataGridView1.Rows[index].Cells[5].Value = (object) this.txtbuysell.Text;
                this.dataGridView1.Rows[index].Cells[6].Value = (object) this.txtqty.Value.ToString();
                this.dataGridView1.Rows[index].Cells[7].Value = (object) trades.price;
                this.dataGridView1.Rows[index].Cells[8].Value = (object) trades.Lastmodified;
                this.dataGridView1.Rows[index].Cells[9].Value = trades.validity != 1 ? (object) "Day" : (object) "Carryforward";
                this.objdash.DisplayConfirmationMsg(trades);
              }
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to insert Trade", 3);
            }
            Thread.Sleep(5);
            Application.DoEvents();
          }
        }
      }
      this.cmbclient.Focus();
    }

    private void rdoOrders_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoOrders.Checked)
      {
        this.btninsert.Text = "Execute";
        this.btndelete.Text = "Cancel";
        this.btninsert.Enabled = false;
      }
      else
      {
        this.btninsert.Text = "Insert";
        this.btndelete.Text = "Delete";
      }
    }

    private void cmbclient_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.cmbValidity.Enabled = true;
      if (!this.objdash._Userinformation.ContainsKey(this.cmbclient.Text))
        return;
      Userinfo userinfo = this.objdash._Userinformation[this.cmbclient.Text];
      this.txtName.Text = userinfo.name;
      this.cc = userinfo.clientcode;
    }

    private void cmbclient_Leave(object sender, EventArgs e)
    {
      if (!this.objdash._Userinformation.ContainsKey(this.cmbclient.Text))
        return;
      Userinfo userinfo = this.objdash._Userinformation[this.cmbclient.Text];
      this.txtName.Text = userinfo.name;
      this.cc = userinfo.clientcode;
    }

    private void rdoTrades_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoTrades.Checked)
        return;
      this.btninsert.Enabled = true;
    }

    private void cmbSymbol_SelectedIndexChanged(object sender, EventArgs e)
    {
      Contracts contract = this.objdash.GetContract(this.cmbSymbol.Text);
      if (contract.exch == 2 || contract.exch == 5)
        this.txtqty.Value = (Decimal) contract.lotsize;
      else
        this.txtqty.Value = Decimal.One;
    }

    private void chkGroupwise_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkGroupwise.Checked)
      {
        this.cmbclient.Items.Clear();
        foreach (KeyValuePair<string, List<string>> keyValuePair in this.objdash._UsertradeGrouping)
          this.cmbclient.Items.Add((object) keyValuePair.Key);
        if (this.cmbclient.Items.Count > 0)
          this.cmbclient.SelectedIndex = 0;
        this.btnmodify.Enabled = false;
        this.btndelete.Enabled = false;
        this.rdoOrders.Enabled = false;
        this.rdoTrades.Checked = true;
      }
      else
        this.ClearControls();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dataGridView1 = new DataGridView();
      this.Clientcode = new DataGridViewTextBoxColumn();
      this.Exch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Expiry = new DataGridViewTextBoxColumn();
      this.Orderno = new DataGridViewTextBoxColumn();
      this.buy_sell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.TradeTime = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.txtorderno = new TextBox();
      this.txtprice = new TextBox();
      this.groupBox1 = new GroupBox();
      this.cmbValidity = new ComboBox();
      this.chkGroupwise = new CheckBox();
      this.dtTimestamp = new DateTimePicker();
      this.txtName = new TextBox();
      this.txtbuysell = new ComboBox();
      this.txtqty = new NumericUpDown();
      this.cmbclient = new ComboBox();
      this.cmbexch = new ComboBox();
      this.btninsert = new Button();
      this.cmbSymbol = new ComboBox();
      this.btnmodify = new Button();
      this.btnclear = new Button();
      this.btnrefresh = new Button();
      this.btndelete = new Button();
      this.groupBox2 = new GroupBox();
      this.rdoTrades = new RadioButton();
      this.rdoOrders = new RadioButton();
      ((ISupportInitialize) this.dataGridView1).BeginInit();
      this.groupBox1.SuspendLayout();
      this.txtqty.BeginInit();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      this.dataGridView1.AllowUserToAddRows = false;
      this.dataGridView1.AllowUserToDeleteRows = false;
      this.dataGridView1.AllowUserToOrderColumns = true;
      this.dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
      this.dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dataGridView1.BackgroundColor = Color.White;
      this.dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dataGridView1.Columns.AddRange((DataGridViewColumn) this.Clientcode, (DataGridViewColumn) this.Exch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Expiry, (DataGridViewColumn) this.Orderno, (DataGridViewColumn) this.buy_sell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.TradeTime, (DataGridViewColumn) this.Validity);
      this.dataGridView1.Location = new Point(2, 121);
      this.dataGridView1.Name = "dataGridView1";
      this.dataGridView1.ReadOnly = true;
      this.dataGridView1.RowHeadersVisible = false;
      this.dataGridView1.Size = new Size(1124, 331);
      this.dataGridView1.TabIndex = 5;
      this.dataGridView1.CellDoubleClick += new DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
      this.Clientcode.HeaderText = "ClientCode";
      this.Clientcode.Name = "Clientcode";
      this.Clientcode.ReadOnly = true;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Expiry.HeaderText = "Expiry";
      this.Expiry.Name = "Expiry";
      this.Expiry.ReadOnly = true;
      this.Expiry.Visible = false;
      this.Orderno.HeaderText = "Order No";
      this.Orderno.Name = "Orderno";
      this.Orderno.ReadOnly = true;
      this.buy_sell.HeaderText = "Buy/Sell";
      this.buy_sell.Name = "buy_sell";
      this.buy_sell.ReadOnly = true;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Price.HeaderText = "Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.TradeTime.HeaderText = "TradeTime";
      this.TradeTime.Name = "TradeTime";
      this.TradeTime.ReadOnly = true;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.txtorderno.Location = new Point(422, 32);
      this.txtorderno.Name = "txtorderno";
      this.txtorderno.ReadOnly = true;
      this.txtorderno.Size = new Size(124, 20);
      this.txtorderno.TabIndex = 3;
      this.txtprice.Location = new Point(796, 31);
      this.txtprice.Name = "txtprice";
      this.txtprice.Size = new Size(64, 20);
      this.txtprice.TabIndex = 6;
      this.groupBox1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
      this.groupBox1.Controls.Add((Control) this.cmbValidity);
      this.groupBox1.Controls.Add((Control) this.chkGroupwise);
      this.groupBox1.Controls.Add((Control) this.dtTimestamp);
      this.groupBox1.Controls.Add((Control) this.txtName);
      this.groupBox1.Controls.Add((Control) this.txtbuysell);
      this.groupBox1.Controls.Add((Control) this.txtqty);
      this.groupBox1.Controls.Add((Control) this.cmbclient);
      this.groupBox1.Controls.Add((Control) this.cmbexch);
      this.groupBox1.Controls.Add((Control) this.btninsert);
      this.groupBox1.Controls.Add((Control) this.txtprice);
      this.groupBox1.Controls.Add((Control) this.cmbSymbol);
      this.groupBox1.Controls.Add((Control) this.txtorderno);
      this.groupBox1.Location = new Point(4, 8);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(1122, 61);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Modify/Insert Trade";
      this.cmbValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbValidity.FormattingEnabled = true;
      this.cmbValidity.Items.AddRange(new object[3]
      {
        (object) "(-Validity-)",
        (object) "CARRYFORWARD",
        (object) "DAY"
      });
      this.cmbValidity.Location = new Point(621, 31);
      this.cmbValidity.Name = "cmbValidity";
      this.cmbValidity.Size = new Size(99, 21);
      this.cmbValidity.Sorted = true;
      this.cmbValidity.TabIndex = 12;
      this.chkGroupwise.AutoSize = true;
      this.chkGroupwise.Location = new Point(6, 14);
      this.chkGroupwise.Name = "chkGroupwise";
      this.chkGroupwise.Size = new Size(76, 17);
      this.chkGroupwise.TabIndex = 11;
      this.chkGroupwise.Text = "Groupwise";
      this.chkGroupwise.UseVisualStyleBackColor = true;
      this.chkGroupwise.CheckedChanged += new EventHandler(this.chkGroupwise_CheckedChanged);
      this.dtTimestamp.CustomFormat = "dd MMM yyyy HH:mm:ss";
      this.dtTimestamp.Format = DateTimePickerFormat.Custom;
      this.dtTimestamp.Location = new Point(866, 32);
      this.dtTimestamp.Name = "dtTimestamp";
      this.dtTimestamp.Size = new Size(146, 20);
      this.dtTimestamp.TabIndex = 10;
      this.dtTimestamp.Value = new DateTime(2018, 10, 4, 0, 0, 0, 0);
      this.txtName.Enabled = false;
      this.txtName.Location = new Point(92, 32);
      this.txtName.Name = "txtName";
      this.txtName.Size = new Size(94, 20);
      this.txtName.TabIndex = 9;
      this.txtbuysell.DropDownStyle = ComboBoxStyle.DropDownList;
      this.txtbuysell.FormattingEnabled = true;
      this.txtbuysell.Items.AddRange(new object[2]
      {
        (object) "BUY",
        (object) "SELL"
      });
      this.txtbuysell.Location = new Point(552, 31);
      this.txtbuysell.Name = "txtbuysell";
      this.txtbuysell.Size = new Size(63, 21);
      this.txtbuysell.Sorted = true;
      this.txtbuysell.TabIndex = 4;
      this.txtqty.Location = new Point(726, 31);
      this.txtqty.Maximum = new Decimal(new int[4]
      {
        100000,
        0,
        0,
        0
      });
      this.txtqty.Minimum = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.txtqty.Name = "txtqty";
      this.txtqty.Size = new Size(64, 20);
      this.txtqty.TabIndex = 5;
      this.txtqty.Value = new Decimal(new int[4]
      {
        1,
        0,
        0,
        0
      });
      this.cmbclient.FormattingEnabled = true;
      this.cmbclient.Location = new Point(4, 31);
      this.cmbclient.Name = "cmbclient";
      this.cmbclient.Size = new Size(84, 21);
      this.cmbclient.Sorted = true;
      this.cmbclient.TabIndex = 0;
      this.cmbclient.SelectedIndexChanged += new EventHandler(this.cmbclient_SelectedIndexChanged);
      this.cmbclient.Leave += new EventHandler(this.cmbclient_Leave);
      this.cmbexch.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbexch.FormattingEnabled = true;
      this.cmbexch.Location = new Point(190, 31);
      this.cmbexch.Name = "cmbexch";
      this.cmbexch.Size = new Size(71, 21);
      this.cmbexch.TabIndex = 1;
      this.btninsert.Location = new Point(1018, 30);
      this.btninsert.Name = "btninsert";
      this.btninsert.Size = new Size(82, 23);
      this.btninsert.TabIndex = 7;
      this.btninsert.Text = "Insert";
      this.btninsert.UseVisualStyleBackColor = true;
      this.btninsert.Click += new EventHandler(this.btninsert_Click);
      this.cmbSymbol.FormattingEnabled = true;
      this.cmbSymbol.Location = new Point(265, 31);
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(153, 21);
      this.cmbSymbol.Sorted = true;
      this.cmbSymbol.TabIndex = 2;
      this.cmbSymbol.SelectedIndexChanged += new EventHandler(this.cmbSymbol_SelectedIndexChanged);
      this.cmbSymbol.Enter += new EventHandler(this.cmbSymbol_Enter);
      this.btnmodify.Location = new Point(269, 86);
      this.btnmodify.Name = "btnmodify";
      this.btnmodify.Size = new Size(88, 23);
      this.btnmodify.TabIndex = 2;
      this.btnmodify.Text = "Modify";
      this.btnmodify.UseVisualStyleBackColor = true;
      this.btnmodify.Click += new EventHandler(this.btnmodify_Click);
      this.btnclear.Location = new Point(1032, 89);
      this.btnclear.Name = "btnclear";
      this.btnclear.Size = new Size(88, 23);
      this.btnclear.TabIndex = 4;
      this.btnclear.Text = "Clear";
      this.btnclear.UseVisualStyleBackColor = true;
      this.btnclear.Click += new EventHandler(this.btnclear_Click);
      this.btnrefresh.Location = new Point(139, 14);
      this.btnrefresh.Name = "btnrefresh";
      this.btnrefresh.Size = new Size(88, 23);
      this.btnrefresh.TabIndex = 2;
      this.btnrefresh.Text = "View";
      this.btnrefresh.UseVisualStyleBackColor = true;
      this.btnrefresh.Click += new EventHandler(this.btnrefresh_Click);
      this.btndelete.Location = new Point(578, 89);
      this.btndelete.Name = "btndelete";
      this.btndelete.Size = new Size(88, 23);
      this.btndelete.TabIndex = 3;
      this.btndelete.Text = "Delete";
      this.btndelete.UseVisualStyleBackColor = true;
      this.btndelete.Click += new EventHandler(this.btndelete_Click);
      this.groupBox2.Controls.Add((Control) this.rdoTrades);
      this.groupBox2.Controls.Add((Control) this.rdoOrders);
      this.groupBox2.Controls.Add((Control) this.btnrefresh);
      this.groupBox2.Location = new Point(4, 72);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(249, 43);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Order/Trade";
      this.rdoTrades.AutoSize = true;
      this.rdoTrades.Checked = true;
      this.rdoTrades.Location = new Point(71, 17);
      this.rdoTrades.Name = "rdoTrades";
      this.rdoTrades.Size = new Size(58, 17);
      this.rdoTrades.TabIndex = 1;
      this.rdoTrades.TabStop = true;
      this.rdoTrades.Text = "Trades";
      this.rdoTrades.UseVisualStyleBackColor = true;
      this.rdoTrades.CheckedChanged += new EventHandler(this.rdoTrades_CheckedChanged);
      this.rdoOrders.AutoSize = true;
      this.rdoOrders.Location = new Point(9, 17);
      this.rdoOrders.Name = "rdoOrders";
      this.rdoOrders.Size = new Size(56, 17);
      this.rdoOrders.TabIndex = 0;
      this.rdoOrders.Text = "Orders";
      this.rdoOrders.UseVisualStyleBackColor = true;
      this.rdoOrders.CheckedChanged += new EventHandler(this.rdoOrders_CheckedChanged);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1132, 456);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.btndelete);
      this.Controls.Add((Control) this.btnclear);
      this.Controls.Add((Control) this.btnmodify);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.dataGridView1);
      this.MaximizeBox = false;
      this.Name = nameof (ModifyOrderTrade);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Modify Insert Order/Trade";
      this.Load += new EventHandler(this.ModifyOrderTrade_Load);
      ((ISupportInitialize) this.dataGridView1).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.txtqty.EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
