﻿// Decompiled with JetBrains decompiler
// Type: DTS.FormValidator
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System.Text.RegularExpressions;

namespace DTS
{
  internal class FormValidator
  {
    public bool ValidateEmail(string email)
    {
      return new Regex("^(([^<>()[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$").IsMatch(email);
    }

    public bool ValidateIsNumeric(string StringToValidate)
    {
      return new Regex("^([0-9])").IsMatch(StringToValidate);
    }
  }
}
