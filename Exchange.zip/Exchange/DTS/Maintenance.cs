﻿// Decompiled with JetBrains decompiler
// Type: DTS.Maintenance
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class Maintenance : Form
  {
    public Dictionary<string, buysellnetpospfls> _NetProftLoss = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, buysellnetpospfls> _NetMTMProftLoss = new Dictionary<string, buysellnetpospfls>();
    public Dictionary<string, Decimal> _ClientNetPfls = new Dictionary<string, Decimal>();
    public Dictionary<int, Dictionary<string, double>> _SymClosePrice = new Dictionary<int, Dictionary<string, double>>();
    public List<string> _SelectedExchanges = new List<string>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public DateTime MarketStarttime;
    public DateTime MarketEndtime;
    public DateTime servertimee;
    private Label label1;
    private Label label2;
    private Label label3;
    private Label label4;
    private Button btnStoreBrkg;
    private Button btnTurnover;
    private Button btnPrftLoss;
    private Button btnCashMrgn;
    private Button btnCryPos;
    private Button btnArchData;
    private Label label5;
    private Label label6;
    private ProgressBar progressMaintenance;
    private GroupBox groupBox1;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private Button btnUploadBhavcopy;
    private GroupBox groupBox2;
    private CheckedListBox chkExchList;
    private ListBox lstMsg;
    private GroupBox groupBox3;
    private DateTimePicker dtToDate;
    private GroupBox groupBox4;
    private DateTimePicker dtClosePriceDate;
    private TreeView treeView1;
    private GroupBox groupBox5;
    private RadioButton rdoBhavcopy;
    private RadioButton rdoLTP;
    private Button btnStoreDAPfls;

    public Maintenance(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
    }

    public void LoadMaintenance()
    {
      string[] strArray = this.objmain.objinfo.exchange.Split(',');
      this.rdoMcx.Enabled = this.rdoncdex.Enabled = this.rdoNsecurr.Enabled = this.rdoNseFut.Enabled = false;
      this.chkExchList.Items.Clear();
      for (int index = 0; index < strArray.Length; ++index)
      {
        if (strArray[index] != string.Empty)
          this.chkExchList.Items.Add((object) strArray[index]);
        string str = strArray[index];
        if (!(str == "MCX"))
        {
          if (!(str == "NCDEX"))
          {
            if (!(str == "NSECURR"))
            {
              if (!(str == "NSEFUT"))
              {
                if (str == "NSEOPT")
                  this.rdoncdex.Enabled = true;
              }
              else
                this.rdoNseFut.Enabled = true;
            }
            else
              this.rdoNsecurr.Enabled = true;
          }
          else
            this.rdoncdex.Enabled = true;
        }
        else
          this.rdoMcx.Enabled = true;
      }
      this.LoadHierarchy();
      this.servertimee = this.objmain.GetServerTime();
      DateTime dateTime = this.servertimee.AddDays(1.0);
      if (dateTime.Day == 6)
      {
        this.dtToDate.Value = this.servertimee.AddDays(3.0);
      }
      else
      {
        dateTime = DateTime.Now;
        dateTime = dateTime.AddDays(1.0);
        this.dtToDate.Value = dateTime.Day != 0 ? this.servertimee.AddDays(1.0) : this.servertimee.AddDays(2.0);
      }
      this.dtClosePriceDate.Value = this.servertimee.AddDays(-1.0);
    }

    public void LoadHierarchy()
    {
      this.treeView1.Nodes.Clear();
      if (this.objmain.objinfo.usertype != 1)
        return;
      this.treeView1.Nodes.Add("DEALER ADMIN");
      int index = 0;
      foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair1 in this.objmain._DAHierarchy)
      {
        this.treeView1.Nodes[0].Nodes.Add(keyValuePair1.Key);
        this.treeView1.Nodes[0].Nodes[index].Nodes.Add("DEALER");
        this.treeView1.Nodes[0].Nodes[index].Nodes.Add("CIENT");
        foreach (KeyValuePair<string, Userinfo> keyValuePair2 in keyValuePair1.Value)
        {
          Userinfo userinfo = keyValuePair2.Value;
          if (userinfo.usertype == 3)
          {
            this.treeView1.Nodes[0].Nodes[index].Nodes[0].Nodes.Add(userinfo.clientcode);
            if (!(userinfo.mappedclients != string.Empty))
              ;
          }
          else
            this.treeView1.Nodes[0].Nodes[index].Nodes[1].Nodes.Add(userinfo.clientcode);
        }
        ++index;
      }
    }

    private string GetAccounts(ref List<string> _lstAccounts)
    {
      string str = string.Empty;
      _lstAccounts = new List<string>();
      foreach (TreeNode node1 in this.treeView1.Nodes)
      {
        foreach (TreeNode node2 in node1.Nodes)
        {
          foreach (TreeNode node3 in node2.Nodes)
          {
            if (node3.Text == "DEALER")
            {
              foreach (TreeNode node4 in node3.Nodes)
              {
                foreach (TreeNode node5 in node4.Nodes)
                {
                  if (!_lstAccounts.Contains(node5.Text) && node5.Checked)
                  {
                    _lstAccounts.Add(node5.Text);
                    str += string.Format("'{0}',", (object) node5.Text);
                  }
                }
              }
            }
            else
            {
              foreach (TreeNode node4 in node3.Nodes)
              {
                if (!_lstAccounts.Contains(node4.Text) && node4.Checked)
                {
                  _lstAccounts.Add(node4.Text);
                  str += string.Format("'{0}',", (object) node4.Text);
                }
              }
            }
          }
        }
      }
      if (str.Length > 0)
        str = str.Substring(0, str.Length - 1);
      return str;
    }

    public Dictionary<string, Dictionary<int, List<Trades>>> GetTradePosition(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      string account,
      bool isIntraday,
      List<string> _exchnages,
      SqlConnection connn,
      DateTime MaintenanceDate)
    {
      Dictionary<string, Dictionary<int, List<Trades>>> dictionary = new Dictionary<string, Dictionary<int, List<Trades>>>();
      switch (account)
      {
        case "":
          return dictionary;
        case null:
          return dictionary;
        default:
          string empty = string.Empty;
          string cmdText = !isIntraday ? string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.Exch from Trade T , Orders O where T.Clientcode in ({0}) and T.OrderNo = O.OrderNo and Timestamp Between '{1}' and '{2}'  ", (object) account, (object) MaintenanceDate.ToString("yyyy-MM-dd 08:59:00"), (object) MaintenanceDate.ToString("yyyy-MM-dd 23:59:00")) : string.Format("Select T.Symbol,T.Qty,T.BuySell,T.TimeStamp,T.Price,T.Clientcode,O.Validity,O.Exch from Trade T , Orders O where T.Clientcode in ({0}) and T.OrderNo = O.OrderNo and O.IsMaintenance = 0 and Timestamp between '{1}' and '{2}'  ", (object) account, (object) MaintenanceDate.ToString("yyyy-MM-dd 09:00:00"), (object) MaintenanceDate.ToString("yyyy-MM-dd 23:55:00"));
          using (DataSet dataSet = new DataSet())
          {
            try
            {
              if (connn.State == ConnectionState.Open)
              {
                using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter()
                {
                  SelectCommand = new SqlCommand(cmdText, connn)
                })
                {
                  sqlDataAdapter.Fill(dataSet);
                  for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
                  {
                    Trades objtrd = new Trades()
                    {
                      Symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString(),
                      qty = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[1]),
                      buysell = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2]),
                      Lastmodified = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[3]),
                      price = Convert.ToDecimal(dataSet.Tables[0].Rows[index].ItemArray[4]),
                      clientcode = dataSet.Tables[0].Rows[index].ItemArray[5].ToString(),
                      validity = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[6]),
                      exch = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[7])
                    };
                    if (_exchnages.Contains(Utils.GetExch(objtrd.exch)))
                    {
                      if (objtrd.validity == 3)
                        objtrd.validity = 1;
                      if (this.objmain._Symconctracts.ContainsKey(objtrd.Symbol))
                      {
                        Contracts symconctract = this.objmain._Symconctracts[objtrd.Symbol];
                        Maintenance.ManagePositions(ref _BuySellAvgPos, objtrd);
                      }
                    }
                  }
                }
              }
              else
                this.InsertMsgBoard("Unable to Connect to Server, Please try again later...");
            }
            catch
            {
            }
          }
          return dictionary;
      }
    }

    public static void ManagePositions(
      ref Dictionary<string, buysellPos> _BuySellAvgPos,
      Trades objtrd)
    {
      string key = string.Format("{0}_{1}_{2}", (object) objtrd.Symbol, (object) objtrd.clientcode, (object) objtrd.validity);
      if (_BuySellAvgPos.ContainsKey(key))
      {
        buysellPos buysellPos = _BuySellAvgPos[key];
        if (objtrd.buysell == 1)
        {
          double num1 = (buysellPos.buyprice * (double) buysellPos.BQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.BQty + objtrd.qty);
          buysellPos.BQty += objtrd.qty;
          buysellPos.buyprice = num1;
          DateTime lastmodified = objtrd.Lastmodified;
          int num2;
          if (lastmodified.Hour == 9)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 0)
            {
              lastmodified = objtrd.Lastmodified;
              if (lastmodified.Second == 0)
              {
                num2 = 0;
                goto label_10;
              }
            }
          }
          lastmodified = objtrd.Lastmodified;
          if (lastmodified.Hour == 23)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 55)
            {
              lastmodified = objtrd.Lastmodified;
              num2 = (uint) lastmodified.Second > 0U ? 1 : 0;
              goto label_10;
            }
          }
          num2 = 1;
label_10:
          if (num2 != 0)
          {
            double num3 = (buysellPos.IntraBPrice * (double) buysellPos.IntraBQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.IntraBQty + objtrd.qty);
            buysellPos.IntraBQty += objtrd.qty;
            buysellPos.IntraBPrice = num1;
          }
        }
        else
        {
          double num1 = (buysellPos.sellprice * (double) buysellPos.SQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.SQty + objtrd.qty);
          buysellPos.SQty += objtrd.qty;
          buysellPos.sellprice = num1;
          DateTime lastmodified = objtrd.Lastmodified;
          int num2;
          if (lastmodified.Hour == 9)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 0)
            {
              lastmodified = objtrd.Lastmodified;
              if (lastmodified.Second == 0)
              {
                num2 = 0;
                goto label_20;
              }
            }
          }
          lastmodified = objtrd.Lastmodified;
          if (lastmodified.Hour == 23)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 55)
            {
              lastmodified = objtrd.Lastmodified;
              num2 = (uint) lastmodified.Second > 0U ? 1 : 0;
              goto label_20;
            }
          }
          num2 = 1;
label_20:
          if (num2 != 0)
          {
            double num3 = (buysellPos.IntraSPrice * (double) buysellPos.IntraSQty + Convert.ToDouble(objtrd.price) * (double) objtrd.qty) / (double) (buysellPos.IntraSQty + objtrd.qty);
            buysellPos.IntraSQty += objtrd.qty;
            buysellPos.IntraSPrice = num1;
          }
        }
        _BuySellAvgPos[key] = buysellPos;
      }
      else
      {
        buysellPos buysellPos = new buysellPos();
        buysellPos.symbol = objtrd.Symbol;
        if (objtrd.buysell == 1)
        {
          buysellPos.BQty = objtrd.qty;
          buysellPos.SQty = 0;
          buysellPos.buyprice = Convert.ToDouble(objtrd.price);
          DateTime lastmodified;
          int num;
          if (objtrd.Lastmodified.Hour == 9)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 0)
            {
              lastmodified = objtrd.Lastmodified;
              if (lastmodified.Second == 0)
              {
                num = 0;
                goto label_33;
              }
            }
          }
          lastmodified = objtrd.Lastmodified;
          if (lastmodified.Hour == 23)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 55)
            {
              lastmodified = objtrd.Lastmodified;
              num = (uint) lastmodified.Second > 0U ? 1 : 0;
              goto label_33;
            }
          }
          num = 1;
label_33:
          if (num != 0)
          {
            buysellPos.IntraBQty = objtrd.qty;
            buysellPos.IntraSQty = 0;
            buysellPos.IntraBPrice = Convert.ToDouble(objtrd.price);
          }
        }
        else
        {
          buysellPos.BQty = 0;
          buysellPos.SQty = objtrd.qty;
          buysellPos.sellprice = Convert.ToDouble(objtrd.price);
          DateTime lastmodified;
          int num;
          if (objtrd.Lastmodified.Hour == 9)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 0)
            {
              lastmodified = objtrd.Lastmodified;
              if (lastmodified.Second == 0)
              {
                num = 0;
                goto label_43;
              }
            }
          }
          lastmodified = objtrd.Lastmodified;
          if (lastmodified.Hour == 23)
          {
            lastmodified = objtrd.Lastmodified;
            if (lastmodified.Minute == 55)
            {
              lastmodified = objtrd.Lastmodified;
              num = (uint) lastmodified.Second > 0U ? 1 : 0;
              goto label_43;
            }
          }
          num = 1;
label_43:
          if (num != 0)
          {
            buysellPos.IntraBQty = 0;
            buysellPos.IntraSQty = objtrd.qty;
            buysellPos.IntraSPrice = Convert.ToDouble(objtrd.price);
          }
        }
        _BuySellAvgPos.Add(key, buysellPos);
      }
    }

    private void GetExchangewisePos(List<string> _exchnages, SqlConnection nwconn, bool isIntra)
    {
      List<string> _lstAccounts = new List<string>();
      string accounts = this.GetAccounts(ref _lstAccounts);
      Dictionary<string, buysellPos> _BuySellAvgPos = new Dictionary<string, buysellPos>();
      this.GetTradePosition(ref _BuySellAvgPos, accounts, isIntra, _exchnages, nwconn, this.dtClosePriceDate.Value);
      this._NetProftLoss = this.ProcessProfitLoss(_BuySellAvgPos);
      this._NetMTMProftLoss = this.GetNetPrfLoss(this._NetProftLoss);
    }

    public Dictionary<string, buysellnetpospfls> ProcessProfitLoss(
      Dictionary<string, buysellPos> _BuySellAvgPos)
    {
      this._NetProftLoss = new Dictionary<string, buysellnetpospfls>();
      foreach (KeyValuePair<string, buysellPos> buySellAvgPo in _BuySellAvgPos)
      {
        buysellnetpospfls buysellnetpospfls = new buysellnetpospfls();
        string key = buySellAvgPo.Key;
        string[] strArray = buySellAvgPo.Key.Split('_');
        string clientcode = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        buysellPos buysellPos = buySellAvgPo.Value;
        if (this.objmain._Symconctracts.ContainsKey(buysellPos.symbol))
        {
          Contracts symconctract = this.objmain._Symconctracts[buysellPos.symbol];
          SymbolMargin symbolwiseMrgn = this.objmain.GetSymbolwiseMrgn(clientcode, symconctract.symbol);
          Limits limits = this.objmain.GetLimits(clientcode);
          Decimal turnoverBrkg = this.objmain.GetTurnoverBrkg(symconctract, limits, int32);
          int num1 = buysellPos.BQty + buysellPos.SQty;
          int num2 = buysellPos.IntraBQty + buysellPos.IntraSQty;
          buysellnetpospfls.symbol = buysellPos.symbol;
          buysellnetpospfls.BQty = buysellPos.BQty;
          buysellnetpospfls.SQty = buysellPos.SQty;
          buysellnetpospfls.buyprice = Decimal.Round(Convert.ToDecimal(buysellPos.buyprice), 2);
          buysellnetpospfls.sellprice = Decimal.Round(Convert.ToDecimal(buysellPos.sellprice), 2);
          buysellnetpospfls.symbol.Split('(');
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.objmain.getFeed(symbol);
          if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
          {
            int num3 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
            Decimal num4 = feed.ltp - buysellnetpospfls.buyprice;
            if (feed.ltp > Decimal.Zero)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.UnrealisedP_l = num5 == 0 ? Decimal.Round(num4 * (Decimal) num3 * (Decimal) symconctract.lotsize, 2) : Decimal.Round(num4 * (Decimal) num3, 2);
            }
            buysellnetpospfls.buy_sell = 1;
            buysellnetpospfls.Qty = num3;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num3 * Convert.ToDouble(buysellnetpospfls.buyprice));
            else
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num3 * Convert.ToDouble(buysellnetpospfls.buyprice) * (double) symconctract.lotsize);
            if (int32 == 1)
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolwiseMrgn.delvmrgn);
              if (limits.brkgtype == 2)
              {
                if (symconctract.exch == 2 || symconctract.exch == 5)
                {
                  int num5 = num2 / symconctract.lotsize;
                  buysellnetpospfls.Commision = Convert.ToDecimal(num5 * symbolwiseMrgn.delvbrkg);
                }
                else
                  buysellnetpospfls.Commision = Convert.ToDecimal(num2 * symbolwiseMrgn.delvbrkg);
              }
              else
              {
                if (buysellnetpospfls.SQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            else
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolwiseMrgn.intramrgn);
              if (limits.brkgtype == 2)
              {
                if (symconctract.exch == 2 || symconctract.exch == 5)
                {
                  int num5 = num2 / symconctract.lotsize;
                  buysellnetpospfls.Commision = Convert.ToDecimal(num5 * symbolwiseMrgn.intrabrkg);
                }
                else
                  buysellnetpospfls.Commision = Convert.ToDecimal(num2 * symbolwiseMrgn.intrabrkg);
              }
              else
              {
                if (buysellnetpospfls.SQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            if (buysellnetpospfls.SQty > 0)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) num3 * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) num3, 2);
              if (symconctract.exch == 2 || symconctract.exch == 5)
                buysellnetpospfls.TurnoverUtilised += Math.Round((double) buysellnetpospfls.SQty * Convert.ToDouble(buysellnetpospfls.sellprice));
              else
                buysellnetpospfls.TurnoverUtilised += Math.Round((double) buysellnetpospfls.SQty * Convert.ToDouble(buysellnetpospfls.sellprice) * (double) symconctract.lotsize);
            }
          }
          else if (buysellnetpospfls.SQty > buysellnetpospfls.BQty)
          {
            int num3 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            Decimal num4 = buysellnetpospfls.sellprice - feed.ltp;
            if (feed.ltp > Decimal.Zero)
              buysellnetpospfls.UnrealisedP_l = Decimal.Round(num4 * (Decimal) num3 * (Decimal) symconctract.lotsize, 2);
            buysellnetpospfls.buy_sell = 2;
            buysellnetpospfls.Qty = num3;
            if (symconctract.exch == 2 || symconctract.exch == 5)
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num3 * Convert.ToDouble(buysellnetpospfls.sellprice));
            else
              buysellnetpospfls.TurnoverUtilised += Math.Round((double) num3 * Convert.ToDouble(buysellnetpospfls.sellprice) * (double) symconctract.lotsize);
            if (int32 == 1)
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolwiseMrgn.delvmrgn);
              if (limits.brkgtype == 2)
              {
                if (symconctract.exch == 2 || symconctract.exch == 5)
                {
                  int num5 = num2 / symconctract.lotsize;
                  buysellnetpospfls.Commision = Convert.ToDecimal(num5 * symbolwiseMrgn.delvbrkg);
                }
                else
                  buysellnetpospfls.Commision = Convert.ToDecimal(num2 * symbolwiseMrgn.delvbrkg);
              }
              else
              {
                if (buysellnetpospfls.BQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            else
            {
              buysellnetpospfls.margin = Convert.ToDecimal(num3 * symbolwiseMrgn.intramrgn);
              if (limits.brkgtype == 2)
              {
                if (symconctract.exch == 2 || symconctract.exch == 5)
                {
                  int num5 = num2 / symconctract.lotsize;
                  buysellnetpospfls.Commision = Convert.ToDecimal(num5 * symbolwiseMrgn.intrabrkg);
                }
                else
                  buysellnetpospfls.Commision = Convert.ToDecimal(num2 * symbolwiseMrgn.intrabrkg);
              }
              else
              {
                if (buysellnetpospfls.BQty > 0)
                {
                  int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
                  buysellnetpospfls.Commision = num5 == 0 ? Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) buysellPos.IntraBQty * Convert.ToDecimal(buysellPos.IntraBPrice) * turnoverBrkg / new Decimal(100), 2);
                }
                if (symconctract.exch == 2 || symconctract.exch == 5)
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * turnoverBrkg / new Decimal(100), 2);
                else
                  buysellnetpospfls.Commision += Decimal.Round((Decimal) buysellPos.IntraSQty * Convert.ToDecimal(buysellPos.IntraSPrice) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2);
              }
            }
            if (buysellnetpospfls.BQty > 0)
            {
              int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.p_l = num5 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) num3 * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) num3, 2);
            }
          }
          else
          {
            double num3 = Math.Round((Convert.ToDouble(buysellnetpospfls.buyprice) + Convert.ToDouble(buysellnetpospfls.sellprice)) / 2.0, 2);
            double num4 = Math.Round((buysellPos.IntraBPrice + buysellPos.IntraSPrice) / 2.0, 2);
            int num5 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
            buysellnetpospfls.TurnoverUtilised = num5 == 0 ? Math.Round((double) num1 * num3 * (double) symconctract.lotsize) : Math.Round((double) num1 * num3);
            if (limits.brkgtype == 2)
            {
              if (int32 == 2)
              {
                if (symconctract.exch == 2 || symconctract.exch == 5)
                {
                  int num6 = num2 / symconctract.lotsize;
                  buysellnetpospfls.Commision = Convert.ToDecimal(num6 * symbolwiseMrgn.delvbrkg);
                }
                else
                  buysellnetpospfls.Commision = Convert.ToDecimal(num2 * symbolwiseMrgn.delvbrkg);
              }
              else if (symconctract.exch == 2 || symconctract.exch == 5)
              {
                int num6 = num2 / symconctract.lotsize;
                buysellnetpospfls.Commision = Convert.ToDecimal(num6 * symbolwiseMrgn.intrabrkg);
              }
              else
                buysellnetpospfls.Commision = Convert.ToDecimal(num2 * symbolwiseMrgn.intrabrkg);
            }
            else
            {
              int num6 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
              buysellnetpospfls.Commision = num6 == 0 ? Decimal.Round((Decimal) num2 * Convert.ToDecimal(num4) * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) num2 * Convert.ToDecimal(num4) * turnoverBrkg / new Decimal(100), 2);
            }
            int num7 = symconctract.exch == 2 ? 1 : (symconctract.exch == 5 ? 1 : 0);
            buysellnetpospfls.p_l = num7 == 0 ? Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((buysellnetpospfls.sellprice - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.BQty, 2);
          }
          try
          {
            if (!this._NetProftLoss.ContainsKey(key))
              this._NetProftLoss.Add(key, buysellnetpospfls);
          }
          catch
          {
          }
        }
      }
      return this._NetProftLoss;
    }

    public Dictionary<string, buysellnetpospfls> GetNetPrfLoss(
      Dictionary<string, buysellnetpospfls> __NetProftLoss)
    {
      this._NetMTMProftLoss = new Dictionary<string, buysellnetpospfls>();
      buysellnetpospfls buysellnetpospfls1 = new buysellnetpospfls();
      try
      {
        foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this._NetProftLoss)
        {
          string[] strArray = keyValuePair.Key.Split('_');
          string key = strArray[1];
          Convert.ToInt32(strArray[2]);
          buysellnetpospfls buysellnetpospfls2 = keyValuePair.Value;
          buysellnetpospfls buysellnetpospfls3;
          if (!this._NetMTMProftLoss.ContainsKey(key))
          {
            buysellnetpospfls3 = buysellnetpospfls2;
            this._NetMTMProftLoss.Add(key, buysellnetpospfls3);
          }
          else
          {
            buysellnetpospfls3 = this._NetMTMProftLoss[key];
            buysellnetpospfls3.p_l += Decimal.Round(buysellnetpospfls2.p_l, 2);
            buysellnetpospfls3.Commision += buysellnetpospfls2.Commision;
            buysellnetpospfls3.UnrealisedP_l += Decimal.Round(buysellnetpospfls2.UnrealisedP_l, 2);
            buysellnetpospfls3.margin += buysellnetpospfls2.margin;
            buysellnetpospfls3.TurnoverUtilised += buysellnetpospfls2.TurnoverUtilised;
            this._NetMTMProftLoss[key] = buysellnetpospfls3;
          }
        }
      }
      catch
      {
      }
      return this._NetMTMProftLoss;
    }

    private void GetClosePrice()
    {
      this.InsertMsgBoard("Downloading Close Price...");
      this._SymClosePrice = new Dictionary<int, Dictionary<string, double>>();
      DateTime serverTime = this.objmain.GetServerTime();
      if (serverTime.AddDays(-1.0).DayOfWeek == DayOfWeek.Sunday)
        serverTime.AddDays(-2.0);
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        if (this.rdoBhavcopy.Checked)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select SymDescription,[Close],Exch from Bhavcopy where Timestamp = '" + this.dtClosePriceDate.Value.ToString("yyyy-MM-dd 00:00:00") + "'", conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                string empty = string.Empty;
                double num = 0.0;
                if (!sqlDataReader.IsDBNull(0))
                  empty = sqlDataReader.GetString(0);
                if (!sqlDataReader.IsDBNull(1))
                  num = Convert.ToDouble(sqlDataReader.GetValue(1));
                if (!sqlDataReader.IsDBNull(2))
                {
                  int int32 = sqlDataReader.GetInt32(2);
                  if (!this._SymClosePrice.ContainsKey(int32))
                  {
                    this._SymClosePrice.Add(int32, new Dictionary<string, double>()
                    {
                      {
                        empty,
                        num
                      }
                    });
                  }
                  else
                  {
                    Dictionary<string, double> dictionary = this._SymClosePrice[int32];
                    if (!dictionary.ContainsKey(empty))
                      dictionary.Add(empty, num);
                    this._SymClosePrice[int32] = dictionary;
                  }
                }
              }
            }
          }
        }
        else if (this.rdoLTP.Checked)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Symbol,[LTP],Exch from SymbolLastLTP where Timestamp > '" + this.dtClosePriceDate.Value.ToString("yyyy-MM-dd 00:00:00") + "'", conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                string empty = string.Empty;
                double num = 0.0;
                if (!sqlDataReader.IsDBNull(0))
                  empty = sqlDataReader.GetString(0);
                if (!sqlDataReader.IsDBNull(1))
                  num = Convert.ToDouble(sqlDataReader.GetValue(1));
                if (!sqlDataReader.IsDBNull(2))
                {
                  int int32 = sqlDataReader.GetInt32(2);
                  if (!this._SymClosePrice.ContainsKey(int32))
                  {
                    this._SymClosePrice.Add(int32, new Dictionary<string, double>()
                    {
                      {
                        empty,
                        num
                      }
                    });
                  }
                  else
                  {
                    Dictionary<string, double> dictionary = this._SymClosePrice[int32];
                    if (!dictionary.ContainsKey(empty))
                      dictionary.Add(empty, num);
                    this._SymClosePrice[int32] = dictionary;
                  }
                }
              }
            }
          }
        }
      }
      this.InsertMsgBoard("Close Price Download Complete.");
    }

    private void btnCommTax_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.StoreCommTax())).Invoke)).Start();
    }

    private void StoreCommTax()
    {
      if (this._SelectedExchanges.Count == 0)
      {
        this.InsertMsgBoard("Select Exchange to run Maintenance.");
        this.objmain.DisplayMessage("Select Exchange to run Maintenance.", 3);
      }
      else
      {
        this.InsertMsgBoard("Storing Brokerage...");
        SqlConnection conn = this.objmain.getConn();
        foreach (string selectedExchange in this._SelectedExchanges)
        {
          this.GetExchangewisePos(new List<string>()
          {
            selectedExchange
          }, conn, true);
          if (this._NetMTMProftLoss.Count > 0)
          {
            this.Invoke((Delegate) (() =>
            {
              this.progressMaintenance.Minimum = 0;
              this.progressMaintenance.Maximum = this._NetMTMProftLoss.Count;
              this.progressMaintenance.Value = 0;
            }));
            if (conn.State == ConnectionState.Open)
            {
              int num = 0;
              foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this._NetMTMProftLoss)
              {
                this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
                string key = keyValuePair.Key;
                buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
                SqlCommand sqlCommand1 = new SqlCommand("StoreBrokerage", conn);
                sqlCommand1.CommandType = CommandType.StoredProcedure;
                using (SqlCommand sqlCommand2 = sqlCommand1)
                {
                  sqlCommand2.Parameters.AddWithValue("@clientcode", (object) key);
                  sqlCommand2.Parameters.AddWithValue("@brkg", (object) buysellnetpospfls.Commision);
                  sqlCommand2.Parameters.AddWithValue("@exch", (object) Utils.GetIntExch(selectedExchange));
                  sqlCommand2.Parameters.AddWithValue("@timestamp", (object) new DateTime(this.dtClosePriceDate.Value.Year, this.dtClosePriceDate.Value.Month, this.dtClosePriceDate.Value.Day, 0, 0, 0));
                  try
                  {
                    num += sqlCommand2.ExecuteNonQuery();
                  }
                  catch
                  {
                    this.InsertMsgBoard("Unable to Perform Task, please try again.");
                  }
                }
                Thread.Sleep(50);
                Application.DoEvents();
              }
              if (num > 0)
                this.InsertMsgBoard("Brokerage stored Successfully!!");
              else
                this.InsertMsgBoard("Data not available to store brokerage.");
              this.Invoke((Delegate) (() => this.progressMaintenance.Value = 0));
            }
            else
              this.InsertMsgBoard("Unable to Perform Task, please try again.");
          }
        }
      }
    }

    private void btnTurnover_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.StoreTurnover())).Invoke)).Start();
    }

    private void StoreTurnover()
    {
      if (this._SelectedExchanges.Count == 0)
      {
        this.InsertMsgBoard("Select Exchange to run Maintenance.");
        this.objmain.DisplayMessage("Select Exchange to run Maintenance.", 3);
      }
      else
      {
        this.InsertMsgBoard("Storing Turnover...");
        SqlConnection conn = this.objmain.getConn();
        foreach (string selectedExchange in this._SelectedExchanges)
        {
          this.GetExchangewisePos(new List<string>()
          {
            selectedExchange
          }, conn, true);
          if (this._NetMTMProftLoss.Count > 0)
          {
            this.Invoke((Delegate) (() =>
            {
              this.progressMaintenance.Minimum = 0;
              this.progressMaintenance.Maximum = this._NetMTMProftLoss.Count;
              this.progressMaintenance.Value = 0;
            }));
            if (conn.State == ConnectionState.Open)
            {
              int num = 0;
              foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this._NetMTMProftLoss)
              {
                this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
                string key = keyValuePair.Key;
                buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
                SqlCommand sqlCommand1 = new SqlCommand(nameof (StoreTurnover), conn);
                sqlCommand1.CommandType = CommandType.StoredProcedure;
                using (SqlCommand sqlCommand2 = sqlCommand1)
                {
                  sqlCommand2.Parameters.AddWithValue("@clientcode", (object) key);
                  sqlCommand2.Parameters.AddWithValue("@turnover", (object) buysellnetpospfls.TurnoverUtilised);
                  sqlCommand2.Parameters.AddWithValue("@exch", (object) Utils.GetIntExch(selectedExchange));
                  sqlCommand2.Parameters.AddWithValue("@timestamp", (object) new DateTime(this.dtClosePriceDate.Value.Year, this.dtClosePriceDate.Value.Month, this.dtClosePriceDate.Value.Day, 0, 0, 0));
                  try
                  {
                    num += sqlCommand2.ExecuteNonQuery();
                  }
                  catch
                  {
                    this.InsertMsgBoard("Unable to Perform Task, please try again.");
                  }
                }
                Thread.Sleep(50);
                Application.DoEvents();
              }
              if (num > 0)
                this.InsertMsgBoard("Turnover Stored Successfully!!");
              else
                this.InsertMsgBoard("Data not available to store brokerage.");
              this.Invoke((Delegate) (() => this.progressMaintenance.Value = 0));
            }
          }
        }
      }
    }

    private void btnPrftLoss_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.StoreProfitLoss())).Invoke)).Start();
    }

    private void StoreProfitLoss()
    {
      if (this._SelectedExchanges.Count == 0)
      {
        this.InsertMsgBoard("Select Exchange to run Maintenance.");
        this.objmain.DisplayMessage("Select Exchange to run Maintenance.", 3);
      }
      else
      {
        this.GetClosePrice();
        SqlConnection conn = this.objmain.getConn();
        this.GetExchangewisePos(this._SelectedExchanges, conn, false);
        if (this._NetProftLoss.Count > 0)
        {
          if (this._SymClosePrice.Count <= 0)
          {
            this.objmain.DisplayMessage("No ClosePrice Available to Store Profit/Loss", 2);
          }
          else
          {
            this.Invoke((Delegate) (() =>
            {
              this.progressMaintenance.Minimum = 0;
              this.progressMaintenance.Maximum = this._NetProftLoss.Count;
              this.progressMaintenance.Value = 0;
            }));
            DateTime dateTime1 = this.dtClosePriceDate.Value;
            DateTime dateTime2 = new DateTime(dateTime1.Year, dateTime1.Month, dateTime1.Day, 23, 55, 0);
            if (conn.State != ConnectionState.Open)
              return;
            this.InsertMsgBoard("Storing Profit/Loss...");
            bool flag = false;
            foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this._NetProftLoss)
            {
              this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
              string[] strArray = keyValuePair.Key.Split('_');
              string key = strArray[0];
              string index = strArray[1];
              int int32 = Convert.ToInt32(strArray[2]);
              Decimal num1 = new Decimal();
              Decimal num2 = new Decimal();
              Decimal num3 = new Decimal();
              Decimal num4 = new Decimal();
              Decimal num5 = new Decimal();
              Decimal num6 = new Decimal();
              Decimal num7 = new Decimal();
              if (this.objmain._Symconctracts.ContainsKey(key) && this.objmain._ClientLimits.ContainsKey(index))
              {
                Contracts symconctract = this.objmain._Symconctracts[key];
                Limits clientLimit = this.objmain._ClientLimits[index];
                SymbolMargin symbolwiseMrgn = this.objmain.GetSymbolwiseMrgn(index, symconctract.symbol);
                Decimal turnoverBrkg = this.objmain.GetTurnoverBrkg(symconctract, clientLimit, int32);
                if (this._SymClosePrice.ContainsKey(symconctract.exch))
                {
                  Dictionary<string, double> dictionary = this._SymClosePrice[symconctract.exch];
                  buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
                  Decimal num8 = new Decimal();
                  Decimal num9 = !dictionary.ContainsKey(symconctract.SymDesp) ? this.GetBhavcopyClosePrice(symconctract.SymDesp) : Convert.ToDecimal(dictionary[symconctract.SymDesp]);
                  int num10 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
                  int num11;
                  int num12;
                  Decimal num13;
                  Decimal num14;
                  Decimal num15;
                  if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
                  {
                    num5 = (Decimal) (buysellnetpospfls.BQty + buysellnetpospfls.SQty);
                    int num16 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
                    num12 = num11 = buysellnetpospfls.BQty;
                    num13 = buysellnetpospfls.buyprice;
                    num14 = Decimal.Round((buysellnetpospfls.sellprice * (Decimal) buysellnetpospfls.SQty + num9 * (Decimal) num16) / (Decimal) buysellnetpospfls.BQty, 2);
                    num15 = symconctract.exch != 2 && symconctract.exch != 5 ? Decimal.Round((num14 - num13) * (Decimal) buysellnetpospfls.BQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((num14 - num13) * (Decimal) buysellnetpospfls.BQty, 2);
                    if (int32 == 1)
                      num4 = clientLimit.brkgtype != 2 ? (buysellnetpospfls.SQty <= 0 ? (symconctract.exch != 2 && symconctract.exch != 5 ? buysellnetpospfls.Commision : buysellnetpospfls.Commision) : (symconctract.exch != 2 && symconctract.exch != 5 ? buysellnetpospfls.Commision : buysellnetpospfls.Commision)) : buysellnetpospfls.Commision;
                    else if (buysellnetpospfls.SQty > 0)
                      num4 = clientLimit.brkgtype != 2 ? (symconctract.exch != 2 && symconctract.exch != 5 ? Decimal.Round((Decimal) num16 * num14 * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) num16 * num13 * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) num16 * num14 * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) num16 * num13 * turnoverBrkg / new Decimal(100), 2)) : buysellnetpospfls.Commision + Convert.ToDecimal(num16 * symbolwiseMrgn.delvbrkg);
                  }
                  else if (buysellnetpospfls.SQty > buysellnetpospfls.BQty)
                  {
                    num5 = (Decimal) (buysellnetpospfls.SQty + buysellnetpospfls.BQty);
                    int num16 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
                    num12 = num11 = buysellnetpospfls.SQty;
                    num14 = buysellnetpospfls.sellprice;
                    num13 = Decimal.Round((buysellnetpospfls.buyprice * (Decimal) buysellnetpospfls.BQty + num9 * (Decimal) num16) / (Decimal) buysellnetpospfls.SQty, 2);
                    num15 = symconctract.exch != 2 && symconctract.exch != 5 ? Decimal.Round((num14 - num13) * (Decimal) buysellnetpospfls.SQty * (Decimal) symconctract.lotsize, 2) : Decimal.Round((num14 - num13) * (Decimal) buysellnetpospfls.SQty, 2);
                    if (int32 == 1)
                      num4 = clientLimit.brkgtype != 2 ? (buysellnetpospfls.BQty <= 0 ? (symconctract.exch != 2 && symconctract.exch != 5 ? buysellnetpospfls.Commision : buysellnetpospfls.Commision) : (symconctract.exch != 2 && symconctract.exch != 5 ? buysellnetpospfls.Commision : buysellnetpospfls.Commision)) : buysellnetpospfls.Commision;
                    else if (buysellnetpospfls.BQty > 0)
                      num4 = clientLimit.brkgtype != 2 ? (symconctract.exch != 2 && symconctract.exch != 5 ? Decimal.Round((Decimal) num16 * num14 * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) num16 * num13 * (Decimal) symconctract.lotsize * turnoverBrkg / new Decimal(100), 2) : Decimal.Round((Decimal) num16 * num14 * turnoverBrkg / new Decimal(100), 2) + Decimal.Round((Decimal) num16 * num13 * turnoverBrkg / new Decimal(100), 2)) : Convert.ToDecimal(num16 * 2 * symbolwiseMrgn.delvbrkg);
                  }
                  else
                  {
                    num13 = buysellnetpospfls.buyprice;
                    num14 = buysellnetpospfls.sellprice;
                    num12 = num11 = buysellnetpospfls.BQty;
                    num15 = buysellnetpospfls.p_l;
                    num4 = buysellnetpospfls.Commision;
                    num6 = buysellnetpospfls.p_ltax;
                  }
                  Decimal num17 = Decimal.Round(num15 - num4, 2);
                  SqlCommand sqlCommand1 = new SqlCommand(nameof (StoreProfitLoss), conn);
                  sqlCommand1.CommandType = CommandType.StoredProcedure;
                  using (SqlCommand sqlCommand2 = sqlCommand1)
                  {
                    sqlCommand2.Parameters.AddWithValue("@clientcode", (object) index);
                    sqlCommand2.Parameters.AddWithValue("@exch", (object) Utils.GetExch(symconctract.exch));
                    sqlCommand2.Parameters.AddWithValue("@symbol", (object) key);
                    sqlCommand2.Parameters.AddWithValue("@validity", (object) Utils.GetValidity(int32));
                    sqlCommand2.Parameters.AddWithValue("@lotsize", (object) symconctract.lotsize);
                    sqlCommand2.Parameters.AddWithValue("@bqty", (object) num12);
                    sqlCommand2.Parameters.AddWithValue("@bavgprice", (object) num13);
                    sqlCommand2.Parameters.AddWithValue("@sqty", (object) num11);
                    sqlCommand2.Parameters.AddWithValue("@savgprice", (object) num14);
                    sqlCommand2.Parameters.AddWithValue("@netlot", (object) num10);
                    sqlCommand2.Parameters.AddWithValue("@closeprice", (object) num9);
                    sqlCommand2.Parameters.AddWithValue("@realisedpl", (object) num15);
                    sqlCommand2.Parameters.AddWithValue("@unrealisedpl", (object) 0);
                    sqlCommand2.Parameters.AddWithValue("@brkg", (object) num4);
                    sqlCommand2.Parameters.AddWithValue("@netmtmpl", (object) num17);
                    sqlCommand2.Parameters.AddWithValue("@datetime", (object) dateTime1.ToString("yyyy-MM-dd 00:00:00"));
                    try
                    {
                      sqlCommand2.ExecuteNonQuery();
                      flag = true;
                    }
                    catch
                    {
                      this.InsertMsgBoard("Unable to store Profit/Loss for ClientCode: " + index + ", Symbol: " + key ?? "");
                      break;
                    }
                  }
                }
                else
                  this.objmain.DisplayMessage("ClosePrice Not Available for: " + key + " to Store Profit/Loss", 2);
              }
              Thread.Sleep(250);
              Application.DoEvents();
            }
            if (flag)
            {
              this.InsertMsgBoard("Profit/Loss Stored Successfully!!");
              this.objmain.DisplayMessage("Profit/Loss Stored Successfully!!", 1);
              this.Invoke((Delegate) (() => this.progressMaintenance.Value = 0));
            }
          }
        }
        else
          this.objmain.DisplayMessage("No Profit/Loss Available to Store", 2);
      }
    }

    private void btnCashMrgn_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.UpdateCashMargin())).Invoke)).Start();
    }

    private void UpdateCashMargin()
    {
      if (this._SelectedExchanges.Count == 0)
      {
        this.InsertMsgBoard("Select Exchange to run Maintenance.");
        this.objmain.DisplayMessage("Select Exchange to run Maintenance.", 3);
      }
      else
      {
        SqlConnection conn = this.objmain.getConn();
        List<string> _lstAccounts = new List<string>();
        string accounts = this.GetAccounts(ref _lstAccounts);
        if (accounts.Length > 0)
        {
          DateTime dateTime1 = this.dtClosePriceDate.Value;
          string str = string.Empty;
          foreach (string selectedExchange in this._SelectedExchanges)
            str += string.Format("'{0}',", (object) selectedExchange);
          if (str.Length > 0)
            str = str.Substring(0, str.Length - 1);
          DateTime dateTime2 = new DateTime(dateTime1.Year, dateTime1.Month, dateTime1.Day, 0, 0, 0);
          if (conn.State != ConnectionState.Open)
            return;
          this.InsertMsgBoard("Updating CashMargin...");
          using (SqlCommand sqlCommand = new SqlCommand(string.Format("Select Clientcode,NetMTMPL from Profit_Loss_Archive where Clientcode in ({0}) and Timestamp = '{1}' and Exch in ({2}) ", (object) accounts, (object) dateTime2.ToString("yyyy-MM-dd HH:mm:ss"), (object) str), conn))
          {
            try
            {
              using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  string key = string.Empty;
                  Decimal num1 = new Decimal();
                  if (!sqlDataReader.IsDBNull(0))
                    key = sqlDataReader.GetString(0).Trim();
                  if (!sqlDataReader.IsDBNull(1))
                    num1 = Convert.ToDecimal(sqlDataReader.GetValue(1));
                  if (!this._ClientNetPfls.ContainsKey(key))
                  {
                    this._ClientNetPfls.Add(key, num1);
                  }
                  else
                  {
                    Decimal num2 = this._ClientNetPfls[key] + num1;
                    this._ClientNetPfls[key] = num2;
                  }
                }
              }
            }
            catch
            {
              this.InsertMsgBoard("Error occured while trying to get Net Profit/Loss.");
              return;
            }
          }
          if (this._ClientNetPfls.Count > 0)
          {
            this.Invoke((Delegate) (() =>
            {
              this.progressMaintenance.Minimum = 0;
              this.progressMaintenance.Maximum = this._ClientNetPfls.Count;
              this.progressMaintenance.Value = 0;
            }));
            foreach (KeyValuePair<string, Decimal> clientNetPfl in this._ClientNetPfls)
            {
              this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
              string key = clientNetPfl.Key;
              if (this.objmain._ClientLimits.ContainsKey(key))
              {
                Limits clientLimit = this.objmain._ClientLimits[key];
                Decimal num1 = clientNetPfl.Value;
                Decimal num2 = clientLimit.cashmrgn + num1;
                Decimal num3 = Decimal.Round(num2 * (Decimal) clientLimit.mtmmulti, 2);
                SqlCommand sqlCommand1 = new SqlCommand(nameof (UpdateCashMargin), conn);
                sqlCommand1.CommandType = CommandType.StoredProcedure;
                using (SqlCommand sqlCommand2 = sqlCommand1)
                {
                  sqlCommand2.Parameters.AddWithValue("@clientcode", (object) key);
                  sqlCommand2.Parameters.AddWithValue("@cashmrgn", (object) (num2 * new Decimal(100)));
                  sqlCommand2.Parameters.AddWithValue("@mtmlosslimit", (object) num3);
                  sqlCommand2.ExecuteNonQuery();
                }
              }
              Thread.Sleep(500);
              Application.DoEvents();
            }
            this.InsertMsgBoard("Cash Margin Updated Successfully!!");
            this.objmain.DisplayMessage("Cash Margin Updated Successfully!!", 1);
            this.Invoke((Delegate) (() => this.progressMaintenance.Value = 0));
          }
          else
            this.InsertMsgBoard("No Profit/Loss Accounted to Update Cash Margin.");
        }
        else
          this.objmain.DisplayMessage("Client Accounts Not Available to Update CashMargin", 1);
      }
    }

    private void btnCryPos_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.CarryForwardPosition())).Invoke)).Start();
    }

    private void CarryForwardPosition()
    {
      if (this._SelectedExchanges.Count == 0)
      {
        this.InsertMsgBoard("Select Exchange to run Maintenance.");
        this.objmain.DisplayMessage("Select Exchange to run Maintenance.", 3);
      }
      else
      {
        this.GetClosePrice();
        this.GetExchangewisePos(this._SelectedExchanges, this.objmain.getConn(), false);
        if (this._NetProftLoss.Count > 0)
        {
          this.Invoke((Delegate) (() =>
          {
            this.progressMaintenance.Minimum = 0;
            this.progressMaintenance.Maximum = this._NetProftLoss.Count;
            this.progressMaintenance.Value = 0;
          }));
          this.objmain.GetServerTime();
          DateTime dateTime1 = this.dtClosePriceDate.Value;
          DateTime dateTime2 = this.dtToDate.Value;
          DateTime dateTime3 = new DateTime(dateTime1.Year, dateTime1.Month, dateTime1.Day, 23, 55, 0);
          DateTime dateTime4 = new DateTime(dateTime2.Year, dateTime2.Month, dateTime2.Day, 9, 0, 0);
          this.InsertMsgBoard("Closing and Opening CarryForward Position...");
          foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in this._NetProftLoss)
          {
            this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
            string[] strArray = keyValuePair.Key.Split('_');
            string key = strArray[0];
            string str = strArray[1];
            int int32 = Convert.ToInt32(strArray[2]);
            if (this.objmain._Symconctracts.ContainsKey(key))
            {
              Contracts symconctract = this.objmain._Symconctracts[key];
              if (this._SymClosePrice.ContainsKey(symconctract.exch))
              {
                Dictionary<string, double> dictionary = this._SymClosePrice[symconctract.exch];
                Decimal num = new Decimal();
                if (dictionary.ContainsKey(symconctract.SymDesp))
                {
                  if (dictionary.ContainsKey(symconctract.SymDesp))
                    num = Convert.ToDecimal(dictionary[symconctract.SymDesp]);
                }
                else
                  num = this.GetBhavcopyClosePrice(symconctract.SymDesp);
                if (!(num <= Decimal.Zero))
                {
                  buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
                  if (buysellnetpospfls.buy_sell > 0)
                  {
                    Trades objtrade = new Trades()
                    {
                      exch = symconctract.exch,
                      Symbol = key,
                      validity = int32,
                      userremarks = string.Empty,
                      producttype = 1,
                      qty = buysellnetpospfls.Qty,
                      orderno = Trades.OrderNoGenerate(),
                      clientcode = str,
                      traderid = str,
                      Ordprice = num,
                      price = num,
                      Createon = dateTime3,
                      Lastmodified = dateTime3,
                      ordstatus = 1,
                      isMaintenance = 1,
                      exectype = 2
                    };
                    objtrade.buysell = buysellnetpospfls.buy_sell != 1 ? 1 : 2;
                    if (objtrade.qty > 0 && objtrade.price > Decimal.Zero && Trades.SaveOrder(objtrade, this.objmain.getConn()))
                      Trades.SaveTrade(objtrade, this.objmain.getConn());
                    if (int32 != 2)
                    {
                      Thread.Sleep(500);
                      Application.DoEvents();
                      if (symconctract.expiry >= dateTime4)
                      {
                        objtrade.buysell = buysellnetpospfls.buy_sell;
                        objtrade.Createon = dateTime4;
                        objtrade.Lastmodified = dateTime4;
                        objtrade.orderno = Trades.OrderNoGenerate();
                        if (objtrade.qty > 0 && objtrade.price > Decimal.Zero && Trades.SaveOrder(objtrade, this.objmain.getConn()))
                          Trades.SaveTrade(objtrade, this.objmain.getConn());
                      }
                    }
                  }
                }
                else
                  continue;
              }
            }
            Thread.Sleep(500);
            Application.DoEvents();
          }
          this.InsertMsgBoard("Position Carry Forward done Successfully!!");
          this.objmain.DisplayMessage("Position Carry Forward done Successfully!!", 1);
          this.Invoke((Delegate) (() => this.progressMaintenance.Value = 0));
        }
        else
          this.objmain.DisplayMessage("No Position Available for Carry Forward.", 1);
      }
    }

    private void btnArchData_Click(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.ArchiveData())).Invoke)).Start();
    }

    private void ArchiveData()
    {
      if (this._SelectedExchanges.Count == 0)
      {
        this.InsertMsgBoard("Select Exchange to run Maintenance.");
        this.objmain.DisplayMessage("Select Exchange to run Maintenance.", 3);
      }
      else
      {
        DateTime serverTime = this.objmain.GetServerTime();
        DateTime dateTime1 = serverTime.AddDays(-1.0);
        if (dateTime1.DayOfWeek == DayOfWeek.Saturday)
          dateTime1 = serverTime.AddDays(-2.0);
        DateTime dateTime2 = new DateTime(this.dtClosePriceDate.Value.Year, this.dtClosePriceDate.Value.Month, this.dtClosePriceDate.Value.Day, 23, 59, 0);
        if (this.objmain.getConn().State != ConnectionState.Open)
          return;
        this.InsertMsgBoard("Archiving Data...");
        this.ArchiveDataQueries();
        this.InsertMsgBoard("Data Archived Successfully!!");
        this.objmain.DisplayMessage("Data Archived Successfully!!", 1);
        this.Invoke((Delegate) (() => this.progressMaintenance.Value = 0));
      }
    }

    private void btnUploadBhavcopy_Click(object sender, EventArgs e)
    {
      if (this.rdoNsecurr.Checked)
      {
        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        openFileDialog1.Title = "Browse NSE Currency Bhavcopy";
        openFileDialog1.InitialDirectory = "D:\\My Documents\\Downloads";
        openFileDialog1.RestoreDirectory = true;
        openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
        openFileDialog1.FilterIndex = 1;
        using (OpenFileDialog openFileDialog2 = openFileDialog1)
        {
          if (openFileDialog2.ShowDialog() != DialogResult.OK)
            return;
          string filePath = openFileDialog2.FileName;
          new Thread(new ThreadStart(((ThreadStart) (() => this.UploadNSECURREOD(filePath))).Invoke)).Start();
        }
      }
      else if (this.rdoMcx.Checked)
      {
        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        openFileDialog1.Title = "Browse MCX Bhavcopy";
        openFileDialog1.InitialDirectory = "D:\\My Documents\\Downloads";
        openFileDialog1.RestoreDirectory = true;
        openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
        openFileDialog1.FilterIndex = 1;
        using (OpenFileDialog openFileDialog2 = openFileDialog1)
        {
          if (openFileDialog2.ShowDialog() != DialogResult.OK)
            return;
          string filePath = openFileDialog2.FileName;
          new Thread(new ThreadStart(((ThreadStart) (() => this.UploadMCXEOD(filePath))).Invoke)).Start();
        }
      }
      else if (this.rdoncdex.Checked)
      {
        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        openFileDialog1.Title = "Browse NCDEX Bhavcopy";
        openFileDialog1.InitialDirectory = "D:\\My Documents\\Downloads";
        openFileDialog1.RestoreDirectory = true;
        openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
        openFileDialog1.FilterIndex = 1;
        using (OpenFileDialog openFileDialog2 = openFileDialog1)
        {
          if (openFileDialog2.ShowDialog() != DialogResult.OK)
            return;
          string path = openFileDialog2.FileName;
          new Thread(new ThreadStart(((ThreadStart) (() => this.UploadNCDEXEOD(path))).Invoke)).Start();
        }
      }
      else
      {
        if (!this.rdoNseFut.Checked)
          return;
        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        openFileDialog1.Title = "Browse NSE FO Bhavcopy";
        openFileDialog1.InitialDirectory = "D:\\My Documents\\Downloads";
        openFileDialog1.RestoreDirectory = true;
        openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
        openFileDialog1.FilterIndex = 1;
        using (OpenFileDialog openFileDialog2 = openFileDialog1)
        {
          if (openFileDialog2.ShowDialog() == DialogResult.OK)
          {
            string filePath = openFileDialog2.FileName;
            new Thread(new ThreadStart(((ThreadStart) (() => this.UploadNSEEOD(filePath))).Invoke)).Start();
          }
        }
      }
    }

    private void UploadNSEEOD(string filePath)
    {
      FileStream fileStream = new FileStream(filePath, FileMode.Open);
      StreamReader streamReader = new StreamReader((Stream) fileStream);
      bool flag = true;
      Dictionary<string, Maintenance.EOD> dictionary = new Dictionary<string, Maintenance.EOD>();
      Dictionary<string, List<DateTime>> _Bhavcopy2 = new Dictionary<string, List<DateTime>>();
      Dictionary<string, List<Maintenance.EOD>> _Bhavcopylist = new Dictionary<string, List<Maintenance.EOD>>();
      this.InsertMsgBoard("Processing NSE Bhavcopy...");
      while (true)
      {
        string str1 = streamReader.ReadLine();
        if (str1 != null)
        {
          if (flag)
          {
            flag = false;
          }
          else
          {
            string[] strArray = str1.Split(',');
            Maintenance.EOD eod = new Maintenance.EOD();
            string str2 = strArray[0];
            if (str2.ToUpper() == "FUTIDX" || str2.ToUpper() == "FUTSTK")
            {
              eod.symbol = strArray[1];
              eod.expiry = Convert.ToDateTime(strArray[2]);
              eod.open = Convert.ToDouble(strArray[5]);
              eod.high = Convert.ToDouble(strArray[6]);
              eod.low = Convert.ToDouble(strArray[7]);
              eod.close = Convert.ToDouble(strArray[8]);
              eod.Volume = Convert.ToDouble(strArray[10]);
              eod.Feed = Convert.ToDateTime(strArray[14]);
              eod.OpenInterest = Convert.ToInt32(strArray[12]);
              eod.SymDescp = this.GetSymbolDescrp(eod.symbol, eod.expiry);
              eod.Exch = 2;
              eod.exchange = "NSE-FO";
              if (!_Bhavcopy2.ContainsKey(eod.symbol))
              {
                _Bhavcopy2.Add(eod.symbol, new List<DateTime>()
                {
                  eod.expiry
                });
              }
              else
              {
                List<DateTime> dateTimeList = _Bhavcopy2[eod.symbol];
                if (!dateTimeList.Contains(eod.expiry))
                  dateTimeList.Add(eod.expiry);
                _Bhavcopy2[eod.symbol] = dateTimeList;
              }
              if (!_Bhavcopylist.ContainsKey(eod.symbol))
              {
                _Bhavcopylist.Add(eod.symbol, new List<Maintenance.EOD>()
                {
                  eod
                });
              }
              else
              {
                List<Maintenance.EOD> eodList = _Bhavcopylist[eod.symbol];
                eodList.Add(eod);
                _Bhavcopylist[eod.symbol] = eodList;
              }
            }
            Thread.Sleep(1);
          }
        }
        else
          break;
      }
      Dictionary<string, Maintenance.EOD> _Bhavcopy = this.SegregateBhavcopy(_Bhavcopy2, _Bhavcopylist);
      if (_Bhavcopy.Count > 0)
      {
        this.InsertMsgBoard(this.InsertEOD(_Bhavcopy).ToString() + " Symbols Imported Successfully!!");
      }
      else
      {
        int num = (int) MessageBox.Show("No data to import.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
      fileStream.Close();
      streamReader.Close();
    }

    private void UploadNCDEXEOD(string filePath)
    {
      FileStream fileStream = new FileStream(filePath, FileMode.Open);
      StreamReader streamReader = new StreamReader((Stream) fileStream);
      bool flag = true;
      Dictionary<string, Maintenance.EOD> dictionary = new Dictionary<string, Maintenance.EOD>();
      Dictionary<string, List<DateTime>> _Bhavcopy2 = new Dictionary<string, List<DateTime>>();
      Dictionary<string, List<Maintenance.EOD>> _Bhavcopylist = new Dictionary<string, List<Maintenance.EOD>>();
      this.InsertMsgBoard("Processing NCDEX Bhavcopy...");
      while (true)
      {
        string[] strArray;
        Maintenance.EOD eod;
        do
        {
          do
          {
            string str = streamReader.ReadLine();
            if (str != null)
            {
              if (!flag)
              {
                strArray = str.Split(',');
                eod = new Maintenance.EOD();
              }
              else
                goto label_2;
            }
            else
              goto label_29;
          }
          while (!this.GetNcdexExpiry(strArray[15], ref eod.Feed));
          string str1 = strArray[0];
          if (str1[0] == '"')
          {
            string str2 = str1.Substring(1, str1.Length - 1);
            str1 = str2.Substring(0, str2.Length - 1);
          }
          eod.symbol = str1.Trim();
        }
        while (!this.GetNcdexExpiry(strArray[1], ref eod.expiry));
        goto label_7;
label_2:
        flag = false;
        continue;
label_7:
        string str3 = strArray[6];
        string str4 = strArray[7];
        string str5 = strArray[8];
        string str6 = strArray[9];
        string str7 = strArray[10];
        string str8 = strArray[14];
        if (strArray[6][0] == '"')
        {
          string str1 = strArray[6].Substring(1, strArray[6].Length - 1);
          str3 = str1.Substring(0, str1.Length - 1);
        }
        eod.open = Convert.ToDouble(str3);
        if (strArray[7][0] == '"')
        {
          string str1 = strArray[7].Substring(1, strArray[7].Length - 1);
          str4 = str1.Substring(0, str1.Length - 1);
        }
        eod.high = Convert.ToDouble(str4);
        if (strArray[8][0] == '"')
        {
          string str1 = strArray[8].Substring(1, strArray[8].Length - 1);
          str5 = str1.Substring(0, str1.Length - 1);
        }
        eod.low = Convert.ToDouble(str5);
        if (strArray[9][0] == '"')
        {
          string str1 = strArray[9].Substring(1, strArray[9].Length - 1);
          str6 = str1.Substring(0, str1.Length - 1);
        }
        eod.close = Convert.ToDouble(str6);
        if (strArray[10][0] == '"')
        {
          string str1 = strArray[10].Substring(1, strArray[10].Length - 1);
          str7 = str1.Substring(0, str1.Length - 1);
        }
        eod.Volume = Convert.ToDouble(str7);
        if (strArray[14][0] == '"')
        {
          string str1 = strArray[14].Substring(1, strArray[14].Length - 1);
          str8 = str1.Substring(0, str1.Length - 1);
        }
        eod.OpenInterest = Convert.ToInt32(str8);
        eod.exchange = "NCDEX";
        eod.Exch = 3;
        eod.SymDescp = this.GetSymbolDescrp(eod.symbol, eod.expiry);
        if (!_Bhavcopy2.ContainsKey(eod.symbol))
        {
          _Bhavcopy2.Add(eod.symbol, new List<DateTime>()
          {
            eod.expiry
          });
        }
        else
        {
          List<DateTime> dateTimeList = _Bhavcopy2[eod.symbol];
          if (!dateTimeList.Contains(eod.expiry))
            dateTimeList.Add(eod.expiry);
          _Bhavcopy2[eod.symbol] = dateTimeList;
        }
        if (!_Bhavcopylist.ContainsKey(eod.symbol))
        {
          _Bhavcopylist.Add(eod.symbol, new List<Maintenance.EOD>()
          {
            eod
          });
        }
        else
        {
          List<Maintenance.EOD> eodList = _Bhavcopylist[eod.symbol];
          eodList.Add(eod);
          _Bhavcopylist[eod.symbol] = eodList;
        }
        Thread.Sleep(1);
      }
label_29:
      Dictionary<string, Maintenance.EOD> _Bhavcopy = this.SegregateBhavcopy(_Bhavcopy2, _Bhavcopylist);
      if (_Bhavcopy.Count > 0)
      {
        this.InsertMsgBoard(this.InsertEOD(_Bhavcopy).ToString() + " Symbols Imported Successfully!!");
      }
      else
      {
        int num = (int) MessageBox.Show("No data to import.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
      fileStream.Close();
      streamReader.Close();
    }

    private bool GetNcdexExpiry(string expiry, ref DateTime fexpiry)
    {
      if (expiry.IndexOf("/") > 0)
      {
        string[] strArray = expiry.Split('/');
        string str1 = strArray[0][0] != '"' ? strArray[0] : strArray[0].Substring(1, strArray[0].Length - 1);
        string str2 = strArray[1];
        string str3 = strArray[2][strArray[2].Length - 1] != '"' ? strArray[2] : strArray[2].Substring(0, strArray[2].Length - 1);
        fexpiry = new DateTime(Convert.ToInt32(str3), Convert.ToInt32(str1), Convert.ToInt32(str2), 0, 0, 0);
        return true;
      }
      if (expiry.IndexOf("-") <= 0)
        return false;
      string[] strArray1 = expiry.Split('-');
      string str4 = strArray1[0][0] != '"' ? strArray1[0] : strArray1[0].Substring(1, strArray1[0].Length - 1);
      string str5 = strArray1[1];
      string str6 = strArray1[2][strArray1[2].Length - 1] != '"' ? strArray1[2] : strArray1[2].Substring(0, strArray1[2].Length - 1);
      fexpiry = new DateTime(Convert.ToInt32(str6), Convert.ToInt32(str4), Convert.ToInt32(str5), 0, 0, 0);
      return true;
    }

    private void UploadMCXEOD(string filePath)
    {
      FileStream fileStream = new FileStream(filePath, FileMode.Open);
      StreamReader streamReader = new StreamReader((Stream) fileStream);
      bool flag = true;
      Dictionary<string, Maintenance.EOD> dictionary = new Dictionary<string, Maintenance.EOD>();
      Dictionary<string, List<DateTime>> _Bhavcopy2 = new Dictionary<string, List<DateTime>>();
      Dictionary<string, List<Maintenance.EOD>> _Bhavcopylist = new Dictionary<string, List<Maintenance.EOD>>();
      this.InsertMsgBoard("Processing MCX Bhavcopy...");
      while (true)
      {
        string str = streamReader.ReadLine();
        if (str != null)
        {
          if (flag)
          {
            flag = false;
          }
          else
          {
            string[] strArray = str.Split(',');
            Maintenance.EOD eod = new Maintenance.EOD()
            {
              Feed = Convert.ToDateTime(strArray[0]),
              symbol = strArray[1],
              expiry = Convert.ToDateTime(strArray[2]),
              open = Convert.ToDouble(strArray[3]),
              high = Convert.ToDouble(strArray[4]),
              low = Convert.ToDouble(strArray[5]),
              close = Convert.ToDouble(strArray[6]),
              Volume = Convert.ToDouble(strArray[8]),
              OpenInterest = Convert.ToInt32(strArray[11])
            };
            eod.SymDescp = this.GetSymbolDescrp(eod.symbol, eod.expiry);
            eod.exchange = "MCX";
            eod.Exch = 1;
            if (!_Bhavcopy2.ContainsKey(eod.symbol))
            {
              _Bhavcopy2.Add(eod.symbol, new List<DateTime>()
              {
                eod.expiry
              });
            }
            else
            {
              List<DateTime> dateTimeList = _Bhavcopy2[eod.symbol];
              if (!dateTimeList.Contains(eod.expiry))
                dateTimeList.Add(eod.expiry);
              _Bhavcopy2[eod.symbol] = dateTimeList;
            }
            if (!_Bhavcopylist.ContainsKey(eod.symbol))
            {
              _Bhavcopylist.Add(eod.symbol, new List<Maintenance.EOD>()
              {
                eod
              });
            }
            else
            {
              List<Maintenance.EOD> eodList = _Bhavcopylist[eod.symbol];
              eodList.Add(eod);
              _Bhavcopylist[eod.symbol] = eodList;
            }
            Thread.Sleep(1);
          }
        }
        else
          break;
      }
      Dictionary<string, Maintenance.EOD> _Bhavcopy = this.SegregateBhavcopy(_Bhavcopy2, _Bhavcopylist);
      if (_Bhavcopy.Count > 0)
      {
        this.InsertMsgBoard(this.InsertEOD(_Bhavcopy).ToString() + " Symbols Imported Successfully!!");
      }
      else
      {
        int num = (int) MessageBox.Show("No data to import.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
      fileStream.Close();
      streamReader.Close();
    }

    private void UploadNSECURREOD(string filePath)
    {
      FileStream fileStream = new FileStream(filePath, FileMode.Open);
      StreamReader streamReader = new StreamReader((Stream) fileStream);
      bool flag = true;
      Dictionary<string, Maintenance.EOD> dictionary = new Dictionary<string, Maintenance.EOD>();
      Dictionary<string, List<DateTime>> _Bhavcopy2 = new Dictionary<string, List<DateTime>>();
      Dictionary<string, List<Maintenance.EOD>> _Bhavcopylist = new Dictionary<string, List<Maintenance.EOD>>();
      this.InsertMsgBoard("Processing NSECURR Bhavcopy...");
      while (true)
      {
        string[] strArray;
        Maintenance.EOD eod;
        do
        {
          do
          {
            string str = streamReader.ReadLine();
            if (str != null)
            {
              if (!flag)
              {
                strArray = str.Split(',');
                eod = new Maintenance.EOD();
                if (strArray[0].Trim().ToUpper() == "FUTCUR")
                  eod.symbol = strArray[1].Trim();
                else
                  goto label_15;
              }
              else
                goto label_2;
            }
            else
              goto label_17;
          }
          while (!this.GetNseCurExpiry(strArray[2], ref eod.expiry));
          eod.open = Convert.ToDouble(strArray[3]);
          eod.high = Convert.ToDouble(strArray[4]);
          eod.low = Convert.ToDouble(strArray[5]);
          eod.close = Convert.ToDouble(strArray[6]);
          eod.Volume = Convert.ToDouble(strArray[9]);
          eod.SymDescp = this.GetSymbolDescrp(eod.symbol, eod.expiry);
        }
        while (!this.GetNseCurExpiry(strArray[12], ref eod.Feed));
        goto label_6;
label_2:
        flag = false;
        continue;
label_6:
        eod.OpenInterest = Convert.ToInt32(strArray[7]);
        eod.exchange = "NSECURR";
        eod.Exch = 4;
        if (!_Bhavcopy2.ContainsKey(eod.symbol))
        {
          _Bhavcopy2.Add(eod.symbol, new List<DateTime>()
          {
            eod.expiry
          });
        }
        else
        {
          List<DateTime> dateTimeList = _Bhavcopy2[eod.symbol];
          if (!dateTimeList.Contains(eod.expiry))
            dateTimeList.Add(eod.expiry);
          _Bhavcopy2[eod.symbol] = dateTimeList;
        }
        if (!_Bhavcopylist.ContainsKey(eod.symbol))
        {
          _Bhavcopylist.Add(eod.symbol, new List<Maintenance.EOD>()
          {
            eod
          });
        }
        else
        {
          List<Maintenance.EOD> eodList = _Bhavcopylist[eod.symbol];
          eodList.Add(eod);
          _Bhavcopylist[eod.symbol] = eodList;
        }
label_15:
        Thread.Sleep(1);
      }
label_17:
      Dictionary<string, Maintenance.EOD> _Bhavcopy = this.SegregateBhavcopy(_Bhavcopy2, _Bhavcopylist);
      if (_Bhavcopy.Count > 0)
      {
        this.InsertMsgBoard(this.InsertEOD(_Bhavcopy).ToString() + " Symbols Imported Successfully!!");
      }
      else
      {
        int num = (int) MessageBox.Show("No data to import.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
      fileStream.Close();
      streamReader.Close();
    }

    private void InsertMsgBoard(string message)
    {
      this.Invoke((Delegate) (() => this.lstMsg.Items.Insert(0, (object) message)));
    }

    private int InsertEOD(Dictionary<string, Maintenance.EOD> _Bhavcopy)
    {
      int num1 = 0;
      SqlConnection conn = this.objmain.getConn();
      foreach (KeyValuePair<string, Maintenance.EOD> keyValuePair in _Bhavcopy)
      {
        Maintenance.EOD eod = keyValuePair.Value;
        this.InsertMsgBoard(eod.SymDescp);
        SqlCommand sqlCommand1 = new SqlCommand("UpdateBhavcopy", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@symbol", (object) eod.symbol.Trim());
          sqlCommand2.Parameters.AddWithValue("@expiry", (object) eod.expiry.ToString("yyyy-MM-dd HH:mm:ss"));
          sqlCommand2.Parameters.AddWithValue("@open", (object) eod.open);
          sqlCommand2.Parameters.AddWithValue("@high", (object) eod.high);
          sqlCommand2.Parameters.AddWithValue("@low", (object) eod.low);
          sqlCommand2.Parameters.AddWithValue("@close", (object) eod.close);
          sqlCommand2.Parameters.AddWithValue("@datetime", (object) eod.Feed.ToString("yyyy-MM-dd HH:mm:ss"));
          sqlCommand2.Parameters.AddWithValue("@OpenInt", (object) eod.OpenInterest);
          sqlCommand2.Parameters.AddWithValue("@volume", (object) eod.Volume);
          sqlCommand2.Parameters.AddWithValue("@exch", (object) eod.Exch);
          sqlCommand2.Parameters.AddWithValue("@symdescrp", (object) eod.SymDescp);
          try
          {
            num1 += sqlCommand2.ExecuteNonQuery();
            if (!this._SymClosePrice.ContainsKey(eod.Exch))
            {
              this._SymClosePrice.Add(eod.Exch, new Dictionary<string, double>()
              {
                {
                  eod.SymDescp.Trim(),
                  eod.close
                }
              });
            }
            else
            {
              Dictionary<string, double> dictionary = this._SymClosePrice[eod.Exch];
              if (!dictionary.ContainsKey(eod.SymDescp.Trim()))
                dictionary.Add(eod.SymDescp.Trim(), eod.close);
              this._SymClosePrice[eod.Exch] = dictionary;
            }
          }
          catch (Exception ex)
          {
            int num2 = (int) MessageBox.Show("Error occured while importing bhavcopy: " + ex.Message ?? "", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            break;
          }
        }
        Thread.Sleep(1);
      }
      return num1;
    }

    private Dictionary<string, Maintenance.EOD> SegregateBhavcopy(
      Dictionary<string, List<DateTime>> _Bhavcopy2,
      Dictionary<string, List<Maintenance.EOD>> _Bhavcopylist)
    {
      Dictionary<string, Maintenance.EOD> dictionary = new Dictionary<string, Maintenance.EOD>();
      foreach (KeyValuePair<string, List<DateTime>> keyValuePair in _Bhavcopy2)
      {
        string key = keyValuePair.Key;
        List<DateTime> dateTimeList = keyValuePair.Value;
        dateTimeList.Sort();
        if (dateTimeList.Count > 2)
        {
          int count = dateTimeList.Count - 2;
          dateTimeList.RemoveRange(2, count);
        }
        if (_Bhavcopylist.ContainsKey(key))
        {
          foreach (Maintenance.EOD eod in _Bhavcopylist[key])
          {
            if (dateTimeList.Contains(eod.expiry))
            {
              int num = dateTimeList.IndexOf(eod.expiry) + 1;
              eod.usersymbol = eod.symbol + num.ToString();
              if (!dictionary.ContainsKey(eod.usersymbol))
                dictionary.Add(eod.usersymbol, eod);
            }
          }
        }
      }
      return dictionary;
    }

    private string GetSymbolDescrp(string symbol, DateTime expiry)
    {
      string str = expiry.Day.ToString();
      if (str.Length == 1)
        str = "0" + str;
      string month = Utils.GetMonth(expiry.Month);
      return string.Format("{0} {1}{2}{3}", (object) symbol, (object) str, (object) month, (object) expiry.Year);
    }

    private bool GetNseCurExpiry(string expiry, ref DateTime fexpiry)
    {
      if (expiry.IndexOf("/") > 0)
      {
        string[] strArray = expiry.Split('/');
        string str1 = strArray[1];
        string str2 = strArray[0];
        string str3 = strArray[2];
        fexpiry = new DateTime(Convert.ToInt32(str3), Convert.ToInt32(str1), Convert.ToInt32(str2), 0, 0, 0);
        return true;
      }
      if (expiry.IndexOf("-") <= 0)
        return false;
      string[] strArray1 = expiry.Split('-');
      string str4 = strArray1[1];
      string str5 = strArray1[0];
      string str6 = strArray1[2];
      fexpiry = new DateTime(Convert.ToInt32(str6), Convert.ToInt32(str4), Convert.ToInt32(str5), 0, 0, 0);
      return true;
    }

    private void chkExchList_SelectedIndexChanged(object sender, EventArgs e)
    {
      this._SelectedExchanges = new List<string>();
      foreach (object checkedItem in this.chkExchList.CheckedItems)
        this._SelectedExchanges.Add(checkedItem.ToString());
    }

    private void ArchiveDataQueries()
    {
      List<string> _lstAccounts = new List<string>();
      string accounts = this.GetAccounts(ref _lstAccounts);
      foreach (string selectedExchange in this._SelectedExchanges)
      {
        this.Invoke((Delegate) (() =>
        {
          this.progressMaintenance.Minimum = 0;
          this.progressMaintenance.Maximum = 11;
          this.progressMaintenance.Value = 0;
        }));
        int intExch = Utils.GetIntExch(selectedExchange);
        DateTime dateTime = new DateTime(this.dtClosePriceDate.Value.Year, this.dtClosePriceDate.Value.Month, this.dtClosePriceDate.Value.Day, 23, 59, 0);
        string cmdText1 = "Select Symbol,Exch,BuySell,Productype,Qty,OrdPrice,Price,Orderno,Validity,Userremarks,Clientcode,Traderid,Createon,Lastmodified, OrdStatus,IsAdmin,IsMaintenance,ExecType from Orders where Validity <> 3 and Lastmodified < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "'  and Clientcode in  (" + accounts + ") and Exch = " + (object) intExch ?? "";
        SqlConnection conn1 = this.objmain.getConn();
        if (conn1.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand(cmdText1, conn1))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
                this.ArchiveOrders(this.GetOrders(reader), conn1);
            }
          }
        }
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Delete from Orders  where Validity <> 3 and Lastmodified < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ") and Exch = " + (object) intExch ?? "");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        string cmdText2 = "Select Symbol,Exch,BuySell,Productype,Qty,OrdPrice,Price,Orderno,Validity,Userremarks,Clientcode,Traderid,Createon, Lastmodified, OrdStatus,IsAdmin,IsMaintenance, ExecType from Orders where Validity = 3 and OrdStatus <> 2 and LastModified < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "'  and Clientcode in (" + accounts + ") and Exch = " + (object) intExch ?? "";
        SqlConnection conn2 = this.objmain.getConn();
        if (conn2.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand(cmdText2, conn2))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
                this.ArchiveOrders(this.GetOrders(reader), conn2);
            }
          }
        }
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Delete from Orders where Validity = 3 and OrdStatus <> 2 and LastModified < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ") and Exch = " + (object) intExch ?? "");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        string cmdText3 = "Select Clientcode,Symbol,Qty,Orderno,Price,[Timestamp],BuySell,Exch from Trade  with(nolock) where [Timestamp] <  '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ") and Exch = " + (object) intExch + " ";
        SqlConnection conn3 = this.objmain.getConn();
        if (conn3.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand(cmdText3, conn3))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
                this.ArchiveTrades(this.GetTrades(reader), conn3);
            }
          }
        }
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Delete from Trade where [Timestamp] < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ") and Exch = " + (object) intExch ?? "");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery(" Insert into Modified_History (Clientcode,Orderno,OldQty,OldPrice,ModifiedQty,ModifiedPrice,ModifiedTime) Select Clientcode,Orderno, OldQty,OldPrice, ModifiedQty,ModifiedPrice,ModifiedTime  from [Modified]  with(nolock) where ModifiedTime < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ")");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Delete from Modified where ModifiedTime < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ")");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Insert into MessageLogs_History Select Clientcode,Logmsg,Logtime from MessageLogs with(nolock) where LogTime < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "'  and Clientcode in (" + accounts + ")");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Delete from MessageLogs where LogTime < '" + dateTime.ToString("yyyy-MM-dd HH:mm:ss") + "' and Clientcode in (" + accounts + ")");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
        this.ExecuteQuery("Insert into Limitset_History (Clientcode,Cashmrgn, [Turnoverlimit],[MTMlosslimit],[Turnmulti],[MTMmulti],Breakup,Brkgtype,Mcxbrkg, Nsefutbrkg, Ncdexbrkg,Nsecurrbrkg,McxCNFbrkg,NsefutCNFbrkg,NcdexCNFbrkg,NsecurrCNFbrkg, TradeAttbutes,Mrgntype,isIntrasqoff, isMrgnsqoff,Timestamp, lotwisetype,mcxlots,ncxlots,nsefutlots,nsecurlots)  Select Clientcode,Cashmrgn, [Turnoverlimit],[MTMlosslimit],[Turnmulti],[MTMmulti],Breakup,Brkgtype,Mcxbrkg,  Nsefutbrkg,Ncdexbrkg,Nsecurrbrkg,McxCNFbrkg,NsefutCNFbrkg,NcdexCNFbrkg,NsecurrCNFbrkg,TradeAttbutes,Mrgntype, isIntrasqoff,isMrgnsqoff,GETDATE(),lotwisetype,mcxlots,ncxlots,nsefutlots,nsecurlots from Limitset where Clientcode in (" + accounts + ")");
        this.Invoke((Delegate) (() => this.progressMaintenance.PerformStep()));
      }
    }

    private bool ExecuteQuery(string Query)
    {
      SqlConnection conn = this.objmain.getConn();
      if (conn.State != ConnectionState.Open)
        return false;
      using (SqlCommand sqlCommand = new SqlCommand(Query, conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    private Orders GetOrders(SqlDataReader reader)
    {
      Orders orders = new Orders();
      if (!reader.IsDBNull(0))
        orders.symbol = reader.GetString(0);
      if (!reader.IsDBNull(1))
        orders.ExchangeTypeID = reader.GetInt32(1);
      if (!reader.IsDBNull(2))
        orders.BuySell = reader.GetInt32(2);
      if (!reader.IsDBNull(3))
        orders.ProductType = reader.GetInt32(2);
      if (!reader.IsDBNull(4))
        orders.Ordeqty = reader.GetInt32(4);
      if (!reader.IsDBNull(5))
        orders.OrdePrice = Convert.ToDecimal(reader.GetValue(5));
      if (!reader.IsDBNull(6))
        orders.ExecPrice = Convert.ToDecimal(reader.GetValue(6));
      if (!reader.IsDBNull(7))
        orders.OrderNo = Convert.ToDouble(reader.GetValue(7));
      if (!reader.IsDBNull(8))
        orders.ValidityType = reader.GetInt32(8);
      if (!reader.IsDBNull(9))
        orders.UserRemark = reader.GetString(9);
      if (!reader.IsDBNull(10))
        orders.accountNo = reader.GetString(10);
      if (!reader.IsDBNull(11))
        orders.TraderId = reader.GetString(11);
      if (!reader.IsDBNull(12))
        orders.CreatedOn = Convert.ToDateTime(reader.GetValue(12));
      if (!reader.IsDBNull(13))
        orders.LastModified = Convert.ToDateTime(reader.GetValue(13));
      if (!reader.IsDBNull(14))
        orders.Orderstatus = reader.GetInt32(14);
      if (!reader.IsDBNull(15))
        orders.isAdmin = reader.GetInt32(15);
      if (!reader.IsDBNull(16))
        orders.isMaintenance = reader.GetInt32(16);
      if (!reader.IsDBNull(17))
        orders.Exectype = reader.GetInt32(17);
      return orders;
    }

    private bool ArchiveOrders(Orders objord, SqlConnection conn)
    {
      SqlCommand sqlCommand1 = new SqlCommand(nameof (ArchiveOrders), conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@symbol", (object) objord.symbol);
        sqlCommand2.Parameters.AddWithValue("@exch", (object) objord.ExchangeTypeID);
        sqlCommand2.Parameters.AddWithValue("@buysell", (object) objord.BuySell);
        sqlCommand2.Parameters.AddWithValue("@productType", (object) objord.ProductType);
        sqlCommand2.Parameters.AddWithValue("@qty", (object) objord.Ordeqty);
        sqlCommand2.Parameters.AddWithValue("@ordprice", (object) objord.OrdePrice);
        sqlCommand2.Parameters.AddWithValue("@price", (object) objord.ExecPrice);
        sqlCommand2.Parameters.AddWithValue("@orderno", (object) objord.OrderNo);
        sqlCommand2.Parameters.AddWithValue("@validity", (object) objord.ValidityType);
        sqlCommand2.Parameters.AddWithValue("@userremarks", (object) objord.UserRemark);
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objord.accountNo);
        sqlCommand2.Parameters.AddWithValue("@traderid", (object) objord.TraderId);
        sqlCommand2.Parameters.AddWithValue("@createon", (object) objord.CreatedOn);
        sqlCommand2.Parameters.AddWithValue("@lastmodified", (object) objord.LastModified);
        sqlCommand2.Parameters.AddWithValue("@ordstatus", (object) objord.Orderstatus);
        sqlCommand2.Parameters.AddWithValue("@isadmin", (object) objord.isAdmin);
        sqlCommand2.Parameters.AddWithValue("@ismaintenance", (object) objord.isMaintenance);
        sqlCommand2.Parameters.AddWithValue("@exectype", (object) objord.Exectype);
        try
        {
          sqlCommand2.ExecuteNonQuery();
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    private Trades GetTrades(SqlDataReader reader)
    {
      Trades trades = new Trades();
      if (!reader.IsDBNull(0))
        trades.clientcode = reader.GetString(0);
      if (!reader.IsDBNull(1))
        trades.Symbol = reader.GetString(1);
      if (!reader.IsDBNull(2))
        trades.qty = reader.GetInt32(2);
      if (!reader.IsDBNull(3))
        trades.orderno = Convert.ToDouble(reader.GetValue(3));
      if (!reader.IsDBNull(4))
        trades.price = Convert.ToDecimal(reader.GetValue(4));
      if (!reader.IsDBNull(5))
        trades.Lastmodified = Convert.ToDateTime(reader.GetValue(5));
      if (!reader.IsDBNull(6))
        trades.buysell = reader.GetInt32(6);
      if (!reader.IsDBNull(7))
        trades.exch = reader.GetInt32(7);
      return trades;
    }

    private bool ArchiveTrades(Trades objtrd, SqlConnection conn)
    {
      SqlCommand sqlCommand1 = new SqlCommand(nameof (ArchiveTrades), conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objtrd.clientcode);
        sqlCommand2.Parameters.AddWithValue("@symbol", (object) objtrd.Symbol);
        sqlCommand2.Parameters.AddWithValue("@qty", (object) objtrd.qty);
        sqlCommand2.Parameters.AddWithValue("@orderno", (object) objtrd.orderno);
        sqlCommand2.Parameters.AddWithValue("@price", (object) objtrd.price);
        sqlCommand2.Parameters.AddWithValue("@timestamp", (object) objtrd.Lastmodified);
        sqlCommand2.Parameters.AddWithValue("@buysell", (object) objtrd.buysell);
        sqlCommand2.Parameters.AddWithValue("@exch", (object) objtrd.exch);
        try
        {
          sqlCommand2.ExecuteNonQuery();
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
    {
      foreach (TreeNode node in e.Node.Nodes)
        node.Checked = e.Node.Checked;
    }

    private Decimal GetBhavcopyClosePrice(string symbol)
    {
      Decimal num = new Decimal();
      SqlConnection conn = this.objmain.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("Select SymDescription,[Close],Exch from Bhavcopy where Timestamp = '" + this.dtClosePriceDate.Value.ToString("yyyy-MM-dd 00:00:00") + "' and [SymDescription] = '" + symbol + "'", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(1))
              num = Convert.ToDecimal(sqlDataReader.GetValue(1));
          }
        }
      }
      return num;
    }

    private void StoreMaintenanceLogs(int type)
    {
      SqlConnection conn = this.objmain.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("insert into MaintenanceLogs (Code,Type,Timestamp,Exch) values ('" + this.objmain.objinfo.clientcode + "'," + (object) type + ",convert(date, getdate()) ", conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    private bool ValidateMaintenanceLogs(int type)
    {
      SqlConnection conn = this.objmain.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("Select Count(ID) from MaintenanceLogs where Code = '" + this.objmain.objinfo.clientcode + "' and Type = " + (object) type + " and convert(date, getdate())", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              return sqlDataReader.GetInt32(0) <= 0;
          }
        }
      }
      return false;
    }

    private void btnStoreDAPfls_Click(object sender, EventArgs e)
    {
      Dictionary<string, double> dictionary1 = new Dictionary<string, double>();
      Dictionary<string, double> dictionary2 = new Dictionary<string, double>();
      SqlConnection conn = this.objmain.getConn();
      foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair1 in this.objmain._DAHierarchy)
      {
        string key1 = keyValuePair1.Key;
        Dictionary<string, Userinfo> dictionary3 = keyValuePair1.Value;
        string str = string.Empty;
        foreach (KeyValuePair<string, Userinfo> keyValuePair2 in dictionary3)
          str += string.Format("'{0}',", (object) keyValuePair2.Key);
        if (str.Length > 0)
          str = str.Substring(0, str.Length - 1);
        double num1 = 0.0;
        if (str.Length > 0)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select NetMTMPL,ClientCode from Profit_Loss_Archive where Clientcode in (" + str + ") and Timestamp = '" + this.dtClosePriceDate.Value.ToString("yyyy-MM-dd 00:00:00") + "'", conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                if (!sqlDataReader.IsDBNull(0))
                {
                  double num2 = Convert.ToDouble(sqlDataReader.GetValue(0));
                  num1 += num2;
                  string key2 = sqlDataReader.GetString(1);
                  if (!dictionary2.ContainsKey(key2))
                    dictionary2.Add(key2, num2);
                  else
                    dictionary2[key2] += num2;
                }
              }
            }
          }
        }
        if (!dictionary1.ContainsKey(key1))
          dictionary1.Add(key1, num1);
      }
      foreach (KeyValuePair<string, double> keyValuePair in dictionary1)
      {
        string key = keyValuePair.Key;
        Userinfo userinfo = this.objmain.GetUserinfo(key);
        double num1 = keyValuePair.Value;
        double num2;
        double num3;
        if (num1 > 0.0)
        {
          double num4 = Math.Round(num1 * (double) userinfo.DApflsPercent / 100.0, 2);
          num2 = Math.Round((num1 - num4) * -1.0);
          num3 = num4 * -1.0;
        }
        else
        {
          double num4 = num1 * -1.0;
          num3 = Math.Round(num4 * (double) userinfo.DApflsPercent / 100.0, 2);
          num2 = Math.Round(num4 - num3);
        }
        SqlCommand sqlCommand1 = new SqlCommand("SaveDAwisePfls", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@dacode", (object) key);
          sqlCommand2.Parameters.AddWithValue("@netpfls", (object) (num1 * -1.0));
          sqlCommand2.Parameters.AddWithValue("@dapfls", (object) num3);
          sqlCommand2.Parameters.AddWithValue("@sapfls", (object) num2);
          sqlCommand2.Parameters.AddWithValue("@timestamp", (object) this.dtClosePriceDate.Value.ToString("yyyy-MM-dd 00:00:00"));
          try
          {
            sqlCommand2.ExecuteNonQuery();
          }
          catch
          {
            this.objmain.DisplayMessage("Unable to store Dealer-Admin wise Profit-Loss", 3);
            break;
          }
        }
        if (num2 != 0.0)
        {
          SqlCommand sqlCommand2 = new SqlCommand("SavePendingPFls", conn);
          sqlCommand2.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand3 = sqlCommand2)
          {
            sqlCommand3.Parameters.AddWithValue("@dacode", (object) key);
            sqlCommand3.Parameters.AddWithValue("@amount", (object) num2);
            try
            {
              sqlCommand3.ExecuteNonQuery();
            }
            catch
            {
              this.objmain.DisplayMessage("Unable to update SA Profit-Loss", 3);
              break;
            }
          }
        }
        if (num3 != 0.0)
        {
          SqlCommand sqlCommand2 = new SqlCommand("DA_Payin_Payout", conn);
          sqlCommand2.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand3 = sqlCommand2)
          {
            sqlCommand3.Parameters.AddWithValue("@dacode", (object) key);
            sqlCommand3.Parameters.AddWithValue("@amount", (object) num3);
            sqlCommand3.Parameters.AddWithValue("@comments", (object) "Profit/Loss Update");
            sqlCommand3.Parameters.AddWithValue("@payinout", (object) 3);
            try
            {
              sqlCommand3.ExecuteNonQuery();
            }
            catch
            {
              this.objmain.DisplayMessage("Unable to update DA Cash Margin", 3);
            }
          }
        }
      }
      foreach (KeyValuePair<string, double> keyValuePair in dictionary2)
      {
        string key = keyValuePair.Key;
        double num = keyValuePair.Value;
        SqlCommand sqlCommand1 = new SqlCommand("storeClientAccounting", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) key);
          sqlCommand2.Parameters.AddWithValue("@amount", (object) num);
          sqlCommand2.Parameters.AddWithValue("@flag", (object) 2);
          sqlCommand2.Parameters.AddWithValue("@timestamp", (object) this.dtClosePriceDate.Value.ToString("yyyy-MM-dd 00:00:00"));
          try
          {
            sqlCommand2.ExecuteNonQuery();
          }
          catch
          {
          }
        }
      }
      this.objmain.DisplayMessage("Dealer-Admin wise Profit-Loss stored Successfully!!", 1);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.label2 = new Label();
      this.label3 = new Label();
      this.label4 = new Label();
      this.btnStoreBrkg = new Button();
      this.btnTurnover = new Button();
      this.btnPrftLoss = new Button();
      this.btnCashMrgn = new Button();
      this.btnCryPos = new Button();
      this.btnArchData = new Button();
      this.label5 = new Label();
      this.label6 = new Label();
      this.progressMaintenance = new ProgressBar();
      this.groupBox1 = new GroupBox();
      this.btnUploadBhavcopy = new Button();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.groupBox2 = new GroupBox();
      this.chkExchList = new CheckedListBox();
      this.lstMsg = new ListBox();
      this.groupBox3 = new GroupBox();
      this.dtToDate = new DateTimePicker();
      this.groupBox4 = new GroupBox();
      this.dtClosePriceDate = new DateTimePicker();
      this.treeView1 = new TreeView();
      this.groupBox5 = new GroupBox();
      this.rdoBhavcopy = new RadioButton();
      this.rdoLTP = new RadioButton();
      this.btnStoreDAPfls = new Button();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupBox4.SuspendLayout();
      this.groupBox5.SuspendLayout();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Modern No. 20", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = Color.Blue;
      this.label1.Location = new Point(165, 234);
      this.label1.Name = "label1";
      this.label1.Size = new Size(20, 17);
      this.label1.TabIndex = 0;
      this.label1.Text = "1.";
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Modern No. 20", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = Color.Blue;
      this.label2.Location = new Point(165, 276);
      this.label2.Name = "label2";
      this.label2.Size = new Size(20, 17);
      this.label2.TabIndex = 1;
      this.label2.Text = "2.";
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Modern No. 20", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label3.ForeColor = Color.Blue;
      this.label3.Location = new Point(165, 318);
      this.label3.Name = "label3";
      this.label3.Size = new Size(20, 17);
      this.label3.TabIndex = 2;
      this.label3.Text = "3.";
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Modern No. 20", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label4.ForeColor = Color.Blue;
      this.label4.Location = new Point(165, 360);
      this.label4.Name = "label4";
      this.label4.Size = new Size(20, 17);
      this.label4.TabIndex = 3;
      this.label4.Text = "4.";
      this.btnStoreBrkg.Location = new Point(191, 229);
      this.btnStoreBrkg.Name = "btnStoreBrkg";
      this.btnStoreBrkg.Size = new Size(131, 29);
      this.btnStoreBrkg.TabIndex = 4;
      this.btnStoreBrkg.Text = "Store Brokerage";
      this.btnStoreBrkg.UseVisualStyleBackColor = true;
      this.btnStoreBrkg.Click += new EventHandler(this.btnCommTax_Click);
      this.btnTurnover.Location = new Point(191, 271);
      this.btnTurnover.Name = "btnTurnover";
      this.btnTurnover.Size = new Size(131, 29);
      this.btnTurnover.TabIndex = 5;
      this.btnTurnover.Text = "Store Turnover";
      this.btnTurnover.UseVisualStyleBackColor = true;
      this.btnTurnover.Click += new EventHandler(this.btnTurnover_Click);
      this.btnPrftLoss.Location = new Point(191, 313);
      this.btnPrftLoss.Name = "btnPrftLoss";
      this.btnPrftLoss.Size = new Size(131, 29);
      this.btnPrftLoss.TabIndex = 6;
      this.btnPrftLoss.Text = "Store Profit/Loss";
      this.btnPrftLoss.UseVisualStyleBackColor = true;
      this.btnPrftLoss.Click += new EventHandler(this.btnPrftLoss_Click);
      this.btnCashMrgn.Location = new Point(191, 355);
      this.btnCashMrgn.Name = "btnCashMrgn";
      this.btnCashMrgn.Size = new Size(131, 29);
      this.btnCashMrgn.TabIndex = 7;
      this.btnCashMrgn.Text = "Update Cash Margin";
      this.btnCashMrgn.UseVisualStyleBackColor = true;
      this.btnCashMrgn.Click += new EventHandler(this.btnCashMrgn_Click);
      this.btnCryPos.Location = new Point(191, 397);
      this.btnCryPos.Name = "btnCryPos";
      this.btnCryPos.Size = new Size(131, 29);
      this.btnCryPos.TabIndex = 8;
      this.btnCryPos.Text = "Carry Forward Position";
      this.btnCryPos.UseVisualStyleBackColor = true;
      this.btnCryPos.Click += new EventHandler(this.btnCryPos_Click);
      this.btnArchData.Location = new Point(191, 439);
      this.btnArchData.Name = "btnArchData";
      this.btnArchData.Size = new Size(131, 29);
      this.btnArchData.TabIndex = 9;
      this.btnArchData.Text = "Archive Data";
      this.btnArchData.UseVisualStyleBackColor = true;
      this.btnArchData.Click += new EventHandler(this.btnArchData_Click);
      this.label5.AutoSize = true;
      this.label5.Font = new Font("Modern No. 20", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label5.ForeColor = Color.Blue;
      this.label5.Location = new Point(165, 402);
      this.label5.Name = "label5";
      this.label5.Size = new Size(20, 17);
      this.label5.TabIndex = 10;
      this.label5.Text = "5.";
      this.label6.AutoSize = true;
      this.label6.Font = new Font("Modern No. 20", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label6.ForeColor = Color.Blue;
      this.label6.Location = new Point(165, 444);
      this.label6.Name = "label6";
      this.label6.Size = new Size(20, 17);
      this.label6.TabIndex = 11;
      this.label6.Text = "6.";
      this.progressMaintenance.Dock = DockStyle.Bottom;
      this.progressMaintenance.Location = new Point(0, 556);
      this.progressMaintenance.Name = "progressMaintenance";
      this.progressMaintenance.Size = new Size(479, 19);
      this.progressMaintenance.Step = 1;
      this.progressMaintenance.TabIndex = 12;
      this.groupBox1.Controls.Add((Control) this.btnUploadBhavcopy);
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoncdex);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(7, 3);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(467, 48);
      this.groupBox1.TabIndex = 13;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Upload Bhavcopy";
      this.btnUploadBhavcopy.Location = new Point(344, 19);
      this.btnUploadBhavcopy.Name = "btnUploadBhavcopy";
      this.btnUploadBhavcopy.Size = new Size(111, 23);
      this.btnUploadBhavcopy.TabIndex = 8;
      this.btnUploadBhavcopy.Text = "Upload Bhavcopy";
      this.btnUploadBhavcopy.UseVisualStyleBackColor = true;
      this.btnUploadBhavcopy.Click += new EventHandler(this.btnUploadBhavcopy_Click);
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(244, 22);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 7;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(157, 22);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 6;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(85, 22);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(47, 17);
      this.rdoNseFut.TabIndex = 5;
      this.rdoNseFut.Text = "NSE";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(12, 22);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 4;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.groupBox2.Controls.Add((Control) this.chkExchList);
      this.groupBox2.Location = new Point(7, 55);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(467, 65);
      this.groupBox2.TabIndex = 14;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Select Exchange for Maintenance";
      this.chkExchList.CheckOnClick = true;
      this.chkExchList.FormattingEnabled = true;
      this.chkExchList.Location = new Point(12, 19);
      this.chkExchList.MultiColumn = true;
      this.chkExchList.Name = "chkExchList";
      this.chkExchList.Size = new Size(443, 34);
      this.chkExchList.TabIndex = 6;
      this.chkExchList.SelectedIndexChanged += new EventHandler(this.chkExchList_SelectedIndexChanged);
      this.lstMsg.Dock = DockStyle.Bottom;
      this.lstMsg.FormattingEnabled = true;
      this.lstMsg.Location = new Point(0, 474);
      this.lstMsg.Name = "lstMsg";
      this.lstMsg.Size = new Size(479, 82);
      this.lstMsg.TabIndex = 15;
      this.groupBox3.Controls.Add((Control) this.dtToDate);
      this.groupBox3.Location = new Point(232, 125);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(242, 45);
      this.groupBox3.TabIndex = 16;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Select Open Position CarryForward - To Date";
      this.dtToDate.CustomFormat = "dd MMM yyyy";
      this.dtToDate.Format = DateTimePickerFormat.Custom;
      this.dtToDate.Location = new Point(19, 19);
      this.dtToDate.MinDate = new DateTime(2014, 12, 8, 0, 0, 0, 0);
      this.dtToDate.Name = "dtToDate";
      this.dtToDate.Size = new Size(113, 20);
      this.dtToDate.TabIndex = 0;
      this.dtToDate.Value = new DateTime(2014, 12, 8, 0, 0, 0, 0);
      this.groupBox4.Controls.Add((Control) this.dtClosePriceDate);
      this.groupBox4.Location = new Point(7, 125);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new Size(219, 45);
      this.groupBox4.TabIndex = 17;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Select Maintenance Running for Date";
      this.dtClosePriceDate.CustomFormat = "dd MMM yyyy";
      this.dtClosePriceDate.Format = DateTimePickerFormat.Custom;
      this.dtClosePriceDate.Location = new Point(19, 19);
      this.dtClosePriceDate.MinDate = new DateTime(2014, 12, 8, 0, 0, 0, 0);
      this.dtClosePriceDate.Name = "dtClosePriceDate";
      this.dtClosePriceDate.Size = new Size(113, 20);
      this.dtClosePriceDate.TabIndex = 0;
      this.dtClosePriceDate.Value = new DateTime(2014, 12, 8, 0, 0, 0, 0);
      this.treeView1.CheckBoxes = true;
      this.treeView1.Location = new Point(7, 225);
      this.treeView1.Name = "treeView1";
      this.treeView1.Size = new Size(152, 243);
      this.treeView1.TabIndex = 18;
      this.treeView1.AfterCheck += new TreeViewEventHandler(this.treeView1_AfterCheck);
      this.groupBox5.Controls.Add((Control) this.rdoBhavcopy);
      this.groupBox5.Controls.Add((Control) this.rdoLTP);
      this.groupBox5.Location = new Point(7, 173);
      this.groupBox5.Name = "groupBox5";
      this.groupBox5.Size = new Size(219, 43);
      this.groupBox5.TabIndex = 19;
      this.groupBox5.TabStop = false;
      this.groupBox5.Text = "Close Price Source";
      this.rdoBhavcopy.AutoSize = true;
      this.rdoBhavcopy.Checked = true;
      this.rdoBhavcopy.Location = new Point(85, 19);
      this.rdoBhavcopy.Name = "rdoBhavcopy";
      this.rdoBhavcopy.Size = new Size(83, 17);
      this.rdoBhavcopy.TabIndex = 21;
      this.rdoBhavcopy.TabStop = true;
      this.rdoBhavcopy.Text = "BHAVCOPY";
      this.rdoBhavcopy.UseVisualStyleBackColor = true;
      this.rdoLTP.AutoSize = true;
      this.rdoLTP.Location = new Point(12, 19);
      this.rdoLTP.Name = "rdoLTP";
      this.rdoLTP.Size = new Size(45, 17);
      this.rdoLTP.TabIndex = 20;
      this.rdoLTP.Text = "LTP";
      this.rdoLTP.UseVisualStyleBackColor = true;
      this.btnStoreDAPfls.Location = new Point(343, 328);
      this.btnStoreDAPfls.Name = "btnStoreDAPfls";
      this.btnStoreDAPfls.Size = new Size(131, 29);
      this.btnStoreDAPfls.TabIndex = 20;
      this.btnStoreDAPfls.Text = "Store DA Profit/Loss";
      this.btnStoreDAPfls.UseVisualStyleBackColor = true;
      this.btnStoreDAPfls.Click += new EventHandler(this.btnStoreDAPfls_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(479, 575);
      this.Controls.Add((Control) this.btnStoreDAPfls);
      this.Controls.Add((Control) this.groupBox5);
      this.Controls.Add((Control) this.treeView1);
      this.Controls.Add((Control) this.groupBox4);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.lstMsg);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.progressMaintenance);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.btnArchData);
      this.Controls.Add((Control) this.btnCryPos);
      this.Controls.Add((Control) this.btnCashMrgn);
      this.Controls.Add((Control) this.btnPrftLoss);
      this.Controls.Add((Control) this.btnTurnover);
      this.Controls.Add((Control) this.btnStoreBrkg);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label1);
      this.MaximizeBox = false;
      this.Name = nameof (Maintenance);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = nameof (Maintenance);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.groupBox4.ResumeLayout(false);
      this.groupBox5.ResumeLayout(false);
      this.groupBox5.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    public struct EOD
    {
      public string symbol;
      public DateTime expiry;
      public DateTime Feed;
      public double open;
      public double close;
      public double high;
      public double low;
      public double Volume;
      public int OpenInterest;
      public string exchange;
      public int Exch;
      public string usersymbol;
      public int scripcode;
      public string series;
      public string ISIN;
      public string BseGroup;
      public string SymDescp;
    }
  }
}
