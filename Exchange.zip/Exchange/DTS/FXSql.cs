﻿// Decompiled with JetBrains decompiler
// Type: DTS.FXSql
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DTS
{
  public class FXSql
  {
    public static SqlConnection _conn;

    public static bool Connect()
    {
      FXSql._conn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FXConnstringNEW));
      try
      {
        FXSql._conn.Open();
        return true;
      }
      catch
      {
        return false;
      }
    }

    public static bool Connect236()
    {
      FXSql._conn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FXConnstring3));
      try
      {
        FXSql._conn.Open();
        return true;
      }
      catch
      {
        return false;
      }
    }

    public static bool Disconnect()
    {
      if (FXSql._conn == null || FXSql._conn.State != ConnectionState.Open)
        return false;
      FXSql._conn.Close();
      return true;
    }

    public static void GetclientwiseFXSettings(SqlConnection conn, Dashboard objdash)
    {
      if (conn == null || conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select F.Clientcode,F.Symbol,F.Spread,F.MinLots,F.MaxLots from FxSettings F, Userinformation U where U.Clientcode = F.Clientcode and U.createdby = '" + objdash.objinfo.clientcode + "'", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
            objdash.ManageClientFXSettingsData(new FXsettings()
            {
              clientcode = sqlDataReader.GetString(0),
              symbol = sqlDataReader.GetString(1),
              spread = !sqlDataReader.IsDBNull(2) ? sqlDataReader.GetInt32(2) : 0,
              minLots = !sqlDataReader.IsDBNull(3) ? Convert.ToDouble(sqlDataReader.GetValue(3)) : 0.0,
              maxLots = !sqlDataReader.IsDBNull(4) ? Convert.ToDouble(sqlDataReader.GetValue(4)) : 0.0
            });
        }
      }
    }

    public static bool SaveSettings(FXsettings _data, SqlConnection conn)
    {
      if (conn == null || conn.State != ConnectionState.Open)
        return false;
      SqlCommand sqlCommand1 = new SqlCommand("SaveFxSettings", conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) _data.clientcode);
        sqlCommand2.Parameters.AddWithValue("@symbol", (object) _data.symbol);
        sqlCommand2.Parameters.AddWithValue("@spread", (object) _data.spread);
        sqlCommand2.Parameters.AddWithValue("@minlots", (object) _data.minLots);
        sqlCommand2.Parameters.AddWithValue("@maxlots", (object) _data.maxLots);
        try
        {
          return sqlCommand2.ExecuteNonQuery() > 0;
        }
        catch (Exception ex)
        {
          return false;
        }
      }
    }

    public static List<string> GetFXSymbols()
    {
      if (FXSql._conn == null || FXSql._conn.State != ConnectionState.Open)
        return new List<string>();
      List<string> stringList = new List<string>();
      SqlCommand sqlCommand1 = new SqlCommand("sp_FetchSymbol", FXSql._conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              stringList.Add(sqlDataReader.GetString(0));
          }
        }
      }
      return stringList;
    }
  }
}
