﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmTradeSettings
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmTradeSettings : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox2;
    private ComboBox cmbClientcode;
    private GroupBox groupBox1;
    private RadioButton rdoNsecurr;
    private RadioButton rdoNseFut;
    private RadioButton rdoNcdex;
    private RadioButton rdoMcx;
    private DataGridView dgv_TradeSettings;
    private Label label1;
    private DataGridViewTextBoxColumn ColSymbol;
    private DataGridViewTextBoxColumn Coloffset;
    private DataGridViewTextBoxColumn col_VolumePercent;
    private DataGridViewButtonColumn Col_Update;

    public frmTradeSettings(Dashboard objdash)
    {
      this.InitializeComponent();
      this.objdash = objdash;
      this.Icon = objdash.Icon;
    }

    public void LoadControls()
    {
      this.dgv_TradeSettings.Rows.Clear();
      this.cmbClientcode.Items.Clear();
      this.cmbClientcode.Items.Add((object) "--Select--");
      this.cmbClientcode.Items.Add((object) "Default");
      foreach (object lstAccount in this.objdash._lstAccounts)
        this.cmbClientcode.Items.Add(lstAccount);
      this.cmbClientcode.SelectedIndex = 0;
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.rdoMcx.Visible = true;
            break;
          case 2:
            this.rdoNseFut.Visible = true;
            break;
          case 3:
            this.rdoNcdex.Visible = true;
            break;
          case 4:
            this.rdoNsecurr.Visible = true;
            break;
        }
      }
    }

    private void cmbClientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmbClientcode.SelectedIndex <= 0)
        return;
      this.LoadSymbols(this.GetSelectedExch(), this.cmbClientcode.Text.ToUpper() == "DEFAULT" ? this.objdash.objinfo.createdby : this.cmbClientcode.Text);
    }

    private int GetSelectedExch()
    {
      if (this.rdoMcx.Checked)
        return 1;
      if (this.rdoNseFut.Checked)
        return 2;
      return this.rdoNcdex.Checked ? 3 : 4;
    }

    public void LoadSymbols(int exch, string clientcode)
    {
      List<string> stringList = new List<string>();
      this.dgv_TradeSettings.Rows.Clear();
      if (this.objdash._ClientExchwiseTrdSettings.ContainsKey(clientcode))
      {
        Dictionary<int, Dictionary<string, TradeSettings>> exchwiseTrdSetting = this.objdash._ClientExchwiseTrdSettings[clientcode];
        if (exchwiseTrdSetting.ContainsKey(exch))
        {
          Dictionary<string, TradeSettings> dictionary = exchwiseTrdSetting[exch];
          if (this.objdash._Exchconctracts.ContainsKey(exch))
          {
            foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
            {
              if (!stringList.Contains(keyValuePair.Value.symbol))
              {
                if (dictionary.ContainsKey(keyValuePair.Value.symbol))
                {
                  TradeSettings tradeSettings = dictionary[keyValuePair.Value.symbol];
                  int index = this.dgv_TradeSettings.Rows.Add();
                  this.dgv_TradeSettings.Rows[index].Cells[0].Value = (object) tradeSettings.symbol;
                  this.dgv_TradeSettings.Rows[index].Cells[1].Value = (object) tradeSettings.closeAfterMins;
                  this.dgv_TradeSettings.Rows[index].Cells[2].Value = (object) tradeSettings.volumePercent;
                  this.dgv_TradeSettings.Rows[index].Cells[3].Value = (object) "Update";
                }
                else
                {
                  int index = this.dgv_TradeSettings.Rows.Add();
                  this.dgv_TradeSettings.Rows[index].Cells[0].Value = (object) keyValuePair.Value.symbol;
                  this.dgv_TradeSettings.Rows[index].Cells[1].Value = (object) "";
                  this.dgv_TradeSettings.Rows[index].Cells[2].Value = (object) "";
                  this.dgv_TradeSettings.Rows[index].Cells[3].Value = (object) "Update";
                }
                stringList.Add(keyValuePair.Value.symbol);
              }
            }
          }
          else
          {
            foreach (KeyValuePair<string, TradeSettings> keyValuePair in dictionary)
            {
              if (!stringList.Contains(keyValuePair.Value.symbol))
              {
                int index = this.dgv_TradeSettings.Rows.Add();
                this.dgv_TradeSettings.Rows[index].Cells[0].Value = (object) keyValuePair.Value.symbol;
                this.dgv_TradeSettings.Rows[index].Cells[1].Value = (object) keyValuePair.Value.closeAfterMins;
                this.dgv_TradeSettings.Rows[index].Cells[2].Value = (object) keyValuePair.Value.volumePercent;
                this.dgv_TradeSettings.Rows[index].Cells[3].Value = (object) "Update";
                stringList.Add(keyValuePair.Value.symbol);
              }
            }
          }
        }
        else
          this.LoadEmptyData(exch);
      }
      else
        this.LoadEmptyData(exch);
    }

    public void LoadEmptyData(int exch)
    {
      List<string> stringList = new List<string>();
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
      {
        if (!stringList.Contains(keyValuePair.Value.symbol))
        {
          int index = this.dgv_TradeSettings.Rows.Add();
          this.dgv_TradeSettings.Rows[index].Cells[0].Value = (object) keyValuePair.Value.symbol;
          this.dgv_TradeSettings.Rows[index].Cells[1].Value = (object) "";
          this.dgv_TradeSettings.Rows[index].Cells[2].Value = (object) "";
          this.dgv_TradeSettings.Rows[index].Cells[3].Value = (object) "Update";
          stringList.Add(keyValuePair.Value.symbol);
        }
      }
    }

    private void dgv_TradeSettings_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
      if (e.RowIndex <= -1 || e.ColumnIndex != 3 || (this.dgv_TradeSettings.Rows[e.RowIndex].Cells[1] == null || this.dgv_TradeSettings.Rows[e.RowIndex].Cells[2] == null))
        return;
      TradeSettings _settings = new TradeSettings();
      _settings.exch = this.GetSelectedExch();
      _settings.clientCode = this.cmbClientcode.Text;
      _settings.symbol = this.dgv_TradeSettings.Rows[e.RowIndex].Cells[0].Value.ToString();
      _settings.closeAfterMins = Convert.ToInt32(this.dgv_TradeSettings.Rows[e.RowIndex].Cells[1].Value);
      _settings.volumePercent = Convert.ToDouble(this.dgv_TradeSettings.Rows[e.RowIndex].Cells[2].Value);
      if (this.SaveTradeSettings(_settings))
      {
        this.objdash.DisplayMessage("Settings saved", 1);
        this.objdash.ManageTradeSettings(_settings);
      }
      else
        this.objdash.DisplayMessage("Unable to save settings", 2);
    }

    private bool SaveTradeSettings(TradeSettings _settings)
    {
      SqlConnection conn = this.objdash.getConn();
      if (conn.State != ConnectionState.Open)
        return false;
      SqlCommand sqlCommand1 = new SqlCommand(nameof (SaveTradeSettings), conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) _settings.clientCode);
        sqlCommand2.Parameters.AddWithValue("@symbol", (object) _settings.symbol);
        sqlCommand2.Parameters.AddWithValue("@closeaftermins", (object) _settings.closeAfterMins);
        sqlCommand2.Parameters.AddWithValue("@volumepercent", (object) _settings.volumePercent);
        try
        {
          return sqlCommand2.ExecuteNonQuery() > 0;
        }
        catch
        {
          return false;
        }
      }
    }

    private void dgv_TradeSettings_CellEndEdit(object sender, DataGridViewCellEventArgs e)
    {
      int result = 0;
      if (e.ColumnIndex != 1 && e.ColumnIndex != 2 || !(this.dgv_TradeSettings[e.ColumnIndex, e.RowIndex].Value.ToString() != string.Empty) || int.TryParse(this.dgv_TradeSettings[e.ColumnIndex, e.RowIndex].Value.ToString(), out result))
        return;
      this.objdash.DisplayMessage("Invalid Value", 2);
      this.dgv_TradeSettings[e.ColumnIndex, e.RowIndex].Value = (object) string.Empty;
    }

    private void dgv_TradeSettings_CellLeave(object sender, DataGridViewCellEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      this.groupBox2 = new GroupBox();
      this.cmbClientcode = new ComboBox();
      this.groupBox1 = new GroupBox();
      this.rdoNsecurr = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoNcdex = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.dgv_TradeSettings = new DataGridView();
      this.label1 = new Label();
      this.ColSymbol = new DataGridViewTextBoxColumn();
      this.Coloffset = new DataGridViewTextBoxColumn();
      this.col_VolumePercent = new DataGridViewTextBoxColumn();
      this.Col_Update = new DataGridViewButtonColumn();
      this.groupBox2.SuspendLayout();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgv_TradeSettings).BeginInit();
      this.SuspendLayout();
      this.groupBox2.Controls.Add((Control) this.cmbClientcode);
      this.groupBox2.Location = new Point(37, 56);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(288, 48);
      this.groupBox2.TabIndex = 3;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "ClientCode";
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(84, 19);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(121, 21);
      this.cmbClientcode.Sorted = true;
      this.cmbClientcode.TabIndex = 0;
      this.cmbClientcode.SelectedIndexChanged += new EventHandler(this.cmbClientcode_SelectedIndexChanged);
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoNcdex);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(37, 6);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(288, 44);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchange";
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(197, 19);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 3;
      this.rdoNsecurr.TabStop = true;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(63, 19);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 2;
      this.rdoNseFut.TabStop = true;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoNcdex.AutoSize = true;
      this.rdoNcdex.Location = new Point(133, 19);
      this.rdoNcdex.Name = "rdoNcdex";
      this.rdoNcdex.Size = new Size(62, 17);
      this.rdoNcdex.TabIndex = 1;
      this.rdoNcdex.TabStop = true;
      this.rdoNcdex.Text = "NCDEX";
      this.rdoNcdex.UseVisualStyleBackColor = true;
      this.rdoNcdex.Visible = false;
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(13, 19);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 0;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.dgv_TradeSettings.AllowUserToAddRows = false;
      this.dgv_TradeSettings.AllowUserToDeleteRows = false;
      this.dgv_TradeSettings.AllowUserToOrderColumns = true;
      this.dgv_TradeSettings.AllowUserToResizeRows = false;
      this.dgv_TradeSettings.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgv_TradeSettings.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgv_TradeSettings.BackgroundColor = Color.White;
      this.dgv_TradeSettings.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgv_TradeSettings.Columns.AddRange((DataGridViewColumn) this.ColSymbol, (DataGridViewColumn) this.Coloffset, (DataGridViewColumn) this.col_VolumePercent, (DataGridViewColumn) this.Col_Update);
      this.dgv_TradeSettings.EditMode = DataGridViewEditMode.EditOnEnter;
      this.dgv_TradeSettings.Location = new Point(3, 134);
      this.dgv_TradeSettings.MultiSelect = false;
      this.dgv_TradeSettings.Name = "dgv_TradeSettings";
      this.dgv_TradeSettings.RowHeadersVisible = false;
      this.dgv_TradeSettings.Size = new Size(359, 299);
      this.dgv_TradeSettings.TabIndex = 4;
      this.dgv_TradeSettings.CellEndEdit += new DataGridViewCellEventHandler(this.dgv_TradeSettings_CellEndEdit);
      this.dgv_TradeSettings.CellLeave += new DataGridViewCellEventHandler(this.dgv_TradeSettings_CellLeave);
      this.dgv_TradeSettings.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgv_TradeSettings_CellMouseClick);
      this.label1.AutoSize = true;
      this.label1.ForeColor = Color.Red;
      this.label1.Location = new Point(3, 117);
      this.label1.Name = "label1";
      this.label1.Size = new Size(190, 13);
      this.label1.TabIndex = 5;
      this.label1.Text = "* Enter values in cells and click update";
      this.ColSymbol.FillWeight = 142.132f;
      this.ColSymbol.HeaderText = "Symbol";
      this.ColSymbol.Name = "ColSymbol";
      this.ColSymbol.ReadOnly = true;
      gridViewCellStyle1.Format = "N0";
      gridViewCellStyle1.NullValue = (object) null;
      this.Coloffset.DefaultCellStyle = gridViewCellStyle1;
      this.Coloffset.FillWeight = 85.95602f;
      this.Coloffset.HeaderText = "Close After Min";
      this.Coloffset.MaxInputLength = 3;
      this.Coloffset.Name = "Coloffset";
      gridViewCellStyle2.Format = "N2";
      gridViewCellStyle2.NullValue = (object) null;
      this.col_VolumePercent.DefaultCellStyle = gridViewCellStyle2;
      this.col_VolumePercent.FillWeight = 85.95602f;
      this.col_VolumePercent.HeaderText = "Volume %";
      this.col_VolumePercent.MaxInputLength = 4;
      this.col_VolumePercent.Name = "col_VolumePercent";
      this.Col_Update.FillWeight = 85.95602f;
      this.Col_Update.HeaderText = "Update";
      this.Col_Update.Name = "Col_Update";
      this.Col_Update.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(363, 438);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.dgv_TradeSettings);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.Name = nameof (frmTradeSettings);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Trade Settings";
      this.groupBox2.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgv_TradeSettings).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
