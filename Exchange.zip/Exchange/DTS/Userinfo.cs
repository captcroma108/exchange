﻿// Decompiled with JetBrains decompiler
// Type: DTS.Userinfo
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public class Userinfo
  {
    public string name { get; set; }

    public string clientcode { get; set; }

    public string username { get; set; }

    public string password { get; set; }

    public DateTime regdate { get; set; }

    public int userstatus { get; set; }

    public int marginstatus { get; set; }

    public int productype { get; set; }

    public int usertype { get; set; }

    public string createdby { get; set; }

    public string exchange { get; set; }

    public DateTime Lastlogin { get; set; }

    public int pivots { get; set; }

    public int stockperform { get; set; }

    public int charts { get; set; }

    public int offset { get; set; }

    public string mappedclients { get; set; }

    public int oddlot { get; set; }

    public string BlastPassword { get; set; }

    public string AppName { get; set; }

    public int isModTrd { get; set; }

    public byte[] imagedata { get; set; }

    public int DApflsPercent { get; set; }

    public string emailid { get; set; }

    public long Mobno { get; set; }

    public string OffsetExch { get; set; }

    public int isHLTrading { get; set; }

    public string HighLowExch { get; set; }

    public double DAfund { get; set; }

    public int ischngpwd { get; set; }

    public int isSMS { get; set; }

    public string ValidateDate { get; set; }

    public int DIpflsPercent { get; set; }
  }
}
