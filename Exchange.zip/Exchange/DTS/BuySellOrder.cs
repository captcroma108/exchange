﻿// Decompiled with JetBrains decompiler
// Type: DTS.BuySellOrder
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class BuySellOrder : Form
  {
    public string Serverdt = "";
    public double Totprice = 0.0;
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public int mode;
    public bool IsModify;
    public int rowindex;
    private Contracts objconn;
    public Contracts objcon;
    public Thread threadObjRT_Comex;
    private StatusStrip statusStrip1;
    private ToolStripStatusLabel toolStripStatusLabel1;
    private ToolStripStatusLabel toolStripStatusLabel2;
    private ComboBox cmbExch;
    private ComboBox cmbOrdertype;
    private Label label1;
    private Label label2;
    private Label label3;
    private ComboBox cmbSymbol;
    private Label label4;
    private Label label5;
    private Label label6;
    private ComboBox CmbValidity;
    private TextBox txtName;
    private Label label7;
    private TextBox txtUserRemarks;
    private Button btnSubmit;
    private Button btnClear;
    private Label label8;
    private ComboBox cmbClientcode;
    private NumericUpDown numericUpDownPrice;
    private TextBox txtQty;

    public BuySellOrder(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.populateSymbols();
      this.Icon = this.objmain.ico;
    }

    private void populateSymbols()
    {
      this.cmbSymbol.Items.Clear();
      foreach (KeyValuePair<string, Contracts> symconctract in this.objmain._Symconctracts)
        this.cmbSymbol.Items.Add((object) symconctract.Key);
    }

    public void LoadWindow(
      int mode,
      string exch,
      string symbol,
      Decimal price,
      bool Ismodorder,
      int validity,
      Decimal qty,
      int productype,
      string accno,
      int rowindex)
    {
      this.mode = mode;
      if (mode == 1)
      {
        this.label1.Text = "BUY";
        this.BackColor = Color.Blue;
      }
      else
      {
        this.label1.Text = "SELL";
        this.BackColor = Color.Red;
      }
      this.cmbExch.Items.Clear();
      this.cmbExch.Items.Add((object) exch);
      this.cmbExch.SelectedIndex = 0;
      this.cmbSymbol.Items.Clear();
      if (this.objmain._Exchconctracts.ContainsKey(Utils.GetIntExch(this.cmbExch.Text)))
      {
        foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[Utils.GetIntExch(this.cmbExch.Text)])
          this.cmbSymbol.Items.Add((object) keyValuePair.Value.SymDesp);
        if (this.cmbSymbol.Items.Contains((object) symbol))
          this.cmbSymbol.SelectedItem = (object) symbol;
      }
      this.objconn = this.objmain.GetContract(symbol);
      this.numericUpDownPrice.DecimalPlaces = Utils.GetRoundoff(this.objconn.tickprice);
      this.numericUpDownPrice.Increment = Utils.GetTickprice(this.objconn.tickprice);
      this.numericUpDownPrice.Text = price.ToString();
      this.cmbOrdertype.SelectedIndex = 0;
      this.CmbValidity.Items.Clear();
      this.cmbClientcode.Items.Clear();
      if (this.objmain._ClientLimits.ContainsKey(this.objmain.objinfo.clientcode) && this.objmain.objinfo.usertype == 4)
      {
        Limits clientLimit = this.objmain._ClientLimits[this.objmain.objinfo.clientcode];
        if (clientLimit.possitionValidity.Contains(","))
        {
          string possitionValidity = clientLimit.possitionValidity;
          char[] chArray = new char[1]{ ',' };
          foreach (object obj in possitionValidity.Split(chArray))
            this.CmbValidity.Items.Add(obj);
          this.CmbValidity.SelectedIndex = 0;
        }
        else if (clientLimit.possitionValidity != null)
        {
          this.CmbValidity.Items.Add((object) clientLimit.possitionValidity);
          this.CmbValidity.SelectedIndex = 0;
        }
      }
      for (int index = 0; index < this.objmain._lstAccounts.Count; ++index)
        this.cmbClientcode.Items.Add((object) this.objmain._lstAccounts[index]);
      if (this.objmain.objinfo.usertype == 4 && this.cmbClientcode.Items.Count > 0)
        this.cmbClientcode.SelectedIndex = 0;
      this.IsModify = Ismodorder;
      if (this.IsModify)
      {
        this.txtQty.Text = qty.ToString();
        this.CmbValidity.Items.Add((object) "CarryForward");
        this.CmbValidity.Items.Add((object) "Day");
        this.CmbValidity.Items.Add((object) "GTC");
        this.CmbValidity.SelectedIndex = validity - 1;
        this.cmbOrdertype.SelectedIndex = productype - 1;
        this.CmbValidity.Enabled = false;
        this.cmbOrdertype.Enabled = false;
        this.cmbSymbol.Enabled = false;
        this.cmbExch.Enabled = false;
        this.cmbClientcode.Items.Clear();
        this.cmbClientcode.Items.Add((object) accno);
        this.cmbClientcode.SelectedIndex = 0;
        this.cmbClientcode.Enabled = false;
        this.rowindex = rowindex;
      }
      this.txtQty.TabIndex = 0;
      this.txtQty.Focus();
    }

    private void cmbClientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.FillValidity();
    }

    private void FillValidity()
    {
      if (!(this.cmbClientcode.Text != string.Empty))
        return;
      if (this.objmain._Userinformation.ContainsKey(this.cmbClientcode.Text))
        this.txtName.Text = this.objmain._Userinformation[this.cmbClientcode.Text].name;
      if (this.objmain.objinfo.usertype == 4)
        this.txtName.Text = this.objmain.objinfo.name;
      this.CmbValidity.Items.Clear();
      if (this.objmain._ClientLimits.ContainsKey(this.cmbClientcode.Text))
      {
        Limits clientLimit = this.objmain._ClientLimits[this.cmbClientcode.Text];
        if (clientLimit.possitionValidity.Contains(","))
        {
          string[] strArray = clientLimit.possitionValidity.Split(',');
          for (int index = 0; index < strArray.Length; ++index)
          {
            if (strArray[index] != string.Empty)
              this.CmbValidity.Items.Add((object) strArray[index]);
          }
          this.CmbValidity.SelectedIndex = 0;
        }
        else if (clientLimit.possitionValidity != null)
        {
          this.CmbValidity.Items.Add((object) clientLimit.possitionValidity);
          this.CmbValidity.SelectedIndex = 0;
        }
      }
    }

    private void numericUpDownPrice_Enter(object sender, EventArgs e)
    {
      this.numericUpDownPrice.Select(0, this.numericUpDownPrice.ToString().Length);
    }

    private void txtUserRemarks_Enter(object sender, EventArgs e)
    {
      this.txtUserRemarks.Select(0, this.txtUserRemarks.ToString().Length);
    }

    private bool ValidateOrderParameters()
    {
      if (this.cmbExch.Text == string.Empty)
      {
        this.objmain.DisplayMessage("Select Exchange to place order", 2);
        return false;
      }
      if (this.cmbSymbol.Text == string.Empty)
      {
        this.objmain.DisplayMessage("Select Symbol to place order", 2);
        return false;
      }
      if (this.cmbOrdertype.Text == string.Empty)
      {
        this.objmain.DisplayMessage("Select Order Type to place order", 2);
        return false;
      }
      if (this.CmbValidity.Text == string.Empty)
      {
        this.objmain.DisplayMessage("Select Validity Type to place order", 2);
        return false;
      }
      if (this.cmbClientcode.Text == string.Empty)
      {
        this.objmain.DisplayMessage("Select Client Code to place order", 2);
        return false;
      }
      Contracts contract = this.objmain.GetContract(this.cmbSymbol.Text);
      Userinfo userinfo = this.objmain.GetUserinfo(this.cmbClientcode.Text);
      Limits limits = this.objmain.GetLimits(this.cmbClientcode.Text);
      if (Convert.ToInt32(this.txtQty.Text) % contract.lotsize != 0 && (this.cmbExch.Text == "NSEFUT" || this.cmbExch.Text == "NSEOPT") && userinfo.oddlot == 0)
      {
        this.objmain.DisplayMessage("Qty does not matches with Lotsize.", 2);
        return false;
      }
      if (limits.possitionValidity.Contains(this.CmbValidity.Text))
        return true;
      this.objmain.DisplayMessage("Validity not allowed for Client.", 2);
      return false;
    }

    private void GetPendingMargin(
      ref int SumPendIntraLot,
      ref int SumPendCnfLots,
      ref double PendingMargin,
      ref double TurnoverMrgn,
      string symbol,
      string clientcode,
      int exch,
      ref int ExchPendLots,
      int buysell,
      Userinfo _info,
      ref int pendingqty)
    {
      List<Orders> tradeOrders = this.objmain.GetTradeOrders(2);
      int num1 = buysell;
      foreach (Orders orders1 in tradeOrders)
      {
        Orders orders2 = orders1;
        if (orders2.accountNo == clientcode)
        {
          if (orders2.ExchangeTypeID == 2)
          {
            if (symbol == orders2.symbol && num1 == orders2.BuySell)
            {
              if (_info.oddlot == 0)
                pendingqty += orders1.Ordeqty / this.objcon.lotsize;
              else
                pendingqty += orders1.Ordeqty;
            }
          }
          else if (symbol == orders2.symbol && num1 == orders2.BuySell)
            pendingqty += orders1.Ordeqty;
          if (this.objmain._Symconctracts.ContainsKey(orders2.symbol))
          {
            Contracts symconctract = this.objmain._Symconctracts[orders2.symbol];
            SymbolMargin symbolwiseMrgn = this.objmain.GetSymbolwiseMrgn(clientcode, symconctract.symbol);
            Limits limits = this.objmain.GetLimits(clientcode);
            int qty = 0;
            int buysell1 = 0;
            this.GetSymbolwiseOpenPos(symconctract.SymDesp, orders2.ValidityType, clientcode, ref qty, ref buysell1, pendingqty);
            buysell = orders2.BuySell;
            int ordeqty = orders2.Ordeqty;
            if (orders2.symbol != symbol)
              buysell = orders2.BuySell;
            int num2 = symconctract.exch != 2 && symconctract.exch != 5 || _info.oddlot != 0 ? orders2.Ordeqty : orders2.Ordeqty / symconctract.lotsize;
            if (exch == orders2.ExchangeTypeID && orders2.symbol == symbol)
              ExchPendLots += num2;
            if (limits.mrgntype == 1 || limits.mrgntype == 4 || limits.mrgntype == 6 || limits.mrgntype == 7)
            {
              if (orders2.ExchangeTypeID == 2)
                TurnoverMrgn += (double) orders2.Ordeqty * Convert.ToDouble(orders2.OrdePrice);
              else
                TurnoverMrgn += (double) orders2.Ordeqty * Convert.ToDouble(orders2.OrdePrice) * (double) symconctract.lotsize;
            }
            if (limits.mrgntype != 1)
            {
              if (buysell1 != buysell)
              {
                if (qty > num2)
                  num2 = qty - num2;
                else if (qty < num2)
                  num2 -= qty;
                else
                  num2 = qty - num2;
              }
              if (orders2.ValidityType == 1)
              {
                if (orders2.symbol == symbol && orders2.BuySell == num1)
                {
                  if ((symconctract.exch == 2 || symconctract.exch == 5) && _info.oddlot == 0)
                  {
                    int num3 = orders2.Ordeqty / symconctract.lotsize;
                    SumPendCnfLots += num3;
                  }
                  else
                    SumPendCnfLots += orders2.Ordeqty;
                }
                PendingMargin += (double) (num2 * symbolwiseMrgn.delvmrgn);
              }
              else
              {
                if (orders2.symbol == symbol)
                {
                  if ((symconctract.exch == 2 || symconctract.exch == 5) && _info.oddlot == 0)
                  {
                    int num3 = orders2.Ordeqty / symconctract.lotsize;
                    SumPendCnfLots += num3;
                  }
                  else
                    SumPendCnfLots += orders2.Ordeqty;
                }
                PendingMargin += (double) (num2 * symbolwiseMrgn.intramrgn);
              }
            }
          }
        }
      }
    }

    private void GetSymbolwiseOpenPos(
      string symbol,
      int validity,
      string clientcode,
      ref int qty,
      ref int buysell,
      int pendingqty)
    {
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetProftLoss))
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string str = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
        if (symbol == buysellnetpospfls.symbol && str == clientcode && validity == int32)
        {
          if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
          {
            qty = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
            buysell = 1;
          }
          else if (buysellnetpospfls.BQty < buysellnetpospfls.SQty)
          {
            qty = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            buysell = 2;
          }
          if (buysellnetpospfls.BQty > pendingqty)
          {
            qty = buysellnetpospfls.BQty - pendingqty;
            buysell = 1;
          }
          else if (buysellnetpospfls.BQty < pendingqty)
          {
            qty = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
            buysell = 2;
          }
        }
      }
    }

    private void GetMarginUtlised(
      Trades objtrd,
      Userinfo _info,
      ref int SumIntraLots,
      ref int SumCnfLots,
      ref double MarginUtilised,
      ref double ProfitLoss,
      ref int Totintralots,
      ref bool isclosepos,
      ref double RealisedPL,
      ref double TurnoverUtilised,
      ref int SymLots,
      ref int ExchLots,
      ref int netSymLots,
      int pendinglots)
    {
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetProftLoss))
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string clientcode = strArray[1];
        Limits clientLimit = this.objmain._ClientLimits[clientcode];
        int int32 = Convert.ToInt32(strArray[2]);
        buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
        SymbolMargin symbolwiseMrgn = this.objmain.GetSymbolwiseMrgn(clientcode, this.objcon.symbol);
        if (this.objmain._Symconctracts.ContainsKey(buysellnetpospfls.symbol))
        {
          Contracts symconctract = this.objmain._Symconctracts[buysellnetpospfls.symbol];
          string symbol = buysellnetpospfls.symbol;
          string str;
          if (symconctract.symbol == "GOLDMM")
            str = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            str = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.objmain.getFeed(buysellnetpospfls.symbol);
          Decimal num1 = new Decimal();
          if (int32 == 1)
            Totintralots += buysellnetpospfls.BQty + buysellnetpospfls.SQty;
          if (symconctract.exch == objtrd.exch)
          {
            if ((symconctract.exch == 2 || symconctract.exch == 5) && _info.oddlot == 0)
            {
              int num2 = buysellnetpospfls.Qty / symconctract.lotsize;
              ExchLots += num2;
            }
            else
              ExchLots += buysellnetpospfls.Qty;
          }
          if (objtrd.validity == 1)
            SumCnfLots += buysellnetpospfls.Qty;
          else
            SumIntraLots += buysellnetpospfls.Qty;
          if (clientcode == objtrd.clientcode)
          {
            if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
            {
              int num2 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
              if (symconctract.exch == 2 || symconctract.exch == 5)
                TurnoverUtilised += (double) num2 * Convert.ToDouble(buysellnetpospfls.buyprice);
              else
                TurnoverUtilised += (double) (num2 * symconctract.lotsize) * Convert.ToDouble(buysellnetpospfls.buyprice);
            }
            else if (buysellnetpospfls.BQty < buysellnetpospfls.SQty)
            {
              int num2 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
              if (symconctract.exch == 2 || symconctract.exch == 5)
                TurnoverUtilised += (double) num2 * Convert.ToDouble(buysellnetpospfls.sellprice);
              else
                TurnoverUtilised += (double) (num2 * symconctract.lotsize) * Convert.ToDouble(buysellnetpospfls.sellprice);
            }
          }
          if (this.objmain.objinfo.usertype == 3)
          {
            if (clientcode == objtrd.clientcode)
            {
              if (buysellnetpospfls.symbol == objtrd.Symbol)
              {
                if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
                {
                  int num2 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
                  int num3 = symconctract.exch != 2 ? 0 : (_info.oddlot == 0 ? 1 : 0);
                  SymLots = num3 == 0 ? num2 : num2 / symconctract.lotsize;
                  isclosepos = objtrd.buysell == 2;
                }
                else if (buysellnetpospfls.BQty < buysellnetpospfls.SQty)
                {
                  int num2 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
                  int num3 = symconctract.exch != 2 ? 0 : (_info.oddlot == 0 ? 1 : 0);
                  SymLots = num3 == 0 ? num2 : num2 / symconctract.lotsize;
                  isclosepos = objtrd.buysell == 1;
                }
                if ((clientLimit.mrgntype == 2 || clientLimit.mrgntype == 4 || (clientLimit.mrgntype == 5 || clientLimit.mrgntype == 7)) && clientLimit.lotwisetype == 3 || (clientLimit.mrgntype == 2 || clientLimit.mrgntype == 4 || (clientLimit.mrgntype == 5 || clientLimit.mrgntype == 7)) && clientLimit.lotwisetype == 1 || (clientLimit.mrgntype == 2 || clientLimit.mrgntype == 4 || (clientLimit.mrgntype == 5 || clientLimit.mrgntype == 7)) && clientLimit.lotwisetype == 2)
                {
                  int num2 = 0;
                  if (clientLimit.lotwisetype == 2)
                  {
                    if (symconctract.exch == 1)
                      num2 = clientLimit.mcxlots;
                    if (symconctract.exch == 2)
                      num2 = clientLimit.nsefutlots;
                    if (symconctract.exch == 3)
                      num2 = clientLimit.ncxlots;
                    if (symconctract.exch == 4)
                      num2 = clientLimit.nsecurlots;
                  }
                  if (clientLimit.lotwisetype == 3)
                    num2 = symbolwiseMrgn.totlots;
                  if (clientLimit.lotwisetype == 1)
                  {
                    if (symconctract.exch == 1)
                      num2 = this.objmain.MCXlots;
                    if (symconctract.exch == 2)
                      num2 = this.objmain.NSEFUTlots;
                    if (symconctract.exch == 3)
                      num2 = this.objmain.NCDEXlots;
                    if (symconctract.exch == 4)
                      num2 = this.objmain.NSECURlots;
                  }
                  if (isclosepos)
                  {
                    if (symconctract.exch == 2 && _info.oddlot == 0)
                    {
                      int num3 = buysellnetpospfls.Qty / symconctract.lotsize;
                      int num4 = objtrd.qty / symconctract.lotsize;
                      if (num2 + num3 < pendinglots + num4)
                        isclosepos = false;
                    }
                    else if (num2 + buysellnetpospfls.Qty < pendinglots + objtrd.qty)
                      isclosepos = false;
                  }
                }
              }
              netSymLots = buysellnetpospfls.BQty + buysellnetpospfls.SQty;
            }
          }
          else if (buysellnetpospfls.symbol == objtrd.Symbol)
          {
            if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
            {
              int num2 = buysellnetpospfls.BQty - buysellnetpospfls.SQty;
              if (symconctract.exch == 2 && _info.oddlot == 0)
                SymLots += num2 / symconctract.lotsize;
              else
                SymLots += num2;
              isclosepos = objtrd.buysell == 2;
            }
            else if (buysellnetpospfls.BQty < buysellnetpospfls.SQty)
            {
              int num2 = buysellnetpospfls.SQty - buysellnetpospfls.BQty;
              if (symconctract.exch == 2 && _info.oddlot == 0)
                SymLots += num2 / symconctract.lotsize;
              else
                SymLots += num2;
              isclosepos = objtrd.buysell == 1;
            }
            else
              isclosepos = false;
            netSymLots += buysellnetpospfls.BQty + buysellnetpospfls.SQty;
            RealisedPL += Convert.ToDouble(buysellnetpospfls.p_l - buysellnetpospfls.Commision - buysellnetpospfls.Comm_Tax - buysellnetpospfls.p_ltax);
            Decimal num3 = Decimal.Round((buysellnetpospfls.buy_sell != 1 ? buysellnetpospfls.sellprice - feed.ltp : feed.ltp - buysellnetpospfls.buyprice) * (Decimal) buysellnetpospfls.Qty * (Decimal) symconctract.lotsize, 2);
            ProfitLoss += Convert.ToDouble(buysellnetpospfls.p_l - buysellnetpospfls.Commision - buysellnetpospfls.Comm_Tax + num3 - buysellnetpospfls.p_ltax);
            if ((clientLimit.mrgntype == 2 || clientLimit.mrgntype == 4 || (clientLimit.mrgntype == 5 || clientLimit.mrgntype == 7)) && clientLimit.lotwisetype == 3 || (clientLimit.mrgntype == 2 || clientLimit.mrgntype == 4 || (clientLimit.mrgntype == 5 || clientLimit.mrgntype == 7)) && clientLimit.lotwisetype == 1 || (clientLimit.mrgntype == 2 || clientLimit.mrgntype == 4 || (clientLimit.mrgntype == 5 || clientLimit.mrgntype == 7)) && clientLimit.lotwisetype == 2)
            {
              int num2 = 0;
              if (clientLimit.lotwisetype == 2)
              {
                if (symconctract.exch == 1)
                  num2 = clientLimit.mcxlots;
                if (symconctract.exch == 2)
                  num2 = clientLimit.nsefutlots;
                if (symconctract.exch == 3)
                  num2 = clientLimit.ncxlots;
                if (symconctract.exch == 4)
                  num2 = clientLimit.nsecurlots;
              }
              if (clientLimit.lotwisetype == 3)
                num2 = symbolwiseMrgn.totlots;
              if (clientLimit.lotwisetype == 1)
              {
                if (symconctract.exch == 1)
                  num2 = this.objmain.MCXlots;
                if (symconctract.exch == 2)
                  num2 = this.objmain.NSEFUTlots;
                if (symconctract.exch == 3)
                  num2 = this.objmain.NCDEXlots;
                if (symconctract.exch == 4)
                  num2 = this.objmain.NSECURlots;
              }
              if (isclosepos)
              {
                if (symconctract.exch == 2 && _info.oddlot == 0)
                {
                  int num4 = buysellnetpospfls.Qty / symconctract.lotsize;
                  int num5 = objtrd.qty / symconctract.lotsize;
                  if (num2 + num4 < pendinglots + num5)
                    isclosepos = false;
                }
                else if (num2 + buysellnetpospfls.Qty < pendinglots + objtrd.qty)
                  isclosepos = false;
              }
            }
          }
          if (int32 == 1)
            MarginUtilised += Convert.ToDouble(symbolwiseMrgn.delvmrgn);
          else
            MarginUtilised += Convert.ToDouble(symbolwiseMrgn.intramrgn);
        }
      }
    }

    private bool Getoffset(string client, string symbol, ref double offset)
    {
      if (this.objmain._ClientOffset.ContainsKey(client))
      {
        SortedDictionary<string, double> sortedDictionary1 = this.objmain._ClientOffset[client];
        if (sortedDictionary1.ContainsKey(symbol))
        {
          offset = sortedDictionary1[symbol];
          if (offset != 0.0)
            return true;
          if (this.objmain._ClientOffset.ContainsKey(this.objmain.objinfo.createdby))
          {
            SortedDictionary<string, double> sortedDictionary2 = this.objmain._ClientOffset[this.objmain.objinfo.createdby];
            if (sortedDictionary2.ContainsKey(symbol))
            {
              offset = sortedDictionary2[symbol];
              return true;
            }
            offset = sortedDictionary1[symbol];
            return true;
          }
        }
        else if (this.objmain._ClientOffset.ContainsKey(this.objmain.objinfo.createdby))
        {
          SortedDictionary<string, double> sortedDictionary2 = this.objmain._ClientOffset[this.objmain.objinfo.createdby];
          if (sortedDictionary2.ContainsKey(symbol))
          {
            offset = sortedDictionary2[symbol];
            return true;
          }
          this.objmain.DisplayMessage("Offset not defined for: " + symbol ?? "", 2);
        }
        else if (this.objmain._ClientOffset.ContainsKey(this.objmain.objinfo.clientcode))
        {
          SortedDictionary<string, double> sortedDictionary2 = this.objmain._ClientOffset[this.objmain.objinfo.clientcode];
          if (sortedDictionary2.ContainsKey(symbol))
          {
            offset = sortedDictionary2[symbol];
            return true;
          }
          this.objmain.DisplayMessage("Offset not defined for: " + symbol ?? "", 2);
        }
        else
          this.objmain.DisplayMessage("Offset not defined for: " + symbol ?? "", 2);
      }
      else if (this.objmain._ClientOffset.ContainsKey(this.objmain.objinfo.createdby))
      {
        SortedDictionary<string, double> sortedDictionary = this.objmain._ClientOffset[this.objmain.objinfo.createdby];
        if (sortedDictionary.ContainsKey(symbol))
        {
          offset = sortedDictionary[symbol];
          return true;
        }
        this.objmain.DisplayMessage("Offset not defined for: " + symbol ?? "", 2);
      }
      else
        this.objmain.DisplayMessage("Offset not defined for: " + symbol ?? "", 2);
      return false;
    }

    private bool ValidateOffset(
      Feeds objfeeds,
      int buysell,
      Decimal price,
      int producttype,
      string account,
      string usersymbol)
    {
      Decimal num1 = new Decimal();
      double offset = 0.0;
      if (!this.Getoffset(account, usersymbol, ref offset))
        return false;
      Decimal num2 = Convert.ToDecimal(offset);
      switch (buysell)
      {
        case 1:
          switch (producttype)
          {
            case 1:
              if (objfeeds.bid - num2 < price)
              {
                this.objmain.DisplayMessage("Price Exceeding spread defined by Exchange", 2);
                this.objmain.insertSurveillanceMessages(account, "Price Exceeding spread defined by Exchange", this.Serverdt);
                return false;
              }
              break;
            case 2:
              if (objfeeds.ask + num2 > price)
              {
                this.objmain.DisplayMessage("Price Exceeding spread defined by Exchange", 2);
                this.objmain.insertSurveillanceMessages(account, "Price Exceeding spread defined by Exchange", this.Serverdt);
                return false;
              }
              break;
          }
          break;
        case 2:
          switch (producttype)
          {
            case 1:
              if (objfeeds.ask + num2 > price)
              {
                this.objmain.DisplayMessage("Price Exceeding spread defined by Exchange", 2);
                this.objmain.insertSurveillanceMessages(account, "Price Exceeding spread defined by Exchange", this.Serverdt);
                return false;
              }
              break;
            case 2:
              if (objfeeds.bid - num2 < price)
              {
                this.objmain.DisplayMessage("Price Exceeding spread defined by Exchange", 2);
                this.objmain.insertSurveillanceMessages(account, "Price Exceeding spread defined by Exchange", this.Serverdt);
                return false;
              }
              break;
          }
          break;
      }
      return true;
    }

    private int GetLot(int qty, string symbol)
    {
      Contracts contract = this.objmain.GetContract(symbol);
      return qty / contract.lotsize;
    }

    private bool ValidateMargin(
      Trades objtrd,
      double TotTurnover,
      Limits objlimits,
      Userinfo objinfo,
      int totLots,
      double MarginUtilised,
      int SymbolLots)
    {
      switch (objlimits.mrgntype)
      {
        case 1:
          if (TotTurnover > Convert.ToDouble(objlimits.turnoverlimit))
          {
            this.objmain.DisplayMessage("Turnover exceeding Turnover Margin.", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Turnover exceeding Turnover Margin.", "");
            return false;
          }
          break;
        case 2:
          switch (objlimits.lotwisetype)
          {
            case 1:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > this.objmain.MCXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > this.objmain.NSEFUTlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > this.objmain.NCDEXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > this.objmain.NSECURlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 2:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > objlimits.mcxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > objlimits.nsefutlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > objlimits.ncxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > objlimits.nsecurlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 3:
              string[] strArray1 = objtrd.Symbol.Split(' ');
              SymbolMargin symbolwiseMrgn1 = this.objmain.GetSymbolwiseMrgn(objtrd.clientcode, strArray1[0]);
              if (SymbolLots > symbolwiseMrgn1.totlots)
              {
                this.objmain.DisplayMessage("Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn1.totlots + ".", 2);
                this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn1.totlots + ".", "");
                return false;
              }
              break;
          }
          break;
        case 3:
          if (MarginUtilised > Convert.ToDouble(objlimits.cashmrgn))
          {
            this.objmain.DisplayMessage("Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", "");
            return false;
          }
          break;
        case 4:
          if (TotTurnover > Convert.ToDouble(objlimits.turnoverlimit))
          {
            this.objmain.DisplayMessage("Turnover exceeding Turnover Margin.", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Turnover exceeding Turnover Margin.", "");
            return false;
          }
          switch (objlimits.lotwisetype)
          {
            case 1:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > this.objmain.MCXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > this.objmain.NSEFUTlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > this.objmain.NCDEXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > this.objmain.NSECURlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 2:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > objlimits.mcxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > objlimits.nsefutlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > objlimits.ncxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > objlimits.nsecurlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 3:
              string[] strArray2 = objtrd.Symbol.Split(' ');
              SymbolMargin symbolwiseMrgn2 = this.objmain.GetSymbolwiseMrgn(objtrd.clientcode, strArray2[0]);
              if (SymbolLots > symbolwiseMrgn2.totlots)
              {
                this.objmain.DisplayMessage("Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn2.totlots + ".", 2);
                this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn2.totlots + ".", "");
                return false;
              }
              break;
          }
          break;
        case 5:
          if (MarginUtilised > Convert.ToDouble(objlimits.cashmrgn))
          {
            this.objmain.DisplayMessage("Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", "");
            return false;
          }
          switch (objlimits.lotwisetype)
          {
            case 1:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > this.objmain.MCXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > this.objmain.NSEFUTlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > this.objmain.NCDEXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > this.objmain.NSECURlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 2:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > objlimits.mcxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > objlimits.nsefutlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > objlimits.ncxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > objlimits.nsecurlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 3:
              string[] strArray3 = objtrd.Symbol.Split(' ');
              SymbolMargin symbolwiseMrgn3 = this.objmain.GetSymbolwiseMrgn(objtrd.clientcode, strArray3[0]);
              if (SymbolLots > symbolwiseMrgn3.totlots)
              {
                this.objmain.DisplayMessage("Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn3.totlots + ".", 2);
                this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn3.totlots + ".", "");
                return false;
              }
              break;
          }
          break;
        case 6:
          if (TotTurnover > Convert.ToDouble(objlimits.turnoverlimit))
          {
            this.objmain.DisplayMessage("Turnover exceeding Turnover Margin.", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Turnover exceeding Turnover Margin.", "");
            return false;
          }
          if (MarginUtilised > Convert.ToDouble(objlimits.cashmrgn))
          {
            this.objmain.DisplayMessage("Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", "");
            return false;
          }
          break;
        case 7:
          if (TotTurnover > Convert.ToDouble(objlimits.turnoverlimit))
          {
            this.objmain.DisplayMessage("Turnover exceeding Turnover Margin.", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Turnover exceeding Turnover Margin.", "");
            return false;
          }
          if (MarginUtilised > Convert.ToDouble(objlimits.cashmrgn))
          {
            this.objmain.DisplayMessage("Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", 2);
            this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Cash Margin Limit, allowed Cash margin Limit is " + (object) objlimits.cashmrgn + ".", "");
            return false;
          }
          switch (objlimits.lotwisetype)
          {
            case 1:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > this.objmain.MCXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) this.objmain.MCXlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > this.objmain.NSEFUTlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) this.objmain.NSEFUTlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > this.objmain.NCDEXlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) this.objmain.NCDEXlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > this.objmain.NSECURlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) this.objmain.NSECURlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 2:
              switch (objtrd.exch)
              {
                case 1:
                  if (totLots > objlimits.mcxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for MCX is " + (object) objlimits.mcxlots + ".", "");
                    return false;
                  }
                  break;
                case 2:
                  if (totLots > objlimits.nsefutlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSEFUT is " + (object) objlimits.nsefutlots + ".", "");
                    return false;
                  }
                  break;
                case 3:
                  if (totLots > objlimits.ncxlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NCDEX is " + (object) objlimits.ncxlots + ".", "");
                    return false;
                  }
                  break;
                case 4:
                  if (totLots > objlimits.nsecurlots)
                  {
                    this.objmain.DisplayMessage("Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", 2);
                    this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Lotwise Margin, allowed lotwise margin for NSECURR is " + (object) objlimits.nsecurlots + ".", "");
                    return false;
                  }
                  break;
              }
              break;
            case 3:
              string[] strArray4 = objtrd.Symbol.Split(' ');
              SymbolMargin symbolwiseMrgn4 = this.objmain.GetSymbolwiseMrgn(objtrd.clientcode, strArray4[0]);
              if (SymbolLots > symbolwiseMrgn4.totlots)
              {
                this.objmain.DisplayMessage("Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn4.totlots + ".", 2);
                this.objmain.insertSurveillanceMessages(objtrd.clientcode, "Exceeding Symbolwise Lotwise Margin, allowed margin for " + objtrd.Symbol + " is " + (object) symbolwiseMrgn4.totlots + ".", "");
                return false;
              }
              break;
          }
          break;
      }
      return true;
    }

    private void btnSubmit_Click(object sender, EventArgs e)
    {
      if (this.ValidateOrderParameters())
      {
        DateTime dtnow = new DateTime();
        Userinfo userinfo = this.objmain.GetUserinfo(this.cmbClientcode.Text);
        this.objcon = this.objmain.GetContract(this.cmbSymbol.Text);
        string text = this.cmbClientcode.Text;
        if (!this.objmain.ValidateMarketTime(this.cmbExch.Text, ref dtnow))
        {
          this.objmain.DisplayMessage(string.Format(" {0} Market is closed!!", (object) this.cmbExch.Text), 2);
          this.objmain.insertSurveillanceMessages(text, string.Format(" {0} Market is closed!!", (object) this.cmbExch.Text), this.Serverdt);
          return;
        }
        if (!Utils.ValidateRateUpdate(this.objcon.exch, this.objmain.getConn()))
        {
          this.objmain.DisplayMessage(string.Format(" {0} Rate not updating for Trading", (object) this.cmbExch.Text), 2);
          this.objmain.insertSurveillanceMessages(text, string.Format(" {0} Rate not updating for Trading", (object) this.cmbExch.Text), this.Serverdt);
          return;
        }
        this.Serverdt = dtnow.ToString("yyyy-MM-dd HH:mm:ss");
        int intExch = Utils.GetIntExch(this.cmbExch.Text);
        if (this.objmain.objinfo.marginstatus == 0 && this.objmain.objinfo.usertype == 4)
        {
          this.objmain.DisplayMessage("Margin Blocked by Admin, Please Contact Admin", 2);
          this.objmain.insertSurveillanceMessages(text, "Margin Blocked by Admin, Please Contact Admin", this.Serverdt);
          return;
        }
        if (this.objmain.objinfo.usertype == 3)
        {
          if (this.objmain._Userinformation.ContainsKey(this.cmbClientcode.Text) && this.objmain._Userinformation[this.cmbClientcode.Text].marginstatus == 0)
          {
            this.objmain.DisplayMessage("Margin Blocked by Admin, Please Contact Admin", 2);
            this.objmain.insertSurveillanceMessages(text, "Margin Blocked by Admin, Please Contact Admin", this.Serverdt);
            return;
          }
          if (!userinfo.exchange.Contains(this.cmbExch.Text))
          {
            this.objmain.DisplayMessage("Trading in this exchange not allowed for this Client, Please Contact Admin", 2);
            this.objmain.insertSurveillanceMessages(text, "Trading in this exchange not allowed for this Client, Please Contact Admin", this.Serverdt);
            return;
          }
        }
        if (Convert.ToInt32(this.txtQty.Text) == 0)
        {
          this.objmain.DisplayMessage("Please enter valid qty", 2);
          this.objmain.insertSurveillanceMessages(text, "Please enter valid qty", this.Serverdt);
          return;
        }
        Trades trades = new Trades()
        {
          exch = (int) Enum.Parse(typeof (Exch), this.cmbExch.Text.ToUpper()),
          Symbol = this.cmbSymbol.Text,
          buysell = this.mode,
          producttype = (int) Enum.Parse(typeof (OrderType), this.cmbOrdertype.Text.ToUpper()),
          qty = Convert.ToInt32(this.txtQty.Text),
          orderno = Trades.OrderNoGenerate(),
          validity = (int) Enum.Parse(typeof (ValidityType), this.CmbValidity.Text.ToUpper()),
          userremarks = this.txtUserRemarks.Text,
          clientcode = text,
          traderid = this.objmain.objinfo.clientcode,
          Createon = dtnow,
          Lastmodified = dtnow
        };
        Limits limits = this.objmain.GetLimits(trades.clientcode);
        if (this.objmain._SymbolwiseCommTiming.ContainsKey(this.objcon.symbol))
        {
          DateTime dateTime = this.objmain._SymbolwiseCommTiming[this.objcon.symbol];
          dateTime = new DateTime(dtnow.Year, dtnow.Month, dtnow.Day, dateTime.Hour, dateTime.Minute, 0);
          if (dtnow > dateTime)
          {
            this.objmain.DisplayMessage(string.Format(" {0} Market is closed!! for " + trades.Symbol ?? "", (object) this.cmbExch.Text), 2);
            this.objmain.insertSurveillanceMessages(text, string.Format(" {0} Market is closed!! for " + trades.Symbol ?? "", (object) this.cmbExch.Text), this.Serverdt);
            return;
          }
        }
        if (limits.cashmrgn <= Decimal.Zero)
        {
          this.objmain.DisplayMessage("Cash Margin Not Available for Trading", 2);
          this.objmain.insertSurveillanceMessages(text, "Cash Margin Not Available for Trading", this.Serverdt);
          return;
        }
        if (limits.brkupType == 2)
        {
          SymbolMargin symbolwiseMrgn = this.objmain.GetSymbolwiseMrgn(trades.clientcode, this.objcon.symbol);
          if (this.objcon.exch == 2)
          {
            if (userinfo.oddlot == 0)
            {
              int num = this.objcon.lotsize * symbolwiseMrgn.brkupQty;
              if (trades.qty > num)
              {
                this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) symbolwiseMrgn.brkupQty), 2);
                this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) symbolwiseMrgn.brkupQty), this.Serverdt);
                return;
              }
            }
            else if (trades.qty > symbolwiseMrgn.brkupQty)
            {
              this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) symbolwiseMrgn.brkupQty), 2);
              this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) symbolwiseMrgn.brkupQty), this.Serverdt);
              return;
            }
          }
          else if (trades.qty > symbolwiseMrgn.brkupQty)
          {
            this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) symbolwiseMrgn.brkupQty), 2);
            this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) symbolwiseMrgn.brkupQty), this.Serverdt);
            return;
          }
        }
        else
        {
          int breakup = this.getBreakup(this.objcon, limits, userinfo);
          if (trades.qty > breakup)
          {
            switch (trades.exch)
            {
              case 1:
                this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.McxBrkup), 2);
                this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.McxBrkup), this.Serverdt);
                return;
              case 2:
                this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.NsefutBrkup), 2);
                this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.NsefutBrkup), this.Serverdt);
                return;
              case 3:
                this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.NcdexBrkup), 2);
                this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.NcdexBrkup), this.Serverdt);
                return;
              case 4:
                this.objmain.DisplayMessage(string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.NsecurBrkup), 2);
                this.objmain.insertSurveillanceMessages(text, string.Format("Qty Exceeding Breakup Limit, Breakup Defined is: {0} Lots", (object) limits.NsecurBrkup), this.Serverdt);
                return;
              default:
                return;
            }
          }
        }
        if (limits.tradeattributes == 3)
        {
          this.objmain.DisplayMessage("Trading Blocked by Admin, Contact Admin", 2);
          this.objmain.insertSurveillanceMessages(text, "Trading Blocked by Admin, Contact Admin", this.Serverdt);
          return;
        }
        Decimal price1 = Decimal.Round(Convert.ToDecimal(this.numericUpDownPrice.Text), Utils.GetRoundoff(this.objcon.tickprice));
        Decimal num1 = price1;
        if (price1.ToString().Contains("."))
        {
          if (price1.ToString().Split('.')[1].Length == 2 && Utils.GetRoundoff(this.objcon.tickprice) == 2)
          {
            int int32 = Convert.ToInt32(num1.ToString().Substring(num1.ToString().Length - 1, 1));
            if (int32 > 5)
            {
              num1 = Decimal.Round(Convert.ToDecimal(num1.ToString().Substring(0, num1.ToString().Length - 1)), 2);
              num1 += new Decimal(1, 0, 0, false, (byte) 1);
            }
            else if (int32 < 5 && int32 > 0)
              num1 = Convert.ToDecimal(num1.ToString().Substring(0, num1.ToString().Length - 1) + "5");
          }
        }
        string symbol = trades.Symbol;
        if (this.objcon.symbol == "GOLDMM")
          symbol = symbol.Replace("GOLDMM", "GOLD");
        else if (this.objcon.symbol == "SILVERMM")
          symbol = symbol.Replace("SILVERMM", "SILVER");
        Feeds dbFeed = this.objmain.GetDBFeed(symbol);
        if (dbFeed.vol <= 0.0)
        {
          this.objmain.DisplayMessage("Volume not available for trading", 2);
          this.objmain.insertSurveillanceMessages(text, "Volume not available for trading", this.Serverdt);
          return;
        }
        double dprLimit = this.objmain.GetDPRLimit(trades.Symbol);
        double num2 = Math.Round(Convert.ToDouble(dbFeed.close) * dprLimit / 100.0, 2);
        double num3 = Convert.ToDouble(dbFeed.close) + num2;
        double num4 = Convert.ToDouble(dbFeed.close) - num2;
        if (price1 > Decimal.Zero && dprLimit > 0.0)
        {
          if (trades.producttype == 1)
          {
            if (trades.buysell == 1 && Convert.ToDouble(price1) < num4)
            {
              this.objmain.DisplayMessage("Price exceeding DPR Limit", 2);
              this.objmain.insertSurveillanceMessages(text, "Price exceeding DPR Limit(" + trades.Symbol + ")", this.Serverdt);
              return;
            }
            if (trades.buysell == 2 && Convert.ToDouble(price1) > num3)
            {
              this.objmain.DisplayMessage("Price exceeding DPR Limit", 2);
              this.objmain.insertSurveillanceMessages(text, "Price exceeding DPR Limit(" + trades.Symbol + ")", this.Serverdt);
              return;
            }
          }
          else if (trades.producttype == 2)
          {
            if (trades.buysell == 1 && Convert.ToDouble(price1) < num3)
            {
              this.objmain.DisplayMessage("Price exceeding DPR Limit", 2);
              this.objmain.insertSurveillanceMessages(text, "Price exceeding DPR Limit(" + trades.Symbol + ")", this.Serverdt);
              return;
            }
            if (trades.buysell == 2 && Convert.ToDouble(price1) > num4)
            {
              this.objmain.DisplayMessage("Price exceeding DPR Limit", 2);
              this.objmain.insertSurveillanceMessages(text, "Price exceeding DPR Limit(" + trades.Symbol + ")", this.Serverdt);
              return;
            }
          }
        }
        if (price1 > Decimal.Zero && userinfo.offset == 1)
        {
          if (userinfo.OffsetExch.Contains(this.cmbExch.Text))
          {
            if (!this.ValidateOffset(dbFeed, trades.buysell, price1, trades.producttype, trades.clientcode, this.objcon.symbol))
              return;
          }
          else if (price1 > Decimal.Zero && userinfo.isHLTrading == 1 && userinfo.HighLowExch.Contains(this.cmbExch.Text))
          {
            if (trades.producttype == 1)
            {
              if (trades.buysell == 1 && price1 >= dbFeed.low)
              {
                this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
                return;
              }
              if (trades.buysell == 2 && price1 <= dbFeed.high)
              {
                this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
                return;
              }
            }
            else
            {
              if (trades.buysell == 1 && price1 <= dbFeed.high)
              {
                this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
                return;
              }
              if (trades.buysell == 2 && price1 >= dbFeed.low)
              {
                this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
                return;
              }
            }
          }
        }
        else if (price1 > Decimal.Zero && userinfo.isHLTrading == 1 && userinfo.HighLowExch.Contains(this.cmbExch.Text))
        {
          if (trades.producttype == 1)
          {
            if (trades.buysell == 1 && price1 >= dbFeed.low)
            {
              this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
              return;
            }
            if (trades.buysell == 2 && price1 <= dbFeed.high)
            {
              this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
              return;
            }
          }
          else
          {
            if (trades.buysell == 1 && price1 <= dbFeed.high)
            {
              this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
              return;
            }
            if (trades.buysell == 2 && price1 >= dbFeed.low)
            {
              this.objmain.DisplayMessage("Invalid price, order price not matching with offset defined(High-Low)", 2);
              return;
            }
          }
        }
        if (!this.IsModify)
        {
          if (price1 == Decimal.Zero || limits.Productype.ToUpper() == "MKT")
          {
            if (trades.buysell == 1)
            {
              trades.Ordprice = dbFeed.ask;
              trades.price = dbFeed.ask;
            }
            else
            {
              trades.Ordprice = dbFeed.bid;
              trades.price = dbFeed.bid;
            }
            trades.ordstatus = 1;
            trades.exectype = 2;
          }
          else
          {
            trades.Ordprice = price1;
            if (trades.producttype == 1)
            {
              if (trades.buysell == 1)
              {
                if (trades.Ordprice >= dbFeed.ask)
                {
                  trades.price = dbFeed.ask;
                  trades.ordstatus = 1;
                  trades.exectype = 2;
                }
                else if (trades.Ordprice < dbFeed.ask)
                {
                  trades.ordstatus = 2;
                  trades.exectype = 1;
                }
              }
              else if (trades.Ordprice <= dbFeed.bid)
              {
                trades.price = dbFeed.bid;
                trades.ordstatus = 1;
                trades.exectype = 2;
              }
              else if (trades.Ordprice > dbFeed.bid)
              {
                trades.ordstatus = 2;
                trades.exectype = 1;
              }
            }
            else if (trades.producttype == 2)
            {
              if (trades.buysell == 1)
              {
                if (dbFeed.ask >= trades.Ordprice)
                {
                  this.objmain.DisplayMessage("Invalid SL price found.", 2);
                  this.objmain.insertSurveillanceMessages(text, "Invalid SL price found.", this.Serverdt);
                  return;
                }
                trades.ordstatus = 2;
                trades.exectype = 1;
              }
              else
              {
                if (trades.Ordprice >= dbFeed.bid)
                {
                  this.objmain.DisplayMessage("Invalid SL price found.", 2);
                  this.objmain.insertSurveillanceMessages(text, "Invalid SL price found.", this.Serverdt);
                  return;
                }
                trades.ordstatus = 2;
                trades.exectype = 1;
              }
            }
          }
        }
        else
          trades.Ordprice = price1;
        int SumPendIntraLot = 0;
        int SumPendCnfLots = 0;
        int num5 = 0;
        int num6 = 0;
        int num7 = 0;
        double PendingMargin = 0.0;
        double ProfitLoss = 0.0;
        double RealisedPL = 0.0;
        double MarginUtilised1 = 0.0;
        int SumIntraLots = 0;
        int SumCnfLots = 0;
        int Totintralots = 0;
        int SymLots = 0;
        bool isclosepos = false;
        double TurnoverMrgn = 0.0;
        double TurnoverUtilised = 0.0;
        double num8 = 0.0;
        int ExchLots = 0;
        int ExchPendLots = 0;
        SymbolMargin symbolwiseMrgn1 = this.objmain.GetSymbolwiseMrgn(trades.clientcode, this.objcon.symbol);
        double num9;
        double num10;
        if (this.objcon.exch == 2 || this.objcon.exch == 5)
        {
          num9 = num8 + (double) trades.qty * Convert.ToDouble(trades.Ordprice);
          int num11 = trades.qty / this.objcon.lotsize;
          if (userinfo.oddlot == 1)
            num11 = trades.qty;
          if (trades.validity == 1)
          {
            num6 = num11;
            num10 = (double) (symbolwiseMrgn1.delvmrgn * num11);
          }
          else
          {
            num5 = num11;
            num10 = (double) (symbolwiseMrgn1.intramrgn * num11);
          }
        }
        else
        {
          num9 = num8 + (double) (trades.qty * this.objcon.lotsize) * Convert.ToDouble(trades.Ordprice);
          if (trades.validity == 1)
          {
            num6 = trades.qty;
            num10 = (double) (symbolwiseMrgn1.delvmrgn * trades.qty);
          }
          else
          {
            num5 = trades.qty;
            num10 = (double) (symbolwiseMrgn1.intramrgn * trades.qty);
          }
        }
        int netSymLots = 0;
        int pendingqty = 0;
        this.GetPendingMargin(ref SumPendIntraLot, ref SumPendCnfLots, ref PendingMargin, ref TurnoverMrgn, trades.Symbol, trades.clientcode, trades.exch, ref ExchPendLots, trades.buysell, userinfo, ref pendingqty);
        this.GetMarginUtlised(trades, userinfo, ref SumIntraLots, ref SumCnfLots, ref MarginUtilised1, ref ProfitLoss, ref Totintralots, ref isclosepos, ref RealisedPL, ref TurnoverUtilised, ref SymLots, ref ExchLots, ref netSymLots, pendingqty);
        int num12;
        int SymbolLots;
        if ((int) Enum.Parse(typeof (ValidityType), this.CmbValidity.Text.ToUpper()) != 1)
        {
          num12 = SumPendIntraLot + SumCnfLots + num5 + SumPendCnfLots;
          SymbolLots = SymLots + num6 + num12;
        }
        else
        {
          num12 = SumPendCnfLots + SumIntraLots + num5 + SumPendIntraLot;
          SymbolLots = SymLots + num6 + num12;
        }
        int totlots = netSymLots + num6 + SumPendIntraLot + num5 + SumPendCnfLots;
        int num13 = Totintralots + num5;
        double TotTurnover = TurnoverMrgn + TurnoverUtilised + num9;
        int num14 = SumPendCnfLots + SumCnfLots + num6;
        num7 = num12 + num14;
        double MarginUtilised2 = Math.Round(MarginUtilised1 + PendingMargin + num10 - RealisedPL);
        int num15 = trades.qty;
        if ((this.objcon.exch == 2 || this.objcon.exch == 5) && userinfo.oddlot == 0)
        {
          num15 = trades.qty / this.objcon.lotsize;
        }
        else
        {
          int qty = trades.qty;
        }
        int totLots = ExchLots + ExchPendLots + num15;
        if (!isclosepos)
        {
          if (!this.ValidateMargin(trades, TotTurnover, limits, userinfo, totLots, MarginUtilised2, SymbolLots))
            return;
          if (!this.objmain.ValidateContractStatus(this.objcon.SymDesp, 2, this.cmbClientcode.Text, intExch))
          {
            this.objmain.DisplayMessage("Contract banned by Admin for ClientCode " + this.cmbClientcode.Text ?? "", 2);
            this.objmain.insertSurveillanceMessages(text, "Contract " + this.cmbSymbol.Text + " banned for ClientCode " + this.cmbClientcode.Text + ", cannot trade in this Contract", this.Serverdt);
            return;
          }
          if (!this.objmain.ValidateContractStatus(this.objcon.SymDesp, 3, this.cmbClientcode.Text, intExch))
          {
            this.objmain.DisplayMessage("Contract Suspended by Admin for ClientCode " + this.cmbClientcode.Text ?? "", 2);
            this.objmain.insertSurveillanceMessages(text, "Contract " + this.cmbSymbol.Text + " Suspended for ClientCode " + this.cmbClientcode.Text + ", cannot trade in this Contract", this.Serverdt);
            return;
          }
          if (!this.objmain.ValidateContractStatus(this.objcon.SymDesp, 4, userinfo.createdby, this.objcon.exch))
          {
            this.objmain.DisplayMessage("Contract in Exchange Banned Period, you can only close Open Positions in this Contract", 2);
            this.objmain.insertSurveillanceMessages(text, "Contract " + this.cmbSymbol.Text + " in Exchange Banned Period, cannot trade in this Contract", this.Serverdt);
            return;
          }
          if (!this.ValidateTradingVolume(this.objcon, trades, dbFeed, totlots))
          {
            this.objmain.DisplayMessage("Trade volume exceeding volume % defined by admin", 2);
            this.objmain.insertSurveillanceMessages(text, "Trade volume exceeding volume % defined by admin for (" + trades.Symbol + ")", this.Serverdt);
            return;
          }
        }
        else if (!this.ValidatPositionCloseTime(trades, this.objcon, dtnow))
        {
          this.objmain.DisplayMessage("Not allowed to close position within time period defined by admin", 2);
          this.objmain.insertSurveillanceMessages(text, "Not allowed to close position within time period defined by admin, Symbol " + trades.Symbol + " clientcode " + trades.clientcode ?? "", this.Serverdt);
          return;
        }
        if (this.IsModify)
        {
          Decimal price2 = Decimal.Round(Convert.ToDecimal(this.numericUpDownPrice.Text), Utils.GetRoundoff(this.objcon.tickprice));
          if (price2.ToString().Contains("."))
          {
            if (price2.ToString().Split('.')[1].Length == 2 && Utils.GetRoundoff(this.objcon.tickprice) == 2)
            {
              int int32 = Convert.ToInt32(price2.ToString().Substring(price2.ToString().Length - 1, 1));
              if (int32 > 5)
              {
                price2 = Decimal.Round(Convert.ToDecimal(price2.ToString().Substring(0, price2.ToString().Length - 1)), 2);
                price2 += new Decimal(1, 0, 0, false, (byte) 1);
              }
              else if (int32 < 5 && int32 > 0)
                price2 = Convert.ToDecimal(price2.ToString().Substring(0, price2.ToString().Length - 1) + "5");
            }
          }
          if (price2 != Decimal.Zero)
          {
            if (trades.producttype == 1)
            {
              if (trades.buysell == 1)
              {
                if (price2 >= dbFeed.ask)
                  price2 = new Decimal();
              }
              else if (price2 <= dbFeed.bid)
                price2 = new Decimal();
            }
            else if (trades.producttype == 2)
            {
              if (trades.buysell == 1)
              {
                if (dbFeed.ask >= price2)
                {
                  this.objmain.DisplayMessage("Invalid SL price found.", 2);
                  this.objmain.insertSurveillanceMessages(text, "Invalid SL price found.", this.Serverdt);
                  return;
                }
              }
              else if (price2 >= dbFeed.bid)
              {
                this.objmain.DisplayMessage("Invalid SL price found.", 2);
                this.objmain.insertSurveillanceMessages(text, "Invalid SL price found.", this.Serverdt);
                return;
              }
            }
          }
          this.objmain.objordbook.ModifyOrder(dtnow, price2, trades.qty, this.rowindex);
          this.Close();
        }
        if (limits.tradeattributes == 2 && !isclosepos)
        {
          this.objmain.DisplayMessage("Restricted to Create New Positions, Only allowed to Close Positions by Admin, please contact Admin", 2);
          this.objmain.insertSurveillanceMessages(text, "Restricted to Create New Positions, Only allowed to Close Positions by Admin, please contact Admin", this.Serverdt);
          return;
        }
        this.PlaceOrder(trades);
      }
      this.Close();
    }

    private void PlaceOrder(Trades objord)
    {
      if (!(objord.Ordprice > Decimal.Zero) || objord.qty <= 0)
        return;
      if (objord.ordstatus == 2)
      {
        if (Trades.SaveOrder(objord, this.objmain.getConn()))
          this.objmain.DisplayConfirmationMsg(objord);
      }
      else if (Trades.SaveOrder(objord, this.objmain.getConn()) & Trades.SaveTrade(objord, this.objmain.getConn()))
      {
        this.objmain.DisplayConfirmationMsg(objord);
        if (objord.ordstatus == 1)
          Dashboard.PlaySound(2);
      }
    }

    public Userinfo GetUserinfo(string clientcode)
    {
      if (this.objmain.objinfo.usertype == 3)
      {
        if (this.objmain._Userinformation.ContainsKey(clientcode))
          return this.objmain._Userinformation[clientcode];
      }
      else if (this.objmain.objinfo.usertype == 4)
        return this.objmain.objinfo;
      return new Userinfo();
    }

    private void cmbOrdertype_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    private void RealtimeUpdate(string symbol)
    {
    }

    private void cmbSymbol_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (!(this.cmbSymbol.Text != string.Empty))
        return;
      if (this.objmain._SymFeeds.ContainsKey(this.cmbSymbol.Text))
      {
        Feeds symFeed = this.objmain._SymFeeds[this.cmbSymbol.Text];
        if (this.mode == 1)
          this.numericUpDownPrice.Text = symFeed.ask.ToString();
        else
          this.numericUpDownPrice.Text = symFeed.bid.ToString();
      }
      Contracts contract = this.objmain.GetContract(this.cmbSymbol.Text);
      this.objmain.GetUserinfo(this.cmbClientcode.Text);
      if (this.cmbExch.Text == "NSEFUT" || this.cmbExch.Text == "NSEOPT")
        this.txtQty.Text = contract.lotsize.ToString();
      else
        this.txtQty.Text = "1";
      this.numericUpDownPrice.Increment = Utils.GetTickprice(contract.tickprice);
    }

    private int getBreakup(Contracts objcon, Limits objclientlimits, Userinfo _info)
    {
      if (this.cmbExch.Text == "NSEFUT" || this.cmbExch.Text == "NSEOPT")
        return _info.oddlot == 0 ? objcon.lotsize * objclientlimits.NsefutBrkup : objclientlimits.NsefutBrkup;
      if (objcon.exch == 1)
        return objclientlimits.McxBrkup;
      return objcon.exch == 3 ? objclientlimits.NcdexBrkup : objclientlimits.NsecurBrkup;
    }

    private void cmbClientcode_Leave(object sender, EventArgs e)
    {
      if (this.cmbClientcode.Text.Length <= 0)
        return;
      if (!this.objmain._lstAccounts.Contains(this.cmbClientcode.Text))
      {
        this.objmain.DisplayMessage("Client code does not exists.", 2);
        this.cmbClientcode.Text = string.Empty;
      }
      else
        this.FillValidity();
    }

    private void textBox1_KeyUp(object sender, KeyEventArgs e)
    {
      Contracts contract = this.objmain.GetContract(this.cmbSymbol.Text);
      this.objmain.GetUserinfo(this.cmbClientcode.Text);
      int result = 0;
      if (!int.TryParse(this.txtQty.Text, out result))
        return;
      if (e.KeyCode == Keys.Up)
      {
        if (this.cmbExch.Text == "NSEFUT" || this.cmbExch.Text == "NSEOPT")
        {
          this.txtQty.Text = (Convert.ToInt32(this.txtQty.Text) + contract.lotsize).ToString();
          this.txtQty.Select(0, this.txtQty.ToString().Length);
        }
        else
        {
          this.txtQty.Text = (Convert.ToInt32(this.txtQty.Text) + 1).ToString();
          this.txtQty.Select(0, this.txtQty.ToString().Length);
        }
      }
      else
      {
        if (e.KeyCode != Keys.Down)
          return;
        if (this.cmbExch.Text == "NSEFUT" || this.cmbExch.Text == "NSEOPT")
        {
          int int32 = Convert.ToInt32(this.txtQty.Text);
          if (int32 != contract.lotsize)
          {
            this.txtQty.Text = (int32 - contract.lotsize).ToString();
            this.txtQty.Select(0, this.txtQty.ToString().Length);
          }
        }
        else
        {
          int int32 = Convert.ToInt32(this.txtQty.Text);
          if (int32 != 1)
          {
            this.txtQty.Text = (int32 - 1).ToString();
            this.txtQty.Select(0, this.txtQty.ToString().Length);
          }
        }
      }
    }

    private void txtQty_Enter(object sender, EventArgs e)
    {
      this.txtQty.Select(0, this.txtQty.ToString().Length);
    }

    private void BuySellOrder_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode != Keys.Escape)
        return;
      this.Close();
    }

    private void txtQty_TextChanged(object sender, EventArgs e)
    {
      int result = 0;
      if (int.TryParse(this.txtQty.Text, out result))
        return;
      this.txtQty.Text = "";
    }

    private void BuySellOrder_Load(object sender, EventArgs e)
    {
    }

    public bool ValidateTradingVolume(
      Contracts objcontracts,
      Trades objord,
      Feeds _objfeeds,
      int totlots)
    {
      TradeSettings tradeSettings = this.objmain.GetTradeSettings(objord.clientcode, objord.exch, objcontracts.symbol);
      if (tradeSettings != null && tradeSettings.volumePercent > 0.0)
      {
        double num = Math.Round(_objfeeds.vol * tradeSettings.volumePercent / 100.0, 2);
        if ((double) totlots > num)
          return false;
      }
      return true;
    }

    public bool ValidatPositionCloseTime(
      Trades objord,
      Contracts objcontracts,
      DateTime servertime)
    {
      TradeSettings tradeSettings = this.objmain.GetTradeSettings(objord.clientcode, objord.exch, objcontracts.symbol);
      if (tradeSettings == null || tradeSettings.closeAfterMins <= 0)
        return true;
      int postype = objord.buysell == 1 ? 2 : 1;
      return objord.qty <= this.objmain.GetAllowedTradeableQty(objord.clientcode, objord.Symbol, postype, servertime.AddMinutes((double) (-1 * tradeSettings.closeAfterMins)));
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.statusStrip1 = new StatusStrip();
      this.toolStripStatusLabel1 = new ToolStripStatusLabel();
      this.toolStripStatusLabel2 = new ToolStripStatusLabel();
      this.cmbExch = new ComboBox();
      this.cmbOrdertype = new ComboBox();
      this.label1 = new Label();
      this.label2 = new Label();
      this.label3 = new Label();
      this.cmbSymbol = new ComboBox();
      this.label4 = new Label();
      this.label5 = new Label();
      this.label6 = new Label();
      this.CmbValidity = new ComboBox();
      this.txtName = new TextBox();
      this.label7 = new Label();
      this.txtUserRemarks = new TextBox();
      this.btnSubmit = new Button();
      this.btnClear = new Button();
      this.label8 = new Label();
      this.cmbClientcode = new ComboBox();
      this.numericUpDownPrice = new NumericUpDown();
      this.txtQty = new TextBox();
      this.statusStrip1.SuspendLayout();
      this.numericUpDownPrice.BeginInit();
      this.SuspendLayout();
      this.statusStrip1.Items.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.toolStripStatusLabel1,
        (ToolStripItem) this.toolStripStatusLabel2
      });
      this.statusStrip1.Location = new Point(0, 102);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new Size(711, 22);
      this.statusStrip1.TabIndex = 0;
      this.statusStrip1.Text = "statusStrip1";
      this.toolStripStatusLabel1.BackColor = Color.Transparent;
      this.toolStripStatusLabel1.ForeColor = SystemColors.ControlText;
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new Size(49, 17);
      this.toolStripStatusLabel1.Text = "Message";
      this.toolStripStatusLabel2.BackColor = Color.Transparent;
      this.toolStripStatusLabel2.ForeColor = Color.Black;
      this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
      this.toolStripStatusLabel2.Size = new Size(59, 17);
      this.toolStripStatusLabel2.Text = "New Order";
      this.cmbExch.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbExch.FormattingEnabled = true;
      this.cmbExch.Location = new Point(12, 21);
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(73, 21);
      this.cmbExch.TabIndex = 7;
      this.cmbOrdertype.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbOrdertype.FormattingEnabled = true;
      this.cmbOrdertype.Items.AddRange(new object[2]
      {
        (object) "RL",
        (object) "SL"
      });
      this.cmbOrdertype.Location = new Point(102, 21);
      this.cmbOrdertype.Name = "cmbOrdertype";
      this.cmbOrdertype.Size = new Size(50, 21);
      this.cmbOrdertype.TabIndex = 8;
      this.cmbOrdertype.SelectedIndexChanged += new EventHandler(this.cmbOrdertype_SelectedIndexChanged);
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(0, 4);
      this.label1.Name = "label1";
      this.label1.Size = new Size(32, 13);
      this.label1.TabIndex = 3;
      this.label1.Text = "BUY";
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(101, 5);
      this.label2.Name = "label2";
      this.label2.Size = new Size(60, 13);
      this.label2.TabIndex = 4;
      this.label2.Text = "Order Type";
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label3.Location = new Point(173, 6);
      this.label3.Name = "label3";
      this.label3.Size = new Size(41, 13);
      this.label3.TabIndex = 6;
      this.label3.Text = "Symbol";
      this.cmbSymbol.FormattingEnabled = true;
      this.cmbSymbol.Location = new Point(170, 21);
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(172, 21);
      this.cmbSymbol.TabIndex = 8;
      this.cmbSymbol.SelectedIndexChanged += new EventHandler(this.cmbSymbol_SelectedIndexChanged);
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label4.Location = new Point(363, 7);
      this.label4.Name = "label4";
      this.label4.Size = new Size(50, 13);
      this.label4.TabIndex = 8;
      this.label4.Text = "Total Qty";
      this.label5.AutoSize = true;
      this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label5.Location = new Point(444, 7);
      this.label5.Name = "label5";
      this.label5.Size = new Size(31, 13);
      this.label5.TabIndex = 10;
      this.label5.Text = "Price";
      this.label6.AutoSize = true;
      this.label6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label6.Location = new Point(281, 52);
      this.label6.Name = "label6";
      this.label6.Size = new Size(40, 13);
      this.label6.TabIndex = 12;
      this.label6.Text = "Validity";
      this.CmbValidity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.CmbValidity.FormattingEnabled = true;
      this.CmbValidity.Items.AddRange(new object[3]
      {
        (object) "Day",
        (object) "CarryForward",
        (object) "GTC"
      });
      this.CmbValidity.Location = new Point(278, 67);
      this.CmbValidity.Name = "CmbValidity";
      this.CmbValidity.Size = new Size(92, 21);
      this.CmbValidity.TabIndex = 3;
      this.txtName.Location = new Point(124, 68);
      this.txtName.Name = "txtName";
      this.txtName.ReadOnly = true;
      this.txtName.Size = new Size(145, 20);
      this.txtName.TabIndex = 6;
      this.label7.AutoSize = true;
      this.label7.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label7.Location = new Point(382, 52);
      this.label7.Name = "label7";
      this.label7.Size = new Size(74, 13);
      this.label7.TabIndex = 14;
      this.label7.Text = "User Remarks";
      this.txtUserRemarks.Location = new Point(381, 68);
      this.txtUserRemarks.Name = "txtUserRemarks";
      this.txtUserRemarks.Size = new Size(143, 20);
      this.txtUserRemarks.TabIndex = 4;
      this.txtUserRemarks.Enter += new EventHandler(this.txtUserRemarks_Enter);
      this.btnSubmit.ForeColor = Color.Black;
      this.btnSubmit.Location = new Point(543, 65);
      this.btnSubmit.Name = "btnSubmit";
      this.btnSubmit.Size = new Size(66, 23);
      this.btnSubmit.TabIndex = 5;
      this.btnSubmit.Text = "Submit";
      this.btnSubmit.UseVisualStyleBackColor = true;
      this.btnSubmit.Click += new EventHandler(this.btnSubmit_Click);
      this.btnClear.DialogResult = DialogResult.Cancel;
      this.btnClear.ForeColor = Color.Black;
      this.btnClear.Location = new Point(628, 65);
      this.btnClear.Name = "btnClear";
      this.btnClear.Size = new Size(66, 23);
      this.btnClear.TabIndex = 6;
      this.btnClear.Text = "Clear";
      this.btnClear.UseVisualStyleBackColor = true;
      this.label8.AutoSize = true;
      this.label8.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label8.Location = new Point(12, 52);
      this.label8.Name = "label8";
      this.label8.Size = new Size(61, 13);
      this.label8.TabIndex = 19;
      this.label8.Text = "Client Code";
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(12, 67);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(104, 21);
      this.cmbClientcode.TabIndex = 2;
      this.cmbClientcode.SelectedIndexChanged += new EventHandler(this.cmbClientcode_SelectedIndexChanged);
      this.cmbClientcode.Leave += new EventHandler(this.cmbClientcode_Leave);
      this.numericUpDownPrice.DecimalPlaces = 2;
      this.numericUpDownPrice.Location = new Point(444, 21);
      this.numericUpDownPrice.Maximum = new Decimal(new int[4]
      {
        100000,
        0,
        0,
        0
      });
      this.numericUpDownPrice.Name = "numericUpDownPrice";
      this.numericUpDownPrice.Size = new Size(80, 20);
      this.numericUpDownPrice.TabIndex = 1;
      this.numericUpDownPrice.Enter += new EventHandler(this.numericUpDownPrice_Enter);
      this.txtQty.Location = new Point(364, 21);
      this.txtQty.Name = "txtQty";
      this.txtQty.Size = new Size(72, 20);
      this.txtQty.TabIndex = 0;
      this.txtQty.TextChanged += new EventHandler(this.txtQty_TextChanged);
      this.txtQty.Enter += new EventHandler(this.txtQty_Enter);
      this.txtQty.KeyUp += new KeyEventHandler(this.textBox1_KeyUp);
      this.AcceptButton = (IButtonControl) this.btnSubmit;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = Color.Blue;
      this.ClientSize = new Size(711, 124);
      this.Controls.Add((Control) this.txtQty);
      this.Controls.Add((Control) this.numericUpDownPrice);
      this.Controls.Add((Control) this.label8);
      this.Controls.Add((Control) this.cmbClientcode);
      this.Controls.Add((Control) this.btnClear);
      this.Controls.Add((Control) this.btnSubmit);
      this.Controls.Add((Control) this.txtUserRemarks);
      this.Controls.Add((Control) this.label7);
      this.Controls.Add((Control) this.txtName);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.CmbValidity);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.cmbSymbol);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.cmbOrdertype);
      this.Controls.Add((Control) this.cmbExch);
      this.Controls.Add((Control) this.statusStrip1);
      this.ForeColor = SystemColors.ButtonHighlight;
      this.FormBorderStyle = FormBorderStyle.Fixed3D;
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.Name = nameof (BuySellOrder);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Order Entry";
      this.Load += new EventHandler(this.BuySellOrder_Load);
      this.KeyUp += new KeyEventHandler(this.BuySellOrder_KeyUp);
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.numericUpDownPrice.EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
