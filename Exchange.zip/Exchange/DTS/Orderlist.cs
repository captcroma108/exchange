﻿// Decompiled with JetBrains decompiler
// Type: DTS.Orderlist
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class Orderlist : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public MWColumnProfile objColProfile;
    private DataGridView dgvOrdersList;
    private DataGridViewTextBoxColumn regulationcode;
    private DataGridViewTextBoxColumn Exchange;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn ProductType;
    private DataGridViewTextBoxColumn Buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Orderby;
    private DataGridViewTextBoxColumn Status;
    private DataGridViewTextBoxColumn UserRemarks;
    private DataGridViewTextBoxColumn LastModified;
    private DataGridViewTextBoxColumn colIp;

    public Orderlist(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      this._ColumnOnOff = new Dictionary<string, int>();
      string lstColumnProfile = Settings.Default.OrdLstColumnProfile;
      if (lstColumnProfile != string.Empty)
      {
        string str1 = lstColumnProfile;
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ '_' };
          string[] strArray = str2.Split(chArray2);
          int int32 = Convert.ToInt32(strArray[1]);
          switch (Convert.ToInt32(strArray[2]))
          {
            case 0:
              this.dgvOrdersList.Columns[int32].Visible = false;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 0);
                break;
              }
              break;
            case 1:
              this.dgvOrdersList.Columns[int32].Visible = true;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 1);
                break;
              }
              break;
          }
        }
      }
      else
      {
        for (int index = 0; index < this.dgvOrdersList.Columns.Count; ++index)
        {
          if (!this._ColumnOnOff.ContainsKey(this.dgvOrdersList.Columns[index].HeaderText))
          {
            if (this.dgvOrdersList.Columns[index].Visible)
              this._ColumnOnOff.Add(this.dgvOrdersList.Columns[index].HeaderText, 1);
            else
              this._ColumnOnOff.Add(this.dgvOrdersList.Columns[index].HeaderText, 0);
          }
        }
      }
      this.dgvOrdersList.Rows.Clear();
      SqlConnection conn = this.objmain.getConn();
      if (conn.State != ConnectionState.Open || (this.objmain.claccounts == null || !(this.objmain.claccounts != string.Empty)))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select Clientcode,Exch,Symbol,Productype,BuySell,Qty,Price,Validity,Traderid, (case OrdStatus WHEN 1 THEN 'EXECUTED' WHEN 2  THEN 'PENDING' WHEN 3 THEN 'CANCELLED' WHEN 4 THEN 'FORCE SQ-OFF' WHEN 5 THEN 'AUTO SQ-OFF' END) as OrdStatus,Userremarks,Lastmodified,Ipaddress  from Orders where Clientcode in (" + this.objmain.claccounts + ")", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            int index = this.dgvOrdersList.Rows.Add();
            this.dgvOrdersList.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(0);
            this.dgvOrdersList.Rows[index].Cells[1].Value = (object) Utils.GetExch(sqlDataReader.GetInt32(1));
            this.dgvOrdersList.Rows[index].Cells[2].Value = (object) sqlDataReader.GetString(2);
            this.dgvOrdersList.Rows[index].Cells[3].Value = (object) Utils.GetProductType(sqlDataReader.GetInt32(3));
            this.dgvOrdersList.Rows[index].Cells[4].Value = (object) Utils.GetBuysell(sqlDataReader.GetInt32(4));
            this.dgvOrdersList.Rows[index].Cells[5].Value = (object) sqlDataReader.GetInt32(5);
            this.dgvOrdersList.Rows[index].Cells[6].Value = sqlDataReader.GetValue(6);
            this.dgvOrdersList.Rows[index].Cells[7].Value = (object) Utils.GetValidity(sqlDataReader.GetInt32(7));
            if (!sqlDataReader.IsDBNull(8))
              this.dgvOrdersList.Rows[index].Cells[8].Value = (object) sqlDataReader.GetString(8);
            this.dgvOrdersList.Rows[index].Cells[9].Value = (object) sqlDataReader.GetString(9);
            if (!sqlDataReader.IsDBNull(10))
              this.dgvOrdersList.Rows[index].Cells[10].Value = (object) sqlDataReader.GetString(10);
            this.dgvOrdersList.Rows[index].Cells[11].Value = (object) Convert.ToDateTime(sqlDataReader.GetValue(11)).ToString("hh:mm:ss");
            this.dgvOrdersList.Rows[index].Cells[12].Value = !sqlDataReader.IsDBNull(12) ? (object) sqlDataReader.GetString(12).Trim() : (object) string.Empty;
            if (sqlDataReader.GetInt32(4) == 1)
              this.dgvOrdersList.Rows[index].DefaultCellStyle.BackColor = Color.LightBlue;
            else
              this.dgvOrdersList.Rows[index].DefaultCellStyle.BackColor = Color.Pink;
          }
        }
      }
    }

    private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Column Profile", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Save Column Profile", (Image) null, new EventHandler(this.Task2_Click));
      contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task7_Click));
      contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task8_Click));
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task9_Click));
      Point client = this.dgvOrdersList.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvOrdersList, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.objColProfile == null || this.objColProfile.IsDisposed)
      {
        MWColumnProfile mwColumnProfile = new MWColumnProfile(this.objmain, 3);
        mwColumnProfile.MdiParent = (Form) this.objmain;
        this.objColProfile = mwColumnProfile;
        this.objColProfile.Show();
      }
      else
      {
        this.objColProfile.MdiParent = (Form) this.objmain;
        this.objColProfile.Activate();
        this.objColProfile.Show();
      }
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvOrdersList.Columns.Count; ++index)
        str = !this.dgvOrdersList.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvOrdersList.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvOrdersList.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.OrdLstColumnProfile = str;
      Settings.Default.Save();
    }

    private void Task3_Click(object sender, EventArgs e)
    {
    }

    private void Task7_Click(object sender, EventArgs e)
    {
      this.dgvOrdersList.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task8_Click(object sender, EventArgs e)
    {
      this.dgvOrdersList.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task9_Click(object sender, EventArgs e)
    {
      if (this.dgvOrdersList.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvOrdersList, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvOrdersList = new DataGridView();
      this.regulationcode = new DataGridViewTextBoxColumn();
      this.Exchange = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.ProductType = new DataGridViewTextBoxColumn();
      this.Buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Orderby = new DataGridViewTextBoxColumn();
      this.Status = new DataGridViewTextBoxColumn();
      this.UserRemarks = new DataGridViewTextBoxColumn();
      this.LastModified = new DataGridViewTextBoxColumn();
      this.colIp = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvOrdersList).BeginInit();
      this.SuspendLayout();
      this.dgvOrdersList.AllowUserToAddRows = false;
      this.dgvOrdersList.AllowUserToDeleteRows = false;
      this.dgvOrdersList.AllowUserToOrderColumns = true;
      this.dgvOrdersList.BackgroundColor = Color.White;
      this.dgvOrdersList.CellBorderStyle = DataGridViewCellBorderStyle.None;
      this.dgvOrdersList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvOrdersList.Columns.AddRange((DataGridViewColumn) this.regulationcode, (DataGridViewColumn) this.Exchange, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.ProductType, (DataGridViewColumn) this.Buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Orderby, (DataGridViewColumn) this.Status, (DataGridViewColumn) this.UserRemarks, (DataGridViewColumn) this.LastModified, (DataGridViewColumn) this.colIp);
      this.dgvOrdersList.Dock = DockStyle.Fill;
      this.dgvOrdersList.Location = new Point(0, 0);
      this.dgvOrdersList.Name = "dgvOrdersList";
      this.dgvOrdersList.ReadOnly = true;
      this.dgvOrdersList.RowHeadersVisible = false;
      this.dgvOrdersList.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvOrdersList.Size = new Size(945, 290);
      this.dgvOrdersList.TabIndex = 0;
      this.dgvOrdersList.MouseClick += new MouseEventHandler(this.dataGridView1_MouseClick);
      this.regulationcode.HeaderText = "ClientCode";
      this.regulationcode.Name = "regulationcode";
      this.regulationcode.ReadOnly = true;
      this.Exchange.HeaderText = "Exchange";
      this.Exchange.Name = "Exchange";
      this.Exchange.ReadOnly = true;
      this.Exchange.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.ProductType.HeaderText = "ProductType";
      this.ProductType.Name = "ProductType";
      this.ProductType.ReadOnly = true;
      this.ProductType.Width = 60;
      this.Buysell.HeaderText = "B/S";
      this.Buysell.Name = "Buysell";
      this.Buysell.ReadOnly = true;
      this.Buysell.Width = 60;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 60;
      this.Price.HeaderText = "Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 60;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 70;
      this.Orderby.HeaderText = "Orderedby";
      this.Orderby.Name = "Orderby";
      this.Orderby.ReadOnly = true;
      this.Status.HeaderText = "Status";
      this.Status.Name = "Status";
      this.Status.ReadOnly = true;
      this.Status.Width = 70;
      this.UserRemarks.HeaderText = "UserRemarks";
      this.UserRemarks.Name = "UserRemarks";
      this.UserRemarks.ReadOnly = true;
      this.LastModified.HeaderText = "LastModified";
      this.LastModified.Name = "LastModified";
      this.LastModified.ReadOnly = true;
      this.LastModified.Width = 60;
      this.colIp.HeaderText = "IpAddress";
      this.colIp.Name = "colIp";
      this.colIp.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvOrdersList);
      this.Name = nameof (Orderlist);
      this.Text = "Orders Lists";
      ((ISupportInitialize) this.dgvOrdersList).EndInit();
      this.ResumeLayout(false);
    }
  }
}
