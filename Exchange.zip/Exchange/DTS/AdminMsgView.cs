﻿// Decompiled with JetBrains decompiler
// Type: DTS.AdminMsgView
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class AdminMsgView : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    private DataGridView dgvAdminMsg;
    private DataGridViewTextBoxColumn Adminmsg;
    private DataGridViewTextBoxColumn DatTime;

    public AdminMsgView(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    public void LoadAdminMsgs()
    {
      this.dgvAdminMsg.Rows.Clear();
      int index = 0;
      if (this.conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Select TextMsg,Timestamp from MessageBoard where ClientCode = '{0}' and Timestamp > '{1}'", (object) this.objmain.objinfo.clientcode, (object) DateTime.Now.ToString("yyyy-MM-dd 00:00:00")), this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            this.dgvAdminMsg.Rows.Add();
            if (!sqlDataReader.IsDBNull(0))
              this.dgvAdminMsg.Rows[index].Cells[0].Value = sqlDataReader.GetValue(0);
            if (!sqlDataReader.IsDBNull(1))
            {
              DateTime dateTime = Convert.ToDateTime(sqlDataReader.GetValue(1));
              this.dgvAdminMsg.Rows[index].Cells[1].Value = (object) string.Format("{0}:{1}:{2}", (object) dateTime.Hour, (object) dateTime.Minute, (object) dateTime.Second);
            }
            ++index;
          }
        }
      }
    }

    private void dgvAdminMsg_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task1_Click));
      Point client = this.dgvAdminMsg.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvAdminMsg, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.dgvAdminMsg.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvAdminMsg, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvAdminMsg = new DataGridView();
      this.Adminmsg = new DataGridViewTextBoxColumn();
      this.DatTime = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvAdminMsg).BeginInit();
      this.SuspendLayout();
      this.dgvAdminMsg.AllowUserToAddRows = false;
      this.dgvAdminMsg.AllowUserToDeleteRows = false;
      this.dgvAdminMsg.AllowUserToOrderColumns = true;
      this.dgvAdminMsg.BackgroundColor = Color.White;
      this.dgvAdminMsg.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
      this.dgvAdminMsg.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvAdminMsg.Columns.AddRange((DataGridViewColumn) this.Adminmsg, (DataGridViewColumn) this.DatTime);
      this.dgvAdminMsg.Dock = DockStyle.Fill;
      this.dgvAdminMsg.Location = new Point(0, 0);
      this.dgvAdminMsg.Name = "dgvAdminMsg";
      this.dgvAdminMsg.ReadOnly = true;
      this.dgvAdminMsg.RowHeadersVisible = false;
      this.dgvAdminMsg.Size = new Size(448, 266);
      this.dgvAdminMsg.TabIndex = 0;
      this.dgvAdminMsg.MouseClick += new MouseEventHandler(this.dgvAdminMsg_MouseClick);
      this.Adminmsg.HeaderText = "Admin Message";
      this.Adminmsg.Name = "Adminmsg";
      this.Adminmsg.ReadOnly = true;
      this.Adminmsg.Width = 350;
      this.DatTime.HeaderText = "Time";
      this.DatTime.Name = "DatTime";
      this.DatTime.ReadOnly = true;
      this.DatTime.Width = 70;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(448, 266);
      this.Controls.Add((Control) this.dgvAdminMsg);
      this.MaximizeBox = false;
      this.Name = nameof (AdminMsgView);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Admin Messages";
      ((ISupportInitialize) this.dgvAdminMsg).EndInit();
      this.ResumeLayout(false);
    }
  }
}
