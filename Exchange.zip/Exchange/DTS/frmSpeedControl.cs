﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmSpeedControl
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmSpeedControl : Form
  {
    private IContainer components = (IContainer) null;
    private Label label1;
    private TrackBar trackBar1;

    public frmSpeedControl()
    {
      this.InitializeComponent();
    }

    private void trackBar1_ValueChanged(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.trackBar1 = new TrackBar();
      this.trackBar1.BeginInit();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(21, 9);
      this.label1.Name = "label1";
      this.label1.Size = new Size(76, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Manage Delay";
      this.trackBar1.Location = new Point(32, 25);
      this.trackBar1.Maximum = 100;
      this.trackBar1.Name = "trackBar1";
      this.trackBar1.Size = new Size(290, 45);
      this.trackBar1.SmallChange = 5;
      this.trackBar1.TabIndex = 1;
      this.trackBar1.TickFrequency = 5;
      this.trackBar1.ValueChanged += new EventHandler(this.trackBar1_ValueChanged);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(354, 69);
      this.Controls.Add((Control) this.trackBar1);
      this.Controls.Add((Control) this.label1);
      this.MaximizeBox = false;
      this.Name = nameof (frmSpeedControl);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Speed Control";
      this.trackBar1.EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
