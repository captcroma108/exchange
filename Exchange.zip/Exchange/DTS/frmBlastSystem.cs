﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmBlastSystem
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmBlastSystem : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private Label label1;
    private Label label2;
    private TextBox textBox1;
    private Button btnBlast;

    public frmBlastSystem(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    private void btnBlast_Click(object sender, EventArgs e)
    {
      if (MessageBox.Show("Do You really want to Blast System.", "Blast System", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
        return;
      if (this.textBox1.Text == string.Empty)
        this.objdash.DisplayMessage("Enter password.", 2);
      else if (this.textBox1.Text != Dashboard.Decryptdata(this.objdash.objinfo.BlastPassword))
      {
        this.objdash.DisplayMessage("Incorrect password.", 2);
      }
      else
      {
        SqlConnection conn = this.objdash.getConn();
        if (conn.State == ConnectionState.Open)
        {
          SqlCommand sqlCommand1 = new SqlCommand("FlushData", conn);
          sqlCommand1.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand2 = sqlCommand1)
          {
            try
            {
              sqlCommand2.ExecuteNonQuery();
              this.objdash.DisplayMessage("System Blast successfull!!", 1);
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to Blast System", 3);
            }
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.label2 = new Label();
      this.textBox1 = new TextBox();
      this.btnBlast = new Button();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(5, 9);
      this.label1.Name = "label1";
      this.label1.Size = new Size(373, 30);
      this.label1.TabIndex = 0;
      this.label1.Text = "This will flush all your data and wont be recoverable, \r\nso please make sure that you really want to Blast System.";
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(93, 72);
      this.label2.Name = "label2";
      this.label2.Size = new Size(71, 16);
      this.label2.TabIndex = 1;
      this.label2.Text = "Password:";
      this.textBox1.Location = new Point(170, 71);
      this.textBox1.Name = "textBox1";
      this.textBox1.Size = new Size(119, 20);
      this.textBox1.TabIndex = 2;
      this.btnBlast.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnBlast.Location = new Point(132, 118);
      this.btnBlast.Name = "btnBlast";
      this.btnBlast.Size = new Size(119, 23);
      this.btnBlast.TabIndex = 3;
      this.btnBlast.Text = "Blast System";
      this.btnBlast.UseVisualStyleBackColor = true;
      this.btnBlast.Click += new EventHandler(this.btnBlast_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(383, 153);
      this.Controls.Add((Control) this.btnBlast);
      this.Controls.Add((Control) this.textBox1);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label1);
      this.MaximizeBox = false;
      this.Name = nameof (frmBlastSystem);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Blast System";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
