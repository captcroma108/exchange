﻿// Decompiled with JetBrains decompiler
// Type: DTS.FXsettings
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

namespace DTS
{
  public class FXsettings
  {
    public string clientcode { get; set; }

    public string symbol { get; set; }

    public string leverage { get; set; }

    public int spread { get; set; }

    public double minLots { get; set; }

    public double maxLots { get; set; }
  }
}
