﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmRMS_DAwise
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmRMS_DAwise : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public int sortcolumn;
    public string sortorder;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripButton btnSearch;
    private DataGridView dgvRMSClientwise;
    private TableLayoutPanel tableLayoutPanel1;
    private Label lblNetMTMPL;
    private Label label1;
    private Label label4;
    private Label lblSANetMTM;
    private DataGridViewTextBoxColumn RegulationCode;
    private DataGridViewTextBoxColumn ColName;
    private DataGridViewTextBoxColumn NetPL;
    private DataGridViewTextBoxColumn Commission;
    private DataGridViewTextBoxColumn colDAPfls;
    private DataGridViewTextBoxColumn colSAPFLS;

    public frmRMS_DAwise(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.sortcolumn = 0;
      this.sortorder = string.Empty;
      this.Icon = this.objmain.ico;
    }

    public void LoadRMS()
    {
      this.cmbclientcode.Items.Clear();
      this.cmbclientcode.Items.Add((object) "");
      this.dgvRMSClientwise.Rows.Clear();
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>();
      Dictionary<string, buysellnetpospfls> dawiseProfitLoss = this.objmain._DAwiseProfitLoss;
      double num1 = 0.0;
      double num2 = 0.0;
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dawiseProfitLoss)
      {
        string key = keyValuePair.Key;
        buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
        int index = this.dgvRMSClientwise.Rows.Add();
        this.dgvRMSClientwise.Rows[index].Cells[0].Value = (object) key;
        Userinfo userinfo = this.objmain.GetUserinfo(key);
        this.dgvRMSClientwise.Rows[index].Cells[1].Value = (object) userinfo.name;
        double num3 = Convert.ToDouble(buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l);
        this.dgvRMSClientwise.Rows[index].Cells[2].Value = (object) num3;
        this.dgvRMSClientwise.Rows[index].Cells[3].Value = (object) buysellnetpospfls.Commision;
        double num4 = Math.Round(num3 * (double) userinfo.DApflsPercent / 100.0, 2);
        this.dgvRMSClientwise.Rows[index].Cells[4].Value = (object) num4;
        double num5 = num3 - num4;
        this.dgvRMSClientwise.Rows[index].Cells[5].Value = (object) num5;
        num1 += num3;
        num2 += num5;
      }
      this.lblNetMTMPL.Text = num1.ToString();
      this.lblSANetMTM.Text = num2.ToString();
      new Thread((ThreadStart) (() => this.UpdateRMS())).Start();
    }

    private void UpdateRMS()
    {
      if (this.dgvRMSClientwise.Rows.Count <= 0)
        return;
      try
      {
        while (true)
        {
          Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>();
          Dictionary<string, buysellnetpospfls> dawiseProfitLoss = this.objmain._DAwiseProfitLoss;
          double NETPfls = 0.0;
          double SANetPfls = 0.0;
          for (int index1 = 0; index1 < this.dgvRMSClientwise.Rows.Count; ++index1)
          {
            string index2 = this.dgvRMSClientwise.Rows[index1].Cells[0].Value.ToString();
            if (dawiseProfitLoss.ContainsKey(index2))
            {
              buysellnetpospfls buysellnetpospfls = dawiseProfitLoss[index2];
              double num1 = Convert.ToDouble(buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l);
              this.dgvRMSClientwise.Rows[index1].Cells[2].Value = (object) num1;
              this.dgvRMSClientwise.Rows[index1].Cells[3].Value = (object) buysellnetpospfls.Commision;
              Userinfo userinfo = this.objmain.GetUserinfo(index2);
              double num2 = Math.Round(num1 * (double) userinfo.DApflsPercent / 100.0, 2);
              this.dgvRMSClientwise.Rows[index1].Cells[4].Value = (object) num2;
              double num3 = num1 - num2;
              this.dgvRMSClientwise.Rows[index1].Cells[5].Value = (object) num3;
              NETPfls += num1;
              SANetPfls += num3;
            }
          }
          if (!this.IsDisposed)
            this.Invoke((Delegate) (() =>
            {
              this.lblNetMTMPL.Text = NETPfls.ToString();
              this.lblSANetMTM.Text = SANetPfls.ToString();
            }));
          Thread.Sleep(3000);
        }
      }
      catch
      {
      }
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvRMSClientwise.Rows)
          row.Visible = true;
      }
      else
      {
        if (!(this.cmbclientcode.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvRMSClientwise.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (frmRMS_DAwise));
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      this.dgvRMSClientwise = new DataGridView();
      this.tableLayoutPanel1 = new TableLayoutPanel();
      this.lblNetMTMPL = new Label();
      this.label4 = new Label();
      this.lblSANetMTM = new Label();
      this.label1 = new Label();
      this.RegulationCode = new DataGridViewTextBoxColumn();
      this.ColName = new DataGridViewTextBoxColumn();
      this.NetPL = new DataGridViewTextBoxColumn();
      this.Commission = new DataGridViewTextBoxColumn();
      this.colDAPfls = new DataGridViewTextBoxColumn();
      this.colSAPFLS = new DataGridViewTextBoxColumn();
      this.toolStrip1.SuspendLayout();
      ((ISupportInitialize) this.dgvRMSClientwise).BeginInit();
      this.tableLayoutPanel1.SuspendLayout();
      this.SuspendLayout();
      this.toolStrip1.Items.AddRange(new ToolStripItem[3]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(945, 25);
      this.toolStrip1.TabIndex = 4;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.cmbclientcode.Sorted = true;
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.dgvRMSClientwise.AllowUserToAddRows = false;
      this.dgvRMSClientwise.AllowUserToDeleteRows = false;
      this.dgvRMSClientwise.AllowUserToOrderColumns = true;
      this.dgvRMSClientwise.AllowUserToResizeRows = false;
      this.dgvRMSClientwise.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvRMSClientwise.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvRMSClientwise.BackgroundColor = Color.White;
      this.dgvRMSClientwise.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvRMSClientwise.Columns.AddRange((DataGridViewColumn) this.RegulationCode, (DataGridViewColumn) this.ColName, (DataGridViewColumn) this.NetPL, (DataGridViewColumn) this.Commission, (DataGridViewColumn) this.colDAPfls, (DataGridViewColumn) this.colSAPFLS);
      this.dgvRMSClientwise.Location = new Point(0, 28);
      this.dgvRMSClientwise.Name = "dgvRMSClientwise";
      this.dgvRMSClientwise.ReadOnly = true;
      this.dgvRMSClientwise.RowHeadersVisible = false;
      this.dgvRMSClientwise.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvRMSClientwise.Size = new Size(945, 237);
      this.dgvRMSClientwise.TabIndex = 5;
      this.tableLayoutPanel1.ColumnCount = 8;
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10.47619f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10.79365f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16.19048f));
      this.tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 12.5f));
      this.tableLayoutPanel1.Controls.Add((Control) this.lblNetMTMPL, 3, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.label4, 6, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.lblSANetMTM, 7, 0);
      this.tableLayoutPanel1.Controls.Add((Control) this.label1, 2, 0);
      this.tableLayoutPanel1.Dock = DockStyle.Bottom;
      this.tableLayoutPanel1.Location = new Point(0, 268);
      this.tableLayoutPanel1.Name = "tableLayoutPanel1";
      this.tableLayoutPanel1.RowCount = 1;
      this.tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
      this.tableLayoutPanel1.Size = new Size(945, 22);
      this.tableLayoutPanel1.TabIndex = 6;
      this.lblNetMTMPL.AutoSize = true;
      this.lblNetMTMPL.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblNetMTMPL.Location = new Point(357, 0);
      this.lblNetMTMPL.Name = "lblNetMTMPL";
      this.lblNetMTMPL.Size = new Size(0, 15);
      this.lblNetMTMPL.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label4.Location = new Point(676, 0);
      this.label4.Name = "label4";
      this.label4.Size = new Size(115, 15);
      this.label4.TabIndex = 6;
      this.label4.Text = "SA Net MTM P/L:";
      this.lblSANetMTM.AutoSize = true;
      this.lblSANetMTM.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lblSANetMTM.Location = new Point(829, 0);
      this.lblSANetMTM.Name = "lblSANetMTM";
      this.lblSANetMTM.Size = new Size(0, 15);
      this.lblSANetMTM.TabIndex = 7;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(239, 0);
      this.label1.Name = "label1";
      this.label1.Size = new Size(104, 15);
      this.label1.TabIndex = 0;
      this.label1.Text = "Total MTM P/L:";
      this.RegulationCode.HeaderText = "DealerAdminCode";
      this.RegulationCode.Name = "RegulationCode";
      this.RegulationCode.ReadOnly = true;
      this.ColName.HeaderText = "Name";
      this.ColName.Name = "ColName";
      this.ColName.ReadOnly = true;
      this.NetPL.HeaderText = "NetMTMP/L";
      this.NetPL.Name = "NetPL";
      this.NetPL.ReadOnly = true;
      this.NetPL.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.Commission.HeaderText = "Brokerage";
      this.Commission.Name = "Commission";
      this.Commission.ReadOnly = true;
      this.Commission.SortMode = DataGridViewColumnSortMode.Programmatic;
      this.colDAPfls.HeaderText = "DA_Profit_Loss";
      this.colDAPfls.Name = "colDAPfls";
      this.colDAPfls.ReadOnly = true;
      this.colSAPFLS.HeaderText = "SA_Profit_Loss";
      this.colSAPFLS.Name = "colSAPFLS";
      this.colSAPFLS.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.tableLayoutPanel1);
      this.Controls.Add((Control) this.dgvRMSClientwise);
      this.Controls.Add((Control) this.toolStrip1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (frmRMS_DAwise);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "RMS";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((ISupportInitialize) this.dgvRMSClientwise).EndInit();
      this.tableLayoutPanel1.ResumeLayout(false);
      this.tableLayoutPanel1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
