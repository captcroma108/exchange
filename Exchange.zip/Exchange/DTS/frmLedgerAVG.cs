﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmLedgerAVG
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmLedgerAVG : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private ComboBox cmbClientcode;
    private Label label3;
    private GroupBox groupBox1;
    private DateTimePicker Todate;
    private DateTimePicker Fromdate;
    private Label label2;
    private Label label1;
    private Button btnView;
    private Button btnExport;
    private DataGridView dgvledger;
    private DataGridViewTextBoxColumn col1;
    private DataGridViewTextBoxColumn col2;
    private DataGridViewTextBoxColumn col3;
    private DataGridViewTextBoxColumn col5;
    private DataGridViewTextBoxColumn col6;
    private DataGridViewTextBoxColumn Column1;
    private DataGridViewTextBoxColumn col9;
    private DataGridViewTextBoxColumn col10;
    private DataGridViewTextBoxColumn dpwd;
    private DataGridViewTextBoxColumn col12;
    private DataGridViewTextBoxColumn col11;
    private DataGridViewTextBoxColumn col13;

    public frmLedgerAVG(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void Loadwindow()
    {
      if (this.objdash.objinfo.usertype == 3)
      {
        this.label3.Visible = true;
        this.cmbClientcode.Items.Clear();
        foreach (object lstAccount in this.objdash._lstAccounts)
          this.cmbClientcode.Items.Add(lstAccount);
        if (this.cmbClientcode.Items.Count > 0)
          this.cmbClientcode.SelectedIndex = 0;
        this.cmbClientcode.Visible = true;
      }
      else
      {
        this.label3.Visible = false;
        this.cmbClientcode.Visible = false;
      }
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      this.dgvledger.Rows.Clear();
      string str1 = this.cmbClientcode.Text;
      if (this.objdash.objinfo.usertype == 4)
        str1 = this.objdash.objinfo.clientcode;
      DateTime serverTime = this.objdash.GetServerTime();
      if (str1.Length <= 0)
        return;
      DateTime dateTime = this.Fromdate.Value;
      string fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
      dateTime = this.Fromdate.Value;
      switch (dateTime.DayOfWeek)
      {
        case DayOfWeek.Sunday:
          dateTime = this.Fromdate.Value;
          dateTime = dateTime.AddDays(-1.0);
          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
          break;
        case DayOfWeek.Monday:
          dateTime = this.Fromdate.Value;
          dateTime = dateTime.AddDays(-2.0);
          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
          break;
      }
      dateTime = this.Fromdate.Value;
      string startdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
      dateTime = this.Todate.Value;
      string str2 = dateTime.ToString("yyyy-MM-dd 23:59:00");
      dateTime = this.Fromdate.Value;
      dateTime.ToString("yyyy-MM-dd 23:59:00");
      Dictionary<string, LedgerAVG> dictionary = new Dictionary<string, LedgerAVG>();
      TimeSpan timeSpan = serverTime - this.Fromdate.Value;
      Dictionary<string, LedgerAVG> ledgerAvg = this.objdash.GetLedgerAVG(str1, startdate, str2);
      SortedDictionary<DateTime, payinoutDetails> payinPayout = this.objdash.GetPayinPayout(str1, fromdate, str2);
      Decimal begningBal = this.objdash.GetBegningBal(str1, this.Fromdate.Value, str2);
      this.DisplayLedgerAVG(ledgerAvg, begningBal, payinPayout, str1);
    }

    private void btnExport_Click(object sender, EventArgs e)
    {
      if (this.dgvledger.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvledger, false);
    }

    private void AddLedgerColsAVG()
    {
      this.dgvledger.DataSource = (object) null;
      this.dgvledger.Columns.Clear();
      this.dgvledger.Rows.Clear();
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Closed Date/Time";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Type";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Symbol";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "BUY QTY";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn6.HeaderText = "SELL QTY";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn6);
      DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn7.HeaderText = "Open/SL";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn7);
      DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn8.HeaderText = "Close/TP";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn8);
      DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn9.HeaderText = "DP/WD";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn9);
      DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn10.HeaderText = "Profit/Desc";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn10);
      DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn11.HeaderText = "Comm";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn11);
      DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn12.HeaderText = "Net Profit";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn12);
    }

    private void DisplayLedgerAVG(
      Dictionary<string, LedgerAVG> _Ledgervalues,
      Decimal begbal,
      SortedDictionary<DateTime, payinoutDetails> _PayinOutDetails,
      string codee)
    {
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      double num4 = 0.0;
      if (_Ledgervalues.Count <= 0)
        return;
      this.AddLedgerColsAVG();
      int index1 = 0;
      foreach (KeyValuePair<string, LedgerAVG> ledgervalue in _Ledgervalues)
      {
        LedgerAVG ledgerAvg = ledgervalue.Value;
        this.dgvledger.Rows.Add();
        this.dgvledger.Rows[index1].Cells[0].Value = (object) ledgerAvg.accountno;
        this.dgvledger.Rows[index1].Cells[1].Value = (object) ledgerAvg.CloseTime.ToString("dd/MM/yyyy 23:55:00");
        this.dgvledger.Rows[index1].Cells[2].Value = (object) "L";
        this.dgvledger.Rows[index1].Cells[3].Value = (object) ledgerAvg.symbol;
        this.dgvledger.Rows[index1].Cells[4].Value = (object) ledgerAvg.buyqty;
        this.dgvledger.Rows[index1].Cells[5].Value = (object) ledgerAvg.sellqty;
        this.dgvledger.Rows[index1].Cells[6].Value = (object) ledgerAvg.buyprice;
        this.dgvledger.Rows[index1].Cells[7].Value = (object) ledgerAvg.sellprice;
        this.dgvledger.Rows[index1].Cells[10].Value = (object) ledgerAvg.comm;
        this.dgvledger.Rows[index1].Cells[9].Value = (object) ledgerAvg.RealisedPL;
        this.dgvledger.Rows[index1].Cells[11].Value = (object) ledgerAvg.NettPl;
        num1 += ledgerAvg.comm;
        num2 += Convert.ToDecimal(ledgerAvg.RealisedPL);
        num3 += ledgerAvg.NettPl;
        ++index1;
      }
      foreach (KeyValuePair<DateTime, payinoutDetails> payinOutDetail in _PayinOutDetails)
      {
        int index2 = this.dgvledger.Rows.Add();
        this.dgvledger.Rows[index2].Cells[0].Value = (object) codee;
        this.dgvledger.Rows[index2].Cells[1].Value = (object) payinOutDetail.Key.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvledger.Rows[index2].Cells[3].Value = (object) payinOutDetail.Value.comments;
        if (payinOutDetail.Value.payinout.ToUpper() == "PAYIN")
        {
          this.dgvledger.Rows[index2].Cells[2].Value = (object) "DP";
          this.dgvledger.Rows[index2].Cells[8].Value = (object) payinOutDetail.Value.amount;
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 += payinOutDetail.Value.amount;
        }
        else if (payinOutDetail.Value.payinout.ToUpper() == "PAYOUT")
        {
          this.dgvledger.Rows[index2].Cells[2].Value = (object) "WD";
          this.dgvledger.Rows[index2].Cells[8].Value = (object) (payinOutDetail.Value.amount * -1.0);
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 -= payinOutDetail.Value.amount;
        }
        ++index1;
      }
      this.dgvledger.Sort(this.dgvledger.Columns[1], ListSortDirection.Ascending);
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index1].Cells[7].Value = (object) "Totals:";
      this.dgvledger.Rows[index1].Cells[8].Value = (object) num4;
      this.dgvledger.Rows[index1].Cells[10].Value = (object) (num1 * Decimal.MinusOne);
      this.dgvledger.Rows[index1].Cells[9].Value = (object) num2;
      this.dgvledger.Rows[index1].Cells[11].Value = (object) num3;
      int index3 = index1 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index3].Cells[0].Value = (object) "Account Summary";
      int index4 = index3 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index4].Cells[0].Value = (object) "Beg.Balance";
      this.dgvledger.Rows[index4].Cells[1].Value = (object) begbal;
      int index5 = index4 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index5].Cells[0].Value = (object) "Margin In/Out";
      this.dgvledger.Rows[index5].Cells[1].Value = (object) num4;
      int index6 = index5 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index6].Cells[0].Value = (object) "Trading Profit/Loss";
      this.dgvledger.Rows[index6].Cells[1].Value = (object) num2;
      int index7 = index6 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index7].Cells[0].Value = (object) "Commissions";
      this.dgvledger.Rows[index7].Cells[1].Value = (object) (num1 * Decimal.MinusOne);
      int index8 = index7 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index8].Cells[0].Value = (object) "Net Trading Profit/Loss";
      this.dgvledger.Rows[index8].Cells[1].Value = (object) num3;
      int index9 = index8 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index9].Cells[0].Value = (object) "Balance";
      this.dgvledger.Rows[index9].Cells[1].Value = (object) (begbal + num3 + Convert.ToDecimal(num4));
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.cmbClientcode = new ComboBox();
      this.label3 = new Label();
      this.groupBox1 = new GroupBox();
      this.Todate = new DateTimePicker();
      this.Fromdate = new DateTimePicker();
      this.label2 = new Label();
      this.label1 = new Label();
      this.btnView = new Button();
      this.btnExport = new Button();
      this.dgvledger = new DataGridView();
      this.col1 = new DataGridViewTextBoxColumn();
      this.col2 = new DataGridViewTextBoxColumn();
      this.col3 = new DataGridViewTextBoxColumn();
      this.col5 = new DataGridViewTextBoxColumn();
      this.col6 = new DataGridViewTextBoxColumn();
      this.Column1 = new DataGridViewTextBoxColumn();
      this.col9 = new DataGridViewTextBoxColumn();
      this.col10 = new DataGridViewTextBoxColumn();
      this.dpwd = new DataGridViewTextBoxColumn();
      this.col12 = new DataGridViewTextBoxColumn();
      this.col11 = new DataGridViewTextBoxColumn();
      this.col13 = new DataGridViewTextBoxColumn();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgvledger).BeginInit();
      this.SuspendLayout();
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(205, 39);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(89, 21);
      this.cmbClientcode.Sorted = true;
      this.cmbClientcode.TabIndex = 69;
      this.cmbClientcode.Visible = false;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(204, 21);
      this.label3.Name = "label3";
      this.label3.Size = new Size(64, 13);
      this.label3.TabIndex = 68;
      this.label3.Text = "Client Code ";
      this.label3.Visible = false;
      this.groupBox1.Controls.Add((Control) this.Todate);
      this.groupBox1.Controls.Add((Control) this.Fromdate);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(12, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(184, 77);
      this.groupBox1.TabIndex = 67;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Date";
      this.Todate.CustomFormat = "dd-MMM-yyyy";
      this.Todate.Format = DateTimePickerFormat.Custom;
      this.Todate.Location = new Point(66, 45);
      this.Todate.Name = "Todate";
      this.Todate.Size = new Size(110, 20);
      this.Todate.TabIndex = 3;
      this.Fromdate.CustomFormat = "dd-MMM-yyyy";
      this.Fromdate.Format = DateTimePickerFormat.Custom;
      this.Fromdate.Location = new Point(66, 19);
      this.Fromdate.Name = "Fromdate";
      this.Fromdate.Size = new Size(110, 20);
      this.Fromdate.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(4, 48);
      this.label2.Name = "label2";
      this.label2.Size = new Size(49, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "To Date:";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(4, 23);
      this.label1.Name = "label1";
      this.label1.Size = new Size(59, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "From Date:";
      this.btnView.FlatStyle = FlatStyle.System;
      this.btnView.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnView.ForeColor = Color.Navy;
      this.btnView.Location = new Point(641, 51);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(109, 34);
      this.btnView.TabIndex = 71;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.btnExport.FlatStyle = FlatStyle.System;
      this.btnExport.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnExport.ForeColor = Color.Navy;
      this.btnExport.Location = new Point(826, 51);
      this.btnExport.Name = "btnExport";
      this.btnExport.Size = new Size(109, 34);
      this.btnExport.TabIndex = 70;
      this.btnExport.Text = "Export";
      this.btnExport.UseVisualStyleBackColor = true;
      this.btnExport.Click += new EventHandler(this.btnExport_Click);
      this.dgvledger.AllowUserToAddRows = false;
      this.dgvledger.AllowUserToDeleteRows = false;
      this.dgvledger.AllowUserToOrderColumns = true;
      this.dgvledger.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvledger.Columns.AddRange((DataGridViewColumn) this.col1, (DataGridViewColumn) this.col2, (DataGridViewColumn) this.col3, (DataGridViewColumn) this.col5, (DataGridViewColumn) this.col6, (DataGridViewColumn) this.Column1, (DataGridViewColumn) this.col9, (DataGridViewColumn) this.col10, (DataGridViewColumn) this.dpwd, (DataGridViewColumn) this.col12, (DataGridViewColumn) this.col11, (DataGridViewColumn) this.col13);
      this.dgvledger.Dock = DockStyle.Bottom;
      this.dgvledger.Location = new Point(0, 96);
      this.dgvledger.Name = "dgvledger";
      this.dgvledger.ReadOnly = true;
      this.dgvledger.RowHeadersVisible = false;
      this.dgvledger.Size = new Size(945, 390);
      this.dgvledger.TabIndex = 72;
      this.col1.HeaderText = "ClientCode";
      this.col1.Name = "col1";
      this.col1.ReadOnly = true;
      this.col2.HeaderText = "Closed Date/Time";
      this.col2.Name = "col2";
      this.col2.ReadOnly = true;
      this.col3.HeaderText = "Type";
      this.col3.Name = "col3";
      this.col3.ReadOnly = true;
      this.col5.HeaderText = "Symbol";
      this.col5.Name = "col5";
      this.col5.ReadOnly = true;
      this.col6.HeaderText = "Buy Qty";
      this.col6.Name = "col6";
      this.col6.ReadOnly = true;
      this.Column1.HeaderText = "Sell Qty";
      this.Column1.Name = "Column1";
      this.Column1.ReadOnly = true;
      this.col9.HeaderText = "Open/SL";
      this.col9.Name = "col9";
      this.col9.ReadOnly = true;
      this.col10.HeaderText = "Close/TP";
      this.col10.Name = "col10";
      this.col10.ReadOnly = true;
      this.dpwd.HeaderText = "DP/WD";
      this.dpwd.Name = "dpwd";
      this.dpwd.ReadOnly = true;
      this.col12.HeaderText = "Profit/Desc";
      this.col12.Name = "col12";
      this.col12.ReadOnly = true;
      this.col11.HeaderText = "Com";
      this.col11.Name = "col11";
      this.col11.ReadOnly = true;
      this.col13.HeaderText = "Net Profit";
      this.col13.Name = "col13";
      this.col13.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 486);
      this.Controls.Add((Control) this.dgvledger);
      this.Controls.Add((Control) this.btnView);
      this.Controls.Add((Control) this.btnExport);
      this.Controls.Add((Control) this.cmbClientcode);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.groupBox1);
      this.Name = nameof (frmLedgerAVG);
      this.Text = "View Ledger(Average)";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgvledger).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
