﻿// Decompiled with JetBrains decompiler
// Type: DTS.Payin_Payoutt
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace DTS
{
  public class Payin_Payoutt : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public Dictionary<string, int> _ClientRowindex;
    private int index;
    private GroupBox groupBox1;
    private RadioButton rdoPayout;
    private RadioButton rdoPayin;
    private DataGridView dgvPayinPayout;
    private GroupBox groupBox2;
    private TextBox txtComments;
    private Label label4;
    private TextBox txtamount;
    private Label label3;
    private TextBox txtname;
    private Label label2;
    private TextBox txtCode;
    private Label label1;
    private Button btnupdate;
    private Label label5;
    private Button btnUpload;
    private Button btnDownload;
    private DataGridViewTextBoxColumn Regulationcode;
    private DataGridViewTextBoxColumn UName;
    private DataGridViewTextBoxColumn Cashmrgn;
    private DataGridViewTextBoxColumn MTMLoss;
    private DataGridViewTextBoxColumn MTMlospercen;
    private CheckBox chkGroupwise;
    private Label lblSelectGroup;
    private ComboBox cmbGroup;
    private RadioButton rdoPercent;
    private RadioButton rdoRs;
    private DataGridView dgvPayinOutHistory;
    private Label label6;
    private Button btnRefresh;
    private DataGridViewTextBoxColumn colID;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private DataGridViewTextBoxColumn ColStatus;
    private DataGridViewButtonColumn ColConfirm;

    public Payin_Payoutt(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      this._ClientRowindex = new Dictionary<string, int>();
      this.dgvPayinPayout.Rows.Clear();
      if (this.objmain._ClientLimits.Count > 0)
      {
        foreach (KeyValuePair<string, Limits> clientLimit in this.objmain._ClientLimits)
        {
          Limits limits = clientLimit.Value;
          int index = this.dgvPayinPayout.Rows.Add();
          this.dgvPayinPayout.Rows[index].Cells[0].Value = (object) limits.clientcode;
          if (this.objmain._Userinformation.ContainsKey(limits.clientcode))
          {
            Userinfo userinfo = this.objmain._Userinformation[limits.clientcode];
            this.dgvPayinPayout.Rows[index].Cells[1].Value = (object) userinfo.name;
          }
          else
            this.dgvPayinPayout.Rows[index].Cells[1].Value = (object) "";
          this.dgvPayinPayout.Rows[index].Cells[2].Value = (object) limits.cashmrgn;
          this.dgvPayinPayout.Rows[index].Cells[3].Value = (object) limits.mtmlosslimit;
          this.dgvPayinPayout.Rows[index].Cells[4].Value = (object) limits.mtmmulti;
          if (!this._ClientRowindex.ContainsKey(limits.clientcode))
            this._ClientRowindex.Add(limits.clientcode, index);
        }
      }
      this.LoadHistory();
    }

    private void dgvPayinPayout_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1)
        return;
      DataGridViewRow row = this.dgvPayinPayout.Rows[e.RowIndex];
      this.index = e.RowIndex;
      if (row != null)
      {
        this.ClearControls((Control) this);
        this.txtCode.Text = this.dgvPayinPayout.Rows[this.index].Cells[0].Value.ToString();
        this.txtname.Text = this.dgvPayinPayout.Rows[this.index].Cells[1].Value.ToString();
      }
    }

    private void ClearControls(Control Control)
    {
      foreach (Control control in (ArrangedElementCollection) Control.Controls)
      {
        if (control is TextBox)
          ((TextBoxBase) control).Clear();
        if (control.HasChildren)
          this.ClearControls(control);
      }
    }

    private void dgvPayinPayout_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task1_Click));
      Point client = this.dgvPayinPayout.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvPayinPayout, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.dgvPayinPayout.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvPayinPayout, false);
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      Thread thread = new Thread((ThreadStart) (() => this.UploadFunds()));
      thread.SetApartmentState(ApartmentState.STA);
      thread.Start();
    }

    private void UploadFunds()
    {
      bool flag = true;
      OpenFileDialog openFileDialog1 = new OpenFileDialog();
      openFileDialog1.CheckPathExists = true;
      openFileDialog1.InitialDirectory = Application.StartupPath;
      openFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      openFileDialog1.Title = "Browse Payin/Payout file";
      using (OpenFileDialog openFileDialog2 = openFileDialog1)
      {
        if (openFileDialog2.ShowDialog() == DialogResult.Cancel)
          return;
        try
        {
          using (StreamReader streamReader = new StreamReader(openFileDialog2.FileName))
          {
            while (true)
            {
              string str1 = streamReader.ReadLine();
              if (flag)
                flag = false;
              else if (str1 != null)
              {
                string[] strArray = str1.Split(',');
                int num1 = 1;
                string key = strArray[0];
                string str2 = strArray[1];
                Decimal num2 = Convert.ToDecimal(strArray[2]);
                if (num2 < Decimal.Zero)
                  num1 = 2;
                string str3 = strArray[3];
                if (this.objmain._ClientLimits.ContainsKey(key))
                {
                  Limits clientLimit = this.objmain._ClientLimits[key];
                  clientLimit.cashmrgn = num2 + clientLimit.cashmrgn;
                  clientLimit.mtmlosslimit = clientLimit.cashmrgn * (Decimal) clientLimit.mtmmulti;
                  SqlCommand sqlCommand1 = new SqlCommand("SavePayinPayout", this.conn);
                  sqlCommand1.CommandType = CommandType.StoredProcedure;
                  using (SqlCommand sqlCommand2 = sqlCommand1)
                  {
                    try
                    {
                      sqlCommand2.Parameters.AddWithValue("@clientcode", (object) key);
                      sqlCommand2.Parameters.AddWithValue("@cashmrgn", (object) (clientLimit.cashmrgn * new Decimal(100)));
                      sqlCommand2.Parameters.AddWithValue("@mtmlosslimit", (object) clientLimit.mtmlosslimit);
                      sqlCommand2.Parameters.AddWithValue("@name", (object) str2);
                      sqlCommand2.Parameters.AddWithValue("@amount", (object) num2);
                      sqlCommand2.Parameters.AddWithValue("@comments", (object) str3.Trim());
                      sqlCommand2.Parameters.AddWithValue("@payinout", (object) num1);
                      sqlCommand2.ExecuteNonQuery();
                      this.objmain._ClientLimits[key] = clientLimit;
                      if (this._ClientRowindex.ContainsKey(clientLimit.clientcode))
                      {
                        int index = this._ClientRowindex[clientLimit.clientcode];
                        this.dgvPayinPayout.Rows[index].Cells[2].Value = (object) clientLimit.cashmrgn;
                        this.dgvPayinPayout.Rows[index].Cells[3].Value = (object) (clientLimit.mtmlosslimit / new Decimal(100));
                      }
                    }
                    catch
                    {
                      this.objmain.DisplayMessage("Unable to Update Funds", 3);
                      return;
                    }
                  }
                }
                Thread.Sleep(50);
                Application.DoEvents();
              }
              else
                break;
            }
            this.objmain.DisplayMessage("File uploaded successfully!!", 1);
          }
        }
        catch
        {
        }
      }
    }

    private void rdoPayin_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoPayin.Checked)
      {
        this.label3.Text = "Payin Amount";
        this.btnupdate.Text = "Allocate Funds";
      }
      else
      {
        this.label3.Text = "Payout Amount";
        this.btnupdate.Text = "Withdraw Funds";
      }
    }

    private void btnupdate_Click(object sender, EventArgs e)
    {
      this.btnupdate.Enabled = false;
      if (this.chkGroupwise.Checked)
      {
        int Percent = 0;
        int Rs = 0;
        this.GetGroupwiseInfo(this.cmbGroup.Text, ref Percent, ref Rs);
        List<string> stringList = this.GetclientGroupList(this.cmbGroup.Text);
        int payinOut = 1;
        if (this.rdoPayout.Checked)
          payinOut = 2;
        foreach (string index in stringList)
        {
          if (this.objmain._ClientLimits.ContainsKey(index))
          {
            Limits clientLimit = this.objmain._ClientLimits[index];
            Userinfo userinfo = this.objmain.GetUserinfo(index);
            Decimal amount = Decimal.Round(clientLimit.cashmrgn * (Decimal) Percent / new Decimal(100));
            Decimal cashmrgn = payinOut != 1 ? (!this.rdoPercent.Checked ? clientLimit.cashmrgn - (Decimal) Rs : clientLimit.cashmrgn - amount) : (!this.rdoPercent.Checked ? clientLimit.cashmrgn + (Decimal) Rs : amount + clientLimit.cashmrgn);
            Decimal num = cashmrgn * (Decimal) clientLimit.mtmmulti / new Decimal(100);
            clientLimit.cashmrgn = cashmrgn;
            clientLimit.mtmlosslimit = num;
            this.objmain._ClientLimits[index] = clientLimit;
            if (this.UploadPayinPayout(index, cashmrgn, clientLimit.mtmlosslimit, userinfo.name, amount, "", payinOut, clientLimit))
            {
              this.txtname.Text = userinfo.name;
              Thread.Sleep(250);
            }
            else
              break;
          }
        }
        this.txtname.Text = string.Empty;
      }
      else if (this.txtCode.Text != string.Empty)
      {
        FormValidator formValidator = new FormValidator();
        if (this.txtamount.Text == string.Empty || !formValidator.ValidateIsNumeric(this.txtamount.Text))
        {
          this.objmain.DisplayMessage(string.Format("Enter Amount to {0}", (object) this.btnupdate.Text), 2);
          return;
        }
        int payinOut = 1;
        if (this.rdoPayout.Checked)
          payinOut = 2;
        string text = this.txtCode.Text;
        if (this.objmain._ClientLimits.ContainsKey(text))
        {
          Limits clientLimit = this.objmain._ClientLimits[text];
          Decimal cashmrgn1 = clientLimit.cashmrgn;
          Decimal cashmrgn2 = payinOut != 1 ? clientLimit.cashmrgn - Convert.ToDecimal(this.txtamount.Text) : Convert.ToDecimal(this.txtamount.Text) + clientLimit.cashmrgn;
          Decimal mtmlosslimit = cashmrgn2 * (Decimal) clientLimit.mtmmulti / new Decimal(100);
          if (this.UploadPayinPayout(text, cashmrgn2, mtmlosslimit, this.txtname.Text, Convert.ToDecimal(this.txtamount.Text), this.txtComments.Text, payinOut, clientLimit))
          {
            this.dgvPayinPayout.Rows[this.index].Cells[2].Value = (object) cashmrgn2;
            this.dgvPayinPayout.Rows[this.index].Cells[3].Value = (object) mtmlosslimit;
          }
        }
      }
      else
        this.objmain.DisplayMessage(string.Format("Select Regulation Code to {0}", (object) this.btnupdate.Text), 2);
      this.btnupdate.Enabled = true;
      this.LoadWindow();
    }

    private bool UploadPayinPayout(
      string code,
      Decimal cashmrgn,
      Decimal mtmlosslimit,
      string name,
      Decimal amount,
      string comments,
      int payinOut,
      Limits objlimits)
    {
      SqlCommand sqlCommand1 = new SqlCommand("SavePayinPayout", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        try
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) code);
          sqlCommand2.Parameters.AddWithValue("@cashmrgn", (object) (cashmrgn * new Decimal(100)));
          sqlCommand2.Parameters.AddWithValue("@mtmlosslimit", (object) (mtmlosslimit * new Decimal(100)));
          sqlCommand2.Parameters.AddWithValue("@name", (object) name);
          sqlCommand2.Parameters.AddWithValue("@amount", (object) amount);
          sqlCommand2.Parameters.AddWithValue("@comments", (object) comments);
          sqlCommand2.Parameters.AddWithValue("@payinout", (object) payinOut);
          sqlCommand2.ExecuteNonQuery();
          objlimits.cashmrgn = cashmrgn;
          objlimits.mtmlosslimit = mtmlosslimit;
          this.objmain._ClientLimits[code] = objlimits;
          return true;
        }
        catch
        {
          return false;
        }
      }
    }

    private void btnDownload_Click(object sender, EventArgs e)
    {
      bool flag = true;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.InitialDirectory = Convert.ToString((object) Environment.SpecialFolder.Personal);
      saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      saveFileDialog1.Title = "Download File";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        string fileName = saveFileDialog2.FileName;
        StreamWriter streamWriter;
        if (File.Exists(fileName))
        {
          try
          {
            new FileStream(fileName, FileMode.Truncate).Close();
          }
          catch
          {
            int num = (int) MessageBox.Show("Unable to download file, please close the file if the file is open and try again.", "Download File", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          }
          streamWriter = new StreamWriter(fileName);
        }
        else
          streamWriter = new StreamWriter(fileName);
        for (int index = 0; index < this.dgvPayinPayout.Rows.Count; ++index)
        {
          DataGridViewRow row = this.dgvPayinPayout.Rows[index];
          string str1 = Convert.ToString(this.dgvPayinPayout.Rows[row.Index].Cells["Regulationcode"].Value);
          string str2 = Convert.ToString(this.dgvPayinPayout.Rows[row.Index].Cells["UName"].Value);
          if (flag)
          {
            string str3 = string.Format("{0},{1},{2},Comments\n", (object) "ClientCode", (object) "Name", (object) "Payin/Payout Amount");
            streamWriter.Write(str3);
            flag = false;
          }
          string str4 = string.Format("{0},{1},{2},{3}\n", (object) str1, (object) str2, (object) 0, (object) "");
          streamWriter.Write(str4);
        }
        streamWriter.Flush();
        streamWriter.Close();
        int num1 = (int) MessageBox.Show("File Downloaded successfully!!", "Download File", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
      }
    }

    private void btnUpload_Click(object sender, EventArgs e)
    {
      Thread thread = new Thread((ThreadStart) (() => this.UploadFunds()));
      thread.SetApartmentState(ApartmentState.STA);
      thread.Start();
    }

    private void chkGroupwise_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkGroupwise.Checked)
      {
        this.lblSelectGroup.Visible = true;
        this.cmbGroup.Visible = true;
        this.rdoPercent.Visible = true;
        this.rdoRs.Visible = true;
        this.cmbGroup.SelectedIndex = 0;
      }
      else
      {
        this.lblSelectGroup.Visible = false;
        this.cmbGroup.Visible = false;
        this.rdoPercent.Visible = false;
        this.rdoRs.Visible = false;
      }
    }

    private void GetGroupwiseInfo(string groupname, ref int Percent, ref int Rs)
    {
      SqlConnection conn = this.objmain.getConn();
      if (conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select [Percent],Rs from GroupingInfo where GroupName = '" + groupname + "' and DACode = '" + this.objmain.objinfo.clientcode + "'", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              Percent = sqlDataReader.GetInt32(0);
            if (!sqlDataReader.IsDBNull(1))
              Rs = sqlDataReader.GetInt32(1);
          }
        }
      }
    }

    private List<string> GetclientGroupList(string groupname)
    {
      List<string> stringList = new List<string>();
      SqlConnection conn = this.objmain.getConn();
      if (conn.State == ConnectionState.Open)
      {
        using (SqlCommand sqlCommand = new SqlCommand("select ClientCode from PayIN_OUTGrouping where GroupType = '" + groupname + "' and DACode = '" + this.objmain.objinfo.clientcode + "'", conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(0) && !stringList.Contains(sqlDataReader.GetString(0)))
                stringList.Add(sqlDataReader.GetString(0));
            }
          }
        }
      }
      return stringList;
    }

    private void btnRefresh_Click(object sender, EventArgs e)
    {
      this.LoadHistory();
    }

    private void LoadHistory()
    {
      this.dgvPayinOutHistory.Rows.Clear();
      using (SqlCommand sqlCommand = new SqlCommand("Select ID,Clientcode,Amount,Timestamp,PayinPayout from Payin_Payout where Clientcode in (" + this.objmain.claccounts + ") and AmtStatus = 0 order by Timestamp", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            int index = this.dgvPayinOutHistory.Rows.Add();
            if (!sqlDataReader.IsDBNull(0))
              this.dgvPayinOutHistory.Rows[index].Cells[0].Value = (object) sqlDataReader.GetInt32(0);
            if (!sqlDataReader.IsDBNull(1))
              this.dgvPayinOutHistory.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
              this.dgvPayinOutHistory.Rows[index].Cells[2].Value = sqlDataReader.GetValue(2);
            if (!sqlDataReader.IsDBNull(3))
              this.dgvPayinOutHistory.Rows[index].Cells[3].Value = (object) Convert.ToDateTime(sqlDataReader.GetValue(3)).ToString("yyyy-MM-dd HH:mm:ss");
            if (!sqlDataReader.IsDBNull(4))
              this.dgvPayinOutHistory.Rows[index].Cells[4].Value = sqlDataReader.GetInt32(4) != 1 ? (object) "Payout" : (object) "Payin";
            this.dgvPayinOutHistory.Rows[index].Cells[5].Value = (object) "CONFIRM";
          }
        }
      }
    }

    private void dgvPayinOutHistory_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
      if (this.dgvPayinOutHistory.Rows.Count <= 0 || e.ColumnIndex != 5)
        return;
      if (this.dgvPayinOutHistory.Rows[e.RowIndex].Cells[4].Value.ToString().ToUpper() == "PAYIN")
      {
        if (MessageBox.Show("Are you sure, you received the payment?", "Confirm Payin Amount Receieved", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Update Payin_Payout Set Amtstatus = 1 where ID = " + (object) Convert.ToInt32(this.dgvPayinOutHistory.Rows[e.RowIndex].Cells[0].Value) + " ", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.objmain.DisplayMessage("Payin Amount Recieved Confirmed", 1);
              this.dgvPayinOutHistory.Rows[e.RowIndex].Visible = false;
            }
            catch
            {
              this.objmain.DisplayMessage("Unable to update the status", 3);
            }
          }
        }
      }
      else if (this.dgvPayinOutHistory.Rows[e.RowIndex].Cells[4].Value.ToString().ToUpper() == "PAYOUT" && MessageBox.Show("Are you sure, you delivered the payment?", "Confirm Payout Amount Delivered", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
      {
        using (SqlCommand sqlCommand = new SqlCommand("Update Payin_Payout Set Amtstatus = 1 where ID = " + (object) Convert.ToInt32(this.dgvPayinOutHistory.Rows[e.RowIndex].Cells[0].Value) + " ", this.conn))
        {
          try
          {
            sqlCommand.ExecuteNonQuery();
            this.objmain.DisplayMessage("Payin Amount Delivered Confirmed", 1);
            this.dgvPayinOutHistory.Rows[e.RowIndex].Visible = false;
          }
          catch
          {
            this.objmain.DisplayMessage("Unable to update the status", 3);
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoPayout = new RadioButton();
      this.rdoPayin = new RadioButton();
      this.dgvPayinPayout = new DataGridView();
      this.Regulationcode = new DataGridViewTextBoxColumn();
      this.UName = new DataGridViewTextBoxColumn();
      this.Cashmrgn = new DataGridViewTextBoxColumn();
      this.MTMLoss = new DataGridViewTextBoxColumn();
      this.MTMlospercen = new DataGridViewTextBoxColumn();
      this.groupBox2 = new GroupBox();
      this.txtComments = new TextBox();
      this.label4 = new Label();
      this.txtamount = new TextBox();
      this.label3 = new Label();
      this.txtname = new TextBox();
      this.label2 = new Label();
      this.txtCode = new TextBox();
      this.label1 = new Label();
      this.btnupdate = new Button();
      this.label5 = new Label();
      this.btnUpload = new Button();
      this.btnDownload = new Button();
      this.chkGroupwise = new CheckBox();
      this.lblSelectGroup = new Label();
      this.cmbGroup = new ComboBox();
      this.rdoPercent = new RadioButton();
      this.rdoRs = new RadioButton();
      this.dgvPayinOutHistory = new DataGridView();
      this.label6 = new Label();
      this.btnRefresh = new Button();
      this.colID = new DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      this.ColStatus = new DataGridViewTextBoxColumn();
      this.ColConfirm = new DataGridViewButtonColumn();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgvPayinPayout).BeginInit();
      this.groupBox2.SuspendLayout();
      ((ISupportInitialize) this.dgvPayinOutHistory).BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoPayout);
      this.groupBox1.Controls.Add((Control) this.rdoPayin);
      this.groupBox1.Location = new Point(1, 6);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(149, 51);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Payin/Payout";
      this.rdoPayout.AutoSize = true;
      this.rdoPayout.Location = new Point(81, 23);
      this.rdoPayout.Name = "rdoPayout";
      this.rdoPayout.Size = new Size(58, 17);
      this.rdoPayout.TabIndex = 1;
      this.rdoPayout.Text = "Payout";
      this.rdoPayout.UseVisualStyleBackColor = true;
      this.rdoPayin.AutoSize = true;
      this.rdoPayin.Checked = true;
      this.rdoPayin.Location = new Point(6, 23);
      this.rdoPayin.Name = "rdoPayin";
      this.rdoPayin.Size = new Size(51, 17);
      this.rdoPayin.TabIndex = 0;
      this.rdoPayin.TabStop = true;
      this.rdoPayin.Text = "Payin";
      this.rdoPayin.UseVisualStyleBackColor = true;
      this.rdoPayin.CheckedChanged += new EventHandler(this.rdoPayin_CheckedChanged);
      this.dgvPayinPayout.AllowUserToAddRows = false;
      this.dgvPayinPayout.AllowUserToDeleteRows = false;
      this.dgvPayinPayout.AllowUserToOrderColumns = true;
      this.dgvPayinPayout.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvPayinPayout.Columns.AddRange((DataGridViewColumn) this.Regulationcode, (DataGridViewColumn) this.UName, (DataGridViewColumn) this.Cashmrgn, (DataGridViewColumn) this.MTMLoss, (DataGridViewColumn) this.MTMlospercen);
      this.dgvPayinPayout.Location = new Point(1, 148);
      this.dgvPayinPayout.Name = "dgvPayinPayout";
      this.dgvPayinPayout.ReadOnly = true;
      this.dgvPayinPayout.RowHeadersVisible = false;
      this.dgvPayinPayout.Size = new Size(487, 326);
      this.dgvPayinPayout.TabIndex = 3;
      this.dgvPayinPayout.CellClick += new DataGridViewCellEventHandler(this.dgvPayinPayout_CellClick);
      this.dgvPayinPayout.MouseClick += new MouseEventHandler(this.dgvPayinPayout_MouseClick);
      this.Regulationcode.HeaderText = "ClientCode";
      this.Regulationcode.Name = "Regulationcode";
      this.Regulationcode.ReadOnly = true;
      this.UName.HeaderText = "Name";
      this.UName.Name = "UName";
      this.UName.ReadOnly = true;
      this.Cashmrgn.HeaderText = "Cash Margin";
      this.Cashmrgn.Name = "Cashmrgn";
      this.Cashmrgn.ReadOnly = true;
      this.MTMLoss.HeaderText = "MTM Loss Limit";
      this.MTMLoss.Name = "MTMLoss";
      this.MTMLoss.ReadOnly = true;
      this.MTMLoss.Width = 110;
      this.MTMlospercen.HeaderText = "Loss(%)";
      this.MTMlospercen.Name = "MTMlospercen";
      this.MTMlospercen.ReadOnly = true;
      this.MTMlospercen.Width = 50;
      this.groupBox2.Controls.Add((Control) this.txtComments);
      this.groupBox2.Controls.Add((Control) this.label4);
      this.groupBox2.Controls.Add((Control) this.txtamount);
      this.groupBox2.Controls.Add((Control) this.label3);
      this.groupBox2.Controls.Add((Control) this.txtname);
      this.groupBox2.Controls.Add((Control) this.label2);
      this.groupBox2.Controls.Add((Control) this.txtCode);
      this.groupBox2.Controls.Add((Control) this.label1);
      this.groupBox2.Location = new Point(2, 63);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(401, 61);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Enter Amount";
      this.txtComments.Location = new Point(300, 32);
      this.txtComments.Name = "txtComments";
      this.txtComments.Size = new Size(92, 20);
      this.txtComments.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(304, 16);
      this.label4.Name = "label4";
      this.label4.Size = new Size(56, 13);
      this.label4.TabIndex = 6;
      this.label4.Text = "Comments";
      this.txtamount.Location = new Point(202, 32);
      this.txtamount.MaxLength = 10;
      this.txtamount.Name = "txtamount";
      this.txtamount.Size = new Size(92, 20);
      this.txtamount.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(206, 16);
      this.label3.Name = "label3";
      this.label3.Size = new Size(72, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Payin Amount";
      this.txtname.Enabled = false;
      this.txtname.Location = new Point(104, 32);
      this.txtname.Name = "txtname";
      this.txtname.Size = new Size(92, 20);
      this.txtname.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(108, 16);
      this.label2.Name = "label2";
      this.label2.Size = new Size(35, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Name";
      this.txtCode.Enabled = false;
      this.txtCode.Location = new Point(6, 32);
      this.txtCode.Name = "txtCode";
      this.txtCode.Size = new Size(92, 20);
      this.txtCode.TabIndex = 0;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(10, 16);
      this.label1.Name = "label1";
      this.label1.Size = new Size(61, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Client Code";
      this.btnupdate.Location = new Point(413, 74);
      this.btnupdate.Name = "btnupdate";
      this.btnupdate.Size = new Size(75, 41);
      this.btnupdate.TabIndex = 2;
      this.btnupdate.Text = "Allocate Funds";
      this.btnupdate.UseVisualStyleBackColor = true;
      this.btnupdate.Click += new EventHandler(this.btnupdate_Click);
      this.label5.AutoSize = true;
      this.label5.ForeColor = Color.Red;
      this.label5.Location = new Point(3, 132);
      this.label5.Name = "label5";
      this.label5.Size = new Size(150, 13);
      this.label5.TabIndex = 8;
      this.label5.Text = "*Click on the Record to Select";
      this.btnUpload.Location = new Point(413, 35);
      this.btnUpload.Name = "btnUpload";
      this.btnUpload.Size = new Size(75, 23);
      this.btnUpload.TabIndex = 9;
      this.btnUpload.Text = "Upload";
      this.btnUpload.UseVisualStyleBackColor = true;
      this.btnUpload.Click += new EventHandler(this.btnUpload_Click);
      this.btnDownload.Location = new Point(413, 6);
      this.btnDownload.Name = "btnDownload";
      this.btnDownload.Size = new Size(75, 23);
      this.btnDownload.TabIndex = 10;
      this.btnDownload.Text = "Download";
      this.btnDownload.UseVisualStyleBackColor = true;
      this.btnDownload.Click += new EventHandler(this.btnDownload_Click);
      this.chkGroupwise.AutoSize = true;
      this.chkGroupwise.Location = new Point(156, 10);
      this.chkGroupwise.Name = "chkGroupwise";
      this.chkGroupwise.Size = new Size(76, 17);
      this.chkGroupwise.TabIndex = 11;
      this.chkGroupwise.Text = "Groupwise";
      this.chkGroupwise.UseVisualStyleBackColor = true;
      this.chkGroupwise.CheckedChanged += new EventHandler(this.chkGroupwise_CheckedChanged);
      this.lblSelectGroup.AutoSize = true;
      this.lblSelectGroup.Location = new Point(156, 33);
      this.lblSelectGroup.Name = "lblSelectGroup";
      this.lblSelectGroup.Size = new Size(72, 13);
      this.lblSelectGroup.TabIndex = 12;
      this.lblSelectGroup.Text = "Select Group:";
      this.lblSelectGroup.Visible = false;
      this.cmbGroup.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbGroup.FormattingEnabled = true;
      this.cmbGroup.Items.AddRange(new object[6]
      {
        (object) "Group1",
        (object) "Group2",
        (object) "Group3",
        (object) "Group4",
        (object) "Group5",
        (object) "Group6"
      });
      this.cmbGroup.Location = new Point(234, 28);
      this.cmbGroup.Name = "cmbGroup";
      this.cmbGroup.Size = new Size(93, 21);
      this.cmbGroup.TabIndex = 13;
      this.cmbGroup.Visible = false;
      this.rdoPercent.AutoSize = true;
      this.rdoPercent.Checked = true;
      this.rdoPercent.Location = new Point(333, 31);
      this.rdoPercent.Name = "rdoPercent";
      this.rdoPercent.Size = new Size(33, 17);
      this.rdoPercent.TabIndex = 14;
      this.rdoPercent.TabStop = true;
      this.rdoPercent.Text = "%";
      this.rdoPercent.UseVisualStyleBackColor = true;
      this.rdoPercent.Visible = false;
      this.rdoRs.AutoSize = true;
      this.rdoRs.Location = new Point(372, 31);
      this.rdoRs.Name = "rdoRs";
      this.rdoRs.Size = new Size(41, 17);
      this.rdoRs.TabIndex = 15;
      this.rdoRs.Text = "Rs.";
      this.rdoRs.UseVisualStyleBackColor = true;
      this.rdoRs.Visible = false;
      this.dgvPayinOutHistory.AllowUserToAddRows = false;
      this.dgvPayinOutHistory.AllowUserToDeleteRows = false;
      this.dgvPayinOutHistory.AllowUserToOrderColumns = true;
      this.dgvPayinOutHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvPayinOutHistory.Columns.AddRange((DataGridViewColumn) this.colID, (DataGridViewColumn) this.dataGridViewTextBoxColumn1, (DataGridViewColumn) this.dataGridViewTextBoxColumn4, (DataGridViewColumn) this.dataGridViewTextBoxColumn5, (DataGridViewColumn) this.ColStatus, (DataGridViewColumn) this.ColConfirm);
      this.dgvPayinOutHistory.Location = new Point(494, 148);
      this.dgvPayinOutHistory.Name = "dgvPayinOutHistory";
      this.dgvPayinOutHistory.ReadOnly = true;
      this.dgvPayinOutHistory.RowHeadersVisible = false;
      this.dgvPayinOutHistory.Size = new Size(448, 326);
      this.dgvPayinOutHistory.TabIndex = 16;
      this.dgvPayinOutHistory.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgvPayinOutHistory_CellMouseClick);
      this.label6.AutoSize = true;
      this.label6.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label6.Location = new Point(502, 129);
      this.label6.Name = "label6";
      this.label6.Size = new Size(133, 16);
      this.label6.TabIndex = 17;
      this.label6.Text = "Payin/Payout History";
      this.btnRefresh.Location = new Point(867, 119);
      this.btnRefresh.Name = "btnRefresh";
      this.btnRefresh.Size = new Size(75, 23);
      this.btnRefresh.TabIndex = 18;
      this.btnRefresh.Text = "Refresh";
      this.btnRefresh.UseVisualStyleBackColor = true;
      this.btnRefresh.Click += new EventHandler(this.btnRefresh_Click);
      this.colID.HeaderText = "ID";
      this.colID.Name = "colID";
      this.colID.ReadOnly = true;
      this.colID.Visible = false;
      this.dataGridViewTextBoxColumn1.HeaderText = "ClientCode";
      this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
      this.dataGridViewTextBoxColumn1.ReadOnly = true;
      this.dataGridViewTextBoxColumn4.HeaderText = "Amount";
      this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
      this.dataGridViewTextBoxColumn4.ReadOnly = true;
      this.dataGridViewTextBoxColumn4.Width = 80;
      this.dataGridViewTextBoxColumn5.HeaderText = "Timestamp";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      this.dataGridViewTextBoxColumn5.Width = 120;
      this.ColStatus.HeaderText = "Payin_Payout";
      this.ColStatus.Name = "ColStatus";
      this.ColStatus.ReadOnly = true;
      this.ColStatus.Width = 70;
      this.ColConfirm.HeaderText = "Confirm";
      this.ColConfirm.Name = "ColConfirm";
      this.ColConfirm.ReadOnly = true;
      this.ColConfirm.Width = 70;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(946, 478);
      this.Controls.Add((Control) this.btnRefresh);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.dgvPayinOutHistory);
      this.Controls.Add((Control) this.rdoRs);
      this.Controls.Add((Control) this.rdoPercent);
      this.Controls.Add((Control) this.cmbGroup);
      this.Controls.Add((Control) this.lblSelectGroup);
      this.Controls.Add((Control) this.chkGroupwise);
      this.Controls.Add((Control) this.btnDownload);
      this.Controls.Add((Control) this.btnUpload);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.btnupdate);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.dgvPayinPayout);
      this.Controls.Add((Control) this.groupBox1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (Payin_Payoutt);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Payin/Payout Management";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgvPayinPayout).EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((ISupportInitialize) this.dgvPayinOutHistory).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
