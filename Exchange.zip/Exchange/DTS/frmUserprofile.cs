﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmUserprofile
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace DTS
{
  public class frmUserprofile : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public SqlConnection conn;
    public int rowindex;
    private GroupBox groupBox1;
    private DataGridView dgvUserprofile;
    private TextBox txtpassword;
    private Label label5;
    private TextBox txtusername;
    private Label label4;
    private TextBox txtclientcode;
    private Label label3;
    private TextBox txtname;
    private Label label2;
    private ComboBox cmbUsertype;
    private Label label1;
    private CheckBox chkCharts;
    private GroupBox groupBox2;
    private CheckBox chkStckPerfm;
    private CheckBox chkPivots;
    private Button btnAdd;
    private Button btnModify;
    private Button btnDelete;
    private Button btnLogoff;
    private Button btnReleaseMrgn;
    private Button btnBlockMargin;
    private Button btndisable;
    private Button btnEnable;
    private CheckedListBox chkExchList;
    private Label label6;
    private CheckBox chkOffset;
    private CheckBox chkOddLot;
    private TextBox txtAppName;
    private Label label7;
    private Label label8;
    private TextBox txtNameSearch;
    private TextBox txtClientcodeSearch;
    private TextBox txtUsernameSearch;
    private Button btnSet;
    private Label lblProgress;
    private Button btnUploadImage;
    private TextBox txtImagePath;
    private PictureBox pictureBox1;
    private Button button1;
    private Label label9;
    private CheckBox chkModTrd;
    private Label lblpfls;
    private TextBox txtPflsPercent;
    private TextBox txtMobNo;
    private Label label10;
    private TextBox txtEmailid;
    private Label label11;
    private GroupBox grpOffsetExch;
    private CheckBox chkNSECURR;
    private CheckBox chkNCDEX;
    private CheckBox chkNSEFUT;
    private CheckBox chkMCX;
    private GroupBox grpHighLowExch;
    private CheckBox chkHLnsecurr;
    private CheckBox chkHLncdex;
    private CheckBox chkHLnsefut;
    private CheckBox chkHLmcx;
    private CheckBox chkHighLowTrading;
    private TextBox txtDAfund;
    private Label lblDAfund;
    private CheckBox chk_SendSMS;
    private Label DIPLF;
    private TextBox textBoxDIPFLS;
    private DataGridViewTextBoxColumn usertype;
    private DataGridViewTextBoxColumn UName;
    private DataGridViewTextBoxColumn Clientcode;
    private DataGridViewTextBoxColumn Username;
    private DataGridViewTextBoxColumn Password;
    private DataGridViewTextBoxColumn Pivots;
    private DataGridViewTextBoxColumn StocksPerfor;
    private DataGridViewTextBoxColumn Charting;
    private DataGridViewTextBoxColumn Userstatus;
    private DataGridViewTextBoxColumn Marginstatus;
    private DataGridViewTextBoxColumn Exchnage;
    private DataGridViewTextBoxColumn RegDate;
    private DataGridViewTextBoxColumn ColOffset;
    private DataGridViewTextBoxColumn colOddLot;
    private DataGridViewTextBoxColumn ColAppName;
    private DataGridViewTextBoxColumn DIComm;

    public frmUserprofile(Dashboard dash, SqlConnection db)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = db;
      this.Icon = this.objdash.ico;
    }

    public void LoadWindow(int usertype)
    {
      this.cmbUsertype.Items.Clear();
      this.chkExchList.Items.Clear();
      switch (usertype)
      {
        case 1:
          this.cmbUsertype.Items.Add((object) "DealerAdmin");
          this.chkOffset.Visible = false;
          this.chkOddLot.Visible = false;
          this.btnLogoff.Visible = false;
          break;
        case 2:
          this.btnLogoff.Visible = true;
          this.cmbUsertype.Items.Add((object) "Dealer");
          this.cmbUsertype.Items.Add((object) "Client");
          if (this.objdash.objinfo.isSMS == 1)
          {
            this.txtMobNo.Size = new Size(89, 20);
            this.chk_SendSMS.Visible = true;
          }
          else
          {
            this.txtMobNo.Size = new Size(126, 20);
            this.chk_SendSMS.Visible = false;
          }
          if (this.objdash.objinfo.isModTrd == 1)
          {
            this.chkModTrd.Visible = true;
            break;
          }
          this.chkModTrd.Visible = false;
          break;
      }
      this.cmbUsertype.SelectedIndex = 0;
      string exchange = this.objdash.objinfo.exchange;
      char[] chArray = new char[1]{ ',' };
      foreach (object obj in exchange.Split(chArray))
        this.chkExchList.Items.Add(obj);
      this.BindGird();
    }

    private string Getexch()
    {
      string str = string.Empty;
      for (int index = 0; index < this.chkExchList.Items.Count; ++index)
      {
        if (this.chkExchList.GetItemCheckState(index) == CheckState.Checked)
          str += string.Format("{0},", this.chkExchList.Items[index]);
      }
      if (str.Length > 0)
        str = str.Substring(0, str.Length - 1);
      return str;
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      int num1 = 0;
      int num2 = 0;
      int num3 = 0;
      int num4 = 0;
      int num5 = 0;
      int result1 = 0;
      int num6 = 0;
      int num7 = 0;
      double result2 = 0.0;
      FormValidator formValidator = new FormValidator();
      string empty1 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      if (this.txtclientcode.Text == string.Empty)
        empty1 += "Enter ClientCode \n";
      if (this.txtusername.Text == string.Empty)
        empty1 += "Enter Username \n";
      if (this.txtpassword.Text == string.Empty)
        empty1 += "Enter Password \n";
      if (this.txtpassword.Text == this.txtusername.Text)
        empty1 += "Password cannot be same as Username \n";
      if (this.txtAppName.Text == string.Empty)
        empty1 += "Enter App Name \n";
      if (this.txtEmailid.Text != string.Empty && !formValidator.ValidateEmail(this.txtEmailid.Text))
        empty1 += "Enter Valid email id\n";
      if (this.txtMobNo.Text != string.Empty && !formValidator.ValidateIsNumeric(this.txtMobNo.Text))
        empty1 += "Enter Valid Mobile No\n";
      string str3 = this.Getexch();
      if (this.cmbUsertype.Text == "DealerAdmin")
      {
        if (!int.TryParse(this.txtPflsPercent.Text, out result1))
          empty1 += "Please enter correct Profit/Loss % \n";
        if (this.txtDAfund.Text == string.Empty)
          empty1 += "Please enter Dealer Admin initial Margin.\n";
        if (!double.TryParse(this.txtDAfund.Text, out result2))
          empty1 += "Enter correct amount.\n";
      }
      if (this.cmbUsertype.Text.ToUpper() != "DEALER")
      {
        if (str3 == string.Empty)
          empty1 += "Select atleast One Exchange \n";
      }
      else
        str3 = this.objdash.objinfo.exchange;
      if (this.cmbUsertype.Text.ToUpper() == "DEALER" && this.textBoxDIPFLS.Text == string.Empty)
        empty1 += "DI ProfitLoss% \n";
      if (this.chkPivots.Checked)
        num1 = 1;
      if (this.chkCharts.Checked)
        num2 = 1;
      if (this.chkStckPerfm.Checked)
        num3 = 1;
      if (this.chkOffset.Checked)
      {
        num4 = 1;
        if (this.chkMCX.Checked)
          str1 += "MCX,";
        if (this.chkNSEFUT.Checked)
          str1 += "NSEFUT,";
        if (this.chkNCDEX.Checked)
          str1 += "NCDEX,";
        if (this.chkNSECURR.Checked)
          str1 += "NSECURR,";
        if (str1.Length > 0)
          str1 = str1.Substring(0, str1.Length - 1);
        else
          empty1 += "Select atleast one Offset Exchange \n";
      }
      if (this.chkHighLowTrading.Checked)
      {
        num6 = 1;
        if (this.chkHLmcx.Checked)
          str2 += "MCX,";
        if (this.chkHLnsefut.Checked)
          str2 += "NSEFUT,";
        if (this.chkHLncdex.Checked)
          str2 += "NCDEX,";
        if (this.chkHLnsecurr.Checked)
          str2 += "NSECURR,";
        if (str2.Length > 0)
          str2 = str2.Substring(0, str2.Length - 1);
        else
          empty1 += "Select atleast one High/Low Trading Exchange \n";
      }
      if (this.chkOddLot.Checked)
        num5 = 1;
      if (this.textBoxDIPFLS.Text != string.Empty)
        num7 = Convert.ToInt32(this.textBoxDIPFLS.Text);
      if (empty1 == string.Empty)
      {
        Userinfo objinfo = new Userinfo()
        {
          usertype = (int) Enum.Parse(typeof (Usertype), this.cmbUsertype.Text.ToUpper()),
          name = this.txtname.Text,
          username = this.txtusername.Text,
          clientcode = this.txtclientcode.Text,
          password = this.objdash.Encryptdata(this.txtpassword.Text),
          userstatus = 1,
          marginstatus = 1,
          productype = 1,
          createdby = this.objdash.objinfo.clientcode,
          pivots = num1,
          charts = num2,
          stockperform = num3,
          exchange = str3,
          offset = num4,
          oddlot = num5,
          AppName = this.txtAppName.Text.Trim(),
          DApflsPercent = result1,
          emailid = this.txtEmailid.Text,
          OffsetExch = str1,
          isHLTrading = num6,
          HighLowExch = str2,
          DAfund = result2,
          DIpflsPercent = num7
        };
        objinfo.isSMS = !this.chk_SendSMS.Checked ? 0 : 1;
        if (this.txtMobNo.Text != string.Empty)
          objinfo.Mobno = Convert.ToInt64(this.txtMobNo.Text);
        int num8 = objinfo.usertype == 3 || objinfo.usertype == 2 ? (this.chkModTrd.Checked ? 1 : 0) : 0;
        objinfo.isModTrd = num8 == 0 ? 0 : 1;
        string empty2 = string.Empty;
        if (this.ValidateClientcodeandUsername(objinfo.clientcode, objinfo.username, ref empty2))
        {
          int num9 = UserinfoMain.saveUserinfo(objinfo, this.conn);
          if (num9 >= 1)
          {
            this.objdash.DisplayMessage(empty1 + "User Created Successfully", 1);
            this.objdash.ManageUserinformation(objinfo);
            this.BindGird();
            this.ClearControls((Control) this);
          }
          else
          {
            if (num9 != 0)
              return;
            this.objdash.DisplayMessage(empty1 + "Client Code or Username already exists, Please enter another Clientcode or username", 2);
          }
        }
        else
          this.objdash.DisplayMessage(empty2, 2);
      }
      else
        this.objdash.DisplayMessage(empty1 + "These Fields are Mandatory", 2);
    }

    private void btnClear_Click(object sender, EventArgs e)
    {
      if (this.txtclientcode.Text.Length <= 0)
        this.objdash.DisplayMessage("Select Client id to Log Off", 2);
      else if (this.objdash.InsertMessage(this.txtclientcode.Text.Trim(), "Force Log-Off from Admin.", 10))
        this.objdash.DisplayMessage("User Logged-Off Successfully!!", 1);
      else
        this.objdash.DisplayMessage("Unable to perform Task", 3);
    }

    private void ClearControls(Control Control)
    {
      foreach (Control control in (ArrangedElementCollection) Control.Controls)
      {
        if (control is TextBox)
          ((TextBoxBase) control).Clear();
        if (control.HasChildren)
          this.ClearControls(control);
        if (control is MaskedTextBox)
          ((TextBoxBase) control).Clear();
        if (control is CheckBox)
          ((CheckBox) control).Checked = false;
        this.txtclientcode.Enabled = true;
        for (int index = 0; index < this.chkExchList.Items.Count; ++index)
          this.chkExchList.SetItemCheckState(index, CheckState.Unchecked);
        this.cmbUsertype.Focus();
        this.btnAdd.Enabled = true;
      }
    }

    private void dgvUserprofile_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1)
        return;
      DataGridViewRow row = this.dgvUserprofile.Rows[e.RowIndex];
      int rowIndex = e.RowIndex;
      this.rowindex = rowIndex;
      if (row != null)
      {
        this.ClearControls((Control) this);
        this.cmbUsertype.Text = this.dgvUserprofile.Rows[rowIndex].Cells[0].Value.ToString();
        this.btnAdd.Enabled = false;
        this.txtname.Text = this.dgvUserprofile.Rows[rowIndex].Cells[1].Value.ToString();
        this.txtclientcode.Text = this.dgvUserprofile.Rows[rowIndex].Cells[2].Value.ToString();
        this.txtusername.Text = this.dgvUserprofile.Rows[rowIndex].Cells[3].Value.ToString();
        this.txtpassword.Text = Dashboard.Decryptdata(this.dgvUserprofile.Rows[rowIndex].Cells[4].Value.ToString());
        string str1 = this.dgvUserprofile.Rows[rowIndex].Cells[10].Value.ToString();
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          for (int index = 0; index < this.chkExchList.Items.Count; ++index)
          {
            if (this.chkExchList.Items[index].ToString() == str2)
              this.chkExchList.SetItemCheckState(index, CheckState.Checked);
          }
        }
        if (this.dgvUserprofile.Rows[rowIndex].Cells[5].Value.ToString().ToUpper() == "YES")
          this.chkPivots.Checked = true;
        if (this.dgvUserprofile.Rows[rowIndex].Cells[6].Value.ToString().ToUpper() == "YES")
          this.chkStckPerfm.Checked = true;
        if (this.dgvUserprofile.Rows[rowIndex].Cells[7].Value.ToString().ToUpper() == "YES")
          this.chkCharts.Checked = true;
        if (this.dgvUserprofile.Rows[rowIndex].Cells[12].Value.ToString().ToUpper() == "YES")
          this.chkOffset.Checked = true;
        if (this.dgvUserprofile.Rows[rowIndex].Cells[13].Value.ToString().ToUpper() == "YES")
          this.chkOddLot.Checked = true;
        if (this.dgvUserprofile.Rows[rowIndex].Cells[14].Value != null)
          this.txtAppName.Text = this.dgvUserprofile.Rows[rowIndex].Cells[14].Value.ToString();
        this.txtclientcode.Enabled = false;
        Userinfo userinfo = this.objdash.GetUserinfo(this.txtclientcode.Text);
        if (userinfo.usertype == 3 || userinfo.usertype == 2)
          this.chkModTrd.Visible = true;
        else
          this.chkModTrd.Visible = false;
        this.chkModTrd.Checked = userinfo.isModTrd == 1;
        if (userinfo.usertype == 3 && this.objdash.objinfo.usertype == 2)
        {
          if (this.objdash.objinfo.isModTrd == 1)
            this.chkModTrd.Visible = true;
          else
            this.chkModTrd.Visible = false;
        }
        TextBox txtPflsPercent = this.txtPflsPercent;
        int num = userinfo.DApflsPercent;
        string str3 = num.ToString();
        txtPflsPercent.Text = str3;
        this.txtEmailid.Text = userinfo.emailid;
        this.txtMobNo.Text = userinfo.Mobno.ToString();
        TextBox textBoxDipfls = this.textBoxDIPFLS;
        num = userinfo.DIpflsPercent;
        string str4 = num.ToString();
        textBoxDipfls.Text = str4;
        this.chkNSECURR.Checked = this.chkNCDEX.Checked = this.chkNSEFUT.Checked = this.chkMCX.Checked = false;
        if (userinfo.usertype == 2 || userinfo.usertype == 0)
        {
          this.lblDAfund.Visible = false;
          this.txtDAfund.Visible = false;
        }
        if (userinfo.OffsetExch.Length > 0)
        {
          string offsetExch = userinfo.OffsetExch;
          char[] chArray2 = new char[1]{ ',' };
          foreach (string str2 in offsetExch.Split(chArray2))
          {
            if (!(str2 == "MCX"))
            {
              if (!(str2 == "NSEFUT"))
              {
                if (!(str2 == "NCDEX"))
                {
                  if (str2 == "NSECURR")
                    this.chkNSECURR.Checked = true;
                }
                else
                  this.chkNCDEX.Checked = true;
              }
              else
                this.chkNSEFUT.Checked = true;
            }
            else
              this.chkMCX.Checked = true;
          }
        }
        if (userinfo.isHLTrading == 1)
          this.chkHighLowTrading.Checked = true;
        if (userinfo.HighLowExch.Length > 0)
        {
          string highLowExch = userinfo.HighLowExch;
          char[] chArray2 = new char[1]{ ',' };
          foreach (string str2 in highLowExch.Split(chArray2))
          {
            if (!(str2 == "MCX"))
            {
              if (!(str2 == "NSEFUT"))
              {
                if (!(str2 == "NCDEX"))
                {
                  if (str2 == "NSECURR")
                    this.chkHLnsecurr.Checked = true;
                }
                else
                  this.chkHLncdex.Checked = true;
              }
              else
                this.chkHLnsefut.Checked = true;
            }
            else
              this.chkHLmcx.Checked = true;
          }
        }
        this.chk_SendSMS.CheckState = userinfo.isSMS != 1 ? CheckState.Unchecked : CheckState.Checked;
      }
    }

    private string GetYesNO(int level)
    {
      switch (level)
      {
        case 0:
          return "NO";
        case 1:
          return "YES";
        default:
          return "YES";
      }
    }

    public void BindGird()
    {
      this.dgvUserprofile.Rows.Clear();
      foreach (KeyValuePair<string, Userinfo> keyValuePair in this.objdash._Userinformation)
      {
        Userinfo userinfo = keyValuePair.Value;
        if (!(userinfo.createdby != this.objdash.objinfo.clientcode))
        {
          int index = this.dgvUserprofile.Rows.Add();
          this.dgvUserprofile.Rows[index].Cells[0].Value = (object) this.objdash.GetUsertype(userinfo.usertype);
          this.dgvUserprofile.Rows[index].Cells[1].Value = (object) userinfo.name;
          this.dgvUserprofile.Rows[index].Cells[2].Value = (object) userinfo.clientcode;
          this.dgvUserprofile.Rows[index].Cells[3].Value = (object) userinfo.username;
          this.dgvUserprofile.Rows[index].Cells[4].Value = (object) userinfo.password;
          this.dgvUserprofile.Rows[index].Cells[5].Value = (object) this.GetYesNO(userinfo.pivots);
          this.dgvUserprofile.Rows[index].Cells[6].Value = (object) this.GetYesNO(userinfo.stockperform);
          this.dgvUserprofile.Rows[index].Cells[7].Value = (object) this.GetYesNO(userinfo.charts);
          this.dgvUserprofile.Rows[index].Cells[8].Value = userinfo.userstatus != 1 ? (object) "Disabled" : (object) "Enabled";
          this.dgvUserprofile.Rows[index].Cells[9].Value = userinfo.marginstatus != 1 ? (object) "Blocked" : (object) "Released";
          this.dgvUserprofile.Rows[index].Cells[10].Value = (object) userinfo.exchange;
          this.dgvUserprofile.Rows[index].Cells[11].Value = (object) userinfo.regdate;
          this.dgvUserprofile.Rows[index].Cells[12].Value = (object) this.GetYesNO(userinfo.offset);
          this.dgvUserprofile.Rows[index].Cells[13].Value = (object) this.GetYesNO(userinfo.oddlot);
          this.dgvUserprofile.Rows[index].Cells[14].Value = (object) userinfo.AppName;
          this.dgvUserprofile.Rows[index].Cells[15].Value = (object) userinfo.DIpflsPercent;
        }
      }
    }

    private void btnModify_Click(object sender, EventArgs e)
    {
      int num1 = 0;
      int num2 = 0;
      int num3 = 0;
      int num4 = 0;
      int num5 = 0;
      int result = 0;
      int num6 = 0;
      string empty1 = string.Empty;
      long num7 = 0;
      FormValidator formValidator = new FormValidator();
      string str1 = string.Empty;
      string str2 = string.Empty;
      if (this.txtpassword.Text == string.Empty)
        empty1 += "Enter Password \n";
      if (this.txtpassword.Text == this.txtusername.Text)
        empty1 += "Password cannot be same as Username \n";
      if (this.txtAppName.Text == string.Empty)
        empty1 += "Enter App Name \n";
      if (this.txtEmailid.Text != string.Empty && !formValidator.ValidateEmail(this.txtEmailid.Text))
        empty1 += "Enter Valid email id\n";
      if (this.txtMobNo.Text != string.Empty && !formValidator.ValidateIsNumeric(this.txtMobNo.Text))
        empty1 += "Enter Valid Mobile No\n";
      string str3 = this.Getexch();
      if (str3 == string.Empty)
        empty1 += "Select atleast One Exchange \n";
      if (this.cmbUsertype.Text == "DealerAdmin" && !int.TryParse(this.txtPflsPercent.Text, out result))
        empty1 += "Please enter correct Profit/Loss % \n";
      if (this.cmbUsertype.Text.ToUpper() == "DEALER" && this.textBoxDIPFLS.Text == string.Empty)
        empty1 += "DI ProfitLoss%  \n";
      if (this.chkPivots.Checked)
        num1 = 1;
      if (this.chkCharts.Checked)
        num2 = 1;
      if (this.chkStckPerfm.Checked)
        num3 = 1;
      if (this.chkOddLot.Checked)
        num4 = 1;
      if (this.chkOffset.Checked)
      {
        num5 = 1;
        if (this.chkMCX.Checked)
          str1 += "MCX,";
        if (this.chkNSEFUT.Checked)
          str1 += "NSEFUT,";
        if (this.chkNCDEX.Checked)
          str1 += "NCDEX,";
        if (this.chkNSECURR.Checked)
          str1 += "NSECURR,";
        if (str1.Length > 0)
          str1 = str1.Substring(0, str1.Length - 1);
        else
          empty1 += "Select atleast one Offset Exchange \n";
      }
      if (this.chkHighLowTrading.Checked)
      {
        num6 = 1;
        if (this.chkHLmcx.Checked)
          str2 += "MCX,";
        if (this.chkHLnsefut.Checked)
          str2 += "NSEFUT,";
        if (this.chkHLncdex.Checked)
          str2 += "NCDEX,";
        if (this.chkHLnsecurr.Checked)
          str2 += "NSECURR,";
        if (str2.Length > 0)
          str2 = str2.Substring(0, str2.Length - 1);
        else
          empty1 += "Select atleast one High/Low Trading Exchange \n";
      }
      int num8 = !this.chk_SendSMS.Checked ? 0 : 1;
      int num9 = !this.chkModTrd.Checked ? 0 : 1;
      if (this.txtMobNo.Text != string.Empty)
        num7 = Convert.ToInt64(this.txtMobNo.Text);
      if (empty1 == string.Empty)
      {
        string cmdText = string.Empty;
        DateTime now = DateTime.Now;
        string empty2 = string.Empty;
        if (this.cmbUsertype.SelectedIndex == 1)
          cmdText = string.Format("Update Userinformation SET Name = '{0}',Password = '{1}', exchanges = '{2}',pivots = {3}, stockperform = {4}, charts = {5},Oddlot = {6},AppName = '{7}',Offset = {8},isModTrdOpt = {9},DApfls = {10}, Emailid = '{11}',Mobno = {12},OffsetExch = '{13}',isHighLowTrding = {14},HighLowExch = '{15}' , isSMS = {16}   where Clientcode = '{17}'", (object) this.txtname.Text, (object) this.objdash.Encryptdata(this.txtpassword.Text), (object) str3, (object) num1, (object) num3, (object) num2, (object) num4, (object) this.txtAppName.Text.Trim(), (object) num5, (object) num9, (object) result, (object) this.txtEmailid.Text, (object) num7, (object) str1, (object) num6, (object) str2, (object) num8, (object) this.txtclientcode.Text);
        if (this.cmbUsertype.SelectedIndex == 0)
          cmdText = string.Format("Update Userinformation SET Name = '{0}',Password = '{1}', exchanges = '{2}',pivots = {3}, stockperform = {4}, charts = {5},Oddlot = {6},AppName = '{7}',Offset = {8},isModTrdOpt = {9},DApfls = {10}, Emailid = '{11}',Mobno = {12},OffsetExch = '{13}',isHighLowTrding = {14},HighLowExch = '{15}' , isSMS = {16},DIpfls={18}    where Clientcode = '{17}'", (object) this.txtname.Text, (object) this.objdash.Encryptdata(this.txtpassword.Text), (object) str3, (object) num1, (object) num3, (object) num2, (object) num4, (object) this.txtAppName.Text.Trim(), (object) num5, (object) num9, (object) result, (object) this.txtEmailid.Text, (object) num7, (object) str1, (object) num6, (object) str2, (object) num8, (object) this.txtclientcode.Text, (object) this.textBoxDIPFLS.Text);
        using (SqlCommand sqlCommand = new SqlCommand(cmdText, this.conn))
        {
          if (sqlCommand.ExecuteNonQuery() != 1)
            return;
          this.objdash.DisplayMessage(empty1 + "Record Modified Successfully!!", 1);
          if (this.objdash._Userinformation.ContainsKey(this.txtclientcode.Text))
          {
            Userinfo userinfo = this.objdash._Userinformation[this.txtclientcode.Text];
            userinfo.name = this.txtname.Text;
            userinfo.password = this.objdash.Encryptdata(this.txtpassword.Text);
            userinfo.exchange = str3;
            userinfo.pivots = num1;
            userinfo.stockperform = num3;
            userinfo.charts = num2;
            userinfo.oddlot = num4;
            userinfo.AppName = this.txtAppName.Text.Trim();
            userinfo.offset = num5;
            userinfo.DApflsPercent = result;
            userinfo.emailid = this.txtEmailid.Text;
            userinfo.OffsetExch = str1;
            userinfo.isHLTrading = num6;
            userinfo.HighLowExch = str2;
            userinfo.DIpflsPercent = Convert.ToInt32(this.textBoxDIPFLS.Text);
            if (this.txtMobNo.Text != string.Empty)
              userinfo.Mobno = Convert.ToInt64(this.txtMobNo.Text);
            userinfo.isModTrd = num9;
            this.objdash._Userinformation[this.txtclientcode.Text] = userinfo;
          }
          this.BindGird();
          this.ClearControls((Control) this);
        }
      }
      else
        this.objdash.DisplayMessage(empty1 + "These Fields are Mandatory", 2);
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
      this.btnDelete.Enabled = false;
      this.lblProgress.Visible = true;
      Application.DoEvents();
      if (this.txtclientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select Record to delete.", 2);
      if (this.objdash.objinfo.usertype != 1)
        ;
      if (MessageBox.Show("Do you really want to delete this Record?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
      {
        if (this.objdash.objinfo.usertype == 2)
          this.DeleteClientData(this.txtclientcode.Text);
        else if (this.objdash.objinfo.usertype == 1)
          this.DeleteLowerHierarchyData(this.txtclientcode.Text);
        using (SqlCommand sqlCommand = new SqlCommand(string.Format("Delete from Userinformation where Clientcode = '{0}'", (object) this.txtclientcode.Text), this.conn))
        {
          if (sqlCommand.ExecuteNonQuery() == 1)
          {
            this.objdash.DisplayMessage("Record Deleted Successfully!!", 1);
            Utils.SaveMiscLogs(this.objdash.objinfo.clientcode, string.Format("User: {0} deleted by: {1}", (object) this.txtclientcode.Text, (object) this.objdash.objinfo.clientcode), this.conn);
            if (this.objdash._Userinformation.ContainsKey(this.txtclientcode.Text))
              this.objdash._Userinformation.Remove(this.txtclientcode.Text);
            if (this.objdash._lstAccounts.Contains(this.txtclientcode.Text))
              this.objdash._lstAccounts.Remove(this.txtclientcode.Text);
            this.BindGird();
          }
          else
            this.objdash.DisplayMessage("Unable to Delete Record", 3);
        }
      }
      this.btnDelete.Enabled = true;
      this.lblProgress.Visible = false;
    }

    private void btnEnable_Click(object sender, EventArgs e)
    {
      if (this.txtclientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select User to Enable.", 2);
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Update Userinformation SET Userstatus = 1 where Clientcode = '{0}'", (object) this.txtclientcode.Text), this.conn))
      {
        if (sqlCommand.ExecuteNonQuery() == 1)
        {
          this.objdash.DisplayMessage("User Enabled Successfully!!", 1);
          if (this.objdash._Userinformation.ContainsKey(this.txtclientcode.Text))
          {
            Userinfo userinfo = this.objdash._Userinformation[this.txtclientcode.Text];
            userinfo.userstatus = 1;
            this.objdash._Userinformation[this.txtclientcode.Text] = userinfo;
          }
          this.BindGird();
        }
        else
          this.objdash.DisplayMessage("Unable to Enable User", 3);
      }
    }

    private void btndisable_Click(object sender, EventArgs e)
    {
      Application.DoEvents();
      if (this.txtclientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select User to Disable.", 2);
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Update Userinformation SET Userstatus = 0 where Clientcode = '{0}'", (object) this.txtclientcode.Text), this.conn))
      {
        if (sqlCommand.ExecuteNonQuery() == 1)
        {
          this.objdash.DisplayMessage("User Disabled Successfully!!", 1);
          if (this.objdash._Userinformation.ContainsKey(this.txtclientcode.Text))
          {
            Userinfo userinfo = this.objdash._Userinformation[this.txtclientcode.Text];
            userinfo.userstatus = 0;
            this.objdash._Userinformation[this.txtclientcode.Text] = userinfo;
          }
          this.BindGird();
        }
        else
          this.objdash.DisplayMessage("Unable to Disable User", 3);
      }
    }

    private void DeleteLowerHierarchyData(string deletecode)
    {
      string clientCodes = this.objdash.GetClientCodes(2, deletecode);
      if (!(clientCodes != string.Empty))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Brokerage where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where ClientCode = '" + clientCodes + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from ExchwiseMarginLots where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from IntraSqOffTiming where ClientCode = '" + deletecode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset_History where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from LogIn_OffReports where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageBoard where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs_History where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified_History where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Offset where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Offset where ClientCode = '" + deletecode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders_History where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Payin_Payout where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Profit_Loss_Archive where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from RejectionMessages where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from SymbolwiseMargin where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from SymbolwiseMargin where ClientCode = '" + deletecode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade_History where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from TurnoverUtilised where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(300);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Userinformation where ClientCode in (" + clientCodes + ")", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    private void DeleteClientData(string clientcode)
    {
      if (!(clientcode != string.Empty))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Brokerage where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from ExchwiseMarginLots where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset_History where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from LogIn_OffReports where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageBoard where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs_History where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified_History where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Offset where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders_History where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Payin_Payout where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Profit_Loss_Archive where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from RejectionMessages where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from SymbolwiseMargin where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade_History where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
      Thread.Sleep(100);
      using (SqlCommand sqlCommand = new SqlCommand("Delete from TurnoverUtilised where ClientCode = '" + clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    private void btnBlockMargin_Click(object sender, EventArgs e)
    {
      if (this.txtclientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select User to Block Margin.", 2);
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Update Userinformation SET Marginstatus = 0 where Clientcode = '{0}'", (object) this.txtclientcode.Text), this.conn))
      {
        if (sqlCommand.ExecuteNonQuery() == 1)
        {
          this.objdash.DisplayMessage("Margin Blocked Successfully!!", 1);
          if (this.objdash._Userinformation.ContainsKey(this.txtclientcode.Text))
          {
            Userinfo userinfo = this.objdash._Userinformation[this.txtclientcode.Text];
            userinfo.marginstatus = 0;
            this.objdash._Userinformation[this.txtclientcode.Text] = userinfo;
          }
          this.BindGird();
        }
        else
          this.objdash.DisplayMessage("Unable to Block Margin", 3);
      }
    }

    private void btnReleaseMrgn_Click(object sender, EventArgs e)
    {
      if (this.txtclientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select User to Release Margin.", 2);
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("Update Userinformation SET Marginstatus = 1 where Clientcode = '{0}'", (object) this.txtclientcode.Text), this.conn))
      {
        if (sqlCommand.ExecuteNonQuery() == 1)
        {
          this.objdash.DisplayMessage("Margin Released Successfully!!", 1);
          if (this.objdash._Userinformation.ContainsKey(this.txtclientcode.Text))
          {
            Userinfo userinfo = this.objdash._Userinformation[this.txtclientcode.Text];
            userinfo.marginstatus = 1;
            this.objdash._Userinformation[this.txtclientcode.Text] = userinfo;
          }
          this.BindGird();
        }
        else
          this.objdash.DisplayMessage("Unable to Release Margin", 3);
      }
    }

    private void dgvUserprofile_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task1_Click));
      Point client = this.dgvUserprofile.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvUserprofile, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.dgvUserprofile.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvUserprofile, false);
    }

    private void cmbUsertype_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.ClearControls((Control) this);
      if (this.cmbUsertype.Text.ToUpper() == "DEALER")
      {
        this.chkExchList.Visible = false;
        this.label6.Visible = false;
        this.chkOddLot.Visible = false;
        this.groupBox2.Visible = false;
        this.chkOffset.Visible = false;
        this.chkHighLowTrading.Visible = false;
        if (this.objdash.objinfo.isModTrd == 1)
        {
          this.chkModTrd.Visible = true;
          this.chkModTrd.Location = new Point(70, 206);
        }
        else
          this.chkModTrd.Visible = false;
        this.lblpfls.Visible = false;
        this.txtPflsPercent.Visible = false;
        this.lblDAfund.Visible = false;
        this.txtDAfund.Visible = false;
        this.textBoxDIPFLS.Visible = true;
        this.DIPLF.Visible = true;
        this.txtMobNo.Size = new Size(126, 20);
        this.chk_SendSMS.Visible = false;
      }
      else if (this.cmbUsertype.Text.ToUpper() == "CLIENT")
      {
        this.chkExchList.Visible = true;
        this.label6.Visible = true;
        this.chkOddLot.Visible = true;
        this.groupBox2.Visible = false;
        this.chkOffset.Visible = true;
        this.chkHighLowTrading.Visible = true;
        this.lblpfls.Visible = false;
        this.txtPflsPercent.Visible = false;
        this.lblDAfund.Visible = false;
        this.txtDAfund.Visible = false;
        this.chkModTrd.Visible = false;
        this.textBoxDIPFLS.Visible = false;
        this.DIPLF.Visible = false;
        if (this.objdash.objinfo.isSMS == 1)
        {
          this.txtMobNo.Size = new Size(89, 20);
          this.chk_SendSMS.Visible = true;
        }
        else
        {
          this.txtMobNo.Size = new Size(126, 20);
          this.chk_SendSMS.Visible = false;
        }
      }
      else
      {
        this.chkExchList.Visible = true;
        this.label6.Visible = true;
        this.groupBox2.Visible = false;
        this.chkOddLot.Visible = false;
        this.chkOffset.Visible = false;
        this.chkHighLowTrading.Visible = false;
        this.lblpfls.Visible = true;
        this.txtPflsPercent.Visible = true;
        this.lblDAfund.Visible = true;
        this.txtDAfund.Visible = true;
        this.chkModTrd.Visible = true;
        this.chkModTrd.Location = new Point(70, 333);
      }
      if (this.cmbUsertype.Text.ToUpper() == "CLIENT")
      {
        this.btnBlockMargin.Enabled = true;
        this.btnReleaseMrgn.Enabled = true;
      }
      else
      {
        this.btnBlockMargin.Enabled = false;
        this.btnReleaseMrgn.Enabled = false;
      }
      this.txtAppName.Text = this.objdash.objinfo.AppName;
    }

    private void txtNameSearch_TextChanged(object sender, EventArgs e)
    {
      this.txtClientcodeSearch.Text = "";
      this.txtUsernameSearch.Text = "";
      if (this.txtNameSearch.Text.Length > 0)
        this.FilterUsers(1, this.txtNameSearch.Text.Trim(), 1);
      else
        this.FilterUsers(0, "", 0);
    }

    private void FilterUsers(int cell, string text, int type)
    {
      if (type == 1)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvUserprofile.Rows)
        {
          if (row.Cells[cell].Value.ToString().StartsWith(text, StringComparison.CurrentCultureIgnoreCase))
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvUserprofile.Rows)
          row.Visible = true;
      }
    }

    private void txtClientcodeSearch_TextChanged(object sender, EventArgs e)
    {
      this.txtNameSearch.Text = "";
      this.txtUsernameSearch.Text = "";
      if (this.txtClientcodeSearch.Text.Length > 0)
        this.FilterUsers(2, this.txtClientcodeSearch.Text.Trim(), 1);
      else
        this.FilterUsers(0, "", 0);
    }

    private void txtUsernameSearch_TextChanged(object sender, EventArgs e)
    {
      this.txtNameSearch.Text = "";
      this.txtClientcodeSearch.Text = "";
      if (this.txtUsernameSearch.Text.Length > 0)
        this.FilterUsers(3, this.txtUsernameSearch.Text.Trim(), 1);
      else
        this.FilterUsers(0, "", 0);
    }

    private void btnSet_Click(object sender, EventArgs e)
    {
      if (this.txtclientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select Client code to SET App Name.", 2);
      else if (this.txtAppName.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter App Name to SET.", 2);
      }
      else
      {
        string key = this.txtclientcode.Text.Trim();
        if (this.objdash.objinfo.usertype == 1)
        {
          if (this.conn.State == ConnectionState.Open)
          {
            using (SqlCommand sqlCommand1 = new SqlCommand("Update Userinformation SET AppName = '" + this.txtAppName.Text.Trim() + "' where Clientcode = '" + key + "' ", this.conn))
            {
              try
              {
                this.btnSet.Enabled = false;
                sqlCommand1.ExecuteNonQuery();
                this.objdash.DisplayMessage("App Name Updated Successfully!!", 1);
                this.btnSet.Enabled = true;
                this.dgvUserprofile.Rows[this.rowindex].Cells[14].Value = (object) this.txtAppName.Text.Trim();
                using (SqlCommand sqlCommand2 = new SqlCommand("Update Userinformation SET AppName = '" + this.txtAppName.Text.Trim() + "' where Createdby = '" + key + "' ", this.conn))
                  sqlCommand2.ExecuteNonQuery();
              }
              catch
              {
                this.objdash.DisplayMessage("Unable to update record", 3);
              }
            }
          }
        }
        else if (this.conn.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Update Userinformation SET AppName = '" + this.txtAppName.Text.Trim() + "' where ClientCode = '" + key + "'", this.conn))
          {
            try
            {
              this.btnSet.Enabled = false;
              sqlCommand.ExecuteNonQuery();
              this.objdash.DisplayMessage("App Name Updated Successfully!!", 1);
              this.btnSet.Enabled = true;
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to update record", 3);
            }
          }
        }
        if (!this.objdash._Userinformation.ContainsKey(key))
          return;
        Userinfo userinfo = this.objdash._Userinformation[key];
        userinfo.AppName = this.txtAppName.Text.Trim();
        this.objdash._Userinformation[key] = userinfo;
      }
    }

    private void btnUploadImage_Click(object sender, EventArgs e)
    {
      OpenFileDialog openFileDialog1 = new OpenFileDialog();
      openFileDialog1.CheckPathExists = true;
      openFileDialog1.Filter = "(*.ICO)|*.ico";
      openFileDialog1.Title = "Browse XML file";
      OpenFileDialog openFileDialog2 = openFileDialog1;
      if (openFileDialog2.ShowDialog() == DialogResult.Cancel)
        return;
      this.pictureBox1.ImageLocation = openFileDialog2.FileName;
      this.txtImagePath.Text = openFileDialog2.FileName;
    }

    private byte[] ReadFile(string sPath)
    {
      long length = new FileInfo(sPath).Length;
      return new BinaryReader((Stream) new FileStream(sPath, FileMode.Open, FileAccess.Read)).ReadBytes((int) length);
    }

    private void Uploadicon()
    {
      try
      {
        byte[] numArray = this.ReadFile(this.txtImagePath.Text);
        new SqlCommand("Update Userinformation SET icon = @ImageData where Clientcode = @clientcode", this.conn)
        {
          Parameters = {
            new SqlParameter("@clientcode", (object) this.txtclientcode.Text),
            new SqlParameter("@ImageData", (object) numArray)
          }
        }.ExecuteNonQuery();
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show(ex.ToString());
      }
    }

    private void button1_Click(object sender, EventArgs e)
    {
    }

    private void RetrieveIcon(string clientcode)
    {
      SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
      sqlDataAdapter.SelectCommand = new SqlCommand("Select icon from Userinformation where Clientcode = '" + clientcode + "'", this.conn);
      DataSet dataSet = new DataSet("Dset");
      sqlDataAdapter.Fill(dataSet);
      DataTable table = dataSet.Tables[0];
      if (this.pictureBox1.Image != null)
        this.pictureBox1.Image.Dispose();
      FileStream fileStream = new FileStream("logo.ico", FileMode.Create);
      byte[] buffer = (byte[]) table.Rows[0][0];
      fileStream.Write(buffer, 0, buffer.Length);
      fileStream.Close();
      this.pictureBox1.Image = Image.FromFile("logo.ico");
      this.pictureBox1.Refresh();
    }

    private void chkOffset_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkOffset.Checked)
        this.grpOffsetExch.Visible = true;
      else
        this.grpOffsetExch.Visible = false;
    }

    private void chkHighLowTrading_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkHighLowTrading.Checked)
        this.grpHighLowExch.Visible = true;
      else
        this.grpHighLowExch.Visible = false;
    }

    private void chkMCX_Click(object sender, EventArgs e)
    {
      if (!this.chkMCX.Checked || !this.chkHLmcx.Checked)
        return;
      this.objdash.DisplayMessage("MCX already selected in High Low Trading option", 2);
      this.chkMCX.Checked = false;
    }

    private void chkNSEFUT_Click(object sender, EventArgs e)
    {
      if (!this.chkNSEFUT.Checked || !this.chkHLnsefut.Checked)
        return;
      this.objdash.DisplayMessage("NSEFUT already selected in High Low Trading option", 2);
      this.chkNSEFUT.Checked = false;
    }

    private void chkNCDEX_Click(object sender, EventArgs e)
    {
      if (!this.chkNCDEX.Checked || !this.chkHLncdex.Checked)
        return;
      this.objdash.DisplayMessage("NCDEX already selected in High Low Trading option", 2);
      this.chkNCDEX.Checked = false;
    }

    private void chkNSECURR_Click(object sender, EventArgs e)
    {
      if (!this.chkNSECURR.Checked || !this.chkHLnsecurr.Checked)
        return;
      this.objdash.DisplayMessage("NSECURR already selected in High Low Trading option", 2);
      this.chkNSECURR.Checked = false;
    }

    private void chkHLmcx_Click(object sender, EventArgs e)
    {
      if (!this.chkHLmcx.Checked || !this.chkMCX.Checked)
        return;
      this.objdash.DisplayMessage("MCX already selected in High Low Trading option", 2);
      this.chkHLmcx.Checked = false;
    }

    private void chkHLnsefut_Click(object sender, EventArgs e)
    {
      if (!this.chkHLnsefut.Checked || !this.chkNSEFUT.Checked)
        return;
      this.objdash.DisplayMessage("NSEFUT already selected in High Low Trading option", 2);
      this.chkHLnsefut.Checked = false;
    }

    private void chkHLncdex_Click(object sender, EventArgs e)
    {
      if (!this.chkHLncdex.Checked || !this.chkNCDEX.Checked)
        return;
      this.objdash.DisplayMessage("NCDEX already selected in High Low Trading option", 2);
      this.chkHLncdex.Checked = false;
    }

    private void chkHLnsecurr_Click(object sender, EventArgs e)
    {
      if (!this.chkHLnsecurr.Checked || !this.chkNSECURR.Checked)
        return;
      this.objdash.DisplayMessage("NSECURR already selected in High Low Trading option", 2);
      this.chkHLnsecurr.Checked = false;
    }

    private bool ValidateClientcodeandUsername(string clientcode, string username, ref string msg)
    {
      SqlConnection conn = this.objdash.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("Select Count(ID) from Userinformation where Clientcode = '" + clientcode + "'", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (sqlDataReader.GetInt32(0) > 0)
            {
              msg = "Clientcode already exists.";
              return false;
            }
          }
        }
      }
      using (SqlCommand sqlCommand = new SqlCommand("Select Count(ID) from Userinformation where Username = '" + username + "'", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (sqlDataReader.GetInt32(0) > 0)
            {
              msg = "Username already exists.";
              return false;
            }
          }
        }
      }
      return true;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.chk_SendSMS = new CheckBox();
      this.txtDAfund = new TextBox();
      this.lblDAfund = new Label();
      this.grpHighLowExch = new GroupBox();
      this.chkHLnsecurr = new CheckBox();
      this.chkHLncdex = new CheckBox();
      this.chkHLnsefut = new CheckBox();
      this.chkHLmcx = new CheckBox();
      this.chkHighLowTrading = new CheckBox();
      this.chkModTrd = new CheckBox();
      this.grpOffsetExch = new GroupBox();
      this.chkNSECURR = new CheckBox();
      this.chkNCDEX = new CheckBox();
      this.chkNSEFUT = new CheckBox();
      this.chkMCX = new CheckBox();
      this.txtMobNo = new TextBox();
      this.label10 = new Label();
      this.txtEmailid = new TextBox();
      this.label11 = new Label();
      this.txtPflsPercent = new TextBox();
      this.lblpfls = new Label();
      this.button1 = new Button();
      this.txtImagePath = new TextBox();
      this.lblProgress = new Label();
      this.btnSet = new Button();
      this.txtAppName = new TextBox();
      this.label7 = new Label();
      this.chkOffset = new CheckBox();
      this.chkOddLot = new CheckBox();
      this.label6 = new Label();
      this.chkExchList = new CheckedListBox();
      this.groupBox2 = new GroupBox();
      this.chkCharts = new CheckBox();
      this.chkStckPerfm = new CheckBox();
      this.chkPivots = new CheckBox();
      this.txtpassword = new TextBox();
      this.label5 = new Label();
      this.txtusername = new TextBox();
      this.label4 = new Label();
      this.txtclientcode = new TextBox();
      this.label3 = new Label();
      this.txtname = new TextBox();
      this.label2 = new Label();
      this.cmbUsertype = new ComboBox();
      this.label1 = new Label();
      this.label9 = new Label();
      this.pictureBox1 = new PictureBox();
      this.btnUploadImage = new Button();
      this.dgvUserprofile = new DataGridView();
      this.usertype = new DataGridViewTextBoxColumn();
      this.UName = new DataGridViewTextBoxColumn();
      this.Clientcode = new DataGridViewTextBoxColumn();
      this.Username = new DataGridViewTextBoxColumn();
      this.Password = new DataGridViewTextBoxColumn();
      this.Pivots = new DataGridViewTextBoxColumn();
      this.StocksPerfor = new DataGridViewTextBoxColumn();
      this.Charting = new DataGridViewTextBoxColumn();
      this.Userstatus = new DataGridViewTextBoxColumn();
      this.Marginstatus = new DataGridViewTextBoxColumn();
      this.Exchnage = new DataGridViewTextBoxColumn();
      this.RegDate = new DataGridViewTextBoxColumn();
      this.ColOffset = new DataGridViewTextBoxColumn();
      this.colOddLot = new DataGridViewTextBoxColumn();
      this.ColAppName = new DataGridViewTextBoxColumn();
      this.DIComm = new DataGridViewTextBoxColumn();
      this.btnAdd = new Button();
      this.btnModify = new Button();
      this.btnDelete = new Button();
      this.btnLogoff = new Button();
      this.btnReleaseMrgn = new Button();
      this.btnBlockMargin = new Button();
      this.btndisable = new Button();
      this.btnEnable = new Button();
      this.label8 = new Label();
      this.txtNameSearch = new TextBox();
      this.txtClientcodeSearch = new TextBox();
      this.txtUsernameSearch = new TextBox();
      this.DIPLF = new Label();
      this.textBoxDIPFLS = new TextBox();
      this.groupBox1.SuspendLayout();
      this.grpHighLowExch.SuspendLayout();
      this.grpOffsetExch.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      ((ISupportInitialize) this.dgvUserprofile).BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.chk_SendSMS);
      this.groupBox1.Controls.Add((Control) this.txtDAfund);
      this.groupBox1.Controls.Add((Control) this.lblDAfund);
      this.groupBox1.Controls.Add((Control) this.grpHighLowExch);
      this.groupBox1.Controls.Add((Control) this.chkHighLowTrading);
      this.groupBox1.Controls.Add((Control) this.chkModTrd);
      this.groupBox1.Controls.Add((Control) this.grpOffsetExch);
      this.groupBox1.Controls.Add((Control) this.txtMobNo);
      this.groupBox1.Controls.Add((Control) this.label10);
      this.groupBox1.Controls.Add((Control) this.txtEmailid);
      this.groupBox1.Controls.Add((Control) this.label11);
      this.groupBox1.Controls.Add((Control) this.txtPflsPercent);
      this.groupBox1.Controls.Add((Control) this.lblpfls);
      this.groupBox1.Controls.Add((Control) this.button1);
      this.groupBox1.Controls.Add((Control) this.txtImagePath);
      this.groupBox1.Controls.Add((Control) this.lblProgress);
      this.groupBox1.Controls.Add((Control) this.btnSet);
      this.groupBox1.Controls.Add((Control) this.txtAppName);
      this.groupBox1.Controls.Add((Control) this.label7);
      this.groupBox1.Controls.Add((Control) this.chkOffset);
      this.groupBox1.Controls.Add((Control) this.chkOddLot);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.chkExchList);
      this.groupBox1.Controls.Add((Control) this.groupBox2);
      this.groupBox1.Controls.Add((Control) this.txtpassword);
      this.groupBox1.Controls.Add((Control) this.label5);
      this.groupBox1.Controls.Add((Control) this.txtusername);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.txtclientcode);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.txtname);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.cmbUsertype);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(6, 4);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(213, 446);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Basic Details";
      this.chk_SendSMS.AutoSize = true;
      this.chk_SendSMS.Location = new Point(160, 109);
      this.chk_SendSMS.Name = "chk_SendSMS";
      this.chk_SendSMS.Size = new Size(49, 17);
      this.chk_SendSMS.TabIndex = 25;
      this.chk_SendSMS.Text = "SMS";
      this.chk_SendSMS.UseVisualStyleBackColor = true;
      this.chk_SendSMS.Visible = false;
      this.txtDAfund.Location = new Point(71, 309);
      this.txtDAfund.MaxLength = 10;
      this.txtDAfund.Name = "txtDAfund";
      this.txtDAfund.Size = new Size(126, 20);
      this.txtDAfund.TabIndex = 24;
      this.txtDAfund.Visible = false;
      this.lblDAfund.AutoSize = true;
      this.lblDAfund.Location = new Point(6, 311);
      this.lblDAfund.Name = "lblDAfund";
      this.lblDAfund.Size = new Size(52, 13);
      this.lblDAfund.TabIndex = 23;
      this.lblDAfund.Text = "DA Fund:";
      this.lblDAfund.Visible = false;
      this.grpHighLowExch.Controls.Add((Control) this.chkHLnsecurr);
      this.grpHighLowExch.Controls.Add((Control) this.chkHLncdex);
      this.grpHighLowExch.Controls.Add((Control) this.chkHLnsefut);
      this.grpHighLowExch.Controls.Add((Control) this.chkHLmcx);
      this.grpHighLowExch.Location = new Point(10, 391);
      this.grpHighLowExch.Name = "grpHighLowExch";
      this.grpHighLowExch.Size = new Size(200, 48);
      this.grpHighLowExch.TabIndex = 22;
      this.grpHighLowExch.TabStop = false;
      this.grpHighLowExch.Text = "High_Low Exchanges";
      this.grpHighLowExch.Visible = false;
      this.chkHLnsecurr.AutoSize = true;
      this.chkHLnsecurr.Location = new Point(87, 29);
      this.chkHLnsecurr.Name = "chkHLnsecurr";
      this.chkHLnsecurr.Size = new Size(79, 17);
      this.chkHLnsecurr.TabIndex = 15;
      this.chkHLnsecurr.Text = "NSECURR";
      this.chkHLnsecurr.UseVisualStyleBackColor = true;
      this.chkHLnsecurr.Click += new EventHandler(this.chkHLnsecurr_Click);
      this.chkHLncdex.AutoSize = true;
      this.chkHLncdex.Location = new Point(12, 31);
      this.chkHLncdex.Name = "chkHLncdex";
      this.chkHLncdex.Size = new Size(63, 17);
      this.chkHLncdex.TabIndex = 14;
      this.chkHLncdex.Text = "NCDEX";
      this.chkHLncdex.UseVisualStyleBackColor = true;
      this.chkHLncdex.Click += new EventHandler(this.chkHLncdex_Click);
      this.chkHLnsefut.AutoSize = true;
      this.chkHLnsefut.Location = new Point(87, 13);
      this.chkHLnsefut.Name = "chkHLnsefut";
      this.chkHLnsefut.Size = new Size(69, 17);
      this.chkHLnsefut.TabIndex = 13;
      this.chkHLnsefut.Text = "NSEFUT";
      this.chkHLnsefut.UseVisualStyleBackColor = true;
      this.chkHLnsefut.Click += new EventHandler(this.chkHLnsefut_Click);
      this.chkHLmcx.AutoSize = true;
      this.chkHLmcx.Location = new Point(12, 13);
      this.chkHLmcx.Name = "chkHLmcx";
      this.chkHLmcx.Size = new Size(49, 17);
      this.chkHLmcx.TabIndex = 12;
      this.chkHLmcx.Text = "MCX";
      this.chkHLmcx.UseVisualStyleBackColor = true;
      this.chkHLmcx.Click += new EventHandler(this.chkHLmcx_Click);
      this.chkHighLowTrading.AutoSize = true;
      this.chkHighLowTrading.Location = new Point(10, 375);
      this.chkHighLowTrading.Name = "chkHighLowTrading";
      this.chkHighLowTrading.Size = new Size(113, 17);
      this.chkHighLowTrading.TabIndex = 21;
      this.chkHighLowTrading.Text = "High_Low Trading";
      this.chkHighLowTrading.UseVisualStyleBackColor = true;
      this.chkHighLowTrading.CheckedChanged += new EventHandler(this.chkHighLowTrading_CheckedChanged);
      this.chkModTrd.AutoSize = true;
      this.chkModTrd.Location = new Point(70, 206);
      this.chkModTrd.Name = "chkModTrd";
      this.chkModTrd.Size = new Size(116, 17);
      this.chkModTrd.TabIndex = 12;
      this.chkModTrd.Text = "Allow Modify Trade";
      this.chkModTrd.UseVisualStyleBackColor = true;
      this.chkModTrd.Visible = false;
      this.grpOffsetExch.Controls.Add((Control) this.chkNSECURR);
      this.grpOffsetExch.Controls.Add((Control) this.chkNCDEX);
      this.grpOffsetExch.Controls.Add((Control) this.chkNSEFUT);
      this.grpOffsetExch.Controls.Add((Control) this.chkMCX);
      this.grpOffsetExch.Location = new Point(8, 325);
      this.grpOffsetExch.Name = "grpOffsetExch";
      this.grpOffsetExch.Size = new Size(200, 48);
      this.grpOffsetExch.TabIndex = 12;
      this.grpOffsetExch.TabStop = false;
      this.grpOffsetExch.Text = "Offset Exchanges";
      this.grpOffsetExch.Visible = false;
      this.chkNSECURR.AutoSize = true;
      this.chkNSECURR.Location = new Point(87, 29);
      this.chkNSECURR.Name = "chkNSECURR";
      this.chkNSECURR.Size = new Size(79, 17);
      this.chkNSECURR.TabIndex = 15;
      this.chkNSECURR.Text = "NSECURR";
      this.chkNSECURR.UseVisualStyleBackColor = true;
      this.chkNSECURR.Click += new EventHandler(this.chkNSECURR_Click);
      this.chkNCDEX.AutoSize = true;
      this.chkNCDEX.Location = new Point(12, 30);
      this.chkNCDEX.Name = "chkNCDEX";
      this.chkNCDEX.Size = new Size(63, 17);
      this.chkNCDEX.TabIndex = 14;
      this.chkNCDEX.Text = "NCDEX";
      this.chkNCDEX.UseVisualStyleBackColor = true;
      this.chkNCDEX.Click += new EventHandler(this.chkNCDEX_Click);
      this.chkNSEFUT.AutoSize = true;
      this.chkNSEFUT.Location = new Point(87, 13);
      this.chkNSEFUT.Name = "chkNSEFUT";
      this.chkNSEFUT.Size = new Size(69, 17);
      this.chkNSEFUT.TabIndex = 13;
      this.chkNSEFUT.Text = "NSEFUT";
      this.chkNSEFUT.UseVisualStyleBackColor = true;
      this.chkNSEFUT.Click += new EventHandler(this.chkNSEFUT_Click);
      this.chkMCX.AutoSize = true;
      this.chkMCX.Location = new Point(12, 13);
      this.chkMCX.Name = "chkMCX";
      this.chkMCX.Size = new Size(49, 17);
      this.chkMCX.TabIndex = 12;
      this.chkMCX.Text = "MCX";
      this.chkMCX.UseVisualStyleBackColor = true;
      this.chkMCX.Click += new EventHandler(this.chkMCX_Click);
      this.txtMobNo.Location = new Point(70, 107);
      this.txtMobNo.MaxLength = 10;
      this.txtMobNo.Name = "txtMobNo";
      this.txtMobNo.Size = new Size(126, 20);
      this.txtMobNo.TabIndex = 18;
      this.label10.AutoSize = true;
      this.label10.Location = new Point(5, 110);
      this.label10.Name = "label10";
      this.label10.Size = new Size(58, 13);
      this.label10.TabIndex = 20;
      this.label10.Text = "Mobile No:";
      this.txtEmailid.Location = new Point(70, 84);
      this.txtEmailid.MaxLength = 20;
      this.txtEmailid.Name = "txtEmailid";
      this.txtEmailid.Size = new Size(126, 20);
      this.txtEmailid.TabIndex = 17;
      this.label11.AutoSize = true;
      this.label11.Location = new Point(5, 87);
      this.label11.Name = "label11";
      this.label11.Size = new Size(43, 13);
      this.label11.TabIndex = 19;
      this.label11.Text = "Emailid:";
      this.txtPflsPercent.Location = new Point(70, 285);
      this.txtPflsPercent.MaxLength = 3;
      this.txtPflsPercent.Name = "txtPflsPercent";
      this.txtPflsPercent.Size = new Size(126, 20);
      this.txtPflsPercent.TabIndex = 12;
      this.txtPflsPercent.Visible = false;
      this.lblpfls.AutoSize = true;
      this.lblpfls.Location = new Point(5, 287);
      this.lblpfls.Name = "lblpfls";
      this.lblpfls.Size = new Size(72, 13);
      this.lblpfls.TabIndex = 12;
      this.lblpfls.Text = "Profit/Loss %:";
      this.lblpfls.Visible = false;
      this.button1.Location = new Point(136, 288);
      this.button1.Name = "button1";
      this.button1.Size = new Size(71, 23);
      this.button1.TabIndex = 15;
      this.button1.Text = "Retrieve";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Visible = false;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.txtImagePath.Location = new Point(108, 311);
      this.txtImagePath.Name = "txtImagePath";
      this.txtImagePath.Size = new Size(100, 20);
      this.txtImagePath.TabIndex = 12;
      this.txtImagePath.Visible = false;
      this.lblProgress.AutoSize = true;
      this.lblProgress.Location = new Point(5, 330);
      this.lblProgress.Name = "lblProgress";
      this.lblProgress.Size = new Size(165, 13);
      this.lblProgress.TabIndex = 12;
      this.lblProgress.Text = "Please wait...Delete in Progress...";
      this.lblProgress.Visible = false;
      this.btnSet.Location = new Point(165, 175);
      this.btnSet.Name = "btnSet";
      this.btnSet.Size = new Size(42, 23);
      this.btnSet.TabIndex = 6;
      this.btnSet.Text = "SET";
      this.btnSet.UseVisualStyleBackColor = true;
      this.btnSet.Click += new EventHandler(this.btnSet_Click);
      this.txtAppName.Location = new Point(70, 177);
      this.txtAppName.MaxLength = 50;
      this.txtAppName.Name = "txtAppName";
      this.txtAppName.Size = new Size(89, 20);
      this.txtAppName.TabIndex = 5;
      this.label7.AutoSize = true;
      this.label7.Location = new Point(5, 180);
      this.label7.Name = "label7";
      this.label7.Size = new Size(60, 13);
      this.label7.TabIndex = 13;
      this.label7.Text = "App Name:";
      this.chkOffset.AutoSize = true;
      this.chkOffset.Location = new Point(10, 306);
      this.chkOffset.Name = "chkOffset";
      this.chkOffset.Size = new Size(90, 17);
      this.chkOffset.TabIndex = 9;
      this.chkOffset.Text = "OffsetTrading";
      this.chkOffset.UseVisualStyleBackColor = true;
      this.chkOffset.CheckedChanged += new EventHandler(this.chkOffset_CheckedChanged);
      this.chkOddLot.AutoSize = true;
      this.chkOddLot.Location = new Point(10, 286);
      this.chkOddLot.Name = "chkOddLot";
      this.chkOddLot.Size = new Size(122, 17);
      this.chkOddLot.TabIndex = 8;
      this.chkOddLot.Text = "NSE odd Lot trading";
      this.chkOddLot.UseVisualStyleBackColor = true;
      this.label6.AutoSize = true;
      this.label6.Location = new Point(5, 207);
      this.label6.Name = "label6";
      this.label6.Size = new Size(63, 13);
      this.label6.TabIndex = 11;
      this.label6.Text = "Exchanges:";
      this.chkExchList.CheckOnClick = true;
      this.chkExchList.FormattingEnabled = true;
      this.chkExchList.Items.AddRange(new object[7]
      {
        (object) "MCX",
        (object) "NSEFUT",
        (object) "NCDEX",
        (object) "NSECURR",
        (object) "NSEOPT",
        (object) "NSECASH",
        (object) "FOREX"
      });
      this.chkExchList.Location = new Point(70, 203);
      this.chkExchList.Name = "chkExchList";
      this.chkExchList.Size = new Size(126, 79);
      this.chkExchList.TabIndex = 7;
      this.groupBox2.Controls.Add((Control) this.chkCharts);
      this.groupBox2.Controls.Add((Control) this.chkStckPerfm);
      this.groupBox2.Controls.Add((Control) this.chkPivots);
      this.groupBox2.Location = new Point(8, 435);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(200, 58);
      this.groupBox2.TabIndex = 6;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Additional Features";
      this.groupBox2.Visible = false;
      this.chkCharts.AutoSize = true;
      this.chkCharts.Location = new Point(6, 34);
      this.chkCharts.Name = "chkCharts";
      this.chkCharts.Size = new Size(65, 17);
      this.chkCharts.TabIndex = 1;
      this.chkCharts.Text = "Charting";
      this.chkCharts.UseVisualStyleBackColor = true;
      this.chkStckPerfm.AutoSize = true;
      this.chkStckPerfm.Location = new Point(100, 17);
      this.chkStckPerfm.Name = "chkStckPerfm";
      this.chkStckPerfm.Size = new Size(88, 17);
      this.chkStckPerfm.TabIndex = 2;
      this.chkStckPerfm.Text = "Data Queries";
      this.chkStckPerfm.UseVisualStyleBackColor = true;
      this.chkPivots.AutoSize = true;
      this.chkPivots.Location = new Point(6, 17);
      this.chkPivots.Name = "chkPivots";
      this.chkPivots.Size = new Size(55, 17);
      this.chkPivots.TabIndex = 0;
      this.chkPivots.Text = "Pivots";
      this.chkPivots.UseVisualStyleBackColor = true;
      this.txtpassword.Location = new Point(70, 153);
      this.txtpassword.MaxLength = 18;
      this.txtpassword.Name = "txtpassword";
      this.txtpassword.Size = new Size(126, 20);
      this.txtpassword.TabIndex = 4;
      this.label5.AutoSize = true;
      this.label5.Location = new Point(5, 156);
      this.label5.Name = "label5";
      this.label5.Size = new Size(56, 13);
      this.label5.TabIndex = 9;
      this.label5.Text = "Password:";
      this.txtusername.Location = new Point(70, 130);
      this.txtusername.MaxLength = 18;
      this.txtusername.Name = "txtusername";
      this.txtusername.Size = new Size(126, 20);
      this.txtusername.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(5, 133);
      this.label4.Name = "label4";
      this.label4.Size = new Size(58, 13);
      this.label4.TabIndex = 7;
      this.label4.Text = "Username:";
      this.txtclientcode.Location = new Point(70, 62);
      this.txtclientcode.MaxLength = 10;
      this.txtclientcode.Name = "txtclientcode";
      this.txtclientcode.Size = new Size(126, 20);
      this.txtclientcode.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(5, 65);
      this.label3.Name = "label3";
      this.label3.Size = new Size(35, 13);
      this.label3.TabIndex = 5;
      this.label3.Text = "Code:";
      this.txtname.Location = new Point(70, 39);
      this.txtname.MaxLength = 20;
      this.txtname.Name = "txtname";
      this.txtname.Size = new Size(126, 20);
      this.txtname.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(5, 42);
      this.label2.Name = "label2";
      this.label2.Size = new Size(38, 13);
      this.label2.TabIndex = 3;
      this.label2.Text = "Name:";
      this.cmbUsertype.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbUsertype.FormattingEnabled = true;
      this.cmbUsertype.Location = new Point(70, 15);
      this.cmbUsertype.Name = "cmbUsertype";
      this.cmbUsertype.Size = new Size(126, 21);
      this.cmbUsertype.TabIndex = 0;
      this.cmbUsertype.SelectedIndexChanged += new EventHandler(this.cmbUsertype_SelectedIndexChanged);
      this.label1.AutoSize = true;
      this.label1.Location = new Point(5, 17);
      this.label1.Name = "label1";
      this.label1.Size = new Size(52, 13);
      this.label1.TabIndex = 2;
      this.label1.Text = "Usertype:";
      this.label9.AutoSize = true;
      this.label9.Location = new Point(705, -1);
      this.label9.Name = "label9";
      this.label9.Size = new Size(65, 26);
      this.label9.TabIndex = 16;
      this.label9.Text = "Upload Icon\r\n(.ico format):";
      this.label9.Visible = false;
      this.pictureBox1.Location = new Point(773, -6);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(52, 31);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
      this.pictureBox1.TabIndex = 14;
      this.pictureBox1.TabStop = false;
      this.pictureBox1.Visible = false;
      this.btnUploadImage.Location = new Point(839, -3);
      this.btnUploadImage.Name = "btnUploadImage";
      this.btnUploadImage.Size = new Size(57, 23);
      this.btnUploadImage.TabIndex = 12;
      this.btnUploadImage.Text = "Upload";
      this.btnUploadImage.UseVisualStyleBackColor = true;
      this.btnUploadImage.Visible = false;
      this.btnUploadImage.Click += new EventHandler(this.btnUploadImage_Click);
      this.dgvUserprofile.AllowUserToAddRows = false;
      this.dgvUserprofile.AllowUserToDeleteRows = false;
      this.dgvUserprofile.AllowUserToOrderColumns = true;
      this.dgvUserprofile.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvUserprofile.Columns.AddRange((DataGridViewColumn) this.usertype, (DataGridViewColumn) this.UName, (DataGridViewColumn) this.Clientcode, (DataGridViewColumn) this.Username, (DataGridViewColumn) this.Password, (DataGridViewColumn) this.Pivots, (DataGridViewColumn) this.StocksPerfor, (DataGridViewColumn) this.Charting, (DataGridViewColumn) this.Userstatus, (DataGridViewColumn) this.Marginstatus, (DataGridViewColumn) this.Exchnage, (DataGridViewColumn) this.RegDate, (DataGridViewColumn) this.ColOffset, (DataGridViewColumn) this.colOddLot, (DataGridViewColumn) this.ColAppName, (DataGridViewColumn) this.DIComm);
      this.dgvUserprofile.Location = new Point(225, 32);
      this.dgvUserprofile.Name = "dgvUserprofile";
      this.dgvUserprofile.ReadOnly = true;
      this.dgvUserprofile.RowHeadersVisible = false;
      this.dgvUserprofile.Size = new Size(795, 575);
      this.dgvUserprofile.TabIndex = 1;
      this.dgvUserprofile.CellClick += new DataGridViewCellEventHandler(this.dgvUserprofile_CellClick);
      this.dgvUserprofile.MouseClick += new MouseEventHandler(this.dgvUserprofile_MouseClick);
      this.usertype.HeaderText = "Usertype";
      this.usertype.Name = "usertype";
      this.usertype.ReadOnly = true;
      this.usertype.Width = 90;
      this.UName.HeaderText = "Name";
      this.UName.Name = "UName";
      this.UName.ReadOnly = true;
      this.UName.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.UName.Width = 90;
      this.Clientcode.HeaderText = "ClientCode";
      this.Clientcode.Name = "Clientcode";
      this.Clientcode.ReadOnly = true;
      this.Clientcode.Width = 90;
      this.Username.HeaderText = "Username";
      this.Username.Name = "Username";
      this.Username.ReadOnly = true;
      this.Username.Width = 90;
      this.Password.HeaderText = "Password";
      this.Password.Name = "Password";
      this.Password.ReadOnly = true;
      this.Password.Width = 90;
      this.Pivots.HeaderText = "Pivots";
      this.Pivots.Name = "Pivots";
      this.Pivots.ReadOnly = true;
      this.Pivots.Width = 80;
      this.StocksPerfor.HeaderText = "StocksPerformance";
      this.StocksPerfor.Name = "StocksPerfor";
      this.StocksPerfor.ReadOnly = true;
      this.StocksPerfor.Width = 80;
      this.Charting.HeaderText = "Charting";
      this.Charting.Name = "Charting";
      this.Charting.ReadOnly = true;
      this.Charting.Width = 80;
      this.Userstatus.HeaderText = "UserStatus";
      this.Userstatus.Name = "Userstatus";
      this.Userstatus.ReadOnly = true;
      this.Userstatus.Width = 80;
      this.Marginstatus.HeaderText = "MarginStatus";
      this.Marginstatus.Name = "Marginstatus";
      this.Marginstatus.ReadOnly = true;
      this.Marginstatus.Width = 80;
      this.Exchnage.HeaderText = "Exchanges";
      this.Exchnage.Name = "Exchnage";
      this.Exchnage.ReadOnly = true;
      this.RegDate.HeaderText = "RegistrationDate";
      this.RegDate.Name = "RegDate";
      this.RegDate.ReadOnly = true;
      this.ColOffset.HeaderText = "OffsetTrading";
      this.ColOffset.Name = "ColOffset";
      this.ColOffset.ReadOnly = true;
      this.colOddLot.HeaderText = "OddLot";
      this.colOddLot.Name = "colOddLot";
      this.colOddLot.ReadOnly = true;
      this.ColAppName.HeaderText = "AppName";
      this.ColAppName.Name = "ColAppName";
      this.ColAppName.ReadOnly = true;
      this.DIComm.HeaderText = "DI Commition";
      this.DIComm.Name = "DIComm";
      this.DIComm.ReadOnly = true;
      this.btnAdd.Location = new Point(12, 482);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new Size(90, 23);
      this.btnAdd.TabIndex = 1;
      this.btnAdd.Text = "Add";
      this.btnAdd.UseVisualStyleBackColor = true;
      this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
      this.btnModify.Location = new Point(12, 511);
      this.btnModify.Name = "btnModify";
      this.btnModify.Size = new Size(90, 23);
      this.btnModify.TabIndex = 3;
      this.btnModify.Text = "Modify";
      this.btnModify.UseVisualStyleBackColor = true;
      this.btnModify.Click += new EventHandler(this.btnModify_Click);
      this.btnDelete.Location = new Point(12, 540);
      this.btnDelete.Name = "btnDelete";
      this.btnDelete.Size = new Size(90, 23);
      this.btnDelete.TabIndex = 5;
      this.btnDelete.Text = "Delete";
      this.btnDelete.UseVisualStyleBackColor = true;
      this.btnDelete.Visible = false;
      this.btnDelete.Click += new EventHandler(this.btnDelete_Click);
      this.btnLogoff.Location = new Point(12, 569);
      this.btnLogoff.Name = "btnLogoff";
      this.btnLogoff.Size = new Size(90, 23);
      this.btnLogoff.TabIndex = 7;
      this.btnLogoff.Text = "Log off";
      this.btnLogoff.UseVisualStyleBackColor = true;
      this.btnLogoff.Click += new EventHandler(this.btnClear_Click);
      this.btnReleaseMrgn.Location = new Point(123, 569);
      this.btnReleaseMrgn.Name = "btnReleaseMrgn";
      this.btnReleaseMrgn.Size = new Size(90, 23);
      this.btnReleaseMrgn.TabIndex = 8;
      this.btnReleaseMrgn.Text = "Release Margin";
      this.btnReleaseMrgn.UseVisualStyleBackColor = true;
      this.btnReleaseMrgn.Click += new EventHandler(this.btnReleaseMrgn_Click);
      this.btnBlockMargin.Location = new Point(123, 540);
      this.btnBlockMargin.Name = "btnBlockMargin";
      this.btnBlockMargin.Size = new Size(90, 23);
      this.btnBlockMargin.TabIndex = 6;
      this.btnBlockMargin.Text = "Block Margin";
      this.btnBlockMargin.UseVisualStyleBackColor = true;
      this.btnBlockMargin.Click += new EventHandler(this.btnBlockMargin_Click);
      this.btndisable.Location = new Point(123, 511);
      this.btndisable.Name = "btndisable";
      this.btndisable.Size = new Size(90, 23);
      this.btndisable.TabIndex = 4;
      this.btndisable.Text = "Disable";
      this.btndisable.UseVisualStyleBackColor = true;
      this.btndisable.Click += new EventHandler(this.btndisable_Click);
      this.btnEnable.Location = new Point(125, 482);
      this.btnEnable.Name = "btnEnable";
      this.btnEnable.Size = new Size(90, 23);
      this.btnEnable.TabIndex = 2;
      this.btnEnable.Text = "Enable";
      this.btnEnable.UseVisualStyleBackColor = true;
      this.btnEnable.Click += new EventHandler(this.btnEnable_Click);
      this.label8.AutoSize = true;
      this.label8.Location = new Point(235, 9);
      this.label8.Name = "label8";
      this.label8.Size = new Size(71, 13);
      this.label8.TabIndex = 9;
      this.label8.Text = "Search/Filter:";
      this.txtNameSearch.Location = new Point(321, 6);
      this.txtNameSearch.Name = "txtNameSearch";
      this.txtNameSearch.Size = new Size(83, 20);
      this.txtNameSearch.TabIndex = 9;
      this.txtNameSearch.TextChanged += new EventHandler(this.txtNameSearch_TextChanged);
      this.txtClientcodeSearch.Location = new Point(410, 6);
      this.txtClientcodeSearch.Name = "txtClientcodeSearch";
      this.txtClientcodeSearch.Size = new Size(83, 20);
      this.txtClientcodeSearch.TabIndex = 10;
      this.txtClientcodeSearch.TextChanged += new EventHandler(this.txtClientcodeSearch_TextChanged);
      this.txtUsernameSearch.Location = new Point(499, 6);
      this.txtUsernameSearch.Name = "txtUsernameSearch";
      this.txtUsernameSearch.Size = new Size(83, 20);
      this.txtUsernameSearch.TabIndex = 11;
      this.txtUsernameSearch.TextChanged += new EventHandler(this.txtUsernameSearch_TextChanged);
      this.DIPLF.AutoSize = true;
      this.DIPLF.Location = new Point(17, 460);
      this.DIPLF.Name = "DIPLF";
      this.DIPLF.Size = new Size(75, 13);
      this.DIPLF.TabIndex = 29;
      this.DIPLF.Text = "DI ProfitLoss%";
      this.DIPLF.Visible = false;
      this.textBoxDIPFLS.Location = new Point((int) sbyte.MaxValue, 452);
      this.textBoxDIPFLS.MaxLength = 10;
      this.textBoxDIPFLS.Name = "textBoxDIPFLS";
      this.textBoxDIPFLS.Size = new Size(72, 20);
      this.textBoxDIPFLS.TabIndex = 28;
      this.textBoxDIPFLS.Visible = false;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1023, 604);
      this.Controls.Add((Control) this.DIPLF);
      this.Controls.Add((Control) this.textBoxDIPFLS);
      this.Controls.Add((Control) this.txtUsernameSearch);
      this.Controls.Add((Control) this.txtClientcodeSearch);
      this.Controls.Add((Control) this.txtNameSearch);
      this.Controls.Add((Control) this.label8);
      this.Controls.Add((Control) this.btnReleaseMrgn);
      this.Controls.Add((Control) this.btnBlockMargin);
      this.Controls.Add((Control) this.btndisable);
      this.Controls.Add((Control) this.btnEnable);
      this.Controls.Add((Control) this.label9);
      this.Controls.Add((Control) this.btnLogoff);
      this.Controls.Add((Control) this.btnDelete);
      this.Controls.Add((Control) this.pictureBox1);
      this.Controls.Add((Control) this.btnModify);
      this.Controls.Add((Control) this.btnUploadImage);
      this.Controls.Add((Control) this.btnAdd);
      this.Controls.Add((Control) this.dgvUserprofile);
      this.Controls.Add((Control) this.groupBox1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (frmUserprofile);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "User profile";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.grpHighLowExch.ResumeLayout(false);
      this.grpHighLowExch.PerformLayout();
      this.grpOffsetExch.ResumeLayout(false);
      this.grpOffsetExch.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((ISupportInitialize) this.pictureBox1).EndInit();
      ((ISupportInitialize) this.dgvUserprofile).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
