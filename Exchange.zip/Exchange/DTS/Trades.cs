﻿// Decompiled with JetBrains decompiler
// Type: DTS.Trades
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Data;
using System.Data.SqlClient;

namespace DTS
{
  public class Trades
  {
    public string Symbol { get; set; }

    public int exch { get; set; }

    public int buysell { get; set; }

    public int producttype { get; set; }

    public int qty { get; set; }

    public Decimal price { get; set; }

    public Decimal Ordprice { get; set; }

    public double orderno { get; set; }

    public int validity { get; set; }

    public string userremarks { get; set; }

    public string clientcode { get; set; }

    public string traderid { get; set; }

    public DateTime Createon { get; set; }

    public int ordstatus { get; set; }

    public DateTime Lastmodified { get; set; }

    public int isAdmin { get; set; }

    public int isMaintenance { get; set; }

    public int exectype { get; set; }

    public static bool SaveOrder(Trades objtrade, SqlConnection objconn)
    {
      SqlConnection connection = objconn;
      int num = 0;
      if (connection.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand(nameof (SaveOrder), connection);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@symbol", (object) objtrade.Symbol);
          sqlCommand2.Parameters.AddWithValue("@exch", (object) objtrade.exch);
          sqlCommand2.Parameters.AddWithValue("@buysell", (object) objtrade.buysell);
          sqlCommand2.Parameters.AddWithValue("@producttype", (object) objtrade.producttype);
          sqlCommand2.Parameters.AddWithValue("@qty", (object) objtrade.qty);
          sqlCommand2.Parameters.AddWithValue("@ordprice", (object) objtrade.Ordprice);
          sqlCommand2.Parameters.AddWithValue("@price", (object) objtrade.price);
          sqlCommand2.Parameters.AddWithValue("@orderno", (object) objtrade.orderno);
          sqlCommand2.Parameters.AddWithValue("@validity", (object) objtrade.validity);
          sqlCommand2.Parameters.AddWithValue("@userremarks", (object) objtrade.userremarks);
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objtrade.clientcode);
          sqlCommand2.Parameters.AddWithValue("@traderid", (object) objtrade.traderid);
          SqlParameterCollection parameters1 = sqlCommand2.Parameters;
          DateTime dateTime = objtrade.Createon;
          string str1 = dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
          parameters1.AddWithValue("@createon", (object) str1);
          SqlParameterCollection parameters2 = sqlCommand2.Parameters;
          dateTime = objtrade.Lastmodified;
          string str2 = dateTime.ToString("yyyy-MM-dd HH:mm:ss.fff");
          parameters2.AddWithValue("@lastmodified", (object) str2);
          sqlCommand2.Parameters.AddWithValue("@ordstatus", (object) objtrade.ordstatus);
          sqlCommand2.Parameters.AddWithValue("@isadmin", (object) objtrade.isAdmin);
          sqlCommand2.Parameters.AddWithValue("@ismaintenance", (object) objtrade.isMaintenance);
          sqlCommand2.Parameters.AddWithValue("@exectype", (object) objtrade.exectype);
          sqlCommand2.Parameters.AddWithValue("@ipaddress", (object) Utils.getPublicIPAddress());
          try
          {
            num = sqlCommand2.ExecuteNonQuery();
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to Trade: " + ex.Message ?? "", 3);
          }
        }
      }
      return num > 0;
    }

    public static bool SaveTrade(Trades objtrade, SqlConnection objconn)
    {
      int num = 0;
      if (objconn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand(nameof (SaveTrade), objconn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objtrade.clientcode);
          sqlCommand2.Parameters.AddWithValue("@symbol", (object) objtrade.Symbol);
          sqlCommand2.Parameters.AddWithValue("@qty", (object) objtrade.qty);
          sqlCommand2.Parameters.AddWithValue("@orderno", (object) objtrade.orderno);
          sqlCommand2.Parameters.AddWithValue("@price", (object) objtrade.price);
          sqlCommand2.Parameters.AddWithValue("@lastmodified", (object) objtrade.Lastmodified.ToString("yyyy-MM-dd HH:mm:ss.fff"));
          sqlCommand2.Parameters.AddWithValue("@buysell", (object) objtrade.buysell);
          sqlCommand2.Parameters.AddWithValue("@exch", (object) objtrade.exch);
          sqlCommand2.Parameters.AddWithValue("@ipaddress", (object) Utils.getPublicIPAddress());
          try
          {
            num = sqlCommand2.ExecuteNonQuery();
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to Trade: " + ex.Message ?? "", 3);
          }
        }
      }
      return num > 0;
    }

    public static bool CancelOrder(double Orderno)
    {
      SqlConnection connection = new SqlConnection(Utils.Getconnsss());
      connection.Open();
      int num = 0;
      if (connection.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand(nameof (CancelOrder), connection);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@Orderno", (object) Orderno);
          num = sqlCommand2.ExecuteNonQuery();
        }
        connection.Close();
      }
      return num > 0;
    }

    public static bool ModifyOrder(
      Trades objtrade,
      int oldqty,
      Decimal oldprice,
      Dashboard objdash)
    {
      SqlConnection conn = objdash.getConn();
      int num = 0;
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand(nameof (ModifyOrder), conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objtrade.clientcode);
          sqlCommand2.Parameters.AddWithValue("@oldqty", (object) oldqty);
          sqlCommand2.Parameters.AddWithValue("@oldprice", (object) oldprice);
          sqlCommand2.Parameters.AddWithValue("@qty", (object) objtrade.qty);
          sqlCommand2.Parameters.AddWithValue("@price", (object) objtrade.price);
          sqlCommand2.Parameters.AddWithValue("@orderno", (object) objtrade.orderno);
          sqlCommand2.Parameters.AddWithValue("@lastmodified", (object) objtrade.Lastmodified.ToString("yyyy-MM-dd HH:mm:ss.fff"));
          sqlCommand2.Parameters.AddWithValue("@ipaddress", (object) Utils.getPublicIPAddress());
          num = sqlCommand2.ExecuteNonQuery();
        }
      }
      return num > 0;
    }

    public static bool InsertPendingTrade(Trades objtrd, Dashboard objdash)
    {
      SqlConnection conn = objdash.getConn();
      int num = 0;
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("ExecutePending", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@accno", (object) objtrd.clientcode);
          sqlCommand2.Parameters.AddWithValue("@symbol", (object) objtrd.Symbol);
          sqlCommand2.Parameters.AddWithValue("@qty", (object) objtrd.qty);
          sqlCommand2.Parameters.AddWithValue("@orderno", (object) objtrd.orderno);
          sqlCommand2.Parameters.AddWithValue("@price", (object) objtrd.price);
          sqlCommand2.Parameters.AddWithValue("@buysell", (object) objtrd.buysell);
          sqlCommand2.Parameters.AddWithValue("@exch", (object) objtrd.exch);
          sqlCommand2.Parameters.AddWithValue("@tradedby", (object) objtrd.traderid);
          sqlCommand2.Parameters.AddWithValue("@exectype", (object) objtrd.exectype);
          try
          {
            num = sqlCommand2.ExecuteNonQuery();
          }
          catch
          {
            return false;
          }
        }
      }
      return num > 0;
    }

    public static double OrderNoGenerate()
    {
      DateTime now = DateTime.Now;
      string str1 = now.Month.ToString().Length != 1 ? now.Month.ToString() : "0" + (object) now.Month;
      string str2 = now.Day.ToString().Length != 1 ? now.Day.ToString() : "0" + (object) now.Day;
      string str3 = (now.Year - 2000).ToString() + str1 + str2;
      Convert.ToInt32(str3);
      int num1 = now.Minute;
      string str4;
      if (num1.ToString().Length == 1)
      {
        str4 = "0" + (object) now.Minute;
      }
      else
      {
        num1 = now.Minute;
        str4 = num1.ToString();
      }
      string str5 = now.Hour.ToString() + str4 + (object) now.Second + (object) now.Millisecond;
      num1 = now.Second;
      int num2 = num1.ToString().Length != 1 ? Convert.ToInt32(str5) : Convert.ToInt32(str5) * 10;
      return Convert.ToDouble(str3 + (object) num2);
    }
  }
}
