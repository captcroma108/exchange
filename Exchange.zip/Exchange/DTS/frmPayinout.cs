﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmPayinout
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmPayinout : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private DataGridView dgvPayInOutView;
    private DataGridViewTextBoxColumn colclientcode;
    private DataGridViewTextBoxColumn colName;
    private DataGridViewTextBoxColumn colAmount;
    private DataGridViewTextBoxColumn colComments;
    private DataGridViewTextBoxColumn ColPayinOut;
    private DataGridViewTextBoxColumn colTimestamp;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem filterToolStripMenuItem;
    private ToolStripMenuItem payinToolStripMenuItem;
    private ToolStripMenuItem payoutToolStripMenuItem;
    private ToolStripMenuItem exportToCsvToolStripMenuItem;

    public frmPayinout(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadPayinOut(string type)
    {
      this.dgvPayInOutView.Rows.Clear();
      string cmdText = "Select ClientCode, Name,Amount,Comments,PayinPayout,Timestamp from Payin_Payout where ClientCode = '" + this.objdash.objinfo.clientcode + "' and PayinPayout in (" + type + ") order by Timestamp desc";
      if (this.objdash.objinfo.usertype == 3)
        cmdText = "Select ClientCode, Name,Amount,Comments,PayinPayout,Timestamp from Payin_Payout where ClientCode in (" + this.objdash.claccounts + ") and PayinPayout in (" + type + ") order by Timestamp desc";
      if (this.objdash.conn.State == ConnectionState.Open)
      {
        using (SqlCommand sqlCommand = new SqlCommand(cmdText, this.objdash.conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              int index = this.dgvPayInOutView.Rows.Add();
              if (!sqlDataReader.IsDBNull(0))
                this.dgvPayInOutView.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(0);
              if (!sqlDataReader.IsDBNull(1))
                this.dgvPayInOutView.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(1);
              if (!sqlDataReader.IsDBNull(2))
                this.dgvPayInOutView.Rows[index].Cells[2].Value = (object) sqlDataReader.GetValue(2).ToString();
              if (!sqlDataReader.IsDBNull(3))
                this.dgvPayInOutView.Rows[index].Cells[3].Value = (object) sqlDataReader.GetString(3);
              if (!sqlDataReader.IsDBNull(4))
                this.dgvPayInOutView.Rows[index].Cells[4].Value = sqlDataReader.GetInt32(4) != 1 ? (object) "Payout" : (object) "Payin";
              if (!sqlDataReader.IsDBNull(5))
                this.dgvPayInOutView.Rows[index].Cells[5].Value = (object) Convert.ToDateTime(sqlDataReader.GetValue(5)).ToString("dd-MMM-yyyy hh:mm:ss.fff");
            }
          }
        }
      }
      else
        this.objdash.DisplayMessage("Unable to Load last Payin/Payout details, due to connection failure", 3);
    }

    private void payinToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.LoadPayinOut("1");
    }

    private void payoutToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.LoadPayinOut("2");
    }

    private void exportToCsvToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Export.ExportToExcel(this.dgvPayInOutView, false);
    }

    private void dgvPayInOutView_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvPayInOutView.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvPayInOutView, client.X, client.Y);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      this.dgvPayInOutView = new DataGridView();
      this.colclientcode = new DataGridViewTextBoxColumn();
      this.colName = new DataGridViewTextBoxColumn();
      this.colAmount = new DataGridViewTextBoxColumn();
      this.colComments = new DataGridViewTextBoxColumn();
      this.ColPayinOut = new DataGridViewTextBoxColumn();
      this.colTimestamp = new DataGridViewTextBoxColumn();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.filterToolStripMenuItem = new ToolStripMenuItem();
      this.payinToolStripMenuItem = new ToolStripMenuItem();
      this.payoutToolStripMenuItem = new ToolStripMenuItem();
      this.exportToCsvToolStripMenuItem = new ToolStripMenuItem();
      ((ISupportInitialize) this.dgvPayInOutView).BeginInit();
      this.contextMenuStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvPayInOutView.AllowUserToAddRows = false;
      this.dgvPayInOutView.AllowUserToDeleteRows = false;
      this.dgvPayInOutView.AllowUserToOrderColumns = true;
      this.dgvPayInOutView.AllowUserToResizeRows = false;
      this.dgvPayInOutView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvPayInOutView.BackgroundColor = Color.White;
      this.dgvPayInOutView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvPayInOutView.Columns.AddRange((DataGridViewColumn) this.colclientcode, (DataGridViewColumn) this.colName, (DataGridViewColumn) this.colAmount, (DataGridViewColumn) this.colComments, (DataGridViewColumn) this.ColPayinOut, (DataGridViewColumn) this.colTimestamp);
      this.dgvPayInOutView.Dock = DockStyle.Fill;
      this.dgvPayInOutView.Location = new Point(0, 0);
      this.dgvPayInOutView.Name = "dgvPayInOutView";
      this.dgvPayInOutView.ReadOnly = true;
      this.dgvPayInOutView.RowHeadersVisible = false;
      this.dgvPayInOutView.Size = new Size(945, 290);
      this.dgvPayInOutView.TabIndex = 0;
      this.dgvPayInOutView.MouseClick += new MouseEventHandler(this.dgvPayInOutView_MouseClick);
      this.colclientcode.HeaderText = "ClientCode";
      this.colclientcode.Name = "colclientcode";
      this.colclientcode.ReadOnly = true;
      this.colName.HeaderText = "Name";
      this.colName.Name = "colName";
      this.colName.ReadOnly = true;
      this.colAmount.HeaderText = "Amount";
      this.colAmount.Name = "colAmount";
      this.colAmount.ReadOnly = true;
      this.colComments.HeaderText = "Comments";
      this.colComments.Name = "colComments";
      this.colComments.ReadOnly = true;
      this.ColPayinOut.HeaderText = "Payin/Payout";
      this.ColPayinOut.Name = "ColPayinOut";
      this.ColPayinOut.ReadOnly = true;
      this.colTimestamp.HeaderText = "Timestamp";
      this.colTimestamp.Name = "colTimestamp";
      this.colTimestamp.ReadOnly = true;
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.filterToolStripMenuItem,
        (ToolStripItem) this.exportToCsvToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(142, 48);
      this.filterToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.payinToolStripMenuItem,
        (ToolStripItem) this.payoutToolStripMenuItem
      });
      this.filterToolStripMenuItem.Name = "filterToolStripMenuItem";
      this.filterToolStripMenuItem.Size = new Size(152, 22);
      this.filterToolStripMenuItem.Text = "Filter";
      this.payinToolStripMenuItem.Name = "payinToolStripMenuItem";
      this.payinToolStripMenuItem.Size = new Size(152, 22);
      this.payinToolStripMenuItem.Text = "Payin";
      this.payinToolStripMenuItem.Click += new EventHandler(this.payinToolStripMenuItem_Click);
      this.payoutToolStripMenuItem.Name = "payoutToolStripMenuItem";
      this.payoutToolStripMenuItem.Size = new Size(152, 22);
      this.payoutToolStripMenuItem.Text = "Payout";
      this.payoutToolStripMenuItem.Click += new EventHandler(this.payoutToolStripMenuItem_Click);
      this.exportToCsvToolStripMenuItem.Name = "exportToCsvToolStripMenuItem";
      this.exportToCsvToolStripMenuItem.Size = new Size(152, 22);
      this.exportToCsvToolStripMenuItem.Text = "Export to csv";
      this.exportToCsvToolStripMenuItem.Click += new EventHandler(this.exportToCsvToolStripMenuItem_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvPayInOutView);
      this.MaximizeBox = false;
      this.Name = nameof (frmPayinout);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Last Payin/Payout";
      ((ISupportInitialize) this.dgvPayInOutView).EndInit();
      this.contextMenuStrip1.ResumeLayout(false);
      this.ResumeLayout(false);
    }
  }
}
