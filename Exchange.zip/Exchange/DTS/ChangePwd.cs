﻿// Decompiled with JetBrains decompiler
// Type: DTS.ChangePwd
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace DTS
{
  public class ChangePwd : Form
  {
    private IContainer components = (IContainer) null;
    public Userinfo objinfo;
    public SqlConnection conn;
    public Dashboard objdash;
    private Label label1;
    private TextBox txtCurrPwd;
    private TextBox txtnewpwd;
    private Label label2;
    private TextBox txtconfPwd;
    private Label label3;
    private Button btnSubmit;
    private Button btncancel;
    private Label label4;
    private ProgressBar progressPassStrength;
    private Label label5;
    private Label lblStatus;

    public ChangePwd(Userinfo info, SqlConnection db, Dashboard dash)
    {
      this.InitializeComponent();
      this.objinfo = info;
      this.conn = db;
      this.objdash = dash;
      this.lblStatus.Text = "Blank";
      this.Icon = this.objdash.ico;
    }

    public void Loadwindow()
    {
      this.txtCurrPwd.Text = string.Empty;
      this.txtnewpwd.Text = string.Empty;
      this.txtconfPwd.Text = string.Empty;
      this.btnSubmit.Enabled = false;
    }

    private void btncancel_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void txtCurrPwd_TextChanged(object sender, EventArgs e)
    {
      if (!(this.txtnewpwd.Text != string.Empty) || !(this.txtCurrPwd.Text != string.Empty) || !(this.txtconfPwd.Text != string.Empty))
        return;
      this.btnSubmit.Enabled = true;
    }

    private void txtnewpwd_TextChanged(object sender, EventArgs e)
    {
      if (this.txtnewpwd.Text != string.Empty && this.txtCurrPwd.Text != string.Empty && this.txtconfPwd.Text != string.Empty)
        this.btnSubmit.Enabled = true;
      if (this.txtnewpwd.Text.Length > 0)
      {
        int progress = 0;
        this.progressPassStrength.Value = 0;
        string str = ChangePwd.CheckStrength(this.txtnewpwd.Text, ref progress).ToString();
        this.progressPassStrength.Step = progress * 20;
        this.progressPassStrength.PerformStep();
        this.lblStatus.Text = str;
      }
      else
      {
        this.progressPassStrength.Value = 0;
        this.lblStatus.Text = "Blank";
      }
    }

    private void txtconfPwd_TextChanged(object sender, EventArgs e)
    {
      if (this.txtnewpwd.Text != string.Empty && this.txtCurrPwd.Text != string.Empty && this.txtconfPwd.Text != string.Empty)
        this.btnSubmit.Enabled = true;
      if (this.txtconfPwd.Text.Length > 0)
      {
        int progress = 0;
        this.progressPassStrength.Value = 0;
        string str = ChangePwd.CheckStrength(this.txtconfPwd.Text, ref progress).ToString();
        this.progressPassStrength.Step = progress * 20;
        this.progressPassStrength.PerformStep();
        this.lblStatus.Text = str;
      }
      else
      {
        this.progressPassStrength.Value = 0;
        this.lblStatus.Text = "Blank";
      }
    }

    private void btnSubmit_Click(object sender, EventArgs e)
    {
      string empty = string.Empty;
      if (this.objdash.Encryptdata(this.txtCurrPwd.Text) != this.objinfo.password)
        empty += " Current Password Entered is wrong!!\n";
      if (this.txtnewpwd.Text != this.txtconfPwd.Text)
        empty += " Confirm Password does not Match with New Password\n";
      if (empty == string.Empty)
      {
        SqlCommand sqlCommand1 = new SqlCommand("ChangePassword", this.conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.objinfo.clientcode);
          sqlCommand2.Parameters.AddWithValue("@newpwd", (object) this.objdash.Encryptdata(this.txtnewpwd.Text));
          if (sqlCommand2.ExecuteNonQuery() <= 0)
            return;
          this.objdash.DisplayMessage("Password Changed Successfully!!, Please re-Login with New Password", 1);
          this.objdash.LogOff(true);
        }
      }
      else
        this.objdash.DisplayMessage(empty, 2);
    }

    public static ChangePwd.PasswordScore CheckStrength(string password, ref int progress)
    {
      progress = 1;
      if (password.Length < 1)
        return ChangePwd.PasswordScore.Blank;
      if (password.Length < 4)
        return ChangePwd.PasswordScore.VeryWeak;
      if (password.Length >= 6)
        ++progress;
      if (password.Length >= 12)
        ++progress;
      if (Regex.IsMatch(password, "[a-z]") && Regex.IsMatch(password, "[A-Z]"))
        ++progress;
      if (Regex.IsMatch(password, "[!@#\\$%\\^&\\*\\?_~\\-\\(\\);\\.\\+:]+"))
        ++progress;
      return (ChangePwd.PasswordScore) progress;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.txtCurrPwd = new TextBox();
      this.txtnewpwd = new TextBox();
      this.label2 = new Label();
      this.txtconfPwd = new TextBox();
      this.label3 = new Label();
      this.btnSubmit = new Button();
      this.btncancel = new Button();
      this.label4 = new Label();
      this.progressPassStrength = new ProgressBar();
      this.label5 = new Label();
      this.lblStatus = new Label();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(54, 42);
      this.label1.Name = "label1";
      this.label1.Size = new Size(93, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Current Password:";
      this.txtCurrPwd.Location = new Point(153, 39);
      this.txtCurrPwd.Name = "txtCurrPwd";
      this.txtCurrPwd.Size = new Size(126, 20);
      this.txtCurrPwd.TabIndex = 1;
      this.txtCurrPwd.TextChanged += new EventHandler(this.txtCurrPwd_TextChanged);
      this.txtnewpwd.Location = new Point(153, 71);
      this.txtnewpwd.Name = "txtnewpwd";
      this.txtnewpwd.Size = new Size(126, 20);
      this.txtnewpwd.TabIndex = 3;
      this.txtnewpwd.TextChanged += new EventHandler(this.txtnewpwd_TextChanged);
      this.label2.AutoSize = true;
      this.label2.Location = new Point(54, 74);
      this.label2.Name = "label2";
      this.label2.Size = new Size(81, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "New Password:";
      this.txtconfPwd.Location = new Point(153, 104);
      this.txtconfPwd.Name = "txtconfPwd";
      this.txtconfPwd.Size = new Size(126, 20);
      this.txtconfPwd.TabIndex = 5;
      this.txtconfPwd.TextChanged += new EventHandler(this.txtconfPwd_TextChanged);
      this.label3.AutoSize = true;
      this.label3.Location = new Point(54, 107);
      this.label3.Name = "label3";
      this.label3.Size = new Size(94, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Confirm Password:";
      this.btnSubmit.Enabled = false;
      this.btnSubmit.Location = new Point(71, 171);
      this.btnSubmit.Name = "btnSubmit";
      this.btnSubmit.Size = new Size(75, 23);
      this.btnSubmit.TabIndex = 6;
      this.btnSubmit.Text = "Submit";
      this.btnSubmit.UseVisualStyleBackColor = true;
      this.btnSubmit.Click += new EventHandler(this.btnSubmit_Click);
      this.btncancel.Location = new Point(186, 171);
      this.btncancel.Name = "btncancel";
      this.btncancel.Size = new Size(75, 23);
      this.btncancel.TabIndex = 7;
      this.btncancel.Text = "Cancel";
      this.btncancel.UseVisualStyleBackColor = true;
      this.btncancel.Click += new EventHandler(this.btncancel_Click);
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label4.Location = new Point(16, 9);
      this.label4.Name = "label4";
      this.label4.Size = new Size(300, 13);
      this.label4.TabIndex = 8;
      this.label4.Text = "Please Enter Current and New Password to Change Password";
      this.progressPassStrength.Location = new Point(153, 133);
      this.progressPassStrength.Name = "progressPassStrength";
      this.progressPassStrength.Size = new Size(126, 10);
      this.progressPassStrength.TabIndex = 9;
      this.label5.AutoSize = true;
      this.label5.Location = new Point(34, 146);
      this.label5.Name = "label5";
      this.label5.Size = new Size(113, 13);
      this.label5.TabIndex = 10;
      this.label5.Text = "Performance Strength:";
      this.lblStatus.AutoSize = true;
      this.lblStatus.Location = new Point(150, 146);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new Size(0, 13);
      this.lblStatus.TabIndex = 11;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(332, 204);
      this.Controls.Add((Control) this.lblStatus);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.progressPassStrength);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.btncancel);
      this.Controls.Add((Control) this.btnSubmit);
      this.Controls.Add((Control) this.txtconfPwd);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.txtnewpwd);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.txtCurrPwd);
      this.Controls.Add((Control) this.label1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (ChangePwd);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Change Password";
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    public enum PasswordScore
    {
      Blank,
      VeryWeak,
      Weak,
      Medium,
      Strong,
      VeryStrong,
    }
  }
}
