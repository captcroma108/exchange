﻿// Decompiled with JetBrains decompiler
// Type: DTS.Orders
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public struct Orders
  {
    public int orderid;
    public string symbol;
    public int BuySell;
    public int ExchangeTypeID;
    public int ProductType;
    public int Ordeqty;
    public Decimal OrdePrice;
    public double OrderNo;
    public int ValidityType;
    public string UserRemark;
    public string accountNo;
    public string TraderId;
    public DateTime CreatedOn;
    public DateTime LastModified;
    public int Orderstatus;
    public int isAdmin;
    public int isMaintenance;
    public string AccName;
    public int Exectype;
    public Decimal ExecPrice;
    public string ipAddress;
  }
}
