﻿// Decompiled with JetBrains decompiler
// Type: DTS.TickData
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace DTS
{
  public class TickData : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public SqlConnection conn;
    public SortedDictionary<DateTime, OHLC> _OHLCBars;
    private ToolStrip toolStrip1;
    private ToolStripComboBox cmbexch;
    private ToolStripComboBox cmbSymbol;
    private ToolStripButton btnsearch;
    private DataGridView dgvTickdata;
    private ToolStripButton btnSave;
    private ToolStripComboBox cmbPeriodicity;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Open;
    private DataGridViewTextBoxColumn High;
    private DataGridViewTextBoxColumn Low;
    private DataGridViewTextBoxColumn ColClose;
    private DataGridViewTextBoxColumn Time;

    public TickData(Dashboard dashboard, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objdash = dashboard;
      this.conn = objconn;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      if (!(this.objdash.objinfo.usertype == 3 | this.objdash.objinfo.usertype == 4))
        return;
      this.cmbexch.Items.Clear();
      this.cmbexch.Items.Add((object) "-- Exch --");
    }

    private void cmbSymbol_Enter(object sender, EventArgs e)
    {
      if (this.cmbexch.SelectedIndex <= 0)
        return;
      string text = this.cmbexch.Text;
      this.cmbSymbol.Items.Clear();
      if (this.objdash._Exchconctracts.ContainsKey(this.cmbexch.SelectedIndex))
      {
        this.cmbSymbol.Items.Add((object) "--Symbol--");
        foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[this.cmbexch.SelectedIndex])
          this.cmbSymbol.Items.Add((object) keyValuePair);
        this.cmbSymbol.SelectedIndex = 0;
      }
    }

    private void btnsearch_Click(object sender, EventArgs e)
    {
      if (!this.ValidateControls())
        return;
      string text = this.cmbSymbol.Text;
      this._OHLCBars = new SortedDictionary<DateTime, OHLC>();
      if (this.objdash._Symconctracts.ContainsKey(text))
      {
        string symDesp = this.objdash._Symconctracts[text].SymDesp;
        this.dgvTickdata.Rows.Clear();
        int index = 0;
        this.GetPeriodicity(this.cmbPeriodicity.Text);
        if (this._OHLCBars.Count > 0)
        {
          foreach (KeyValuePair<DateTime, OHLC> ohlcBar in this._OHLCBars)
          {
            DateTime key = ohlcBar.Key;
            OHLC ohlc = ohlcBar.Value;
            this.dgvTickdata.Rows.Add();
            this.dgvTickdata.Rows[index].Cells[0].Value = (object) text;
            this.dgvTickdata.Rows[index].Cells[1].Value = (object) ohlc.Open;
            this.dgvTickdata.Rows[index].Cells[2].Value = (object) ohlc.High;
            this.dgvTickdata.Rows[index].Cells[3].Value = (object) ohlc.Low;
            this.dgvTickdata.Rows[index].Cells[4].Value = (object) ohlc.CLose;
            this.dgvTickdata.Rows[index].Cells[5].Value = (object) key;
            ++index;
          }
        }
      }
    }

    private int GetPeriodicity(string Periodicity)
    {
      string upper = Periodicity.ToUpper();
      if (upper == "1 MIN")
        return 1;
      if (upper == "5 MINS")
        return 5;
      if (upper == "10 MINS")
        return 10;
      if (upper == "15 MINS")
        return 15;
      if (upper == "30 MINS")
        return 30;
      return upper == "60 MINS" ? 60 : 1;
    }

    private bool ValidateControls()
    {
      bool flag = true;
      if (this.cmbexch.Text == string.Empty)
      {
        int num = (int) MessageBox.Show("Select Exchange.", "Historical Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        flag = false;
      }
      else if (this.cmbSymbol.Text == string.Empty || this.cmbSymbol.SelectedIndex <= 0)
      {
        int num = (int) MessageBox.Show("Select Symbol.", "Historical Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        flag = false;
      }
      else if (this.cmbPeriodicity.Text == string.Empty || this.cmbPeriodicity.SelectedIndex <= 0)
      {
        int num = (int) MessageBox.Show("Select Periodicity.", "Historical Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        flag = false;
      }
      return flag;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.dgvTickdata.Rows.Count > 0)
      {
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
        saveFileDialog1.CheckPathExists = true;
        saveFileDialog1.InitialDirectory = "C:\\";
        saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
        saveFileDialog1.FilterIndex = 1;
        using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
        {
          if (saveFileDialog2.ShowDialog() != DialogResult.OK)
            return;
          string fileName = saveFileDialog2.FileName;
          using (StreamWriter streamWriter = new StreamWriter(fileName))
          {
            if (true)
            {
              string str = "Symbol,Bid,Ask,LTP,Vol,Time\r";
              streamWriter.Write(str);
            }
            int num = this.dgvTickdata.Rows.Count - 1;
            for (int index = 0; index < num; ++index)
            {
              string str = string.Format("{0},{1},{2},{3},{4},{5}\r", (object) this.dgvTickdata.Rows[index].Cells[0].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[2].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[3].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[4].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[5].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[6].Value.ToString());
              streamWriter.Write(str);
            }
            streamWriter.Flush();
            streamWriter.Close();
          }
        }
      }
      else
      {
        int num1 = (int) MessageBox.Show("No data to save.", "Last 30 mins Tick Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
      }
    }

    private void cmbSymbol_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.cmbPeriodicity.SelectedIndex = 0;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (TickData));
      this.toolStrip1 = new ToolStrip();
      this.cmbexch = new ToolStripComboBox();
      this.cmbSymbol = new ToolStripComboBox();
      this.cmbPeriodicity = new ToolStripComboBox();
      this.btnsearch = new ToolStripButton();
      this.btnSave = new ToolStripButton();
      this.dgvTickdata = new DataGridView();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Open = new DataGridViewTextBoxColumn();
      this.High = new DataGridViewTextBoxColumn();
      this.Low = new DataGridViewTextBoxColumn();
      this.ColClose = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.toolStrip1.SuspendLayout();
      ((ISupportInitialize) this.dgvTickdata).BeginInit();
      this.SuspendLayout();
      this.toolStrip1.Items.AddRange(new ToolStripItem[5]
      {
        (ToolStripItem) this.cmbexch,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.cmbPeriodicity,
        (ToolStripItem) this.btnsearch,
        (ToolStripItem) this.btnSave
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.RenderMode = ToolStripRenderMode.System;
      this.toolStrip1.Size = new Size(652, 25);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      this.cmbexch.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbexch.Name = "cmbexch";
      this.cmbexch.Size = new Size(80, 25);
      this.cmbSymbol.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(100, 25);
      this.cmbSymbol.Sorted = true;
      this.cmbSymbol.SelectedIndexChanged += new EventHandler(this.cmbSymbol_SelectedIndexChanged);
      this.cmbSymbol.Enter += new EventHandler(this.cmbSymbol_Enter);
      this.cmbPeriodicity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbPeriodicity.Items.AddRange(new object[7]
      {
        (object) "--Priodicity--",
        (object) "1 Min",
        (object) "5 Mins",
        (object) "10 Mins",
        (object) "15 Mins",
        (object) "30 Mins",
        (object) "60 Mins"
      });
      this.cmbPeriodicity.Name = "cmbPeriodicity";
      this.cmbPeriodicity.Size = new Size(100, 25);
      this.btnsearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnsearch.Image = (Image) componentResourceManager.GetObject("btnsearch.Image");
      this.btnsearch.ImageTransparentColor = Color.Magenta;
      this.btnsearch.Name = "btnsearch";
      this.btnsearch.Size = new Size(23, 22);
      this.btnsearch.Text = "Search";
      this.btnsearch.Click += new EventHandler(this.btnsearch_Click);
      this.btnSave.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSave.Image = (Image) componentResourceManager.GetObject("btnSave.Image");
      this.btnSave.ImageTransparentColor = Color.Magenta;
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(23, 22);
      this.btnSave.Text = "Save";
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.dgvTickdata.AllowUserToAddRows = false;
      this.dgvTickdata.AllowUserToDeleteRows = false;
      this.dgvTickdata.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvTickdata.Columns.AddRange((DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Open, (DataGridViewColumn) this.High, (DataGridViewColumn) this.Low, (DataGridViewColumn) this.ColClose, (DataGridViewColumn) this.Time);
      this.dgvTickdata.Dock = DockStyle.Fill;
      this.dgvTickdata.Location = new Point(0, 25);
      this.dgvTickdata.Name = "dgvTickdata";
      this.dgvTickdata.ReadOnly = true;
      this.dgvTickdata.RowHeadersVisible = false;
      this.dgvTickdata.Size = new Size(652, 463);
      this.dgvTickdata.TabIndex = 1;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Open.HeaderText = "Open";
      this.Open.Name = "Open";
      this.Open.ReadOnly = true;
      this.High.HeaderText = "High";
      this.High.Name = "High";
      this.High.ReadOnly = true;
      this.Low.HeaderText = "Low";
      this.Low.Name = "Low";
      this.Low.ReadOnly = true;
      this.ColClose.HeaderText = "Close";
      this.ColClose.Name = "ColClose";
      this.ColClose.ReadOnly = true;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 120;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(652, 488);
      this.Controls.Add((Control) this.dgvTickdata);
      this.Controls.Add((Control) this.toolStrip1);
      this.MaximizeBox = false;
      this.Name = nameof (TickData);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Historical Data";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((ISupportInitialize) this.dgvTickdata).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
