﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmForexSettings
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmForexSettings : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private ComboBox cmb_Clientcode;
    private GroupBox groupBox2;
    private ComboBox cmb_Symbols;
    private Label label1;
    private ComboBox cmb_Spread;
    private Label label2;
    private Label label3;
    private TextBox txt_MaxLot;
    private Label label4;
    private TextBox txt_MinLot;
    private GroupBox groupBox3;
    private ComboBox cmb_Leverage;
    private Button btn_SaveSettings;
    private Button btn_close;
    private Button btn_SaveLeverage;

    public frmForexSettings(Dashboard frmdash)
    {
      this.InitializeComponent();
      this.objdash = frmdash;
      this.Icon = this.objdash.Icon;
    }

    private void btn_close_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    public void LoadWindow()
    {
      this.cmb_Clientcode.Items.Clear();
      foreach (object lstAccount in this.objdash._lstAccounts)
        this.cmb_Clientcode.Items.Add(lstAccount);
      if (this.cmb_Clientcode.Items.Count > 0)
        this.cmb_Clientcode.SelectedIndex = 0;
      this.cmb_Leverage.SelectedIndex = 0;
      this.cmb_Symbols.Items.Clear();
      foreach (object fxSymbol in this.objdash._FxSymbols)
        this.cmb_Symbols.Items.Add(fxSymbol);
      if (this.cmb_Symbols.Items.Count > 0)
        this.cmb_Symbols.SelectedIndex = 0;
      this.cmb_Spread.SelectedIndex = 0;
    }

    private void btn_SaveLeverage_Click(object sender, EventArgs e)
    {
      if (this.cmb_Clientcode.Text == null || this.cmb_Clientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select Clientcode", 2);
      else if (this.cmb_Leverage.Text == string.Empty)
        this.objdash.DisplayMessage("Select Leverage", 2);
      else if (Limits.UpdateLeverage(this.cmb_Clientcode.Text, this.cmb_Leverage.Text, this.objdash.conn))
        this.objdash.DisplayMessage("Leverage updated", 1);
      else
        this.objdash.DisplayMessage("unable to update leverage", 2);
    }

    private void btn_Submit_Click(object sender, EventArgs e)
    {
      if (this.cmb_Clientcode.Text == string.Empty)
        this.objdash.DisplayMessage("Select Clientcode", 2);
      else if (this.cmb_Symbols.Text == string.Empty)
        this.objdash.DisplayMessage("Select Symbol", 2);
      else if (this.cmb_Spread.Text == string.Empty)
        this.objdash.DisplayMessage("Select Spread", 2);
      else if (this.txt_MinLot.Text == string.Empty)
        this.objdash.DisplayMessage("Enter Min Lot", 2);
      else if (this.txt_MaxLot.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter Min Lot", 2);
      }
      else
      {
        FXsettings _data = new FXsettings();
        _data.clientcode = this.cmb_Clientcode.Text;
        _data.symbol = this.cmb_Symbols.Text;
        _data.spread = this.cmb_Spread.SelectedIndex == 0 ? 0 : Convert.ToInt32(this.cmb_Spread.Text);
        _data.minLots = Convert.ToDouble(this.txt_MinLot.Text);
        _data.maxLots = Convert.ToDouble(this.txt_MaxLot.Text);
        if (this.objdash.flag == 1)
        {
          if (!FXSql.Connect())
            return;
          if (FXSql.SaveSettings(_data, this.objdash.conn))
            this.objdash.DisplayMessage("Settings saved", 1);
          else
            this.objdash.DisplayMessage("Unable to save settings", 2);
        }
        else if (FXSql.Connect236())
        {
          if (FXSql.SaveSettings(_data, this.objdash.conn))
            this.objdash.DisplayMessage("Settings saved", 1);
          else
            this.objdash.DisplayMessage("Unable to save settings", 2);
        }
      }
    }

    private void cmb_Symbols_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmb_Clientcode.Text == null && !(this.cmb_Clientcode.Text != string.Empty) || !this.objdash._ClientFXsettings.ContainsKey(this.cmb_Clientcode.Text))
        return;
      Dictionary<string, FXsettings> clientFxsetting = this.objdash._ClientFXsettings[this.cmb_Clientcode.Text];
      if (this.cmb_Symbols.Text != string.Empty)
      {
        if (clientFxsetting.ContainsKey(this.cmb_Symbols.Text))
        {
          FXsettings fxsettings = clientFxsetting[this.cmb_Symbols.Text];
          this.cmb_Spread.SelectedIndex = fxsettings.spread;
          this.txt_MinLot.Text = fxsettings.minLots.ToString();
          this.txt_MaxLot.Text = fxsettings.maxLots.ToString();
        }
        else
        {
          this.cmb_Spread.SelectedIndex = 0;
          this.txt_MinLot.Text = this.txt_MaxLot.Text = string.Empty;
        }
      }
    }

    private void cmb_Clientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (!(this.cmb_Clientcode.Text != string.Empty))
        return;
      if (this.objdash._ClientwiseLeverage.ContainsKey(this.cmb_Clientcode.Text))
        this.cmb_Leverage.SelectedItem = (object) this.objdash._ClientwiseLeverage[this.cmb_Clientcode.Text];
      else
        this.cmb_Leverage.Text = string.Empty;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.cmb_Clientcode = new ComboBox();
      this.groupBox2 = new GroupBox();
      this.txt_MaxLot = new TextBox();
      this.btn_SaveSettings = new Button();
      this.label4 = new Label();
      this.txt_MinLot = new TextBox();
      this.label3 = new Label();
      this.label2 = new Label();
      this.cmb_Spread = new ComboBox();
      this.label1 = new Label();
      this.cmb_Symbols = new ComboBox();
      this.groupBox3 = new GroupBox();
      this.btn_SaveLeverage = new Button();
      this.cmb_Leverage = new ComboBox();
      this.btn_close = new Button();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.cmb_Clientcode);
      this.groupBox1.Location = new Point(1, 12);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(152, 54);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Clientcode";
      this.cmb_Clientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmb_Clientcode.FormattingEnabled = true;
      this.cmb_Clientcode.Location = new Point(11, 21);
      this.cmb_Clientcode.Name = "cmb_Clientcode";
      this.cmb_Clientcode.Size = new Size(121, 21);
      this.cmb_Clientcode.TabIndex = 1;
      this.cmb_Clientcode.SelectedIndexChanged += new EventHandler(this.cmb_Clientcode_SelectedIndexChanged);
      this.groupBox2.Controls.Add((Control) this.txt_MaxLot);
      this.groupBox2.Controls.Add((Control) this.btn_SaveSettings);
      this.groupBox2.Controls.Add((Control) this.label4);
      this.groupBox2.Controls.Add((Control) this.txt_MinLot);
      this.groupBox2.Controls.Add((Control) this.label3);
      this.groupBox2.Controls.Add((Control) this.label2);
      this.groupBox2.Controls.Add((Control) this.cmb_Spread);
      this.groupBox2.Controls.Add((Control) this.label1);
      this.groupBox2.Controls.Add((Control) this.cmb_Symbols);
      this.groupBox2.Location = new Point(159, 12);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(334, 153);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Settings";
      this.txt_MaxLot.Location = new Point(206, 87);
      this.txt_MaxLot.MaxLength = 7;
      this.txt_MaxLot.Name = "txt_MaxLot";
      this.txt_MaxLot.Size = new Size(78, 20);
      this.txt_MaxLot.TabIndex = 8;
      this.btn_SaveSettings.Location = new Point(130, 120);
      this.btn_SaveSettings.Name = "btn_SaveSettings";
      this.btn_SaveSettings.Size = new Size(75, 23);
      this.btn_SaveSettings.TabIndex = 3;
      this.btn_SaveSettings.Text = "Save";
      this.btn_SaveSettings.UseVisualStyleBackColor = true;
      this.btn_SaveSettings.Click += new EventHandler(this.btn_Submit_Click);
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label4.Location = new Point(155, 90);
      this.label4.Name = "label4";
      this.label4.Size = new Size(54, 15);
      this.label4.TabIndex = 7;
      this.label4.Text = "Max Lot:";
      this.txt_MinLot.Location = new Point(206, 56);
      this.txt_MinLot.MaxLength = 7;
      this.txt_MinLot.Name = "txt_MinLot";
      this.txt_MinLot.Size = new Size(78, 20);
      this.txt_MinLot.TabIndex = 6;
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label3.Location = new Point(158, 56);
      this.label3.Name = "label3";
      this.label3.Size = new Size(51, 15);
      this.label3.TabIndex = 5;
      this.label3.Text = "Min Lot:";
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(284, 22);
      this.label2.Name = "label2";
      this.label2.Size = new Size(41, 15);
      this.label2.TabIndex = 4;
      this.label2.Text = "Points";
      this.cmb_Spread.FormattingEnabled = true;
      this.cmb_Spread.Items.AddRange(new object[11]
      {
        (object) "Default",
        (object) "1",
        (object) "2",
        (object) "3",
        (object) "4",
        (object) "5",
        (object) "6",
        (object) "7",
        (object) "8",
        (object) "9",
        (object) "10"
      });
      this.cmb_Spread.Location = new Point(206, 21);
      this.cmb_Spread.Name = "cmb_Spread";
      this.cmb_Spread.Size = new Size(78, 21);
      this.cmb_Spread.TabIndex = 3;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(159, 22);
      this.label1.Name = "label1";
      this.label1.Size = new Size(50, 15);
      this.label1.TabIndex = 2;
      this.label1.Text = "Spread:";
      this.cmb_Symbols.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmb_Symbols.FormattingEnabled = true;
      this.cmb_Symbols.Location = new Point(11, 21);
      this.cmb_Symbols.Name = "cmb_Symbols";
      this.cmb_Symbols.Size = new Size(121, 21);
      this.cmb_Symbols.TabIndex = 1;
      this.cmb_Symbols.SelectedIndexChanged += new EventHandler(this.cmb_Symbols_SelectedIndexChanged);
      this.groupBox3.Controls.Add((Control) this.btn_SaveLeverage);
      this.groupBox3.Controls.Add((Control) this.cmb_Leverage);
      this.groupBox3.Location = new Point(1, 72);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(152, 93);
      this.groupBox3.TabIndex = 2;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Leverage";
      this.btn_SaveLeverage.Location = new Point(39, 60);
      this.btn_SaveLeverage.Name = "btn_SaveLeverage";
      this.btn_SaveLeverage.Size = new Size(75, 23);
      this.btn_SaveLeverage.TabIndex = 9;
      this.btn_SaveLeverage.Text = "Save";
      this.btn_SaveLeverage.UseVisualStyleBackColor = true;
      this.btn_SaveLeverage.Click += new EventHandler(this.btn_SaveLeverage_Click);
      this.cmb_Leverage.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmb_Leverage.FormattingEnabled = true;
      this.cmb_Leverage.Items.AddRange(new object[10]
      {
        (object) "1:100",
        (object) "1:200",
        (object) "1:300",
        (object) "1:400",
        (object) "1:500",
        (object) "1:600",
        (object) "1:700",
        (object) "1:800",
        (object) "1:900",
        (object) "1:1000"
      });
      this.cmb_Leverage.Location = new Point(11, 21);
      this.cmb_Leverage.Name = "cmb_Leverage";
      this.cmb_Leverage.Size = new Size(121, 21);
      this.cmb_Leverage.TabIndex = 1;
      this.btn_close.Location = new Point(215, 174);
      this.btn_close.Name = "btn_close";
      this.btn_close.Size = new Size(75, 23);
      this.btn_close.TabIndex = 4;
      this.btn_close.Text = "Close";
      this.btn_close.UseVisualStyleBackColor = true;
      this.btn_close.Click += new EventHandler(this.btn_close_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(504, 204);
      this.Controls.Add((Control) this.btn_close);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.Name = nameof (frmForexSettings);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Forex Settings";
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.ResumeLayout(false);
    }
  }
}
