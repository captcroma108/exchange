﻿// Decompiled with JetBrains decompiler
// Type: DTS.AboutBox1
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace DTS
{
  internal class AboutBox1 : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private Button okButton;
    private TextBox textBoxDescription;
    private Label labelCompanyName;
    private Label labelCopyright;
    private Label labelVersion;
    private Label labelProductName;
    private TableLayoutPanel tableLayoutPanel;

    public AboutBox1(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Text = string.Format("About {0}", (object) this.objdash.objinfo.AppName);
      this.labelProductName.Text = string.Format("Product Name: {0}", (object) this.objdash.objinfo.AppName);
      this.labelVersion.Text = string.Format("Version {0}", (object) this.AssemblyVersion);
      this.labelCopyright.Text = string.Format("Copyright @ 2015 {0}", (object) this.objdash.objinfo.AppName);
      this.labelCompanyName.Text = string.Format("Company Name: {0}", (object) this.objdash.objinfo.AppName);
    }

    public string AssemblyTitle
    {
      get
      {
        object[] customAttributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof (AssemblyTitleAttribute), false);
        if ((uint) customAttributes.Length > 0U)
        {
          AssemblyTitleAttribute assemblyTitleAttribute = (AssemblyTitleAttribute) customAttributes[0];
          if (assemblyTitleAttribute.Title != "")
            return assemblyTitleAttribute.Title;
        }
        return Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
      }
    }

    public string AssemblyVersion
    {
      get
      {
        return Assembly.GetExecutingAssembly().GetName().Version.ToString();
      }
    }

    public string AssemblyDescription
    {
      get
      {
        object[] customAttributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof (AssemblyDescriptionAttribute), false);
        return customAttributes.Length == 0 ? "" : ((AssemblyDescriptionAttribute) customAttributes[0]).Description;
      }
    }

    public string AssemblyProduct
    {
      get
      {
        object[] customAttributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof (AssemblyProductAttribute), false);
        return customAttributes.Length == 0 ? "" : ((AssemblyProductAttribute) customAttributes[0]).Product;
      }
    }

    public string AssemblyCopyright
    {
      get
      {
        object[] customAttributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof (AssemblyCopyrightAttribute), false);
        return customAttributes.Length == 0 ? "" : ((AssemblyCopyrightAttribute) customAttributes[0]).Copyright;
      }
    }

    public string AssemblyCompany
    {
      get
      {
        object[] customAttributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof (AssemblyCompanyAttribute), false);
        return customAttributes.Length == 0 ? "" : ((AssemblyCompanyAttribute) customAttributes[0]).Company;
      }
    }

    private void okButton_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (AboutBox1));
      this.okButton = new Button();
      this.textBoxDescription = new TextBox();
      this.labelCompanyName = new Label();
      this.labelCopyright = new Label();
      this.labelVersion = new Label();
      this.labelProductName = new Label();
      this.tableLayoutPanel = new TableLayoutPanel();
      this.tableLayoutPanel.SuspendLayout();
      this.SuspendLayout();
      this.okButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
      this.okButton.DialogResult = DialogResult.Cancel;
      this.okButton.Location = new Point(339, 322);
      this.okButton.Name = "okButton";
      this.okButton.Size = new Size(75, 23);
      this.okButton.TabIndex = 24;
      this.okButton.Text = "&OK";
      this.okButton.Click += new EventHandler(this.okButton_Click);
      this.textBoxDescription.Dock = DockStyle.Fill;
      this.textBoxDescription.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.textBoxDescription.Location = new Point(6, 171);
      this.textBoxDescription.Margin = new Padding(6, 3, 3, 3);
      this.textBoxDescription.Multiline = true;
      this.textBoxDescription.Name = "textBoxDescription";
      this.textBoxDescription.ReadOnly = true;
      this.textBoxDescription.Size = new Size(408, 129);
      this.textBoxDescription.TabIndex = 23;
      this.textBoxDescription.TabStop = false;
      this.textBoxDescription.Text = componentResourceManager.GetString("textBoxDescription.Text");
      this.labelCompanyName.Dock = DockStyle.Fill;
      this.labelCompanyName.Location = new Point(6, 126);
      this.labelCompanyName.Margin = new Padding(6, 0, 3, 0);
      this.labelCompanyName.MaximumSize = new Size(0, 17);
      this.labelCompanyName.Name = "labelCompanyName";
      this.labelCompanyName.Size = new Size(408, 17);
      this.labelCompanyName.TabIndex = 22;
      this.labelCompanyName.Text = "Company Name:";
      this.labelCompanyName.TextAlign = ContentAlignment.MiddleLeft;
      this.labelCopyright.Dock = DockStyle.Fill;
      this.labelCopyright.Location = new Point(6, 84);
      this.labelCopyright.Margin = new Padding(6, 0, 3, 0);
      this.labelCopyright.MaximumSize = new Size(0, 17);
      this.labelCopyright.Name = "labelCopyright";
      this.labelCopyright.Size = new Size(408, 17);
      this.labelCopyright.TabIndex = 21;
      this.labelCopyright.Text = "Copyright: @ 2017";
      this.labelCopyright.TextAlign = ContentAlignment.MiddleLeft;
      this.labelVersion.Dock = DockStyle.Fill;
      this.labelVersion.Location = new Point(6, 42);
      this.labelVersion.Margin = new Padding(6, 0, 3, 0);
      this.labelVersion.MaximumSize = new Size(0, 17);
      this.labelVersion.Name = "labelVersion";
      this.labelVersion.Size = new Size(408, 17);
      this.labelVersion.TabIndex = 0;
      this.labelVersion.Text = "Version: 1.0.36";
      this.labelVersion.TextAlign = ContentAlignment.MiddleLeft;
      this.labelProductName.Dock = DockStyle.Fill;
      this.labelProductName.Location = new Point(6, 0);
      this.labelProductName.Margin = new Padding(6, 0, 3, 0);
      this.labelProductName.MaximumSize = new Size(0, 17);
      this.labelProductName.Name = "labelProductName";
      this.labelProductName.Size = new Size(408, 17);
      this.labelProductName.TabIndex = 19;
      this.labelProductName.Text = "Product Name:";
      this.labelProductName.TextAlign = ContentAlignment.MiddleLeft;
      this.tableLayoutPanel.ColumnCount = 1;
      this.tableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
      this.tableLayoutPanel.Controls.Add((Control) this.labelProductName, 0, 0);
      this.tableLayoutPanel.Controls.Add((Control) this.labelVersion, 0, 1);
      this.tableLayoutPanel.Controls.Add((Control) this.labelCopyright, 0, 2);
      this.tableLayoutPanel.Controls.Add((Control) this.labelCompanyName, 0, 3);
      this.tableLayoutPanel.Controls.Add((Control) this.textBoxDescription, 0, 4);
      this.tableLayoutPanel.Controls.Add((Control) this.okButton, 0, 5);
      this.tableLayoutPanel.Dock = DockStyle.Fill;
      this.tableLayoutPanel.Location = new Point(9, 9);
      this.tableLayoutPanel.Name = "tableLayoutPanel";
      this.tableLayoutPanel.RowCount = 6;
      this.tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.21001f));
      this.tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.21001f));
      this.tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.21001f));
      this.tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.21001f));
      this.tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 38.94993f));
      this.tableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 12.21001f));
      this.tableLayoutPanel.Size = new Size(417, 348);
      this.tableLayoutPanel.TabIndex = 0;
      this.AcceptButton = (IButtonControl) this.okButton;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.BackColor = SystemColors.Control;
      this.ClientSize = new Size(435, 366);
      this.Controls.Add((Control) this.tableLayoutPanel);
      this.FormBorderStyle = FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (AboutBox1);
      this.Padding = new Padding(9);
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "About";
      this.tableLayoutPanel.ResumeLayout(false);
      this.tableLayoutPanel.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
