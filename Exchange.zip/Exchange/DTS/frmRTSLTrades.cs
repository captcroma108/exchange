﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmRTSLTrades
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmRTSLTrades : Form
  {
    private int index = -1;
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private Thread threadObjRT_Orders;
    public int dgvrowindex;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripLabel toolStripLabel1;
    private ToolStripComboBox cmbExch;
    private ToolStripLabel toolStripLabel4;
    private ToolStripComboBox cmbSymbol;
    private ToolStripLabel toolStripLabel5;
    private ToolStripComboBox cmbBuySell;
    private ToolStripLabel toolStripLabel3;
    private ToolStripComboBox cmbTraderid;
    private ToolStripButton btnSearch;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem toolStripGrid;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripMenuItem copyToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem exportToCsvToolStripMenuItem;
    private ToolStripMenuItem exportToTxtToolStripMenuItem;
    public DataGridView dgvTradeBook;
    private DataGridViewTextBoxColumn Clientcode;
    private DataGridViewTextBoxColumn ColName;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn ColExpiry;
    private DataGridViewTextBoxColumn Productype;
    private DataGridViewTextBoxColumn ColexeType;
    private DataGridViewTextBoxColumn Buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn ColOrdPrice;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn UserRemarks;
    private DataGridViewTextBoxColumn TradedBy;
    private DataGridViewTextBoxColumn Orderno;
    private DataGridViewTextBoxColumn colIp;
    private DataGridViewCheckBoxColumn read;

    public frmRTSLTrades(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadWindow()
    {
      if (this.threadObjRT_Orders != null)
        return;
      this.threadObjRT_Orders = new Thread(new ThreadStart(((ThreadStart) (() => this.LoadRTTrades())).Invoke));
      this.threadObjRT_Orders.Start();
    }

    private void LoadRTTrades()
    {
      SqlConnection conn = this.objdash.getConn();
      DateTime dateTime = this.objdash.GetServerTime();
      dateTime = new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 9, 0, 0);
      this.Invoke((Delegate) (() =>
      {
        this.dgvTradeBook.Rows.Clear();
        this.clearCombobox();
      }));
      int num = this.objdash.objinfo.usertype - 1;
      List<double> doubleList = new List<double>();
      string str1 = this.objdash.objinfo.createdby;
      if (this.objdash.objinfo.usertype == 4 || this.objdash.objinfo.usertype == 2 || this.objdash.objinfo.usertype == 1)
        str1 = this.objdash.objinfo.clientcode;
      while (true)
      {
        try
        {
          if (conn.State == ConnectionState.Open)
          {
            SqlCommand sqlCommand1 = new SqlCommand("GetRTTrades", conn);
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            using (SqlCommand sqlCommand2 = sqlCommand1)
            {
              sqlCommand2.Parameters.AddWithValue("@DAcode", (object) str1);
              sqlCommand2.Parameters.AddWithValue("@lastupdatetime", (object) dateTime);
              sqlCommand2.Parameters.AddWithValue("@type", (object) num);
              using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  Orders objord = new Orders();
                  string exch = string.Empty;
                  string empty1 = string.Empty;
                  string BuySell = string.Empty;
                  string empty2 = string.Empty;
                  if (!sqlDataReader.IsDBNull(0))
                    objord.accountNo = sqlDataReader.GetString(0);
                  if (!sqlDataReader.IsDBNull(12))
                    objord.AccName = sqlDataReader.GetString(12);
                  if (!sqlDataReader.IsDBNull(1))
                    exch = sqlDataReader.GetString(1);
                  if (!sqlDataReader.IsDBNull(2))
                    objord.symbol = sqlDataReader.GetString(2);
                  if (!sqlDataReader.IsDBNull(3))
                    empty1 = sqlDataReader.GetString(3);
                  if (!sqlDataReader.IsDBNull(4))
                    BuySell = sqlDataReader.GetString(4);
                  if (!sqlDataReader.IsDBNull(5))
                    objord.Ordeqty = sqlDataReader.GetInt32(5);
                  if (!sqlDataReader.IsDBNull(6))
                    objord.ExecPrice = Convert.ToDecimal(sqlDataReader.GetValue(6));
                  if (!sqlDataReader.IsDBNull(7))
                    empty2 = sqlDataReader.GetString(7);
                  if (!sqlDataReader.IsDBNull(8))
                    objord.LastModified = Convert.ToDateTime(sqlDataReader.GetValue(8));
                  if (!sqlDataReader.IsDBNull(9))
                    objord.UserRemark = sqlDataReader.GetString(9);
                  if (!sqlDataReader.IsDBNull(10))
                    objord.TraderId = sqlDataReader.GetString(10);
                  if (!sqlDataReader.IsDBNull(11))
                    objord.OrderNo = Convert.ToDouble(sqlDataReader.GetValue(11));
                  if (!sqlDataReader.IsDBNull(13))
                    objord.OrdePrice = Convert.ToDecimal(sqlDataReader.GetValue(13));
                  if (!sqlDataReader.IsDBNull(14))
                    objord.Exectype = sqlDataReader.GetInt32(14);
                  objord.ipAddress = !sqlDataReader.IsDBNull(16) ? sqlDataReader.GetString(16).Trim() : string.Empty;
                  if (this.objdash.objinfo.usertype == 3 || this.objdash._lstAccounts.Contains(objord.accountNo))
                  {
                    dateTime = objord.LastModified;
                    if (empty1.ToUpper() == "SL")
                    {
                      string traderId = objord.TraderId;
                      string[] strArray = objord.symbol.Split(' ');
                      string str2 = "LMT";
                      if (objord.Exectype == 2)
                        str2 = "MKT";
                      object[] rows = new object[17]
                      {
                        (object) objord.accountNo,
                        (object) objord.AccName,
                        (object) exch,
                        (object) strArray[0],
                        (object) strArray[1],
                        (object) empty1,
                        (object) str2,
                        (object) BuySell.Substring(0, 1),
                        (object) objord.Ordeqty,
                        (object) objord.OrdePrice,
                        (object) objord.ExecPrice,
                        (object) empty2,
                        (object) objord.LastModified.ToString("HH:mm:ss"),
                        (object) objord.UserRemark,
                        (object) traderId,
                        (object) objord.OrderNo,
                        (object) objord.ipAddress
                      };
                      this.Invoke((Delegate) (() =>
                      {
                        this.FillCombobox(objord, exch);
                        this.dgvTradeBook.Rows.Insert(0, rows);
                        if (BuySell == "BUY")
                          this.dgvTradeBook.Rows[0].DefaultCellStyle.BackColor = Color.LightBlue;
                        else
                          this.dgvTradeBook.Rows[0].DefaultCellStyle.BackColor = Color.Pink;
                        this.findOrdNO1();
                      }));
                    }
                  }
                }
              }
            }
          }
          Thread.Sleep(3000);
        }
        catch
        {
          Thread.Sleep(5000);
        }
      }
    }

    private void clearCombobox()
    {
      this.cmbclientcode.Items.Clear();
      this.cmbclientcode.Items.Add((object) "");
      this.cmbExch.Items.Clear();
      this.cmbExch.Items.Add((object) "");
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "");
      this.cmbTraderid.Items.Clear();
      this.cmbTraderid.Items.Add((object) "");
    }

    private void FillCombobox(Orders objord, string exch)
    {
      if (!this.cmbclientcode.Items.Contains((object) objord.accountNo))
        this.cmbclientcode.Items.Add((object) objord.accountNo);
      if (!this.cmbExch.Items.Contains((object) exch))
        this.cmbExch.Items.Add((object) exch);
      if (!this.cmbSymbol.Items.Contains((object) objord.symbol))
        this.cmbSymbol.Items.Add((object) objord.symbol);
      if (this.cmbTraderid.Items.Contains((object) objord.TraderId))
        return;
      this.cmbTraderid.Items.Add((object) objord.TraderId);
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvTradeBook.Rows)
          row.Visible = true;
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && (str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text) && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[7].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[7].Value.ToString() == this.cmbBuySell.Text && row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(this.cmbclientcode.Text == string.Empty) || !(this.cmbExch.Text == string.Empty) || (!(this.cmbSymbol.Text == string.Empty) || !(this.cmbBuySell.Text == string.Empty)) || !(this.cmbTraderid.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
        {
          if (row.Cells[14].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    private void frmRTSLTrades_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.C)
        this.cmbclientcode.Focus();
      else if (e.KeyCode == Keys.E)
        this.cmbExch.Focus();
      else if (e.KeyCode == Keys.S)
      {
        this.cmbSymbol.Focus();
      }
      else
      {
        if (e.KeyCode != Keys.T)
          return;
        this.cmbTraderid.Focus();
      }
    }

    private void dgvTradeBook_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvTradeBook.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvTradeBook, client.X, client.Y);
    }

    private void toolStripGrid_Click(object sender, EventArgs e)
    {
      if (this.toolStripGrid.Checked)
        this.dgvTradeBook.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
      else
        this.dgvTradeBook.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void copyToolStripMenuItem_Click(object sender, EventArgs e)
    {
      Clipboard.SetDataObject((object) this.dgvTradeBook.GetClipboardContent());
    }

    private void exportToCsvToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeBook.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvTradeBook, false);
    }

    private void exportToTxtToolStripMenuItem_Click(object sender, EventArgs e)
    {
    }

    private void dgvTradeBook_CellClick_1(object sender, DataGridViewCellEventArgs e)
    {
      this.dgvrowindex = e.RowIndex;
      if (this.dgvrowindex <= -1)
        return;
      if (this.dgvTradeBook.Rows[e.RowIndex].Cells[17].Value == null)
      {
        int index = this.dgvTradeBook.Rows[e.RowIndex].Index;
        string str = this.dgvTradeBook.Rows[e.RowIndex].Cells[15].Value.ToString();
        this.dgvTradeBook.Rows[e.RowIndex].Cells[17].Value = (object) true;
        Settings.Default.slrdindex = index;
        Settings.Default.SlordNo = str;
        Settings.Default.Save();
        this.findOrdNO();
      }
      else if ((bool) this.dgvTradeBook.Rows[e.RowIndex].Cells[17].Value)
      {
        this.index = this.dgvTradeBook.Rows[e.RowIndex].Index;
        string str = this.index != this.dgvTradeBook.Rows.Count - 1 ? this.dgvTradeBook.Rows[e.RowIndex + 1].Cells[15].Value.ToString() : this.dgvTradeBook.Rows[e.RowIndex].Cells[15].Value.ToString();
        this.dgvTradeBook.Rows[e.RowIndex].Cells[17].Value = (object) false;
        Settings.Default.SlordNo = str;
        Settings.Default.slrdindex = this.index + 1;
        this.untick();
      }
      else
      {
        int index = this.dgvTradeBook.Rows[e.RowIndex].Index;
        string str = this.dgvTradeBook.Rows[e.RowIndex].Cells[15].Value.ToString();
        this.dgvTradeBook.Rows[e.RowIndex].Cells[17].Value = (object) true;
        Settings.Default.slrdindex = index;
        Settings.Default.SlordNo = str;
        Settings.Default.Save();
        this.findOrdNO();
      }
    }

    public void untick()
    {
      if (this.index <= -1)
        return;
      for (int index = this.index; index >= 0; --index)
        this.dgvTradeBook.Rows[index].Cells[17].Value = (object) false;
    }

    public void findOrdNO()
    {
      foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
      {
        if (row.Cells[1].Value != null)
        {
          string str = row.Cells[15].Value.ToString();
          int slrdindex = Settings.Default.slrdindex;
          if (str == Settings.Default.SlordNo)
          {
            int count = this.dgvTradeBook.Rows.Count;
            if (slrdindex >= 0)
            {
              for (int index = slrdindex; index < count; ++index)
                this.dgvTradeBook.Rows[index].Cells[17].Value = (object) true;
            }
            else
              this.dgvTradeBook.Rows[row.Index].Cells[17].Value = (object) false;
          }
        }
      }
    }

    public void findOrdNO1()
    {
      foreach (DataGridViewRow row in (IEnumerable) this.dgvTradeBook.Rows)
      {
        if (row.Cells[1].Value != null)
        {
          string str = row.Cells[15].Value.ToString();
          int index1 = row.Index;
          if (str == Settings.Default.SlordNo)
          {
            int count = this.dgvTradeBook.Rows.Count;
            if (index1 >= 0)
            {
              for (int index2 = index1; index2 < count; ++index2)
                this.dgvTradeBook.Rows[index2].Cells[17].Value = (object) true;
            }
            else
              this.dgvTradeBook.Rows[row.Index].Cells[17].Value = (object) false;
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (frmRTSLTrades));
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.toolStripLabel1 = new ToolStripLabel();
      this.cmbExch = new ToolStripComboBox();
      this.toolStripLabel4 = new ToolStripLabel();
      this.cmbSymbol = new ToolStripComboBox();
      this.toolStripLabel5 = new ToolStripLabel();
      this.cmbBuySell = new ToolStripComboBox();
      this.toolStripLabel3 = new ToolStripLabel();
      this.cmbTraderid = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.toolStripGrid = new ToolStripMenuItem();
      this.toolStripSeparator2 = new ToolStripSeparator();
      this.copyToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator1 = new ToolStripSeparator();
      this.exportToCsvToolStripMenuItem = new ToolStripMenuItem();
      this.exportToTxtToolStripMenuItem = new ToolStripMenuItem();
      this.dgvTradeBook = new DataGridView();
      this.Clientcode = new DataGridViewTextBoxColumn();
      this.ColName = new DataGridViewTextBoxColumn();
      this.Exch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.ColExpiry = new DataGridViewTextBoxColumn();
      this.Productype = new DataGridViewTextBoxColumn();
      this.ColexeType = new DataGridViewTextBoxColumn();
      this.Buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.ColOrdPrice = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.UserRemarks = new DataGridViewTextBoxColumn();
      this.TradedBy = new DataGridViewTextBoxColumn();
      this.Orderno = new DataGridViewTextBoxColumn();
      this.colIp = new DataGridViewTextBoxColumn();
      this.read = new DataGridViewCheckBoxColumn();
      this.toolStrip1.SuspendLayout();
      this.contextMenuStrip1.SuspendLayout();
      ((ISupportInitialize) this.dgvTradeBook).BeginInit();
      this.SuspendLayout();
      this.toolStrip1.Items.AddRange(new ToolStripItem[11]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.toolStripLabel1,
        (ToolStripItem) this.cmbExch,
        (ToolStripItem) this.toolStripLabel4,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.toolStripLabel5,
        (ToolStripItem) this.cmbBuySell,
        (ToolStripItem) this.toolStripLabel3,
        (ToolStripItem) this.cmbTraderid,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1033, 25);
      this.toolStrip1.TabIndex = 5;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.toolStripLabel1.Name = "toolStripLabel1";
      this.toolStripLabel1.Size = new Size(57, 22);
      this.toolStripLabel1.Text = "Exchange";
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(121, 25);
      this.toolStripLabel4.Name = "toolStripLabel4";
      this.toolStripLabel4.Size = new Size(47, 22);
      this.toolStripLabel4.Text = "Symbol";
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(160, 25);
      this.cmbSymbol.Sorted = true;
      this.toolStripLabel5.Name = "toolStripLabel5";
      this.toolStripLabel5.Size = new Size(25, 22);
      this.toolStripLabel5.Text = "B/S";
      this.cmbBuySell.Items.AddRange(new object[2]
      {
        (object) "B",
        (object) "S"
      });
      this.cmbBuySell.Name = "cmbBuySell";
      this.cmbBuySell.Size = new Size(121, 25);
      this.toolStripLabel3.Name = "toolStripLabel3";
      this.toolStripLabel3.Size = new Size(51, 22);
      this.toolStripLabel3.Text = "Traderid";
      this.cmbTraderid.Name = "cmbTraderid";
      this.cmbTraderid.Size = new Size(121, 25);
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[6]
      {
        (ToolStripItem) this.toolStripGrid,
        (ToolStripItem) this.toolStripSeparator2,
        (ToolStripItem) this.copyToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator1,
        (ToolStripItem) this.exportToCsvToolStripMenuItem,
        (ToolStripItem) this.exportToTxtToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(144, 104);
      this.toolStripGrid.CheckOnClick = true;
      this.toolStripGrid.Name = "toolStripGrid";
      this.toolStripGrid.Size = new Size(143, 22);
      this.toolStripGrid.Text = "Grid";
      this.toolStripGrid.Click += new EventHandler(this.toolStripGrid_Click);
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new Size(140, 6);
      this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
      this.copyToolStripMenuItem.Size = new Size(143, 22);
      this.copyToolStripMenuItem.Text = "Copy";
      this.copyToolStripMenuItem.Click += new EventHandler(this.copyToolStripMenuItem_Click);
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new Size(140, 6);
      this.exportToCsvToolStripMenuItem.Name = "exportToCsvToolStripMenuItem";
      this.exportToCsvToolStripMenuItem.Size = new Size(143, 22);
      this.exportToCsvToolStripMenuItem.Text = "Export to Csv";
      this.exportToCsvToolStripMenuItem.Click += new EventHandler(this.exportToCsvToolStripMenuItem_Click);
      this.exportToTxtToolStripMenuItem.Name = "exportToTxtToolStripMenuItem";
      this.exportToTxtToolStripMenuItem.Size = new Size(143, 22);
      this.exportToTxtToolStripMenuItem.Text = "Export to Txt";
      this.exportToTxtToolStripMenuItem.Click += new EventHandler(this.exportToTxtToolStripMenuItem_Click);
      this.dgvTradeBook.AllowUserToAddRows = false;
      this.dgvTradeBook.AllowUserToDeleteRows = false;
      this.dgvTradeBook.AllowUserToOrderColumns = true;
      this.dgvTradeBook.AllowUserToResizeRows = false;
      this.dgvTradeBook.BackgroundColor = Color.White;
      this.dgvTradeBook.CellBorderStyle = DataGridViewCellBorderStyle.None;
      gridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle1.BackColor = SystemColors.Control;
      gridViewCellStyle1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle1.ForeColor = Color.Black;
      gridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle1.WrapMode = DataGridViewTriState.True;
      this.dgvTradeBook.ColumnHeadersDefaultCellStyle = gridViewCellStyle1;
      this.dgvTradeBook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvTradeBook.Columns.AddRange((DataGridViewColumn) this.Clientcode, (DataGridViewColumn) this.ColName, (DataGridViewColumn) this.Exch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.ColExpiry, (DataGridViewColumn) this.Productype, (DataGridViewColumn) this.ColexeType, (DataGridViewColumn) this.Buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.ColOrdPrice, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Time, (DataGridViewColumn) this.UserRemarks, (DataGridViewColumn) this.TradedBy, (DataGridViewColumn) this.Orderno, (DataGridViewColumn) this.colIp, (DataGridViewColumn) this.read);
      gridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle2.BackColor = SystemColors.Window;
      gridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle2.ForeColor = Color.Black;
      gridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle2.WrapMode = DataGridViewTriState.False;
      this.dgvTradeBook.DefaultCellStyle = gridViewCellStyle2;
      this.dgvTradeBook.Dock = DockStyle.Fill;
      this.dgvTradeBook.Location = new Point(0, 25);
      this.dgvTradeBook.MultiSelect = false;
      this.dgvTradeBook.Name = "dgvTradeBook";
      this.dgvTradeBook.ReadOnly = true;
      this.dgvTradeBook.RowHeadersVisible = false;
      this.dgvTradeBook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvTradeBook.Size = new Size(1033, 265);
      this.dgvTradeBook.TabIndex = 6;
      this.dgvTradeBook.CellClick += new DataGridViewCellEventHandler(this.dgvTradeBook_CellClick_1);
      this.Clientcode.HeaderText = "ClientCode";
      this.Clientcode.Name = "Clientcode";
      this.Clientcode.ReadOnly = true;
      this.Clientcode.Width = 90;
      this.ColName.HeaderText = "Name";
      this.ColName.Name = "ColName";
      this.ColName.ReadOnly = true;
      this.ColName.Width = 90;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.ColExpiry.HeaderText = "Expiry";
      this.ColExpiry.Name = "ColExpiry";
      this.ColExpiry.ReadOnly = true;
      this.ColExpiry.Width = 80;
      this.Productype.HeaderText = "ProductType";
      this.Productype.Name = "Productype";
      this.Productype.ReadOnly = true;
      this.Productype.Width = 60;
      this.ColexeType.HeaderText = "ExecType";
      this.ColexeType.Name = "ColexeType";
      this.ColexeType.ReadOnly = true;
      this.ColexeType.Width = 50;
      this.Buysell.HeaderText = "B/S";
      this.Buysell.Name = "Buysell";
      this.Buysell.ReadOnly = true;
      this.Buysell.Width = 40;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 50;
      this.ColOrdPrice.HeaderText = "Ord.Price";
      this.ColOrdPrice.Name = "ColOrdPrice";
      this.ColOrdPrice.ReadOnly = true;
      this.ColOrdPrice.Width = 60;
      this.Price.HeaderText = "Exec.Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 60;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 80;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 70;
      this.UserRemarks.HeaderText = "UserRemarks";
      this.UserRemarks.Name = "UserRemarks";
      this.UserRemarks.ReadOnly = true;
      this.UserRemarks.Width = 70;
      this.TradedBy.HeaderText = "TradedBy";
      this.TradedBy.Name = "TradedBy";
      this.TradedBy.ReadOnly = true;
      this.Orderno.HeaderText = "OrderNo";
      this.Orderno.Name = "Orderno";
      this.Orderno.ReadOnly = true;
      this.colIp.HeaderText = "IpAddress";
      this.colIp.Name = "colIp";
      this.colIp.ReadOnly = true;
      this.read.HeaderText = "Bookmark";
      this.read.Name = "read";
      this.read.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1033, 290);
      this.Controls.Add((Control) this.dgvTradeBook);
      this.Controls.Add((Control) this.toolStrip1);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.Name = nameof (frmRTSLTrades);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "View SL Trades";
      this.KeyUp += new KeyEventHandler(this.frmRTSLTrades_KeyUp);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.contextMenuStrip1.ResumeLayout(false);
      ((ISupportInitialize) this.dgvTradeBook).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
