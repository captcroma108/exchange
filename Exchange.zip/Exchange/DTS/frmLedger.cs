﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmLedger
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmLedger : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private DataGridView dgvledger;
    private DataGridViewTextBoxColumn col1;
    private DataGridViewTextBoxColumn col2;
    private DataGridViewTextBoxColumn col3;
    private DataGridViewTextBoxColumn col4;
    private DataGridViewTextBoxColumn col5;
    private DataGridViewTextBoxColumn col6;
    private DataGridViewTextBoxColumn col7;
    private DataGridViewTextBoxColumn col8;
    private DataGridViewTextBoxColumn col9;
    private DataGridViewTextBoxColumn col10;
    private DataGridViewTextBoxColumn dpwd;
    private DataGridViewTextBoxColumn col11;
    private DataGridViewTextBoxColumn col12;
    private DataGridViewTextBoxColumn col13;
    private GroupBox groupBox1;
    private DateTimePicker Todate;
    private DateTimePicker Fromdate;
    private Label label2;
    private Label label1;
    private Button btnView;
    private Button btnExport;
    private ComboBox cmbClientcode;
    private Label label3;

    public frmLedger(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void Loadwindow()
    {
      if (this.objdash.objinfo.usertype == 3)
      {
        this.label3.Visible = true;
        this.cmbClientcode.Items.Clear();
        foreach (object lstAccount in this.objdash._lstAccounts)
          this.cmbClientcode.Items.Add(lstAccount);
        if (this.cmbClientcode.Items.Count > 0)
          this.cmbClientcode.SelectedIndex = 0;
        this.cmbClientcode.Visible = true;
      }
      else
      {
        this.label3.Visible = false;
        this.cmbClientcode.Visible = false;
      }
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      this.dgvledger.Rows.Clear();
      string str1 = this.cmbClientcode.Text;
      if (this.objdash.objinfo.usertype == 4)
        str1 = this.objdash.objinfo.clientcode;
      DateTime serverTime = this.objdash.GetServerTime();
      if (str1.Length <= 0)
        return;
      DateTime dateTime = this.Fromdate.Value;
      string fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
      dateTime = this.Fromdate.Value;
      switch (dateTime.DayOfWeek)
      {
        case DayOfWeek.Sunday:
          dateTime = this.Fromdate.Value;
          dateTime = dateTime.AddDays(-1.0);
          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
          break;
        case DayOfWeek.Monday:
          dateTime = this.Fromdate.Value;
          dateTime = dateTime.AddDays(-2.0);
          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
          break;
      }
      dateTime = this.Fromdate.Value;
      string startdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
      dateTime = this.Todate.Value;
      string str2 = dateTime.ToString("yyyy-MM-dd 23:59:00");
      dateTime = this.Fromdate.Value;
      dateTime.ToString("yyyy-MM-dd 23:59:00");
      Dictionary<string, Ledger> dictionary = new Dictionary<string, Ledger>();
      Dictionary<string, Ledger> _Ledgervalues = (serverTime - this.Fromdate.Value).Days != 0 ? this.objdash.GetLedger(str1, startdate, str2) : this.objdash.GetIntraLedger(str1, startdate, str2);
      SortedDictionary<DateTime, payinoutDetails> payinPayout = this.objdash.GetPayinPayout(str1, fromdate, str2);
      Decimal begningBal = this.objdash.GetBegningBal(str1, this.Fromdate.Value, str2);
      this.DisplayLedger(_Ledgervalues, begningBal, payinPayout, str1);
    }

    private void AddLedgerCols()
    {
      this.dgvledger.DataSource = (object) null;
      this.dgvledger.Columns.Clear();
      this.dgvledger.Rows.Clear();
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Closed Date/Time";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Type";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Ticket";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "Symbol";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn6.HeaderText = "Amount";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn6);
      DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn7.HeaderText = "B/S";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn7);
      DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn8.HeaderText = "Open Date/Time";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn8);
      DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn9.HeaderText = "Open/BUY";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn9);
      DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn10.HeaderText = "Close/SELL";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn10);
      DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn11.HeaderText = "DP/WD";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn11);
      DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn12.HeaderText = "Comm";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn12);
      DataGridViewTextBoxColumn viewTextBoxColumn13 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn13.HeaderText = "Profit/Desc";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn13);
      DataGridViewTextBoxColumn viewTextBoxColumn14 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn14.HeaderText = "Net Profit";
      this.dgvledger.Columns.Add((DataGridViewColumn) viewTextBoxColumn14);
    }

    private void DisplayLedger(
      Dictionary<string, Ledger> _Ledgervalues,
      Decimal begbal,
      SortedDictionary<DateTime, payinoutDetails> _PayinOutDetails,
      string codee)
    {
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      double num4 = 0.0;
      if (_Ledgervalues.Count <= 0)
        return;
      this.AddLedgerCols();
      int index1 = 0;
      foreach (KeyValuePair<string, Ledger> ledgervalue in _Ledgervalues)
      {
        Ledger ledger = ledgervalue.Value;
        this.dgvledger.Rows.Add();
        this.dgvledger.Rows[index1].Cells[0].Value = (object) ledger.accountno;
        this.dgvledger.Rows[index1].Cells[1].Value = (object) ledger.CloseTime.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvledger.Rows[index1].Cells[2].Value = (object) "L";
        this.dgvledger.Rows[index1].Cells[3].Value = (object) ledger.orderno;
        this.dgvledger.Rows[index1].Cells[4].Value = (object) ledger.symbol;
        this.dgvledger.Rows[index1].Cells[5].Value = (object) ledger.sellqty;
        if (ledger.OpenTime > ledger.CloseTime)
        {
          this.dgvledger.Rows[index1].Cells[6].Value = (object) "S";
          this.dgvledger.Rows[index1].Cells[8].Value = (object) ledger.sellprice;
          this.dgvledger.Rows[index1].Cells[9].Value = (object) ledger.buyprice;
        }
        else
        {
          this.dgvledger.Rows[index1].Cells[6].Value = (object) "B";
          this.dgvledger.Rows[index1].Cells[8].Value = (object) ledger.buyprice;
          this.dgvledger.Rows[index1].Cells[9].Value = (object) ledger.sellprice;
        }
        this.dgvledger.Rows[index1].Cells[7].Value = (object) ledger.OpenTime.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvledger.Rows[index1].Cells[11].Value = (object) ledger.comm;
        this.dgvledger.Rows[index1].Cells[12].Value = (object) ledger.profitLoss;
        this.dgvledger.Rows[index1].Cells[13].Value = (object) ledger.NettPl;
        num1 += ledger.comm;
        num2 += Convert.ToDecimal(ledger.profitLoss);
        num3 += ledger.NettPl;
        ++index1;
      }
      foreach (KeyValuePair<DateTime, payinoutDetails> payinOutDetail in _PayinOutDetails)
      {
        int index2 = this.dgvledger.Rows.Add();
        this.dgvledger.Rows[index2].Cells[0].Value = (object) codee;
        this.dgvledger.Rows[index2].Cells[1].Value = (object) payinOutDetail.Key.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvledger.Rows[index2].Cells[3].Value = (object) payinOutDetail.Value.comments;
        if (payinOutDetail.Value.payinout.ToUpper() == "PAYIN")
        {
          this.dgvledger.Rows[index2].Cells[2].Value = (object) "DP";
          this.dgvledger.Rows[index2].Cells[10].Value = (object) payinOutDetail.Value.amount;
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 += payinOutDetail.Value.amount;
        }
        else if (payinOutDetail.Value.payinout.ToUpper() == "PAYOUT")
        {
          this.dgvledger.Rows[index2].Cells[2].Value = (object) "WD";
          this.dgvledger.Rows[index2].Cells[10].Value = (object) (payinOutDetail.Value.amount * -1.0);
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 -= payinOutDetail.Value.amount;
        }
        ++index1;
      }
      this.dgvledger.Sort(this.dgvledger.Columns[1], ListSortDirection.Ascending);
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index1].Cells[9].Value = (object) "Totals:";
      this.dgvledger.Rows[index1].Cells[10].Value = (object) num4;
      this.dgvledger.Rows[index1].Cells[11].Value = (object) (num1 * Decimal.MinusOne);
      this.dgvledger.Rows[index1].Cells[12].Value = (object) num2;
      this.dgvledger.Rows[index1].Cells[13].Value = (object) num3;
      int index3 = index1 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index3].Cells[0].Value = (object) "Account Summary";
      int index4 = index3 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index4].Cells[0].Value = (object) "Beg.Balance";
      this.dgvledger.Rows[index4].Cells[1].Value = (object) begbal;
      int index5 = index4 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index5].Cells[0].Value = (object) "Margin In/Out";
      this.dgvledger.Rows[index5].Cells[1].Value = (object) num4;
      int index6 = index5 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index6].Cells[0].Value = (object) "Trading Profit/Loss";
      this.dgvledger.Rows[index6].Cells[1].Value = (object) num2;
      int index7 = index6 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index7].Cells[0].Value = (object) "Commissions";
      this.dgvledger.Rows[index7].Cells[1].Value = (object) (num1 * Decimal.MinusOne);
      int index8 = index7 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index8].Cells[0].Value = (object) "Net Trading Profit/Loss";
      this.dgvledger.Rows[index8].Cells[1].Value = (object) num3;
      int index9 = index8 + 1;
      this.dgvledger.Rows.Add();
      this.dgvledger.Rows[index9].Cells[0].Value = (object) "Balance";
      this.dgvledger.Rows[index9].Cells[1].Value = (object) (begbal + num3 + Convert.ToDecimal(num4));
    }

    private void btnExport_Click(object sender, EventArgs e)
    {
      if (this.dgvledger.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvledger, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvledger = new DataGridView();
      this.col1 = new DataGridViewTextBoxColumn();
      this.col2 = new DataGridViewTextBoxColumn();
      this.col3 = new DataGridViewTextBoxColumn();
      this.col4 = new DataGridViewTextBoxColumn();
      this.col5 = new DataGridViewTextBoxColumn();
      this.col6 = new DataGridViewTextBoxColumn();
      this.col7 = new DataGridViewTextBoxColumn();
      this.col8 = new DataGridViewTextBoxColumn();
      this.col9 = new DataGridViewTextBoxColumn();
      this.col10 = new DataGridViewTextBoxColumn();
      this.dpwd = new DataGridViewTextBoxColumn();
      this.col11 = new DataGridViewTextBoxColumn();
      this.col12 = new DataGridViewTextBoxColumn();
      this.col13 = new DataGridViewTextBoxColumn();
      this.groupBox1 = new GroupBox();
      this.Todate = new DateTimePicker();
      this.Fromdate = new DateTimePicker();
      this.label2 = new Label();
      this.label1 = new Label();
      this.btnView = new Button();
      this.btnExport = new Button();
      this.cmbClientcode = new ComboBox();
      this.label3 = new Label();
      ((ISupportInitialize) this.dgvledger).BeginInit();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      this.dgvledger.AllowUserToAddRows = false;
      this.dgvledger.AllowUserToDeleteRows = false;
      this.dgvledger.AllowUserToOrderColumns = true;
      this.dgvledger.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvledger.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvledger.Columns.AddRange((DataGridViewColumn) this.col1, (DataGridViewColumn) this.col2, (DataGridViewColumn) this.col3, (DataGridViewColumn) this.col4, (DataGridViewColumn) this.col5, (DataGridViewColumn) this.col6, (DataGridViewColumn) this.col7, (DataGridViewColumn) this.col8, (DataGridViewColumn) this.col9, (DataGridViewColumn) this.col10, (DataGridViewColumn) this.dpwd, (DataGridViewColumn) this.col11, (DataGridViewColumn) this.col12, (DataGridViewColumn) this.col13);
      this.dgvledger.Location = new Point(7, 90);
      this.dgvledger.Name = "dgvledger";
      this.dgvledger.ReadOnly = true;
      this.dgvledger.RowHeadersVisible = false;
      this.dgvledger.Size = new Size(932, 390);
      this.dgvledger.TabIndex = 2;
      this.col1.HeaderText = "ClientCode";
      this.col1.Name = "col1";
      this.col1.ReadOnly = true;
      this.col2.HeaderText = "Closed Date/Time";
      this.col2.Name = "col2";
      this.col2.ReadOnly = true;
      this.col3.HeaderText = "Type";
      this.col3.Name = "col3";
      this.col3.ReadOnly = true;
      this.col4.HeaderText = "Ticket";
      this.col4.Name = "col4";
      this.col4.ReadOnly = true;
      this.col5.HeaderText = "Symbol";
      this.col5.Name = "col5";
      this.col5.ReadOnly = true;
      this.col6.HeaderText = "Amount";
      this.col6.Name = "col6";
      this.col6.ReadOnly = true;
      this.col7.HeaderText = "B/S";
      this.col7.Name = "col7";
      this.col7.ReadOnly = true;
      this.col8.HeaderText = "Open Date/Time";
      this.col8.Name = "col8";
      this.col8.ReadOnly = true;
      this.col9.HeaderText = "Open/SL";
      this.col9.Name = "col9";
      this.col9.ReadOnly = true;
      this.col10.HeaderText = "Close/TP";
      this.col10.Name = "col10";
      this.col10.ReadOnly = true;
      this.dpwd.HeaderText = "DP/WD";
      this.dpwd.Name = "dpwd";
      this.dpwd.ReadOnly = true;
      this.col11.HeaderText = "Com";
      this.col11.Name = "col11";
      this.col11.ReadOnly = true;
      this.col12.HeaderText = "Profit/Desc";
      this.col12.Name = "col12";
      this.col12.ReadOnly = true;
      this.col13.HeaderText = "Net Profit";
      this.col13.Name = "col13";
      this.col13.ReadOnly = true;
      this.groupBox1.Controls.Add((Control) this.Todate);
      this.groupBox1.Controls.Add((Control) this.Fromdate);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(7, 7);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(184, 77);
      this.groupBox1.TabIndex = 3;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Date";
      this.Todate.CustomFormat = "dd-MMM-yyyy";
      this.Todate.Format = DateTimePickerFormat.Custom;
      this.Todate.Location = new Point(66, 45);
      this.Todate.Name = "Todate";
      this.Todate.Size = new Size(110, 20);
      this.Todate.TabIndex = 3;
      this.Fromdate.CustomFormat = "dd-MMM-yyyy";
      this.Fromdate.Format = DateTimePickerFormat.Custom;
      this.Fromdate.Location = new Point(66, 19);
      this.Fromdate.Name = "Fromdate";
      this.Fromdate.Size = new Size(110, 20);
      this.Fromdate.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(4, 48);
      this.label2.Name = "label2";
      this.label2.Size = new Size(49, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "To Date:";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(4, 23);
      this.label1.Name = "label1";
      this.label1.Size = new Size(59, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "From Date:";
      this.btnView.FlatStyle = FlatStyle.System;
      this.btnView.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnView.ForeColor = Color.Navy;
      this.btnView.Location = new Point(644, 50);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(109, 34);
      this.btnView.TabIndex = 64;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.btnExport.FlatStyle = FlatStyle.System;
      this.btnExport.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnExport.ForeColor = Color.Navy;
      this.btnExport.Location = new Point(829, 50);
      this.btnExport.Name = "btnExport";
      this.btnExport.Size = new Size(109, 34);
      this.btnExport.TabIndex = 63;
      this.btnExport.Text = "Export";
      this.btnExport.UseVisualStyleBackColor = true;
      this.btnExport.Click += new EventHandler(this.btnExport_Click);
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(200, 34);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(89, 21);
      this.cmbClientcode.Sorted = true;
      this.cmbClientcode.TabIndex = 66;
      this.cmbClientcode.Visible = false;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(199, 16);
      this.label3.Name = "label3";
      this.label3.Size = new Size(64, 13);
      this.label3.TabIndex = 65;
      this.label3.Text = "Client Code ";
      this.label3.Visible = false;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 486);
      this.Controls.Add((Control) this.cmbClientcode);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.btnView);
      this.Controls.Add((Control) this.btnExport);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.dgvledger);
      this.Name = nameof (frmLedger);
      this.Text = "View Ledger";
      ((ISupportInitialize) this.dgvledger).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
