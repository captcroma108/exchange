﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmSANetPfls
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmSANetPfls : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private RadioButton rdoPayout;
    private RadioButton rdoPayin;
    private GroupBox groupBox2;
    private Button btnSubmit;
    private TextBox txtComments;
    private Label label4;
    private TextBox txtamount;
    private Label label3;
    private TextBox txtCode;
    private Label label1;
    private DataGridView dgvNetPFls;
    private DataGridViewTextBoxColumn ColDACode;
    private DataGridViewTextBoxColumn ColMargin;
    private GroupBox groupBox3;
    private GroupBox groupBox4;
    private Label label2;
    private DateTimePicker Fromdate;
    private Label label5;
    private DateTimePicker Todate;
    private Button btnView;
    private DataGridView dgvAccountingLogs;
    private Label label6;
    private DataGridViewTextBoxColumn ColDA_Code;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    private DataGridViewTextBoxColumn ColAction;
    private DataGridViewTextBoxColumn ColTimestamp;

    public frmSANetPfls(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.Icon;
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      string str1 = string.Empty;
      foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this.objdash._DAHierarchy)
        str1 += string.Format("'{0}',", (object) keyValuePair.Key);
      if (str1.Length > 0)
        str1 = str1.Substring(0, str1.Length - 1);
      SqlConnection conn = this.objdash.getConn();
      this.dgvAccountingLogs.Rows.Clear();
      string[] strArray = new string[7];
      strArray[0] = "Select Amount, (case Action WHEN 1 THEN 'Profit/Loss' WHEN 2 THEN 'Payin' WHEN 3 THEN 'Payout' END) as Action,Timestamp,Dacode from SA_AccountingLogs where Timestamp between '";
      DateTime dateTime1 = this.Fromdate.Value;
      strArray[1] = dateTime1.ToString("yyyy-MM-dd 00:00:00");
      strArray[2] = "' and '";
      dateTime1 = this.Todate.Value;
      strArray[3] = dateTime1.ToString("yyyy-MM-dd 23:59:00");
      strArray[4] = "' and DACode in (";
      strArray[5] = str1;
      strArray[6] = ") order by Timestamp desc";
      using (SqlCommand sqlCommand = new SqlCommand(string.Concat(strArray), conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
            {
              double num = Convert.ToDouble(sqlDataReader.GetValue(0));
              string str2 = sqlDataReader.GetString(1);
              DateTime dateTime2 = Convert.ToDateTime(sqlDataReader.GetValue(2));
              int index = this.dgvAccountingLogs.Rows.Add();
              if (!sqlDataReader.IsDBNull(3))
                this.dgvAccountingLogs.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(3);
              this.dgvAccountingLogs.Rows[index].Cells[1].Value = (object) num;
              this.dgvAccountingLogs.Rows[index].Cells[2].Value = (object) str2;
              this.dgvAccountingLogs.Rows[index].Cells[3].Value = (object) dateTime2.ToString("dd-MM-yyyy HH:mm:ss");
            }
          }
        }
      }
    }

    public void LoadDefaultLogs()
    {
      string str1 = string.Empty;
      foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this.objdash._DAHierarchy)
        str1 += string.Format("'{0}',", (object) keyValuePair.Key);
      if (str1.Length > 0)
        str1 = str1.Substring(0, str1.Length - 1);
      SqlConnection conn = this.objdash.getConn();
      this.dgvAccountingLogs.Rows.Clear();
      using (SqlCommand sqlCommand = new SqlCommand("Select Amount, (case Action WHEN 1 THEN 'Profit/Loss' WHEN 2 THEN 'Payin' WHEN 3 THEN 'Payout' END) as Action,Timestamp,DACode from SA_AccountingLogs where Timestamp between '" + DateTime.Now.AddDays(-7.0).ToString("yyyy-MM-dd 00:00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd 23:59:00") + "' and DACode in (" + str1 + ") order by Timestamp desc", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
            {
              double num = Convert.ToDouble(sqlDataReader.GetValue(0));
              string str2 = sqlDataReader.GetString(1);
              DateTime dateTime = Convert.ToDateTime(sqlDataReader.GetValue(2));
              int index = this.dgvAccountingLogs.Rows.Add();
              if (!sqlDataReader.IsDBNull(3))
                this.dgvAccountingLogs.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(3);
              this.dgvAccountingLogs.Rows[index].Cells[1].Value = (object) num;
              this.dgvAccountingLogs.Rows[index].Cells[2].Value = (object) str2;
              this.dgvAccountingLogs.Rows[index].Cells[3].Value = (object) dateTime.ToString("dd-MM-yyyy HH:mm:ss");
            }
          }
        }
      }
    }

    private void btnSubmit_Click(object sender, EventArgs e)
    {
      SqlConnection conn = this.objdash.getConn();
      if (this.txtCode.Text == string.Empty)
        this.objdash.DisplayMessage("Select Dealer Admin code to process Payin/Payout", 2);
      else if (this.txtamount.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter Amount ", 2);
      }
      else
      {
        Decimal result;
        if (!Decimal.TryParse(this.txtamount.Text, out result))
          this.objdash.DisplayMessage("Enter Valid Amount ", 2);
        else if (result < Decimal.Zero)
        {
          this.objdash.DisplayMessage("Amount should be greater than 0.", 2);
        }
        else
        {
          int num = 1;
          if (this.rdoPayout.Checked)
            num = 2;
          SqlCommand sqlCommand1 = new SqlCommand("SApfls_Payin_Payout", conn);
          sqlCommand1.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand2 = sqlCommand1)
          {
            sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.txtCode.Text.Trim());
            sqlCommand2.Parameters.AddWithValue("@amount", (object) this.txtamount.Text.Trim());
            sqlCommand2.Parameters.AddWithValue("@payinout", (object) num);
            try
            {
              sqlCommand2.ExecuteNonQuery();
              this.LoadSAPfls();
              this.LoadDefaultLogs();
              this.objdash.DisplayMessage("Payin/Payout processed Successfully!!", 1);
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to process Payin/Payout", 3);
            }
          }
          this.ClearControls();
        }
      }
    }

    public void LoadSAPfls()
    {
      string str = string.Empty;
      foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this.objdash._DAHierarchy)
        str += string.Format("'{0}',", (object) keyValuePair.Key);
      if (str.Length > 0)
        str = str.Substring(0, str.Length - 1);
      this.dgvNetPFls.Rows.Clear();
      SqlConnection conn = this.objdash.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("Select * from SA_PendingProfitLoss where DACode in (" + str + ") ", conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            int index = this.dgvNetPFls.Rows.Add();
            this.dgvNetPFls.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(1);
            this.dgvNetPFls.Rows[index].Cells[1].Value = (object) sqlDataReader.GetValue(2).ToString();
          }
        }
      }
      this.LoadDefaultLogs();
    }

    private void rdoPayin_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoPayin.Checked)
        this.label3.Text = "Payin Amount";
      else
        this.label3.Text = "Payout Amount";
    }

    private void dgvNetPFls_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1 || this.dgvNetPFls.Rows[e.RowIndex] == null)
        return;
      this.ClearControls();
      this.txtCode.Text = this.dgvNetPFls.Rows[e.RowIndex].Cells[0].Value.ToString();
    }

    private void ClearControls()
    {
      this.txtamount.Text = this.txtCode.Text = this.txtComments.Text = string.Empty;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoPayout = new RadioButton();
      this.rdoPayin = new RadioButton();
      this.groupBox2 = new GroupBox();
      this.btnSubmit = new Button();
      this.txtComments = new TextBox();
      this.label4 = new Label();
      this.txtamount = new TextBox();
      this.label3 = new Label();
      this.txtCode = new TextBox();
      this.label1 = new Label();
      this.dgvNetPFls = new DataGridView();
      this.ColDACode = new DataGridViewTextBoxColumn();
      this.ColMargin = new DataGridViewTextBoxColumn();
      this.groupBox3 = new GroupBox();
      this.dgvAccountingLogs = new DataGridView();
      this.ColDA_Code = new DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      this.ColAction = new DataGridViewTextBoxColumn();
      this.ColTimestamp = new DataGridViewTextBoxColumn();
      this.groupBox4 = new GroupBox();
      this.btnView = new Button();
      this.label5 = new Label();
      this.Todate = new DateTimePicker();
      this.label2 = new Label();
      this.Fromdate = new DateTimePicker();
      this.label6 = new Label();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((ISupportInitialize) this.dgvNetPFls).BeginInit();
      this.groupBox3.SuspendLayout();
      ((ISupportInitialize) this.dgvAccountingLogs).BeginInit();
      this.groupBox4.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoPayout);
      this.groupBox1.Controls.Add((Control) this.rdoPayin);
      this.groupBox1.Location = new Point(5, 5);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(149, 51);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Payin/Payout";
      this.rdoPayout.AutoSize = true;
      this.rdoPayout.Location = new Point(81, 23);
      this.rdoPayout.Name = "rdoPayout";
      this.rdoPayout.Size = new Size(58, 17);
      this.rdoPayout.TabIndex = 1;
      this.rdoPayout.Text = "Payout";
      this.rdoPayout.UseVisualStyleBackColor = true;
      this.rdoPayin.AutoSize = true;
      this.rdoPayin.Checked = true;
      this.rdoPayin.Location = new Point(6, 23);
      this.rdoPayin.Name = "rdoPayin";
      this.rdoPayin.Size = new Size(51, 17);
      this.rdoPayin.TabIndex = 0;
      this.rdoPayin.TabStop = true;
      this.rdoPayin.Text = "Payin";
      this.rdoPayin.UseVisualStyleBackColor = true;
      this.rdoPayin.CheckedChanged += new EventHandler(this.rdoPayin_CheckedChanged);
      this.groupBox2.Controls.Add((Control) this.btnSubmit);
      this.groupBox2.Controls.Add((Control) this.txtComments);
      this.groupBox2.Controls.Add((Control) this.label4);
      this.groupBox2.Controls.Add((Control) this.txtamount);
      this.groupBox2.Controls.Add((Control) this.label3);
      this.groupBox2.Controls.Add((Control) this.txtCode);
      this.groupBox2.Controls.Add((Control) this.label1);
      this.groupBox2.Location = new Point(5, 60);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(366, 61);
      this.groupBox2.TabIndex = 3;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Enter Amount";
      this.btnSubmit.Location = new Point(299, 29);
      this.btnSubmit.Name = "btnSubmit";
      this.btnSubmit.Size = new Size(61, 23);
      this.btnSubmit.TabIndex = 7;
      this.btnSubmit.Text = "Submit";
      this.btnSubmit.UseVisualStyleBackColor = true;
      this.btnSubmit.Click += new EventHandler(this.btnSubmit_Click);
      this.txtComments.Location = new Point(201, 32);
      this.txtComments.Name = "txtComments";
      this.txtComments.Size = new Size(92, 20);
      this.txtComments.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(205, 16);
      this.label4.Name = "label4";
      this.label4.Size = new Size(56, 13);
      this.label4.TabIndex = 6;
      this.label4.Text = "Comments";
      this.txtamount.Location = new Point(103, 32);
      this.txtamount.MaxLength = 10;
      this.txtamount.Name = "txtamount";
      this.txtamount.Size = new Size(92, 20);
      this.txtamount.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(107, 16);
      this.label3.Name = "label3";
      this.label3.Size = new Size(72, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Payin Amount";
      this.txtCode.Enabled = false;
      this.txtCode.Location = new Point(6, 32);
      this.txtCode.Name = "txtCode";
      this.txtCode.ReadOnly = true;
      this.txtCode.Size = new Size(92, 20);
      this.txtCode.TabIndex = 0;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(10, 16);
      this.label1.Name = "label1";
      this.label1.Size = new Size(50, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "DA Code";
      this.dgvNetPFls.AllowUserToAddRows = false;
      this.dgvNetPFls.AllowUserToDeleteRows = false;
      this.dgvNetPFls.AllowUserToOrderColumns = true;
      this.dgvNetPFls.AllowUserToResizeRows = false;
      this.dgvNetPFls.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
      this.dgvNetPFls.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvNetPFls.BackgroundColor = Color.White;
      this.dgvNetPFls.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvNetPFls.Columns.AddRange((DataGridViewColumn) this.ColDACode, (DataGridViewColumn) this.ColMargin);
      this.dgvNetPFls.Location = new Point(5, 141);
      this.dgvNetPFls.MultiSelect = false;
      this.dgvNetPFls.Name = "dgvNetPFls";
      this.dgvNetPFls.ReadOnly = true;
      this.dgvNetPFls.RowHeadersVisible = false;
      this.dgvNetPFls.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvNetPFls.Size = new Size(366, 306);
      this.dgvNetPFls.TabIndex = 4;
      this.dgvNetPFls.CellClick += new DataGridViewCellEventHandler(this.dgvNetPFls_CellClick);
      this.ColDACode.HeaderText = "DA_Code";
      this.ColDACode.Name = "ColDACode";
      this.ColDACode.ReadOnly = true;
      this.ColMargin.HeaderText = "Amount";
      this.ColMargin.Name = "ColMargin";
      this.ColMargin.ReadOnly = true;
      this.groupBox3.Controls.Add((Control) this.dgvAccountingLogs);
      this.groupBox3.Controls.Add((Control) this.groupBox4);
      this.groupBox3.Location = new Point(377, 5);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(387, 444);
      this.groupBox3.TabIndex = 5;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Logs";
      this.dgvAccountingLogs.AllowUserToAddRows = false;
      this.dgvAccountingLogs.AllowUserToDeleteRows = false;
      this.dgvAccountingLogs.AllowUserToOrderColumns = true;
      this.dgvAccountingLogs.AllowUserToResizeRows = false;
      this.dgvAccountingLogs.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
      this.dgvAccountingLogs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvAccountingLogs.BackgroundColor = Color.White;
      this.dgvAccountingLogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvAccountingLogs.Columns.AddRange((DataGridViewColumn) this.ColDA_Code, (DataGridViewColumn) this.dataGridViewTextBoxColumn2, (DataGridViewColumn) this.ColAction, (DataGridViewColumn) this.ColTimestamp);
      this.dgvAccountingLogs.Location = new Point(6, 64);
      this.dgvAccountingLogs.MultiSelect = false;
      this.dgvAccountingLogs.Name = "dgvAccountingLogs";
      this.dgvAccountingLogs.ReadOnly = true;
      this.dgvAccountingLogs.RowHeadersVisible = false;
      this.dgvAccountingLogs.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvAccountingLogs.Size = new Size(375, 374);
      this.dgvAccountingLogs.TabIndex = 6;
      this.ColDA_Code.HeaderText = "DA_Code";
      this.ColDA_Code.Name = "ColDA_Code";
      this.ColDA_Code.ReadOnly = true;
      this.dataGridViewTextBoxColumn2.HeaderText = "Amount";
      this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
      this.dataGridViewTextBoxColumn2.ReadOnly = true;
      this.ColAction.HeaderText = "Action";
      this.ColAction.Name = "ColAction";
      this.ColAction.ReadOnly = true;
      this.ColTimestamp.HeaderText = "Timestamp";
      this.ColTimestamp.Name = "ColTimestamp";
      this.ColTimestamp.ReadOnly = true;
      this.groupBox4.Controls.Add((Control) this.btnView);
      this.groupBox4.Controls.Add((Control) this.label5);
      this.groupBox4.Controls.Add((Control) this.Todate);
      this.groupBox4.Controls.Add((Control) this.label2);
      this.groupBox4.Controls.Add((Control) this.Fromdate);
      this.groupBox4.Location = new Point(6, 15);
      this.groupBox4.Name = "groupBox4";
      this.groupBox4.Size = new Size(375, 43);
      this.groupBox4.TabIndex = 0;
      this.groupBox4.TabStop = false;
      this.groupBox4.Text = "Select Period";
      this.btnView.Location = new Point(313, 13);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(56, 23);
      this.btnView.TabIndex = 8;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.label5.AutoSize = true;
      this.label5.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label5.ForeColor = Color.Black;
      this.label5.Location = new Point(168, 20);
      this.label5.Name = "label5";
      this.label5.Size = new Size(57, 13);
      this.label5.TabIndex = 6;
      this.label5.Text = "To Date:";
      this.Todate.CustomFormat = "yyyy-MM-dd HH:mm:ss";
      this.Todate.Format = DateTimePickerFormat.Custom;
      this.Todate.Location = new Point(231, 17);
      this.Todate.MaxDate = new DateTime(2020, 12, 31, 0, 0, 0, 0);
      this.Todate.MinDate = new DateTime(2015, 1, 1, 0, 0, 0, 0);
      this.Todate.Name = "Todate";
      this.Todate.Size = new Size(76, 20);
      this.Todate.TabIndex = 5;
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = Color.Black;
      this.label2.Location = new Point(6, 20);
      this.label2.Name = "label2";
      this.label2.Size = new Size(69, 13);
      this.label2.TabIndex = 4;
      this.label2.Text = "From Date:";
      this.Fromdate.CustomFormat = "yyyy-MM-dd  HH:mm:ss";
      this.Fromdate.Format = DateTimePickerFormat.Custom;
      this.Fromdate.Location = new Point(75, 17);
      this.Fromdate.MaxDate = new DateTime(2020, 12, 31, 0, 0, 0, 0);
      this.Fromdate.MinDate = new DateTime(2015, 1, 1, 0, 0, 0, 0);
      this.Fromdate.Name = "Fromdate";
      this.Fromdate.Size = new Size(82, 20);
      this.Fromdate.TabIndex = 3;
      this.label6.AutoSize = true;
      this.label6.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label6.ForeColor = Color.Red;
      this.label6.Location = new Point(8, 124);
      this.label6.Name = "label6";
      this.label6.Size = new Size(157, 13);
      this.label6.TabIndex = 10;
      this.label6.Text = "*Click on the cell to select";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(769, 454);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.dgvNetPFls);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmSANetPfls);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Net Profit/Loss";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((ISupportInitialize) this.dgvNetPFls).EndInit();
      this.groupBox3.ResumeLayout(false);
      ((ISupportInitialize) this.dgvAccountingLogs).EndInit();
      this.groupBox4.ResumeLayout(false);
      this.groupBox4.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
