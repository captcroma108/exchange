﻿// Decompiled with JetBrains decompiler
// Type: DTS.payinoutDetails
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public struct payinoutDetails
  {
    public double amount;
    public string payinout;
    public DateTime timestamp;
    public string clientcode;
    public string comments;
  }
}
