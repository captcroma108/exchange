﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmIntraHistory
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace DTS
{
  public class frmIntraHistory : Form
  {
    private IContainer components = (IContainer) null;
    public SqlConnection conn;
    public SortedDictionary<DateTime, OHLC> _OHLCBars;
    private Dashboard objdash;
    private ToolStrip toolStrip1;
    private ToolStripComboBox cmbexch;
    private ToolStripComboBox cmbSymbol;
    private ToolStripComboBox cmbPeriodicity;
    private ToolStripButton btnsearch;
    private ToolStripButton btnSave;
    private DataGridView dgvTickdata;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Open;
    private DataGridViewTextBoxColumn High;
    private DataGridViewTextBoxColumn Low;
    private DataGridViewTextBoxColumn ColClose;
    private DataGridViewTextBoxColumn colVol;
    private DataGridViewTextBoxColumn Time;

    public frmIntraHistory(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      this.cmbexch.Items.Clear();
      this.cmbexch.Items.Add((object) "-- Exch --");
      string exchange = this.objdash.objinfo.exchange;
      char[] chArray = new char[1]{ ',' };
      foreach (object obj in exchange.Split(chArray))
        this.cmbexch.Items.Add(obj);
      this.cmbexch.SelectedIndex = 0;
    }

    private bool ValidateControls()
    {
      bool flag = true;
      if (this.cmbexch.Text == string.Empty)
      {
        int num = (int) MessageBox.Show("Select Exchange.", "Historical Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        flag = false;
      }
      else if (this.cmbSymbol.Text == string.Empty || this.cmbSymbol.SelectedIndex <= 0)
      {
        int num = (int) MessageBox.Show("Select Symbol.", "Historical Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        flag = false;
      }
      else if (this.cmbPeriodicity.Text == string.Empty || this.cmbPeriodicity.SelectedIndex <= 0)
      {
        int num = (int) MessageBox.Show("Select Periodicity.", "Historical Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        flag = false;
      }
      return flag;
    }

    private void btnsearch_Click(object sender, EventArgs e)
    {
      if (this.ValidateControls())
      {
        this.Cursor = Cursors.WaitCursor;
        this.conn = this.objdash.flag != 1 ? new SqlConnection(Dashboard.Decryptdata("RGF0YSBTb3VyY2U9MjA3LjE4MC4yNTUuMjM2XFxNMTE4MzZcXFNRTEVYUFJFU1MsNDkxNzA7VXNlciBJRD1zYTtJbml0aWFsIENhdGFsb2c9T0hMQ0RhdGE7UGFzc3dvcmQ9WGFuYWR1QF8rKCkmKiVeIyQhQH47SW50ZWdyYXRlZCBTZWN1cml0eT1mYWxzZTtNdWx0aXBsZUFjdGl2ZVJlc3VsdFNldHMgPSBUcnVlO0Nvbm5lY3QgVGltZW91dD01MDAwMDAwMDA=")) : new SqlConnection(Dashboard.Decryptdata("RGF0YSBTb3VyY2U9MTY0LjY4LjEyMy4yMDRcXE0xMzUwNCwxNDMzO1VzZXIgSUQ9c2E7SW5pdGlhbCBDYXRhbG9nPU9ITENEYXRhO1Bhc3N3b3JkPWFGRldMQDc4NjtJbnRlZ3JhdGVkIFNlY3VyaXR5PWZhbHNlO011bHRpcGxlQWN0aXZlUmVzdWx0U2V0cyA9IFRydWU7Q29ubmVjdCBUaW1lb3V0PTUwMDAwMDAwMA=="));
        try
        {
          this.conn.Open();
        }
        catch
        {
          return;
        }
        string text = this.cmbSymbol.Text;
        this._OHLCBars = new SortedDictionary<DateTime, OHLC>();
        DateTime serverTime = this.objdash.GetServerTime();
        if (this.objdash._Symconctracts.ContainsKey(text))
        {
          Contracts symconctract = this.objdash._Symconctracts[text];
          string userSymbol = symconctract.UserSymbol;
          string tablename = this.GetTablename(symconctract.exch);
          this.dgvTickdata.Rows.Clear();
          int periodicity = this.GetPeriodicity(this.cmbPeriodicity.Text);
          using (SqlCommand sqlCommand = new SqlCommand(string.Format("select Symbol, [OpenPrice],HighPrice,LowPrice,[ClosePrice], Timestamp,Volume from  " + tablename + "  where UserSymbol = '{0}'  and Timestamp > '{1:yyyy-MM-dd 09:00:00}'", (object) userSymbol, (object) serverTime), this.conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                string empty = string.Empty;
                Decimal num1 = new Decimal();
                Decimal num2 = new Decimal();
                Decimal num3 = new Decimal();
                Decimal num4 = new Decimal();
                DateTime dateTime1 = DateTime.Now;
                int num5 = 0;
                if (!sqlDataReader.IsDBNull(0))
                {
                  empty = sqlDataReader.GetString(0);
                  if (!sqlDataReader.IsDBNull(1))
                    num1 = Convert.ToDecimal(sqlDataReader.GetValue(1));
                  if (!sqlDataReader.IsDBNull(2))
                    num2 = Convert.ToDecimal(sqlDataReader.GetValue(2));
                  if (!sqlDataReader.IsDBNull(3))
                    num3 = Convert.ToDecimal(sqlDataReader.GetValue(3));
                  if (!sqlDataReader.IsDBNull(4))
                    num4 = Convert.ToDecimal(sqlDataReader.GetValue(4));
                  if (!sqlDataReader.IsDBNull(5))
                    dateTime1 = Convert.ToDateTime(sqlDataReader.GetValue(5));
                  if (!sqlDataReader.IsDBNull(6))
                    num5 = Convert.ToInt32(sqlDataReader.GetValue(6));
                  if (periodicity == 1)
                  {
                    int index = this.dgvTickdata.Rows.Add();
                    this.dgvTickdata.Rows[index].Cells[0].Value = (object) text;
                    this.dgvTickdata.Rows[index].Cells[1].Value = (object) num1;
                    this.dgvTickdata.Rows[index].Cells[2].Value = (object) num2;
                    this.dgvTickdata.Rows[index].Cells[3].Value = (object) num3;
                    this.dgvTickdata.Rows[index].Cells[4].Value = (object) num4;
                    this.dgvTickdata.Rows[index].Cells[5].Value = (object) num5;
                    this.dgvTickdata.Rows[index].Cells[6].Value = (object) dateTime1;
                  }
                  else
                  {
                    DateTime dateTime2 = dateTime1;
                    DateTime now = DateTime.Now;
                    DateTime key;
                    if ((uint) (dateTime2.Minute % periodicity) > 0U)
                    {
                      int num6 = dateTime2.Minute % periodicity;
                      key = dateTime2.AddMinutes((double) (num6 * -1));
                    }
                    else
                      key = dateTime2;
                    if (!this._OHLCBars.ContainsKey(key))
                    {
                      this._OHLCBars.Add(key, new OHLC()
                      {
                        Open = num1,
                        High = num2,
                        Low = num3,
                        CLose = num4,
                        volume = (long) num5
                      });
                    }
                    else
                    {
                      OHLC ohlcBar = this._OHLCBars[key];
                      if (num2 > ohlcBar.High)
                        ohlcBar.High = num2;
                      if (num3 < ohlcBar.Low)
                        ohlcBar.Low = num3;
                      ohlcBar.CLose = num4;
                      ohlcBar.volume += (long) num5;
                      this._OHLCBars[key] = ohlcBar;
                    }
                  }
                }
              }
            }
          }
          if (this._OHLCBars.Count > 0)
          {
            foreach (KeyValuePair<DateTime, OHLC> ohlcBar in this._OHLCBars)
            {
              DateTime key = ohlcBar.Key;
              OHLC ohlc = ohlcBar.Value;
              int index = this.dgvTickdata.Rows.Add();
              this.dgvTickdata.Rows[index].Cells[0].Value = (object) text;
              this.dgvTickdata.Rows[index].Cells[1].Value = (object) ohlc.Open;
              this.dgvTickdata.Rows[index].Cells[2].Value = (object) ohlc.High;
              this.dgvTickdata.Rows[index].Cells[3].Value = (object) ohlc.Low;
              this.dgvTickdata.Rows[index].Cells[4].Value = (object) ohlc.CLose;
              this.dgvTickdata.Rows[index].Cells[5].Value = (object) ohlc.volume;
              this.dgvTickdata.Rows[index].Cells[6].Value = (object) key;
            }
          }
        }
      }
      this.dgvTickdata.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
      this.Cursor = Cursors.Arrow;
    }

    private string GetTablename(int exch)
    {
      switch (exch)
      {
        case 1:
          return "MCX";
        case 2:
          return "NSE";
        case 3:
          return "NCDEX";
        case 4:
          return "NSECURR";
        default:
          return "MCX";
      }
    }

    private int GetPeriodicity(string Periodicity)
    {
      string upper = Periodicity.ToUpper();
      if (upper == "1 MIN")
        return 1;
      if (upper == "5 MINS")
        return 5;
      if (upper == "10 MINS")
        return 10;
      if (upper == "15 MINS")
        return 15;
      if (upper == "30 MINS")
        return 30;
      return upper == "60 MINS" ? 60 : 1;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.dgvTickdata.Rows.Count > 0)
      {
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
        saveFileDialog1.CheckPathExists = true;
        saveFileDialog1.InitialDirectory = "C:\\";
        saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
        saveFileDialog1.FilterIndex = 1;
        using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
        {
          if (saveFileDialog2.ShowDialog() != DialogResult.OK)
            return;
          string fileName = saveFileDialog2.FileName;
          using (StreamWriter streamWriter = new StreamWriter(fileName))
          {
            if (true)
            {
              string str = "Symbol,Bid,Ask,LTP,Vol,Time\r";
              streamWriter.Write(str);
            }
            int num = this.dgvTickdata.Rows.Count - 1;
            for (int index = 0; index < num; ++index)
            {
              string str = string.Format("{0},{1},{2},{3},{4},{5}\r", (object) this.dgvTickdata.Rows[index].Cells[0].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[2].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[3].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[4].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[5].Value.ToString(), (object) this.dgvTickdata.Rows[index].Cells[6].Value.ToString());
              streamWriter.Write(str);
            }
            streamWriter.Flush();
            streamWriter.Close();
          }
        }
      }
      else
      {
        int num1 = (int) MessageBox.Show("No data to save.", "Last 30 mins Tick Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
      }
    }

    private void cmbSymbol_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.cmbPeriodicity.SelectedIndex = 0;
    }

    private void cmbexch_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmbexch.SelectedIndex <= 0)
        return;
      string text = this.cmbexch.Text;
      this.cmbSymbol.Items.Clear();
      if (this.objdash._Exchconctracts.ContainsKey(Utils.GetIntExch(text)))
      {
        this.cmbSymbol.Items.Add((object) "--Symbol--");
        foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[Utils.GetIntExch(text)])
          this.cmbSymbol.Items.Add((object) keyValuePair.Key);
        this.cmbSymbol.SelectedIndex = 0;
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (frmIntraHistory));
      this.toolStrip1 = new ToolStrip();
      this.cmbexch = new ToolStripComboBox();
      this.cmbSymbol = new ToolStripComboBox();
      this.cmbPeriodicity = new ToolStripComboBox();
      this.btnsearch = new ToolStripButton();
      this.btnSave = new ToolStripButton();
      this.dgvTickdata = new DataGridView();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Open = new DataGridViewTextBoxColumn();
      this.High = new DataGridViewTextBoxColumn();
      this.Low = new DataGridViewTextBoxColumn();
      this.ColClose = new DataGridViewTextBoxColumn();
      this.colVol = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.toolStrip1.SuspendLayout();
      ((ISupportInitialize) this.dgvTickdata).BeginInit();
      this.SuspendLayout();
      this.toolStrip1.Items.AddRange(new ToolStripItem[5]
      {
        (ToolStripItem) this.cmbexch,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.cmbPeriodicity,
        (ToolStripItem) this.btnsearch,
        (ToolStripItem) this.btnSave
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.RenderMode = ToolStripRenderMode.System;
      this.toolStrip1.Size = new Size(650, 25);
      this.toolStrip1.TabIndex = 1;
      this.toolStrip1.Text = "toolStrip1";
      this.cmbexch.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbexch.Name = "cmbexch";
      this.cmbexch.Size = new Size(80, 25);
      this.cmbexch.SelectedIndexChanged += new EventHandler(this.cmbexch_SelectedIndexChanged);
      this.cmbSymbol.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(140, 25);
      this.cmbSymbol.Sorted = true;
      this.cmbSymbol.SelectedIndexChanged += new EventHandler(this.cmbSymbol_SelectedIndexChanged);
      this.cmbPeriodicity.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbPeriodicity.Items.AddRange(new object[7]
      {
        (object) "--Priodicity--",
        (object) "1 Min",
        (object) "5 Mins",
        (object) "10 Mins",
        (object) "15 Mins",
        (object) "30 Mins",
        (object) "60 Mins"
      });
      this.cmbPeriodicity.Name = "cmbPeriodicity";
      this.cmbPeriodicity.Size = new Size(100, 25);
      this.btnsearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnsearch.Image = (Image) componentResourceManager.GetObject("btnsearch.Image");
      this.btnsearch.ImageTransparentColor = Color.Magenta;
      this.btnsearch.Name = "btnsearch";
      this.btnsearch.Size = new Size(23, 22);
      this.btnsearch.Text = "Search";
      this.btnsearch.Click += new EventHandler(this.btnsearch_Click);
      this.btnSave.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSave.Image = (Image) componentResourceManager.GetObject("btnSave.Image");
      this.btnSave.ImageTransparentColor = Color.Magenta;
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(23, 22);
      this.btnSave.Text = "Save";
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.dgvTickdata.AllowUserToAddRows = false;
      this.dgvTickdata.AllowUserToDeleteRows = false;
      this.dgvTickdata.AllowUserToOrderColumns = true;
      this.dgvTickdata.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvTickdata.BackgroundColor = Color.White;
      this.dgvTickdata.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvTickdata.Columns.AddRange((DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Open, (DataGridViewColumn) this.High, (DataGridViewColumn) this.Low, (DataGridViewColumn) this.ColClose, (DataGridViewColumn) this.colVol, (DataGridViewColumn) this.Time);
      this.dgvTickdata.Dock = DockStyle.Fill;
      this.dgvTickdata.Location = new Point(0, 25);
      this.dgvTickdata.Name = "dgvTickdata";
      this.dgvTickdata.ReadOnly = true;
      this.dgvTickdata.RowHeadersVisible = false;
      this.dgvTickdata.Size = new Size(650, 373);
      this.dgvTickdata.TabIndex = 2;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Open.HeaderText = "Open";
      this.Open.Name = "Open";
      this.Open.ReadOnly = true;
      this.High.HeaderText = "High";
      this.High.Name = "High";
      this.High.ReadOnly = true;
      this.Low.HeaderText = "Low";
      this.Low.Name = "Low";
      this.Low.ReadOnly = true;
      this.ColClose.HeaderText = "Close";
      this.ColClose.Name = "ColClose";
      this.ColClose.ReadOnly = true;
      this.colVol.HeaderText = "Volume";
      this.colVol.Name = "colVol";
      this.colVol.ReadOnly = true;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(650, 398);
      this.Controls.Add((Control) this.dgvTickdata);
      this.Controls.Add((Control) this.toolStrip1);
      this.Name = nameof (frmIntraHistory);
      this.Text = "Intraday Data History";
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((ISupportInitialize) this.dgvTickdata).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
