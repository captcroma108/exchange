﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDealerMapping
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmDealerMapping : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    private Label label1;
    private ComboBox cmbSTMCode;
    private ListBox LstMappedCode;
    private ListBox LstAllCode;
    private Label label2;
    private Label label3;
    private Button button4;
    private Button button3;
    private Button button2;
    private Button button1;
    private Button btnClose;
    private Button btnSave;

    public frmDealerMapping(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      this.cmbSTMCode.Items.Clear();
      this.LstAllCode.Items.Clear();
    }

    private void btnClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    private void button3_Click(object sender, EventArgs e)
    {
      foreach (string str in this.LstMappedCode.Items)
        this.LstAllCode.Items.Add((object) str);
      this.LstMappedCode.Items.Clear();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      if (!(this.LstMappedCode.Text != string.Empty))
        return;
      string text = this.LstMappedCode.Text;
      this.LstAllCode.Items.Add((object) text);
      this.LstMappedCode.Items.Remove((object) text);
    }

    private void button2_Click(object sender, EventArgs e)
    {
      if (!(this.LstAllCode.Text != string.Empty))
        return;
      string text = this.LstAllCode.Text;
      this.LstMappedCode.Items.Add((object) text);
      this.LstAllCode.Items.Remove((object) text);
    }

    private void button4_Click(object sender, EventArgs e)
    {
      for (int index = 0; index < this.LstAllCode.Items.Count; ++index)
        this.LstMappedCode.Items.Add(this.LstAllCode.Items[index]);
      this.LstAllCode.Items.Clear();
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.cmbSTMCode.Text == string.Empty)
      {
        this.objmain.DisplayMessage("Select STM Code to Map", 2);
      }
      else
      {
        string str = string.Empty;
        foreach (object obj in this.LstMappedCode.Items)
          str += string.Format("{0},", obj);
        if (str.Contains(","))
          str = str.Substring(0, str.Length - 1);
        if (!(str == string.Empty))
          return;
        using (SqlCommand sqlCommand = new SqlCommand(string.Format("Delete from STMMapping where RegulationCode = '{0}'", (object) this.cmbSTMCode.Text), this.conn))
        {
          try
          {
            if (sqlCommand.ExecuteNonQuery() <= 0)
              ;
            this.objmain.DisplayMessage("Mapping saved Successfully!!", 1);
          }
          catch
          {
            this.objmain.DisplayMessage("Unable to Delete Mapping", 3);
          }
        }
      }
    }

    private void cmbSTMCode_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.cmbSTMCode = new ComboBox();
      this.LstMappedCode = new ListBox();
      this.LstAllCode = new ListBox();
      this.label2 = new Label();
      this.label3 = new Label();
      this.button4 = new Button();
      this.button3 = new Button();
      this.button2 = new Button();
      this.button1 = new Button();
      this.btnClose = new Button();
      this.btnSave = new Button();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(12, 9);
      this.label1.Name = "label1";
      this.label1.Size = new Size(91, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Select STM Code";
      this.cmbSTMCode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSTMCode.FormattingEnabled = true;
      this.cmbSTMCode.Location = new Point(12, 25);
      this.cmbSTMCode.Name = "cmbSTMCode";
      this.cmbSTMCode.Size = new Size(102, 21);
      this.cmbSTMCode.TabIndex = 1;
      this.cmbSTMCode.SelectedIndexChanged += new EventHandler(this.cmbSTMCode_SelectedIndexChanged);
      this.LstMappedCode.FormattingEnabled = true;
      this.LstMappedCode.Location = new Point(12, 82);
      this.LstMappedCode.Name = "LstMappedCode";
      this.LstMappedCode.Size = new Size(102, 160);
      this.LstMappedCode.TabIndex = 2;
      this.LstAllCode.FormattingEnabled = true;
      this.LstAllCode.Location = new Point(179, 82);
      this.LstAllCode.Name = "LstAllCode";
      this.LstAllCode.Size = new Size(102, 160);
      this.LstAllCode.TabIndex = 3;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(12, 66);
      this.label2.Name = "label2";
      this.label2.Size = new Size(74, 13);
      this.label2.TabIndex = 4;
      this.label2.Text = "Mapped Code";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(176, 66);
      this.label3.Name = "label3";
      this.label3.Size = new Size(87, 13);
      this.label3.TabIndex = 5;
      this.label3.Text = "Unmapped Code";
      this.button4.Location = new Point((int) sbyte.MaxValue, 211);
      this.button4.Name = "button4";
      this.button4.Size = new Size(40, 23);
      this.button4.TabIndex = 38;
      this.button4.Text = "<<<<";
      this.button4.UseVisualStyleBackColor = true;
      this.button4.Click += new EventHandler(this.button4_Click);
      this.button3.Location = new Point((int) sbyte.MaxValue, 91);
      this.button3.Name = "button3";
      this.button3.Size = new Size(40, 23);
      this.button3.TabIndex = 37;
      this.button3.Text = ">>>>";
      this.button3.UseVisualStyleBackColor = true;
      this.button3.Click += new EventHandler(this.button3_Click);
      this.button2.Location = new Point((int) sbyte.MaxValue, 171);
      this.button2.Name = "button2";
      this.button2.Size = new Size(40, 23);
      this.button2.TabIndex = 36;
      this.button2.Text = "<<";
      this.button2.UseVisualStyleBackColor = true;
      this.button2.Click += new EventHandler(this.button2_Click);
      this.button1.Location = new Point((int) sbyte.MaxValue, 131);
      this.button1.Name = "button1";
      this.button1.Size = new Size(40, 23);
      this.button1.TabIndex = 35;
      this.button1.Text = ">>";
      this.button1.UseVisualStyleBackColor = true;
      this.button1.Click += new EventHandler(this.button1_Click);
      this.btnClose.Location = new Point(179, 248);
      this.btnClose.Name = "btnClose";
      this.btnClose.Size = new Size(75, 23);
      this.btnClose.TabIndex = 40;
      this.btnClose.Text = "Cancel";
      this.btnClose.UseVisualStyleBackColor = true;
      this.btnClose.Click += new EventHandler(this.btnClose_Click);
      this.btnSave.Location = new Point(39, 248);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 23);
      this.btnSave.TabIndex = 39;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(293, 276);
      this.Controls.Add((Control) this.btnClose);
      this.Controls.Add((Control) this.btnSave);
      this.Controls.Add((Control) this.button4);
      this.Controls.Add((Control) this.button3);
      this.Controls.Add((Control) this.button2);
      this.Controls.Add((Control) this.button1);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.LstAllCode);
      this.Controls.Add((Control) this.LstMappedCode);
      this.Controls.Add((Control) this.cmbSTMCode);
      this.Controls.Add((Control) this.label1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (frmDealerMapping);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Dealer-Client Mapping";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
