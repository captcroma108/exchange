﻿// Decompiled with JetBrains decompiler
// Type: DTS.Orderbook
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class Orderbook : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public Thread cThread;
    public Dictionary<double, int> _OrderNoList;
    private bool isSymbolSpecific;
    public MWColumnProfile objColProfile;
    public BuySellOrder objbuysell;
    public string CurrentOrderDetail;
    public DataGridView dgvOrderbook;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripLabel toolStripLabel1;
    private ToolStripComboBox cmbExch;
    private ToolStripLabel toolStripLabel4;
    private ToolStripComboBox cmbSymbol;
    private ToolStripLabel toolStripLabel5;
    private ToolStripComboBox cmbBuySell;
    private ToolStripLabel toolStripLabel3;
    private ToolStripComboBox cmbTraderid;
    private ToolStripButton btnSearch;
    private DataGridViewTextBoxColumn Code;
    private DataGridViewTextBoxColumn colName;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn sym;
    private DataGridViewTextBoxColumn ColExpiry;
    private DataGridViewTextBoxColumn product;
    private DataGridViewTextBoxColumn buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn Userremarks;
    private DataGridViewTextBoxColumn Traderid;
    private DataGridViewTextBoxColumn Orderno;
    private DataGridViewTextBoxColumn ColIp;

    public Orderbook(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.isSymbolSpecific = false;
      this.Icon = this.objmain.ico;
    }

    public void LoadWindow()
    {
      this.Location = Settings.Default.OrdbookLocation;
      this._ColumnOnOff = new Dictionary<string, int>();
      string ordColumnProfile = Settings.Default.OrdColumnProfile;
      if (ordColumnProfile != string.Empty)
      {
        string str1 = ordColumnProfile;
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ '_' };
          string[] strArray = str2.Split(chArray2);
          int int32 = Convert.ToInt32(strArray[1]);
          switch (Convert.ToInt32(strArray[2]))
          {
            case 0:
              this.dgvOrderbook.Columns[int32].Visible = false;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 0);
                break;
              }
              break;
            case 1:
              this.dgvOrderbook.Columns[int32].Visible = true;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 1);
                break;
              }
              break;
          }
        }
      }
      else
      {
        for (int index = 0; index < this.dgvOrderbook.Columns.Count; ++index)
        {
          if (!this._ColumnOnOff.ContainsKey(this.dgvOrderbook.Columns[index].HeaderText))
          {
            if (this.dgvOrderbook.Columns[index].Visible)
              this._ColumnOnOff.Add(this.dgvOrderbook.Columns[index].HeaderText, 1);
            else
              this._ColumnOnOff.Add(this.dgvOrderbook.Columns[index].HeaderText, 0);
          }
        }
      }
    }

    private void UpdateOrders()
    {
      this.isSymbolSpecific = false;
      this._OrderNoList = new Dictionary<double, int>();
      DateTime lastModified;
      ref DateTime local = ref lastModified;
      DateTime now = DateTime.Now;
      int year = now.Year;
      now = DateTime.Now;
      int month = now.Month;
      now = DateTime.Now;
      int day = now.Day;
      local = new DateTime(year, month, day, 9, 0, 0);
      this.Invoke((Delegate) (() =>
      {
        this.dgvOrderbook.Rows.Clear();
        this.clearCombobox();
      }));
      int rowcount = 0;
      while (true)
      {
        if (!this.isSymbolSpecific)
        {
          List<Orders> tradeOrders = this.objmain.GetTradeOrders(2);
          List<double> _Orders = new List<double>();
          foreach (Orders orders in tradeOrders)
          {
            Orders objord = orders;
            if (!_Orders.Contains(objord.OrderNo))
            {
              _Orders.Add(objord.OrderNo);
              string tradedby = objord.TraderId;
              string accname = this.objmain.GetUserinfo(objord.accountNo).name;
              string[] symData = objord.symbol.Split(' ');
              if (!this._OrderNoList.ContainsKey(objord.OrderNo))
              {
                this.Invoke((Delegate) (() =>
                {
                  rowcount = this.dgvOrderbook.Rows.Add();
                  this.FillCombobox(objord);
                  this.dgvOrderbook.Rows[rowcount].Cells[0].Value = (object) objord.accountNo;
                  this.dgvOrderbook.Rows[rowcount].Cells[1].Value = (object) accname;
                  this.dgvOrderbook.Rows[rowcount].Cells[2].Value = (object) Utils.GetExch(objord.ExchangeTypeID);
                  this.dgvOrderbook.Rows[rowcount].Cells[3].Value = (object) symData[0];
                  this.dgvOrderbook.Rows[rowcount].Cells[4].Value = (object) symData[1];
                  this.dgvOrderbook.Rows[rowcount].Cells[5].Value = (object) Utils.GetProductType(objord.ProductType);
                  this.dgvOrderbook.Rows[rowcount].Cells[6].Value = (object) Utils.GetBuysell(objord.BuySell);
                  this.dgvOrderbook.Rows[rowcount].Cells[7].Value = (object) objord.Ordeqty;
                  this.dgvOrderbook.Rows[rowcount].Cells[8].Value = (object) objord.OrdePrice;
                  this.dgvOrderbook.Rows[rowcount].Cells[9].Value = (object) Utils.GetValidity(objord.ValidityType);
                  this.dgvOrderbook.Rows[rowcount].Cells[10].Value = (object) objord.LastModified.ToString("HH:mm:ss");
                  this.dgvOrderbook.Rows[rowcount].Cells[11].Value = (object) objord.UserRemark;
                  this.dgvOrderbook.Rows[rowcount].Cells[12].Value = (object) tradedby;
                  this.dgvOrderbook.Rows[rowcount].Cells[13].Value = (object) objord.OrderNo;
                  this.dgvOrderbook.Rows[rowcount].Cells[14].Value = (object) objord.ipAddress;
                  if (objord.BuySell == 1)
                    this.dgvOrderbook.Rows[rowcount].DefaultCellStyle.BackColor = Color.Blue;
                  else
                    this.dgvOrderbook.Rows[rowcount].DefaultCellStyle.BackColor = Color.HotPink;
                }));
                this._OrderNoList.Add(objord.OrderNo, rowcount);
              }
              else
              {
                int orderNo = this._OrderNoList[objord.OrderNo];
                this.dgvOrderbook.Rows[orderNo].Cells[7].Value = (object) objord.Ordeqty;
                this.dgvOrderbook.Rows[orderNo].Cells[8].Value = (object) objord.OrdePrice;
                this.dgvOrderbook.Rows[orderNo].Cells[9].Value = (object) Utils.GetValidity(objord.ValidityType);
                this.dgvOrderbook.Rows[orderNo].Cells[10].Value = (object) objord.LastModified.ToString("HH:mm:ss");
                this.dgvOrderbook.Rows[orderNo].Cells[11].Value = (object) objord.UserRemark;
                this.dgvOrderbook.Rows[orderNo].Cells[12].Value = (object) tradedby;
                this.dgvOrderbook.Rows[orderNo].Cells[13].Value = (object) objord.OrderNo;
                if (objord.BuySell == 1)
                  this.dgvOrderbook.Rows[orderNo].DefaultCellStyle.BackColor = Color.Blue;
                else
                  this.dgvOrderbook.Rows[orderNo].DefaultCellStyle.BackColor = Color.HotPink;
              }
              lastModified = objord.LastModified;
            }
          }
          foreach (KeyValuePair<double, int> orderNo in this._OrderNoList)
          {
            KeyValuePair<double, int> itemss = orderNo;
            try
            {
              this.Invoke((Delegate) (() =>
              {
                if (!_Orders.Contains(itemss.Key) && this.dgvOrderbook.Rows.Count > 0)
                  this.dgvOrderbook.Rows[itemss.Value].Visible = false;
                this.dgvOrderbook.Refresh();
              }));
            }
            catch
            {
            }
          }
          Thread.Sleep(5000);
        }
        else
          break;
      }
    }

    public void LoadOrders()
    {
      this.LoadWindow();
      if (this.cThread == null)
      {
        this.cThread = new Thread(new ThreadStart(((ThreadStart) (() => this.UpdateOrders())).Invoke));
        this.cThread.Start();
      }
      else
      {
        this.cThread.Abort();
        this.cThread = new Thread(new ThreadStart(((ThreadStart) (() => this.UpdateOrders())).Invoke));
        this.cThread.Start();
      }
    }

    private void clearCombobox()
    {
      this.cmbclientcode.Items.Clear();
      this.cmbclientcode.Items.Add((object) "");
      this.cmbExch.Items.Clear();
      this.cmbExch.Items.Add((object) "");
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "");
      this.cmbTraderid.Items.Clear();
      this.cmbTraderid.Items.Add((object) "");
    }

    private void FillCombobox(Orders objord)
    {
      if (!this.cmbclientcode.Items.Contains((object) objord.accountNo))
        this.cmbclientcode.Items.Add((object) objord.accountNo);
      if (!this.cmbExch.Items.Contains((object) Utils.GetExch(objord.ExchangeTypeID)))
        this.cmbExch.Items.Add((object) Utils.GetExch(objord.ExchangeTypeID));
      if (!this.cmbSymbol.Items.Contains((object) objord.symbol))
        this.cmbSymbol.Items.Add((object) objord.symbol);
      if (this.cmbTraderid.Items.Contains((object) objord.TraderId))
        return;
      this.cmbTraderid.Items.Add((object) objord.TraderId);
    }

    public void LoadSpecificSymbol(string symbol)
    {
      this.isSymbolSpecific = true;
      this._OrderNoList = new Dictionary<double, int>();
      this.dgvOrderbook.Rows.Clear();
      List<Orders> tradeOrders = this.objmain.GetTradeOrders(2);
      this.clearCombobox();
      List<double> doubleList = new List<double>();
      foreach (Orders objord in tradeOrders)
      {
        if (!doubleList.Contains(objord.OrderNo))
        {
          doubleList.Add(objord.OrderNo);
          string str = objord.TraderId;
          if (this.objmain.GetUserinfo(objord.TraderId).name != null)
            str = this.objmain.GetUserinfo(objord.TraderId).name;
          string name = this.objmain.GetUserinfo(objord.accountNo).name;
          if (objord.symbol == symbol)
          {
            string[] strArray = objord.symbol.Split(' ');
            int index = this.dgvOrderbook.Rows.Add();
            this.FillCombobox(objord);
            this.dgvOrderbook.Rows[index].Cells[0].Value = (object) objord.accountNo;
            this.dgvOrderbook.Rows[index].Cells[1].Value = (object) name;
            this.dgvOrderbook.Rows[index].Cells[2].Value = (object) Utils.GetExch(objord.ExchangeTypeID);
            this.dgvOrderbook.Rows[index].Cells[3].Value = (object) strArray[0];
            this.dgvOrderbook.Rows[index].Cells[4].Value = (object) strArray[1];
            this.dgvOrderbook.Rows[index].Cells[5].Value = (object) Utils.GetProductType(objord.ProductType);
            this.dgvOrderbook.Rows[index].Cells[6].Value = (object) Utils.GetBuysell(objord.BuySell);
            this.dgvOrderbook.Rows[index].Cells[7].Value = (object) objord.Ordeqty;
            this.dgvOrderbook.Rows[index].Cells[8].Value = (object) objord.OrdePrice;
            this.dgvOrderbook.Rows[index].Cells[9].Value = (object) Utils.GetValidity(objord.ValidityType);
            this.dgvOrderbook.Rows[index].Cells[10].Value = (object) string.Format("{0}:{1}:{2}", (object) objord.LastModified.Hour, (object) objord.LastModified.Minute, (object) objord.LastModified.Second);
            this.dgvOrderbook.Rows[index].Cells[11].Value = (object) objord.UserRemark;
            this.dgvOrderbook.Rows[index].Cells[12].Value = (object) str;
            this.dgvOrderbook.Rows[index].Cells[13].Value = (object) objord.OrderNo;
            this.dgvOrderbook.Rows[index].Cells[14].Value = (object) objord.ipAddress;
            if (objord.BuySell == 1)
              this.dgvOrderbook.Rows[index].DefaultCellStyle.BackColor = Color.Blue;
            else
              this.dgvOrderbook.Rows[index].DefaultCellStyle.BackColor = Color.HotPink;
          }
        }
      }
    }

    private void dgvOrderbook_MouseClick(object sender, MouseEventArgs e)
    {
      if (this.dgvOrderbook.Rows.Count > 0)
      {
        int rowIndex = this.dgvOrderbook.HitTest(e.X, e.Y).RowIndex;
        if (rowIndex > -1)
          this.dgvOrderbook.Rows[rowIndex].Selected = true;
      }
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Column Profile", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Save Column Profile", (Image) null, new EventHandler(this.Task2_Click));
      if (this.dgvOrderbook.Rows.Count > 0)
      {
        contextMenuStrip.Items.Add("Modify", (Image) null, new EventHandler(this.Task4_Click));
        contextMenuStrip.Items.Add("Execute Market", (Image) null, new EventHandler(this.Task10_Click));
        contextMenuStrip.Items.Add("Execute All Market", (Image) null, new EventHandler(this.Task11_Click));
        contextMenuStrip.Items.Add("Cancel", (Image) null, new EventHandler(this.Task5_Click));
        contextMenuStrip.Items.Add("Cancel All", (Image) null, new EventHandler(this.Task6_Click));
        contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task7_Click));
        contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task8_Click));
        contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task9_Click));
      }
      Point client = this.dgvOrderbook.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvOrderbook, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.objColProfile == null || this.objColProfile.IsDisposed)
      {
        MWColumnProfile mwColumnProfile = new MWColumnProfile(this.objmain, 3);
        mwColumnProfile.MdiParent = (Form) this.objmain;
        this.objColProfile = mwColumnProfile;
        this.objColProfile.Show();
      }
      else
      {
        this.objColProfile.MdiParent = (Form) this.objmain;
        this.objColProfile.Activate();
        this.objColProfile.Show();
      }
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvOrderbook.Columns.Count; ++index)
        str = !this.dgvOrderbook.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvOrderbook.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvOrderbook.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.OrdColumnProfile = str;
      Settings.Default.Save();
    }

    private void Task10_Click(object sender, EventArgs e)
    {
      if (this.dgvOrderbook.Rows.Count <= 0)
        return;
      DataGridView dgvOrderbook = this.dgvOrderbook;
      if (dgvOrderbook != null)
      {
        int index = dgvOrderbook.CurrentRow.Index;
        string account = this.dgvOrderbook.Rows[index].Cells[0].Value.ToString();
        string exch = this.dgvOrderbook.Rows[index].Cells[2].Value.ToString();
        string key = string.Format("{0} {1}", (object) this.dgvOrderbook.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrderbook.Rows[index].Cells[4].Value.ToString());
        string str1 = this.dgvOrderbook.Rows[index].Cells[6].Value.ToString();
        int num1 = 1;
        if (str1 == "S")
          num1 = 2;
        int int32 = Convert.ToInt32(this.dgvOrderbook.Rows[index].Cells[7].Value.ToString());
        double num2 = Convert.ToDouble(this.dgvOrderbook.Rows[index].Cells[13].Value.ToString());
        string empty = string.Empty;
        DateTime dtnow = new DateTime();
        if (!this.objmain.ValidateMarketTime(exch, ref dtnow))
        {
          this.objmain.DisplayMessage(string.Format(" {0} Market is closed!!", (object) exch), 2);
          this.objmain.insertSurveillanceMessages(account, string.Format(" {0} Market is closed!!", (object) exch), dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
        }
        else if (this.objmain._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objmain._Symconctracts[key];
          DateTime serverTime = this.objmain.GetServerTime();
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.objmain.getFeed(symbol);
          Trades trades = new Trades()
          {
            Symbol = key,
            clientcode = account,
            qty = int32,
            orderno = num2,
            Createon = serverTime,
            Lastmodified = serverTime,
            buysell = num1,
            exch = (int) Enum.Parse(typeof (DTS.Exch), exch),
            traderid = this.objmain.objinfo.clientcode,
            exectype = 2
          };
          trades.price = num1 != 1 ? feed.bid : feed.ask;
          if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.InsertPendingTrade(trades, this.objmain))
          {
            string str2 = " TRADE: " + Utils.GetExch(trades.exch) + ": ";
            string str3 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1}   N {2} LOTS/{3} LOTS  AT Rs. {4} FOR CLI {5} TRADE", (object) trades.orderno, (object) symconctract.symbol, (object) trades.qty, (object) trades.qty, (object) trades.price, (object) trades.clientcode);
            this.objmain.clearMsgBoard();
            switch (trades.buysell)
            {
              case 1:
                string str4 = string.Format("{0} BOUGHT : {1}", (object) str2, (object) str3);
                this.objmain.InsertMsgBoard(str4, 1);
                this.objmain.SaveMessageLogs(str4, trades);
                this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[index]);
                break;
              case 2:
                string str5 = string.Format("{0} SOLD : {1}", (object) str2, (object) str3);
                this.objmain.InsertMsgBoard(str5, 1);
                this.objmain.SaveMessageLogs(str5, trades);
                this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[index]);
                break;
            }
          }
        }
      }
    }

    private void Task11_Click(object sender, EventArgs e)
    {
      if (this.dgvOrderbook.Rows.Count <= 0 || this.dgvOrderbook == null)
        return;
      for (int index1 = 0; index1 < this.dgvOrderbook.Rows.Count; ++index1)
      {
        int index2 = index1;
        string str1 = this.dgvOrderbook.Rows[index2].Cells[0].Value.ToString();
        string exch = this.dgvOrderbook.Rows[index2].Cells[2].Value.ToString();
        string key = string.Format("{0} {1}", (object) this.dgvOrderbook.Rows[index2].Cells[3].Value.ToString(), (object) this.dgvOrderbook.Rows[index2].Cells[4].Value.ToString());
        string str2 = this.dgvOrderbook.Rows[index2].Cells[6].Value.ToString();
        int num1 = 1;
        if (str2 == "S")
          num1 = 2;
        int int32 = Convert.ToInt32(this.dgvOrderbook.Rows[index2].Cells[7].Value.ToString());
        double num2 = Convert.ToDouble(this.dgvOrderbook.Rows[index2].Cells[13].Value.ToString());
        string empty = string.Empty;
        DateTime dtnow = new DateTime();
        if (this.objmain.ValidateMarketTime(exch, ref dtnow) && this.objmain._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objmain._Symconctracts[key];
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          DateTime serverTime = this.objmain.GetServerTime();
          Feeds feed = this.objmain.getFeed(symbol);
          Trades trades = new Trades()
          {
            Symbol = key,
            clientcode = str1,
            qty = int32,
            orderno = num2,
            Createon = serverTime,
            Lastmodified = serverTime,
            buysell = num1,
            exch = (int) Enum.Parse(typeof (DTS.Exch), exch),
            traderid = this.objmain.objinfo.clientcode,
            exectype = 2
          };
          trades.price = num1 != 1 ? feed.bid : feed.ask;
          if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.InsertPendingTrade(trades, this.objmain))
          {
            string str3 = " TRADE: " + Utils.GetExch(trades.exch) + ": ";
            string str4 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1}   N {2} LOTS/{3} LOTS  AT Rs. {4} FOR CLI {5} TRADE", (object) trades.orderno, (object) symconctract.symbol, (object) trades.qty, (object) trades.qty, (object) trades.price, (object) trades.clientcode);
            this.objmain.clearMsgBoard();
            switch (trades.buysell)
            {
              case 1:
                string str5 = string.Format("{0} BOUGHT : {1}", (object) str3, (object) str4);
                this.objmain.InsertMsgBoard(str5, 1);
                this.objmain.SaveMessageLogs(str5, trades);
                this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[index2]);
                break;
              case 2:
                string str6 = string.Format("{0} SOLD : {1}", (object) str3, (object) str4);
                this.objmain.InsertMsgBoard(str6, 1);
                this.objmain.SaveMessageLogs(str6, trades);
                this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[index2]);
                break;
            }
          }
        }
      }
    }

    private void Task3_Click(object sender, EventArgs e)
    {
    }

    private void Task4_Click(object sender, EventArgs e)
    {
      this.ModifyOrder();
    }

    private void ModifyOrder()
    {
      if (this.dgvOrderbook.Rows.Count > 0)
      {
        DataGridView dgvOrderbook = this.dgvOrderbook;
        if (dgvOrderbook == null)
          return;
        int index = dgvOrderbook.CurrentRow.Index;
        string accno = this.dgvOrderbook.Rows[index].Cells[0].Value.ToString();
        string exch = this.dgvOrderbook.Rows[index].Cells[2].Value.ToString();
        string symbol = string.Format("{0} {1}", (object) this.dgvOrderbook.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrderbook.Rows[index].Cells[4].Value.ToString());
        string str1 = this.dgvOrderbook.Rows[index].Cells[5].Value.ToString();
        string str2 = this.dgvOrderbook.Rows[index].Cells[6].Value.ToString();
        int mode = 1;
        if (str2 == "S")
          mode = 2;
        Decimal qty = Convert.ToDecimal(this.dgvOrderbook.Rows[index].Cells[7].Value.ToString());
        Decimal price = Convert.ToDecimal(this.dgvOrderbook.Rows[index].Cells[8].Value.ToString());
        string str3 = this.dgvOrderbook.Rows[index].Cells[9].Value.ToString();
        string str4 = this.dgvOrderbook.Rows[index].Cells[13].Value.ToString();
        this.CurrentOrderDetail = string.Format("{0}_{1}_{2}_{3}_{4}_{5}_{6}", (object) mode, (object) price, (object) qty, (object) str4, (object) accno, (object) exch, (object) symbol);
        if (this.objbuysell == null || this.objbuysell.IsDisposed)
        {
          BuySellOrder buySellOrder = new BuySellOrder(this.objmain);
          buySellOrder.MdiParent = (Form) this.objmain;
          this.objbuysell = buySellOrder;
        }
        this.objbuysell.LoadWindow(mode, exch, symbol, price, true, (int) Enum.Parse(typeof (ValidityType), str3.ToUpper()), qty, (int) Enum.Parse(typeof (OrderType), str1.ToUpper()), accno, index);
        this.objbuysell.Location = new Point(0, this.objmain.objinfo.usertype != 4 ? this.objmain.Height - 330 : this.objmain.Height - 380);
        this.objbuysell.Show();
      }
      else
        this.objmain.DisplayMessage("No Order to Modify", 2);
    }

    public void ModifyOrder(DateTime servertime, Decimal price, int qty, int rowindex)
    {
      string[] strArray = this.CurrentOrderDetail.Split('_');
      int int32_1 = Convert.ToInt32(strArray[0]);
      Decimal num = Convert.ToDecimal(strArray[1]);
      int int32_2 = Convert.ToInt32(strArray[2]);
      long int64 = Convert.ToInt64(strArray[3]);
      string accountNo = strArray[4];
      string exch = strArray[5];
      string index = strArray[6];
      string buysell = "BUY";
      if (int32_1 == 2)
        buysell = "SELL";
      this.conn = this.objmain.getConn();
      if (this.conn.State != ConnectionState.Open)
        return;
      if (price == Decimal.Zero)
      {
        if (!this.objmain._Symconctracts.ContainsKey(index))
          return;
        Contracts symconctract = this.objmain._Symconctracts[index];
        string symbol = symconctract.SymDesp;
        if (symconctract.symbol == "GOLDMM")
          symbol = symbol.Replace("GOLDMM", "GOLD");
        else if (symconctract.symbol == "SILVERMM")
          symbol = symbol.Replace("SILVERMM", "SILVER");
        DateTime serverTime = this.objmain.GetServerTime();
        Feeds feed = this.objmain.getFeed(symbol);
        Trades trades = new Trades()
        {
          Symbol = index,
          clientcode = accountNo,
          qty = qty,
          orderno = (double) int64,
          Createon = serverTime,
          Lastmodified = serverTime,
          buysell = int32_1,
          exch = (int) Enum.Parse(typeof (DTS.Exch), exch),
          traderid = this.objmain.objinfo.clientcode
        };
        trades.price = int32_1 != 1 ? feed.bid : feed.ask;
        if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.InsertPendingTrade(trades, this.objmain))
        {
          SqlCommand sqlCommand1 = new SqlCommand(nameof (ModifyOrder), this.conn);
          sqlCommand1.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand2 = sqlCommand1)
          {
            sqlCommand2.Parameters.AddWithValue("@clientcode", (object) accountNo);
            sqlCommand2.Parameters.AddWithValue("@orderno", (object) int64);
            sqlCommand2.Parameters.AddWithValue("@oldqty", (object) int32_2);
            sqlCommand2.Parameters.AddWithValue("@oldprice", (object) num);
            sqlCommand2.Parameters.AddWithValue("@qty", (object) qty);
            sqlCommand2.Parameters.AddWithValue("@price", (object) num);
            sqlCommand2.Parameters.AddWithValue("@lastmodified", (object) servertime.ToString("yyyy-MM-dd HH:mm:ss"));
            try
            {
              if (sqlCommand2.ExecuteNonQuery() > 0)
              {
                this.dgvOrderbook.Rows[rowindex].Cells[7].Value = (object) qty;
                this.dgvOrderbook.Rows[rowindex].Cells[8].Value = (object) price;
                this.dgvOrderbook.Rows[rowindex].Cells[10].Value = (object) string.Format("{0}:{1}:{2}", (object) servertime.Hour, (object) servertime.Minute, (object) servertime.Second);
                this.DisplayConfirmation(exch, buysell, int64.ToString(), qty.ToString(), index, price.ToString(), accountNo, 1);
              }
            }
            catch
            {
              this.objmain.DisplayMessage("Unable to Modify Order", 3);
            }
          }
          string str1 = " TRADE: " + Utils.GetExch(trades.exch) + ": ";
          string str2 = string.Format(" CARRYFORWARD: AGAINST {0} PLACED AT {1}   N {2} LOTS/{3} LOTS  AT Rs. {4} FOR CLI {5} TRADE", (object) trades.orderno, (object) symconctract.symbol, (object) trades.qty, (object) trades.qty, (object) trades.price, (object) trades.clientcode);
          this.objmain.clearMsgBoard();
          switch (trades.buysell)
          {
            case 1:
              string str3 = string.Format("{0} BOUGHT : {1}", (object) str1, (object) str2);
              this.objmain.InsertMsgBoard(str3, 1);
              this.objmain.SaveMessageLogs(str3, trades);
              this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[rowindex]);
              Dashboard.PlaySound(2);
              break;
            case 2:
              string str4 = string.Format("{0} SOLD : {1}", (object) str1, (object) str2);
              this.objmain.InsertMsgBoard(str4, 1);
              this.objmain.SaveMessageLogs(str4, trades);
              this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[rowindex]);
              Dashboard.PlaySound(2);
              break;
          }
        }
      }
      else
      {
        SqlCommand sqlCommand1 = new SqlCommand(nameof (ModifyOrder), this.conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) accountNo);
          sqlCommand2.Parameters.AddWithValue("@orderno", (object) int64);
          sqlCommand2.Parameters.AddWithValue("@oldqty", (object) int32_2);
          sqlCommand2.Parameters.AddWithValue("@oldprice", (object) num);
          sqlCommand2.Parameters.AddWithValue("@qty", (object) qty);
          sqlCommand2.Parameters.AddWithValue("@price", (object) price);
          sqlCommand2.Parameters.AddWithValue("@lastmodified", (object) servertime.ToString("yyyy-MM-dd HH:mm:ss"));
          try
          {
            if (sqlCommand2.ExecuteNonQuery() > 0)
            {
              this.dgvOrderbook.Rows[rowindex].Cells[7].Value = (object) qty;
              this.dgvOrderbook.Rows[rowindex].Cells[8].Value = (object) price;
              this.dgvOrderbook.Rows[rowindex].Cells[10].Value = (object) string.Format("{0}:{1}:{2}", (object) servertime.Hour, (object) servertime.Minute, (object) servertime.Second);
              this.DisplayConfirmation(exch, buysell, int64.ToString(), qty.ToString(), index, price.ToString(), accountNo, 1);
            }
          }
          catch
          {
            this.objmain.DisplayMessage("Unable to Modify Order", 3);
          }
        }
      }
    }

    private void Task5_Click(object sender, EventArgs e)
    {
      this.CancelOrder();
    }

    private void CancelOrder()
    {
      DataGridView dgvOrderbook = this.dgvOrderbook;
      if (dgvOrderbook == null)
        return;
      try
      {
        if (MessageBox.Show("Do you really want to Cancel this Order?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
        {
          DataGridViewRow currentRow = dgvOrderbook.CurrentRow;
          int index = currentRow.Index;
          string exch = dgvOrderbook.Rows[currentRow.Index].Cells[2].Value.ToString();
          string symbol = string.Format("{0} {1}", (object) this.dgvOrderbook.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrderbook.Rows[index].Cells[4].Value.ToString());
          string buysell = !(dgvOrderbook.Rows[currentRow.Index].Cells[6].Value.ToString() == "B") ? "SELL" : "BUY";
          string qty = dgvOrderbook.Rows[currentRow.Index].Cells[7].Value.ToString();
          string price = dgvOrderbook.Rows[currentRow.Index].Cells[8].Value.ToString();
          double orderno = Convert.ToDouble(dgvOrderbook.Rows[currentRow.Index].Cells[13].Value);
          if (!this.ValidatePendingOrder(orderno))
          {
            this.objmain.DisplayMessage("Order already executed, cannot cancel this order", 2);
            this.LoadOrders();
          }
          else
          {
            string str = dgvOrderbook.Rows[currentRow.Index].Cells[0].Value.ToString();
            DateTime dtnow = new DateTime();
            if (!this.objmain.ValidateMarketTime(exch, ref dtnow))
            {
              this.objmain.DisplayMessage(string.Format(" {0} Market is closed!!", (object) exch), 2);
              this.objmain.insertSurveillanceMessages(str, string.Format(" {0} Market is closed!!", (object) exch), dtnow.ToString("yyyy-MM-dd HH:mm:ss"));
            }
            else
            {
              this.CancelOrder(orderno, str, exch, buysell, qty, symbol, price);
              this.dgvOrderbook.Rows.Remove(this.dgvOrderbook.Rows[index]);
              this.SynchronizeOrdersRows();
            }
          }
        }
      }
      catch
      {
      }
    }

    private void SynchronizeOrdersRows()
    {
      this._OrderNoList = new Dictionary<double, int>();
      foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
      {
        double key = Convert.ToDouble(row.Cells[13].Value);
        if (!this._OrderNoList.ContainsKey(key))
          this._OrderNoList.Add(key, row.Index);
      }
    }

    private void Task6_Click(object sender, EventArgs e)
    {
      if (this.dgvOrderbook.Rows.Count > 0)
      {
        if (MessageBox.Show("Do you really want to Cancel All the Orders?", "Please Confirm...", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) != DialogResult.Yes)
          return;
        for (int index = 0; index < this.dgvOrderbook.Rows.Count; ++index)
        {
          string exch = this.dgvOrderbook.Rows[index].Cells[2].Value.ToString();
          string symbol = string.Format("{0} {1}", (object) this.dgvOrderbook.Rows[index].Cells[3].Value.ToString(), (object) this.dgvOrderbook.Rows[index].Cells[4].Value.ToString());
          string buysell = !(this.dgvOrderbook.Rows[index].Cells[6].Value.ToString() == "B") ? "SELL" : "BUY";
          string qty = this.dgvOrderbook.Rows[index].Cells[7].Value.ToString();
          string price = this.dgvOrderbook.Rows[index].Cells[8].Value.ToString();
          double orderno = Convert.ToDouble(this.dgvOrderbook.Rows[index].Cells[13].Value);
          if (this.ValidatePendingOrder(orderno))
          {
            string regulationcode = this.dgvOrderbook.Rows[index].Cells[0].Value.ToString();
            DateTime now = DateTime.Now;
            if (!this.objmain.ValidateMarketTime(exch, ref now))
              return;
            this.CancelOrder(orderno, regulationcode, exch, buysell, qty, symbol, price);
          }
        }
        this.dgvOrderbook.Rows.Clear();
      }
      else
        this.objmain.DisplayMessage("No Orders to Cancel", 2);
    }

    private void Task7_Click(object sender, EventArgs e)
    {
      this.dgvOrderbook.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task8_Click(object sender, EventArgs e)
    {
      this.dgvOrderbook.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task9_Click(object sender, EventArgs e)
    {
      if (this.dgvOrderbook.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvOrderbook, false);
    }

    private void dgvOrderbook_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode != Keys.F2 || !e.Shift)
        ;
    }

    private void CancelOrder(
      double orderno,
      string regulationcode,
      string exch,
      string buysell,
      string qty,
      string symbol,
      string price)
    {
      this.conn = this.objmain.getConn();
      if (this.conn.State != ConnectionState.Open)
        return;
      SqlCommand sqlCommand1 = new SqlCommand("CancelOrders", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@Orderno", (object) orderno);
        sqlCommand2.Parameters.AddWithValue("@accountno", (object) regulationcode);
        try
        {
          sqlCommand2.ExecuteNonQuery();
          this.DisplayConfirmation(exch, buysell, orderno.ToString(), qty, symbol, price, regulationcode, 2);
        }
        catch
        {
          this.objmain.DisplayMessage("Unable to Cancel Order", 3);
        }
      }
    }

    private void DisplayConfirmation(
      string exch,
      string buysell,
      string OrderNo,
      string Ordeqty,
      string symbol,
      string OrdePrice,
      string accountNo,
      int flag)
    {
      string empty1 = string.Empty;
      string str;
      if (flag == 1)
        str = string.Format("  ORDER : {0} FUT, {1}  {2}  CarryForWard {3} {4}  N at Rs. {5} VALIDITY: DAY For CLI {6} MODIFY CONFIRMED", (object) exch, (object) OrderNo, (object) buysell, (object) Ordeqty, (object) symbol, (object) OrdePrice, (object) accountNo);
      else
        str = string.Format("  ORDER : {0} FUT, {1}   {2}  CarryForWard  {3}  {4}  N at Rs. {5}  VALIDITY: DAY For CLI {6}  CANCELLED", (object) exch, (object) OrderNo, (object) buysell, (object) Ordeqty, (object) symbol, (object) OrdePrice, (object) accountNo);
      this.objmain.clearMsgBoard();
      this.objmain.InsertMsgBoard(str, 1);
      string empty2 = string.Empty;
      Trades objord = new Trades()
      {
        clientcode = accountNo,
        Lastmodified = this.objmain.GetServerTime()
      };
      this.objmain.SaveMessageLogs(str, objord);
    }

    private void Orderbook_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (this.cThread == null)
        return;
      this.cThread.Abort();
    }

    private void Orderbook_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.Delete)
        this.CancelOrder();
      else if (e.Shift && e.KeyCode == Keys.F2)
        this.ModifyOrder();
      else if (e.KeyCode == Keys.C)
        this.cmbclientcode.Focus();
      else if (e.KeyCode == Keys.E)
        this.cmbExch.Focus();
      else if (e.KeyCode == Keys.S)
        this.cmbSymbol.Focus();
      else if (e.KeyCode == Keys.T)
      {
        this.cmbTraderid.Focus();
      }
      else
      {
        if (e.KeyCode != Keys.Escape)
          return;
        Settings.Default.OrdbookLocation = this.Location;
        Settings.Default.Save();
        this.Close();
      }
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvOrderbook.Rows)
          row.Visible = true;
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && (str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text) && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && str == this.cmbSymbol.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text != string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          string str = string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value);
          if (row.Cells[2].Value.ToString() == this.cmbExch.Text && str == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text != string.Empty && this.cmbBuySell.Text == string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (string.Format("{0} {1}", row.Cells[3].Value, row.Cells[4].Value) == this.cmbSymbol.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[6].Value.ToString() == this.cmbBuySell.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbExch.Text == string.Empty && (this.cmbSymbol.Text == string.Empty && this.cmbBuySell.Text != string.Empty) && this.cmbTraderid.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[6].Value.ToString() == this.cmbBuySell.Text && row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(this.cmbclientcode.Text == string.Empty) || !(this.cmbExch.Text == string.Empty) || (!(this.cmbSymbol.Text == string.Empty) || !(this.cmbBuySell.Text == string.Empty)) || !(this.cmbTraderid.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOrderbook.Rows)
        {
          if (row.Cells[12].Value.ToString() == this.cmbTraderid.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    private bool ValidatePendingOrder(double orderno)
    {
      this.conn = this.objmain.getConn();
      if (this.conn.State == ConnectionState.Open)
      {
        using (SqlCommand sqlCommand = new SqlCommand("Select Count(ID) from Orders where Orderno = " + (object) orderno + " and OrdStatus = 2", this.conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(0))
                return sqlDataReader.GetInt32(0) >= 1;
            }
          }
        }
      }
      return true;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (Orderbook));
      this.dgvOrderbook = new DataGridView();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.toolStripLabel1 = new ToolStripLabel();
      this.cmbExch = new ToolStripComboBox();
      this.toolStripLabel4 = new ToolStripLabel();
      this.cmbSymbol = new ToolStripComboBox();
      this.toolStripLabel5 = new ToolStripLabel();
      this.cmbBuySell = new ToolStripComboBox();
      this.toolStripLabel3 = new ToolStripLabel();
      this.cmbTraderid = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      this.Code = new DataGridViewTextBoxColumn();
      this.colName = new DataGridViewTextBoxColumn();
      this.Exch = new DataGridViewTextBoxColumn();
      this.sym = new DataGridViewTextBoxColumn();
      this.ColExpiry = new DataGridViewTextBoxColumn();
      this.product = new DataGridViewTextBoxColumn();
      this.buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.Userremarks = new DataGridViewTextBoxColumn();
      this.Traderid = new DataGridViewTextBoxColumn();
      this.Orderno = new DataGridViewTextBoxColumn();
      this.ColIp = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvOrderbook).BeginInit();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvOrderbook.AllowUserToAddRows = false;
      this.dgvOrderbook.AllowUserToDeleteRows = false;
      this.dgvOrderbook.AllowUserToOrderColumns = true;
      this.dgvOrderbook.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvOrderbook.BackgroundColor = Color.White;
      this.dgvOrderbook.CellBorderStyle = DataGridViewCellBorderStyle.None;
      gridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle1.BackColor = SystemColors.Control;
      gridViewCellStyle1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle1.ForeColor = Color.White;
      gridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle1.WrapMode = DataGridViewTriState.True;
      this.dgvOrderbook.ColumnHeadersDefaultCellStyle = gridViewCellStyle1;
      this.dgvOrderbook.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvOrderbook.Columns.AddRange((DataGridViewColumn) this.Code, (DataGridViewColumn) this.colName, (DataGridViewColumn) this.Exch, (DataGridViewColumn) this.sym, (DataGridViewColumn) this.ColExpiry, (DataGridViewColumn) this.product, (DataGridViewColumn) this.buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Time, (DataGridViewColumn) this.Userremarks, (DataGridViewColumn) this.Traderid, (DataGridViewColumn) this.Orderno, (DataGridViewColumn) this.ColIp);
      gridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle2.BackColor = SystemColors.Window;
      gridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 9.75f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle2.ForeColor = Color.White;
      gridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle2.WrapMode = DataGridViewTriState.False;
      this.dgvOrderbook.DefaultCellStyle = gridViewCellStyle2;
      this.dgvOrderbook.Location = new Point(0, 28);
      this.dgvOrderbook.MultiSelect = false;
      this.dgvOrderbook.Name = "dgvOrderbook";
      this.dgvOrderbook.ReadOnly = true;
      this.dgvOrderbook.RowHeadersVisible = false;
      this.dgvOrderbook.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvOrderbook.Size = new Size(1028, 262);
      this.dgvOrderbook.TabIndex = 1;
      this.dgvOrderbook.KeyUp += new KeyEventHandler(this.dgvOrderbook_KeyUp);
      this.dgvOrderbook.MouseClick += new MouseEventHandler(this.dgvOrderbook_MouseClick);
      this.toolStrip1.Items.AddRange(new ToolStripItem[11]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.toolStripLabel1,
        (ToolStripItem) this.cmbExch,
        (ToolStripItem) this.toolStripLabel4,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.toolStripLabel5,
        (ToolStripItem) this.cmbBuySell,
        (ToolStripItem) this.toolStripLabel3,
        (ToolStripItem) this.cmbTraderid,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1028, 25);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.toolStripLabel1.Name = "toolStripLabel1";
      this.toolStripLabel1.Size = new Size(57, 22);
      this.toolStripLabel1.Text = "Exchange";
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(121, 25);
      this.toolStripLabel4.Name = "toolStripLabel4";
      this.toolStripLabel4.Size = new Size(47, 22);
      this.toolStripLabel4.Text = "Symbol";
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(160, 25);
      this.cmbSymbol.Sorted = true;
      this.toolStripLabel5.Name = "toolStripLabel5";
      this.toolStripLabel5.Size = new Size(25, 22);
      this.toolStripLabel5.Text = "B/S";
      this.cmbBuySell.Items.AddRange(new object[2]
      {
        (object) "B",
        (object) "S"
      });
      this.cmbBuySell.Name = "cmbBuySell";
      this.cmbBuySell.Size = new Size(121, 25);
      this.toolStripLabel3.Name = "toolStripLabel3";
      this.toolStripLabel3.Size = new Size(51, 22);
      this.toolStripLabel3.Text = "Traderid";
      this.cmbTraderid.Name = "cmbTraderid";
      this.cmbTraderid.Size = new Size(121, 25);
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.Code.HeaderText = "ClientCode";
      this.Code.Name = "Code";
      this.Code.ReadOnly = true;
      this.Code.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Code.Width = 90;
      this.colName.HeaderText = "Name";
      this.colName.Name = "colName";
      this.colName.ReadOnly = true;
      this.colName.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.colName.Width = 90;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Exch.Width = 60;
      this.sym.HeaderText = "Symbol";
      this.sym.Name = "sym";
      this.sym.ReadOnly = true;
      this.sym.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.sym.Width = 90;
      this.ColExpiry.HeaderText = "Expiry";
      this.ColExpiry.Name = "ColExpiry";
      this.ColExpiry.ReadOnly = true;
      this.ColExpiry.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.ColExpiry.Width = 90;
      this.product.HeaderText = "ProductType";
      this.product.Name = "product";
      this.product.ReadOnly = true;
      this.product.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.product.Width = 60;
      this.buysell.HeaderText = "B/S";
      this.buysell.Name = "buysell";
      this.buysell.ReadOnly = true;
      this.buysell.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.buysell.Width = 40;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Qty.Width = 50;
      this.Price.HeaderText = "Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Price.Width = 70;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Validity.Width = 70;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Time.Width = 60;
      this.Userremarks.HeaderText = "UserRemarks";
      this.Userremarks.Name = "Userremarks";
      this.Userremarks.ReadOnly = true;
      this.Userremarks.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Userremarks.Width = 70;
      this.Traderid.HeaderText = "OrderedBy";
      this.Traderid.Name = "Traderid";
      this.Traderid.ReadOnly = true;
      this.Traderid.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.Orderno.HeaderText = "Orderno";
      this.Orderno.Name = "Orderno";
      this.Orderno.ReadOnly = true;
      this.Orderno.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.ColIp.HeaderText = "IpAddress";
      this.ColIp.Name = "ColIp";
      this.ColIp.ReadOnly = true;
      this.ColIp.SortMode = DataGridViewColumnSortMode.NotSortable;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1028, 290);
      this.Controls.Add((Control) this.toolStrip1);
      this.Controls.Add((Control) this.dgvOrderbook);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (Orderbook);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = nameof (Orderbook);
      this.FormClosing += new FormClosingEventHandler(this.Orderbook_FormClosing);
      this.KeyUp += new KeyEventHandler(this.Orderbook_KeyUp);
      ((ISupportInitialize) this.dgvOrderbook).EndInit();
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
