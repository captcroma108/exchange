﻿// Decompiled with JetBrains decompiler
// Type: DTS.Login
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace DTS
{
  public class Login : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public Userinfo objinfo;
    public Userinfo _adminobjinfo;
    public SqlConnection conn;
    public TextBox txtPassword;
    public TextBox txtUserName;
    private Label label2;
    private Label label1;
    private Button btnLogin;
    private CheckBox chkRemPassword;
    private CheckBox chkAutoLogin;
    private PictureBox pictureBox1;

    public Login(Dashboard objdashh, SqlConnection objdb)
    {
      this.InitializeComponent();
      this.objdash = objdashh;
      this.conn = objdb;
      this.Icon = this.objdash.ico;
      if (!File.Exists(Application.StartupPath + "\\logo.ico"))
        return;
      this.pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\logo.ico");
      this.pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
      this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
    }

    public void Loadwindow()
    {
      if (Settings.Default.RemPassword)
      {
        this.txtUserName.Text = Settings.Default.Username;
        this.txtPassword.Text = Settings.Default.Password;
        this.chkRemPassword.Checked = true;
      }
      else
      {
        this.txtUserName.Text = string.Empty;
        this.txtPassword.Text = string.Empty;
        this.chkRemPassword.Checked = false;
        this.chkAutoLogin.Checked = false;
        this.btnLogin.Enabled = false;
      }
    }

    private void btnLogin_Click(object sender, EventArgs e)
    {
      if (this.txtUserName.Text == string.Empty || this.txtPassword.Text == string.Empty)
        this.objdash.DisplayMessage("Enter Username and Password to Login", 2);
      else if (this.ValidateLogin(this.txtUserName.Text, this.objdash.Encryptdata(this.txtPassword.Text)))
      {
        if (UserinfoMain.validateadmin(this.objinfo.createdby, this.conn) == 0)
          this.objdash.DisplayMessage("Your ID has been Blocked, Please Contact Admin.", 2);
        else if (this.objinfo.userstatus == 0)
          this.objdash.DisplayMessage("Your ID has been Blocked, Please Contact Admin.", 2);
        else if (this.objinfo.ischngpwd == 1)
        {
          this.objdash.objinfo = this.objinfo;
          this.objdash.DisplayMessage("Its been 15 days since you last changed your password, Please Change Password", 1);
          ChangePwd changePwd1 = (ChangePwd) null;
          if (changePwd1 == null || changePwd1.IsDisposed)
          {
            ChangePwd changePwd2 = new ChangePwd(this.objinfo, this.conn, this.objdash);
            changePwd2.MdiParent = (Form) this.objdash;
            ChangePwd changePwd3 = changePwd2;
            changePwd3.Loadwindow();
            changePwd3.Show();
          }
          else
          {
            changePwd1.Loadwindow();
            changePwd1.MdiParent = (Form) this;
            changePwd1.Show();
          }
          this.Close();
        }
        else
        {
          if (this.objinfo.usertype == 3 || this.objinfo.usertype == 4)
          {
            try
            {
              if (Convert.ToInt32((this.objdash.GetServerTime() - this.objinfo.Lastlogin).TotalSeconds) < 29)
              {
                this.objdash.DisplayMessage("You are already logged in on some other terminal.", 2);
                return;
              }
            }
            catch
            {
            }
          }
          if (this.chkAutoLogin.Checked)
          {
            Settings.Default.Autologin = true;
            Settings.Default.RemPassword = true;
            Settings.Default.Username = this.txtUserName.Text;
            Settings.Default.Password = this.txtPassword.Text;
          }
          else if (this.chkRemPassword.Checked)
          {
            Settings.Default.RemPassword = true;
            Settings.Default.Autologin = false;
            Settings.Default.Username = this.txtUserName.Text;
            Settings.Default.Password = this.txtPassword.Text;
          }
          else
          {
            Settings.Default.Autologin = false;
            Settings.Default.RemPassword = false;
            Settings.Default.Username = string.Empty;
            Settings.Default.Password = string.Empty;
          }
          Settings.Default.Save();
          this.objdash.UpdateLoginStatus(this.objinfo);
          this.Close();
        }
      }
      else
        this.objdash.DisplayMessage("Invalid Username or Password.", 2);
    }

    private bool ValidateLogin(string username, string Password)
    {
      if (this.conn.State == ConnectionState.Closed)
        this.conn = this.objdash.getConn();
      this.objinfo = UserinfoMain.ValidateandGetUserinfo(username, Password, this.conn);
      return this.objinfo != null;
    }

    private void txtUserName_TextChanged(object sender, EventArgs e)
    {
      if (this.txtUserName.Text.Length > 0 && this.txtPassword.Text.Length > 0)
        this.btnLogin.Enabled = true;
      else
        this.btnLogin.Enabled = false;
    }

    private void txtPassword_TextChanged(object sender, EventArgs e)
    {
      if (this.txtUserName.Text.Length > 0 && this.txtPassword.Text.Length > 0)
        this.btnLogin.Enabled = true;
      else
        this.btnLogin.Enabled = false;
    }

    private void chkAutoLogin_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.chkAutoLogin.Checked)
        return;
      this.chkRemPassword.Checked = true;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.txtPassword = new TextBox();
      this.txtUserName = new TextBox();
      this.label2 = new Label();
      this.label1 = new Label();
      this.btnLogin = new Button();
      this.chkRemPassword = new CheckBox();
      this.chkAutoLogin = new CheckBox();
      this.pictureBox1 = new PictureBox();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      this.SuspendLayout();
      this.txtPassword.Location = new Point(143, 70);
      this.txtPassword.MaxLength = 18;
      this.txtPassword.Name = "txtPassword";
      this.txtPassword.PasswordChar = '*';
      this.txtPassword.Size = new Size(122, 20);
      this.txtPassword.TabIndex = 5;
      this.txtPassword.UseSystemPasswordChar = true;
      this.txtPassword.TextChanged += new EventHandler(this.txtPassword_TextChanged);
      this.txtUserName.Location = new Point(143, 30);
      this.txtUserName.Name = "txtUserName";
      this.txtUserName.Size = new Size(122, 20);
      this.txtUserName.TabIndex = 3;
      this.txtUserName.TextChanged += new EventHandler(this.txtUserName_TextChanged);
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(75, 70);
      this.label2.Name = "label2";
      this.label2.Size = new Size(64, 15);
      this.label2.TabIndex = 7;
      this.label2.Text = "Password:";
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(75, 33);
      this.label1.Name = "label1";
      this.label1.Size = new Size(68, 15);
      this.label1.TabIndex = 4;
      this.label1.Text = "Username:";
      this.btnLogin.DialogResult = DialogResult.Cancel;
      this.btnLogin.FlatStyle = FlatStyle.System;
      this.btnLogin.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnLogin.ForeColor = Color.FromArgb(0, 0, 192);
      this.btnLogin.Location = new Point(141, 155);
      this.btnLogin.Name = "btnLogin";
      this.btnLogin.Size = new Size(58, 25);
      this.btnLogin.TabIndex = 6;
      this.btnLogin.Text = nameof (Login);
      this.btnLogin.UseVisualStyleBackColor = true;
      this.btnLogin.Click += new EventHandler(this.btnLogin_Click);
      this.chkRemPassword.AutoSize = true;
      this.chkRemPassword.Location = new Point(78, 99);
      this.chkRemPassword.Name = "chkRemPassword";
      this.chkRemPassword.Size = new Size(126, 17);
      this.chkRemPassword.TabIndex = 8;
      this.chkRemPassword.Text = "Remember Password";
      this.chkRemPassword.UseVisualStyleBackColor = true;
      this.chkAutoLogin.AutoSize = true;
      this.chkAutoLogin.Location = new Point(78, 126);
      this.chkAutoLogin.Name = "chkAutoLogin";
      this.chkAutoLogin.Size = new Size(77, 17);
      this.chkAutoLogin.TabIndex = 9;
      this.chkAutoLogin.Text = "Auto Login";
      this.chkAutoLogin.UseVisualStyleBackColor = true;
      this.chkAutoLogin.CheckedChanged += new EventHandler(this.chkAutoLogin_CheckedChanged);
      this.pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
      this.pictureBox1.InitialImage = (Image) null;
      this.pictureBox1.Location = new Point(6, 6);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(55, 55);
      this.pictureBox1.TabIndex = 11;
      this.pictureBox1.TabStop = false;
      this.AcceptButton = (IButtonControl) this.btnLogin;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(282, 210);
      this.Controls.Add((Control) this.pictureBox1);
      this.Controls.Add((Control) this.chkAutoLogin);
      this.Controls.Add((Control) this.chkRemPassword);
      this.Controls.Add((Control) this.txtPassword);
      this.Controls.Add((Control) this.txtUserName);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.btnLogin);
      this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (Login);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = nameof (Login);
      ((ISupportInitialize) this.pictureBox1).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
