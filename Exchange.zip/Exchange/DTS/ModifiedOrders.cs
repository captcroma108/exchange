﻿// Decompiled with JetBrains decompiler
// Type: DTS.ModifiedOrders
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class ModifiedOrders : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public MWColumnProfile objColProfile;
    public DataGridView dgvModifiedOrd;
    private DataGridViewTextBoxColumn RegulationCode;
    private DataGridViewTextBoxColumn ColName;
    private DataGridViewTextBoxColumn Exchange;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Productype;
    private DataGridViewTextBoxColumn BuySell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Modifiedqty;
    private DataGridViewTextBoxColumn ModifiedPrice;
    private DataGridViewTextBoxColumn Modifiedby;
    private DataGridViewTextBoxColumn Modifiedtime;
    private DataGridViewTextBoxColumn Userremarks;
    private DataGridViewTextBoxColumn colIp;

    public ModifiedOrders(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    private void dgvModifiedOrd_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Column Profile", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Save Column Profile", (Image) null, new EventHandler(this.Task2_Click));
      contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task7_Click));
      contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task8_Click));
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task9_Click));
      Point client = this.dgvModifiedOrd.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvModifiedOrd, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.objColProfile == null || this.objColProfile.IsDisposed)
      {
        MWColumnProfile mwColumnProfile = new MWColumnProfile(this.objmain, 3);
        mwColumnProfile.MdiParent = (Form) this.objmain;
        this.objColProfile = mwColumnProfile;
        this.objColProfile.Show();
      }
      else
      {
        this.objColProfile.MdiParent = (Form) this.objmain;
        this.objColProfile.Activate();
        this.objColProfile.Show();
      }
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvModifiedOrd.Columns.Count; ++index)
        str = !this.dgvModifiedOrd.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvModifiedOrd.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvModifiedOrd.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.ModOrdColumnProfile = str;
      Settings.Default.Save();
    }

    private void Task7_Click(object sender, EventArgs e)
    {
      this.dgvModifiedOrd.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task8_Click(object sender, EventArgs e)
    {
      this.dgvModifiedOrd.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task9_Click(object sender, EventArgs e)
    {
      if (this.dgvModifiedOrd.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvModifiedOrd, false);
    }

    public void LoadWindow()
    {
      this._ColumnOnOff = new Dictionary<string, int>();
      string ordColumnProfile = Settings.Default.ModOrdColumnProfile;
      if (ordColumnProfile != string.Empty)
      {
        string str1 = ordColumnProfile;
        char[] chArray1 = new char[1]{ ',' };
        foreach (string str2 in str1.Split(chArray1))
        {
          char[] chArray2 = new char[1]{ '_' };
          string[] strArray = str2.Split(chArray2);
          int int32 = Convert.ToInt32(strArray[1]);
          switch (Convert.ToInt32(strArray[2]))
          {
            case 0:
              this.dgvModifiedOrd.Columns[int32].Visible = false;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 0);
                break;
              }
              break;
            case 1:
              this.dgvModifiedOrd.Columns[int32].Visible = true;
              if (!this._ColumnOnOff.ContainsKey(strArray[0]))
              {
                this._ColumnOnOff.Add(strArray[0], 1);
                break;
              }
              break;
          }
        }
      }
      else
      {
        for (int index = 0; index < this.dgvModifiedOrd.Columns.Count; ++index)
        {
          if (!this._ColumnOnOff.ContainsKey(this.dgvModifiedOrd.Columns[index].HeaderText))
          {
            if (this.dgvModifiedOrd.Columns[index].Visible)
              this._ColumnOnOff.Add(this.dgvModifiedOrd.Columns[index].HeaderText, 1);
            else
              this._ColumnOnOff.Add(this.dgvModifiedOrd.Columns[index].HeaderText, 0);
          }
        }
      }
    }

    public void LoadModified()
    {
      this.LoadWindow();
      string str = string.Empty;
      if (this.objmain.objinfo.usertype == 3)
        str = this.objmain.claccounts;
      else if (this.objmain.objinfo.usertype == 4)
        str = string.Format("'{0}'", (object) this.objmain.objinfo.clientcode);
      if (str == string.Empty || this.conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("select O.Clientcode,U.Name,case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR'  WHEN 5 THEN 'NSEOPT' END as Exchange,O.Symbol,case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as Producttype,case O.BuySell WHEN 1 THEN 'BUY'  WHEN 2 THEN 'SELL' END as BuySell,M.OldQty,M.OldPrice,M.ModifiedQty,M.ModifiedPrice,O.Traderid,O.Lastmodified,O.Userremarks,O.Ipaddress from Modified M, Orders O,  Userinformation U where M.Orderno = O.Orderno and U.Clientcode = O.Clientcode and  M.Clientcode in (" + str + ") and O.Lastmodified > '" + DateTime.Now.ToString("yyyy-MM-dd 09:00:00") + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            int index = this.dgvModifiedOrd.Rows.Add();
            if (!sqlDataReader.IsDBNull(0))
              this.dgvModifiedOrd.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(0);
            if (!sqlDataReader.IsDBNull(1))
              this.dgvModifiedOrd.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
              this.dgvModifiedOrd.Rows[index].Cells[2].Value = (object) sqlDataReader.GetString(2);
            if (!sqlDataReader.IsDBNull(3))
              this.dgvModifiedOrd.Rows[index].Cells[3].Value = (object) sqlDataReader.GetString(3);
            if (!sqlDataReader.IsDBNull(4))
              this.dgvModifiedOrd.Rows[index].Cells[4].Value = (object) sqlDataReader.GetString(4);
            if (!sqlDataReader.IsDBNull(5))
              this.dgvModifiedOrd.Rows[index].Cells[5].Value = (object) sqlDataReader.GetString(5);
            if (!sqlDataReader.IsDBNull(6))
              this.dgvModifiedOrd.Rows[index].Cells[6].Value = (object) sqlDataReader.GetInt32(6);
            if (!sqlDataReader.IsDBNull(7))
              this.dgvModifiedOrd.Rows[index].Cells[7].Value = sqlDataReader.GetValue(7);
            if (!sqlDataReader.IsDBNull(8))
              this.dgvModifiedOrd.Rows[index].Cells[8].Value = (object) sqlDataReader.GetInt32(8);
            if (!sqlDataReader.IsDBNull(9))
              this.dgvModifiedOrd.Rows[index].Cells[9].Value = sqlDataReader.GetValue(9);
            if (!sqlDataReader.IsDBNull(10))
              this.dgvModifiedOrd.Rows[index].Cells[10].Value = (object) sqlDataReader.GetString(10);
            if (!sqlDataReader.IsDBNull(11))
              this.dgvModifiedOrd.Rows[index].Cells[11].Value = sqlDataReader.GetValue(11);
            if (!sqlDataReader.IsDBNull(12))
              this.dgvModifiedOrd.Rows[index].Cells[12].Value = (object) sqlDataReader.GetString(12);
            this.dgvModifiedOrd.Rows[index].Cells[13].Value = !sqlDataReader.IsDBNull(13) ? (object) sqlDataReader.GetString(12).Trim() : (object) string.Empty;
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvModifiedOrd = new DataGridView();
      this.RegulationCode = new DataGridViewTextBoxColumn();
      this.ColName = new DataGridViewTextBoxColumn();
      this.Exchange = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Productype = new DataGridViewTextBoxColumn();
      this.BuySell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Modifiedqty = new DataGridViewTextBoxColumn();
      this.ModifiedPrice = new DataGridViewTextBoxColumn();
      this.Modifiedby = new DataGridViewTextBoxColumn();
      this.Modifiedtime = new DataGridViewTextBoxColumn();
      this.Userremarks = new DataGridViewTextBoxColumn();
      this.colIp = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvModifiedOrd).BeginInit();
      this.SuspendLayout();
      this.dgvModifiedOrd.AllowUserToAddRows = false;
      this.dgvModifiedOrd.AllowUserToDeleteRows = false;
      this.dgvModifiedOrd.AllowUserToOrderColumns = true;
      this.dgvModifiedOrd.BackgroundColor = Color.White;
      this.dgvModifiedOrd.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
      this.dgvModifiedOrd.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvModifiedOrd.Columns.AddRange((DataGridViewColumn) this.RegulationCode, (DataGridViewColumn) this.ColName, (DataGridViewColumn) this.Exchange, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Productype, (DataGridViewColumn) this.BuySell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Modifiedqty, (DataGridViewColumn) this.ModifiedPrice, (DataGridViewColumn) this.Modifiedby, (DataGridViewColumn) this.Modifiedtime, (DataGridViewColumn) this.Userremarks, (DataGridViewColumn) this.colIp);
      this.dgvModifiedOrd.Dock = DockStyle.Fill;
      this.dgvModifiedOrd.Location = new Point(0, 0);
      this.dgvModifiedOrd.Name = "dgvModifiedOrd";
      this.dgvModifiedOrd.ReadOnly = true;
      this.dgvModifiedOrd.RowHeadersVisible = false;
      this.dgvModifiedOrd.Size = new Size(945, 290);
      this.dgvModifiedOrd.TabIndex = 0;
      this.dgvModifiedOrd.MouseClick += new MouseEventHandler(this.dgvModifiedOrd_MouseClick);
      this.RegulationCode.HeaderText = "ClientCode";
      this.RegulationCode.Name = "RegulationCode";
      this.RegulationCode.ReadOnly = true;
      this.ColName.HeaderText = "Name";
      this.ColName.Name = "ColName";
      this.ColName.ReadOnly = true;
      this.ColName.Width = 80;
      this.Exchange.HeaderText = "Exchange";
      this.Exchange.Name = "Exchange";
      this.Exchange.ReadOnly = true;
      this.Exchange.Width = 75;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Productype.HeaderText = "ProductType";
      this.Productype.Name = "Productype";
      this.Productype.ReadOnly = true;
      this.Productype.Width = 60;
      this.BuySell.HeaderText = "B/S";
      this.BuySell.Name = "BuySell";
      this.BuySell.ReadOnly = true;
      this.BuySell.Width = 60;
      this.Qty.HeaderText = "Old_Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 60;
      this.Price.HeaderText = "Old_Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 60;
      this.Modifiedqty.HeaderText = "Modified_Qty";
      this.Modifiedqty.Name = "Modifiedqty";
      this.Modifiedqty.ReadOnly = true;
      this.Modifiedqty.Width = 60;
      this.ModifiedPrice.HeaderText = "Modified_Price";
      this.ModifiedPrice.Name = "ModifiedPrice";
      this.ModifiedPrice.ReadOnly = true;
      this.ModifiedPrice.Width = 60;
      this.Modifiedby.HeaderText = "Modified By";
      this.Modifiedby.Name = "Modifiedby";
      this.Modifiedby.ReadOnly = true;
      this.Modifiedtime.HeaderText = "Modified Time";
      this.Modifiedtime.Name = "Modifiedtime";
      this.Modifiedtime.ReadOnly = true;
      this.Userremarks.HeaderText = "User Remarks";
      this.Userremarks.Name = "Userremarks";
      this.Userremarks.ReadOnly = true;
      this.colIp.HeaderText = "IpAddress";
      this.colIp.Name = "colIp";
      this.colIp.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvModifiedOrd);
      this.Name = nameof (ModifiedOrders);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Modified Orders";
      ((ISupportInitialize) this.dgvModifiedOrd).EndInit();
      this.ResumeLayout(false);
    }
  }
}
