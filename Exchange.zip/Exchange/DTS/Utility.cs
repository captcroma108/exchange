﻿// Decompiled with JetBrains decompiler
// Type: DTS.Utility
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;

namespace DTS
{
  public class Utility
  {
    public static DataTable GetDataTableFromCsv(string path, bool isFirstRowHeader)
    {
      string str = isFirstRowHeader ? "Yes" : "No";
      string directoryName = Path.GetDirectoryName(path);
      string cmdText = "SELECT * FROM [" + Path.GetFileName(path) + "]";
      using (OleDbConnection connection = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + directoryName + ";Extended Properties=\"Text;HDR=" + str + "\""))
      {
        using (OleDbCommand selectCommand = new OleDbCommand(cmdText, connection))
        {
          using (OleDbDataAdapter oleDbDataAdapter = new OleDbDataAdapter(selectCommand))
          {
            DataTable dataTable = new DataTable();
            dataTable.Locale = CultureInfo.CurrentCulture;
            oleDbDataAdapter.Fill(dataTable);
            return dataTable;
          }
        }
      }
    }
  }
}
