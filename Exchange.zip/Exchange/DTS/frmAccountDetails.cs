﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmAccountDetails
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace DTS
{
  public class frmAccountDetails : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private Label label6;
    private TextBox txtusername;
    private Label label4;
    private TextBox txtname;
    private Label label2;
    private ComboBox cmbClientcode;
    private Label label1;
    private Label label8;
    private TextBox txtOddlottrading;
    private Label label7;
    private GroupBox groupBox2;
    private Label label14;
    private TextBox txtmtmlimit;
    private TextBox txtcashmargin;
    private Label label9;
    private Label label10;
    private TextBox txtBreakupLots;
    private Label label11;
    private TextBox txtBrkgtype;
    private GroupBox groupTurnoverBrkg;
    private MaskedTextBox txtnsecurr;
    private Label lblCommission;
    private MaskedTextBox txtmcx;
    private Label label12;
    private Label label13;
    private MaskedTextBox txtnsefut;
    private MaskedTextBox txtncdex;
    private Label label15;
    private Label label16;
    private TextBox txttrdAttri;
    private Button btnClose;
    private ListBox lstAddFeatures;
    private ListBox lstExchanges;
    private Label label17;
    private TextBox txtMrgnSqoff;
    private Label label5;
    private TextBox txtIntrasqoff;
    private GroupBox groupBox3;
    private TextBox txtMrgnType;
    private Label label18;
    private GroupBox groupLotwiseExchwise;
    private Label label19;
    private Label label20;
    private TextBox txtnsecurrLots;
    private Label label21;
    private Label label22;
    private Label label23;
    private TextBox txtMcxlots;
    private Label label24;
    private Label label25;
    private Label label26;
    private TextBox txtncxlot;
    private TextBox txtnselot;
    private GroupBox groupSymwiseRs;
    private Label label30;
    private TextBox txtIntraMrgn;
    private Label label33;
    private TextBox txtDelvMrgn;
    private ComboBox cmbSymbolwiseRs;
    private Label label27;
    private GroupBox groupSymbolBrkg;
    private ComboBox cmbBrkgSym;
    private Label label28;
    private Label label29;
    private TextBox txtIntraBrkg;
    private Label label31;
    private TextBox txtdelvBrkg;
    private GroupBox groupLotwiseSymwise;
    private ComboBox cmbLotwiseSym;
    private Label label32;
    private Label label34;
    private TextBox txtLots;
    private GroupBox groupOffset;
    private ComboBox cmbOffsetSym;
    private Label label35;
    private Label label36;
    private TextBox txtOffset;
    private TextBox txtMrgnStatus;
    private Label label37;
    private TextBox txtUserstatus;
    private Label label3;
    private TextBox txtTurnLimit;
    private Label lblTurnLimit;
    private Label label38;
    private TextBox txtTradeAttri;
    private MaskedTextBox txtCnfNseCurr;
    private MaskedTextBox txtCnfMcx;
    private MaskedTextBox txtCnfNseFut;
    private MaskedTextBox txtCnfNcdex;
    private Label label39;
    private Label label40;

    public frmAccountDetails(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    private void btnClose_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    public void LoadControls()
    {
      Userinfo userinfo = this.objdash.GetUserinfo(this.cmbClientcode.Text);
      this.txtname.Text = userinfo.name;
      this.txtusername.Text = userinfo.username;
      this.txtUserstatus.Text = "Active";
      if (userinfo.userstatus == 0)
        this.txtUserstatus.Text = "Blocked";
      this.txtMrgnStatus.Text = "Active";
      if (userinfo.marginstatus == 0)
        this.txtMrgnStatus.Text = "Blocked";
      if (userinfo.exchange.Contains(","))
      {
        string[] strArray = userinfo.exchange.Split(',');
        for (int index = 0; index < strArray.Length; ++index)
        {
          if (strArray[index] != string.Empty)
            this.lstExchanges.Items.Add((object) strArray[index]);
          this.OnOffExchangeProperties(strArray[index]);
        }
      }
      else
      {
        this.lstExchanges.Items.Add((object) userinfo.exchange);
        this.OnOffExchangeProperties(userinfo.exchange);
      }
      if (userinfo.oddlot == 1)
        this.txtOddlottrading.Text = "YES";
      else
        this.txtOddlottrading.Text = "NO";
      if (userinfo.pivots == 1)
        this.lstAddFeatures.Items.Add((object) "Pivots");
      if (userinfo.stockperform == 1)
        this.lstAddFeatures.Items.Add((object) "Data Queries");
      if (userinfo.charts == 1)
        this.lstAddFeatures.Items.Add((object) "Charting");
      if (userinfo.offset == 1)
      {
        this.lstAddFeatures.Items.Add((object) "Offset Trading");
        this.groupOffset.Visible = true;
        this.PopulateSymbols(this.cmbOffsetSym);
      }
      if (!this.objdash._ClientLimits.ContainsKey(this.cmbClientcode.Text))
        return;
      Limits clientLimit = this.objdash._ClientLimits[this.cmbClientcode.Text];
      this.txtcashmargin.Text = clientLimit.cashmrgn.ToString();
      TextBox txtmtmlimit = this.txtmtmlimit;
      Decimal num1 = clientLimit.mtmlosslimit;
      string str1 = num1.ToString();
      txtmtmlimit.Text = str1;
      this.txtBreakupLots.Text = clientLimit.breakup.ToString();
      TextBox txttrdAttri = this.txttrdAttri;
      int num2 = clientLimit.tradeattributes;
      string str2 = num2.ToString();
      txttrdAttri.Text = str2;
      this.txtTradeAttri.Text = clientLimit.Productype;
      if (clientLimit.isIntrasqoff == 1)
        this.txtIntrasqoff.Text = "YES";
      else
        this.txtIntrasqoff.Text = "NO";
      if (clientLimit.IsMrgnsqoff == 1)
        this.txtMrgnSqoff.Text = "YES";
      else
        this.txtMrgnSqoff.Text = "NO";
      if (clientLimit.brkgtype == 1)
      {
        this.groupTurnoverBrkg.Visible = true;
        this.groupSymbolBrkg.Visible = false;
        this.txtBrkgtype.Text = "Turnoverwise";
        MaskedTextBox txtmcx = this.txtmcx;
        num1 = clientLimit.mcxIntrdybrkg;
        string str3 = num1.ToString();
        txtmcx.Text = str3;
        MaskedTextBox txtnsefut = this.txtnsefut;
        num1 = clientLimit.nsefutIntrdybrkg;
        string str4 = num1.ToString();
        txtnsefut.Text = str4;
        MaskedTextBox txtncdex = this.txtncdex;
        num1 = clientLimit.ncdexIntrdybrkg;
        string str5 = num1.ToString();
        txtncdex.Text = str5;
        MaskedTextBox txtnsecurr = this.txtnsecurr;
        num1 = clientLimit.nsecurrIntrdybrkg;
        string str6 = num1.ToString();
        txtnsecurr.Text = str6;
        MaskedTextBox txtCnfMcx = this.txtCnfMcx;
        num1 = clientLimit.mcxCnfbrkg;
        string str7 = num1.ToString();
        txtCnfMcx.Text = str7;
        MaskedTextBox txtCnfNseFut = this.txtCnfNseFut;
        num1 = clientLimit.nsefutCnfbrkg;
        string str8 = num1.ToString();
        txtCnfNseFut.Text = str8;
        MaskedTextBox txtCnfNcdex = this.txtCnfNcdex;
        num1 = clientLimit.ncdexCnfbrkg;
        string str9 = num1.ToString();
        txtCnfNcdex.Text = str9;
        MaskedTextBox txtCnfNseCurr = this.txtCnfNseCurr;
        num1 = clientLimit.nsecurrCnfbrkg;
        string str10 = num1.ToString();
        txtCnfNseCurr.Text = str10;
      }
      else
      {
        this.groupTurnoverBrkg.Visible = false;
        this.groupSymbolBrkg.Visible = true;
        this.txtBrkgtype.Text = "Lotwise";
        this.PopulateSymbols(this.cmbBrkgSym);
      }
      switch (clientLimit.mrgntype)
      {
        case 1:
          this.txtMrgnType.Text = "Turnover";
          this.groupLotwiseExchwise.Visible = false;
          this.groupSymwiseRs.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.lblTurnLimit.Visible = true;
          this.txtTurnLimit.Visible = true;
          TextBox txtTurnLimit1 = this.txtTurnLimit;
          num1 = clientLimit.turnoverlimit;
          string str11 = num1.ToString();
          txtTurnLimit1.Text = str11;
          break;
        case 2:
          if (clientLimit.lotwisetype == 1 || clientLimit.lotwisetype == 2)
          {
            this.groupLotwiseExchwise.Visible = true;
            this.groupLotwiseSymwise.Visible = false;
            if (clientLimit.lotwisetype == 2)
            {
              TextBox txtMcxlots = this.txtMcxlots;
              num2 = clientLimit.mcxlots;
              string str3 = num2.ToString();
              txtMcxlots.Text = str3;
              TextBox txtnselot = this.txtnselot;
              num2 = clientLimit.nsefutlots;
              string str4 = num2.ToString();
              txtnselot.Text = str4;
              TextBox txtncxlot = this.txtncxlot;
              num2 = clientLimit.ncxlots;
              string str5 = num2.ToString();
              txtncxlot.Text = str5;
              TextBox txtnsecurrLots = this.txtnsecurrLots;
              num2 = clientLimit.nsecurlots;
              string str6 = num2.ToString();
              txtnsecurrLots.Text = str6;
            }
            else if (clientLimit.lotwisetype == 1)
            {
              this.txtMcxlots.Text = this.objdash.MCXlots.ToString();
              this.txtnselot.Text = this.objdash.NSEFUTlots.ToString();
              this.txtncxlot.Text = this.objdash.NCDEXlots.ToString();
              this.txtnsecurrLots.Text = this.objdash.NSECURlots.ToString();
            }
            this.txtMrgnType.Text = "Lotwise : Exchangewise";
          }
          else
          {
            this.groupLotwiseExchwise.Visible = false;
            this.groupLotwiseSymwise.Visible = true;
            this.PopulateSymbols(this.cmbLotwiseSym);
            this.txtMrgnType.Text = "Lotwise : Symbolwise";
          }
          this.lblTurnLimit.Visible = false;
          this.txtTurnLimit.Visible = false;
          this.groupSymwiseRs.Visible = false;
          break;
        case 3:
          this.groupSymwiseRs.Visible = false;
          this.lblTurnLimit.Visible = false;
          this.txtTurnLimit.Visible = false;
          this.groupLotwiseExchwise.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.PopulateSymbols(this.cmbSymbolwiseRs);
          this.txtMrgnType.Text = "Symbolwise(Rs.)";
          break;
        case 4:
          this.txtMrgnType.Text = "Turnover";
          this.groupLotwiseExchwise.Visible = false;
          this.groupSymwiseRs.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.lblTurnLimit.Visible = true;
          this.txtTurnLimit.Visible = true;
          TextBox txtTurnLimit2 = this.txtTurnLimit;
          num1 = clientLimit.turnoverlimit;
          string str12 = num1.ToString();
          txtTurnLimit2.Text = str12;
          if (clientLimit.lotwisetype == 1 || clientLimit.lotwisetype == 2)
          {
            this.groupLotwiseExchwise.Visible = true;
            this.groupLotwiseSymwise.Visible = false;
            if (clientLimit.lotwisetype == 2)
            {
              TextBox txtMcxlots = this.txtMcxlots;
              num2 = clientLimit.mcxlots;
              string str3 = num2.ToString();
              txtMcxlots.Text = str3;
              TextBox txtnselot = this.txtnselot;
              num2 = clientLimit.nsefutlots;
              string str4 = num2.ToString();
              txtnselot.Text = str4;
              TextBox txtncxlot = this.txtncxlot;
              num2 = clientLimit.ncxlots;
              string str5 = num2.ToString();
              txtncxlot.Text = str5;
              TextBox txtnsecurrLots = this.txtnsecurrLots;
              num2 = clientLimit.nsecurlots;
              string str6 = num2.ToString();
              txtnsecurrLots.Text = str6;
            }
            else if (clientLimit.lotwisetype == 1)
            {
              this.txtMcxlots.Text = this.objdash.MCXlots.ToString();
              this.txtnselot.Text = this.objdash.NSEFUTlots.ToString();
              this.txtncxlot.Text = this.objdash.NCDEXlots.ToString();
              this.txtnsecurrLots.Text = this.objdash.NSECURlots.ToString();
            }
            this.txtMrgnType.Text = "Turnover && Lotwise : Exchangewise";
            break;
          }
          this.groupLotwiseExchwise.Visible = false;
          this.groupLotwiseSymwise.Visible = true;
          this.PopulateSymbols(this.cmbLotwiseSym);
          this.txtMrgnType.Text = "Turnover && Lotwise : Symbolwise";
          this.lblTurnLimit.Visible = true;
          this.txtTurnLimit.Visible = true;
          break;
        case 5:
          this.groupSymwiseRs.Visible = false;
          this.lblTurnLimit.Visible = false;
          this.txtTurnLimit.Visible = false;
          this.groupLotwiseExchwise.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.PopulateSymbols(this.cmbSymbolwiseRs);
          this.txtMrgnType.Text = "Symbolwise(Rs.)";
          if (clientLimit.lotwisetype == 1 || clientLimit.lotwisetype == 2)
          {
            this.groupLotwiseExchwise.Visible = true;
            this.groupLotwiseSymwise.Visible = false;
            if (clientLimit.lotwisetype == 2)
            {
              TextBox txtMcxlots = this.txtMcxlots;
              num2 = clientLimit.mcxlots;
              string str3 = num2.ToString();
              txtMcxlots.Text = str3;
              TextBox txtnselot = this.txtnselot;
              num2 = clientLimit.nsefutlots;
              string str4 = num2.ToString();
              txtnselot.Text = str4;
              TextBox txtncxlot = this.txtncxlot;
              num2 = clientLimit.ncxlots;
              string str5 = num2.ToString();
              txtncxlot.Text = str5;
              TextBox txtnsecurrLots = this.txtnsecurrLots;
              num2 = clientLimit.nsecurlots;
              string str6 = num2.ToString();
              txtnsecurrLots.Text = str6;
            }
            else if (clientLimit.lotwisetype == 1)
            {
              this.txtMcxlots.Text = this.objdash.MCXlots.ToString();
              this.txtnselot.Text = this.objdash.NSEFUTlots.ToString();
              this.txtncxlot.Text = this.objdash.NCDEXlots.ToString();
              this.txtnsecurrLots.Text = this.objdash.NSECURlots.ToString();
            }
            this.txtMrgnType.Text = "Symbolwise(Rs.) && Lotwise : Exchangewise";
            break;
          }
          this.groupLotwiseExchwise.Visible = false;
          this.groupLotwiseSymwise.Visible = true;
          this.PopulateSymbols(this.cmbLotwiseSym);
          this.txtMrgnType.Text = "Symbolwise(Rs.) && Lotwise : Symbolwise";
          this.lblTurnLimit.Visible = true;
          this.txtTurnLimit.Visible = true;
          break;
        case 6:
          this.groupSymwiseRs.Visible = false;
          this.lblTurnLimit.Visible = false;
          this.txtTurnLimit.Visible = false;
          this.groupLotwiseExchwise.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.PopulateSymbols(this.cmbSymbolwiseRs);
          this.txtMrgnType.Text = "Turnover && Symbolwise(Rs.)";
          this.groupLotwiseExchwise.Visible = false;
          this.groupSymwiseRs.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.lblTurnLimit.Visible = true;
          this.txtTurnLimit.Visible = true;
          TextBox txtTurnLimit3 = this.txtTurnLimit;
          num1 = clientLimit.turnoverlimit;
          string str13 = num1.ToString();
          txtTurnLimit3.Text = str13;
          break;
        case 7:
          this.lblTurnLimit.Visible = true;
          this.txtTurnLimit.Visible = true;
          TextBox txtTurnLimit4 = this.txtTurnLimit;
          num1 = clientLimit.turnoverlimit;
          string str14 = num1.ToString();
          txtTurnLimit4.Text = str14;
          if (clientLimit.lotwisetype == 1 || clientLimit.lotwisetype == 2)
          {
            this.groupLotwiseExchwise.Visible = true;
            this.groupLotwiseSymwise.Visible = false;
            if (clientLimit.lotwisetype == 2)
            {
              TextBox txtMcxlots = this.txtMcxlots;
              num2 = clientLimit.mcxlots;
              string str3 = num2.ToString();
              txtMcxlots.Text = str3;
              TextBox txtnselot = this.txtnselot;
              num2 = clientLimit.nsefutlots;
              string str4 = num2.ToString();
              txtnselot.Text = str4;
              TextBox txtncxlot = this.txtncxlot;
              num2 = clientLimit.ncxlots;
              string str5 = num2.ToString();
              txtncxlot.Text = str5;
              TextBox txtnsecurrLots = this.txtnsecurrLots;
              num2 = clientLimit.nsecurlots;
              string str6 = num2.ToString();
              txtnsecurrLots.Text = str6;
            }
            else if (clientLimit.lotwisetype == 1)
            {
              this.txtMcxlots.Text = this.objdash.MCXlots.ToString();
              this.txtnselot.Text = this.objdash.NSEFUTlots.ToString();
              this.txtncxlot.Text = this.objdash.NCDEXlots.ToString();
              this.txtnsecurrLots.Text = this.objdash.NSECURlots.ToString();
            }
            this.txtMrgnType.Text = "Turnover && Lotwise : Exchangewise && Symbolwise(Rs.)";
          }
          else
          {
            this.groupLotwiseExchwise.Visible = false;
            this.groupLotwiseSymwise.Visible = true;
            this.PopulateSymbols(this.cmbLotwiseSym);
            this.txtMrgnType.Text = "Turnover && Lotwise : Symbolwise && Symbolwise(Rs.)";
          }
          this.groupSymwiseRs.Visible = false;
          this.lblTurnLimit.Visible = false;
          this.txtTurnLimit.Visible = false;
          this.groupLotwiseExchwise.Visible = false;
          this.groupLotwiseSymwise.Visible = false;
          this.PopulateSymbols(this.cmbSymbolwiseRs);
          break;
      }
    }

    private void OnOffExchangeProperties(string exchange)
    {
      string str = exchange;
      if (!(str == "MCX"))
      {
        if (!(str == "NSEFUT"))
        {
          if (!(str == "NCDEX"))
          {
            if (!(str == "NSECURR"))
              return;
            this.label12.Visible = true;
            this.txtnsecurr.Visible = true;
            this.txtCnfNseCurr.Visible = true;
            this.label20.Visible = true;
            this.label19.Visible = true;
            this.txtnsecurrLots.Visible = true;
          }
          else
          {
            this.label15.Visible = true;
            this.txtncdex.Visible = true;
            this.txtCnfNcdex.Visible = true;
            this.label23.Visible = true;
            this.label26.Visible = true;
            this.txtncxlot.Visible = true;
          }
        }
        else
        {
          this.label13.Visible = true;
          this.txtnsefut.Visible = true;
          this.txtCnfNseFut.Visible = true;
          this.label25.Visible = true;
          this.label21.Visible = true;
          this.txtnselot.Visible = true;
        }
      }
      else
      {
        this.lblCommission.Visible = true;
        this.txtmcx.Visible = true;
        this.txtCnfMcx.Visible = true;
        this.label22.Visible = true;
        this.txtMcxlots.Visible = true;
        this.label24.Visible = true;
      }
    }

    private void PopulateSymbols(ComboBox cmbbox)
    {
      foreach (KeyValuePair<string, Contracts> symconctract in this.objdash._Symconctracts)
      {
        Contracts contracts = symconctract.Value;
        if (!cmbbox.Items.Contains((object) contracts.symbol))
          cmbbox.Items.Add((object) contracts.symbol);
      }
    }

    private void clearcontrols(Control Control)
    {
      foreach (Control control in (ArrangedElementCollection) Control.Controls)
      {
        if (control is TextBox)
          ((TextBoxBase) control).Clear();
        if (control.HasChildren)
          this.clearcontrols(control);
        if (control is ComboBox && control != this.cmbClientcode)
          ((ComboBox) control).Items.Clear();
        if (control is ListBox)
          ((ListBox) control).Items.Clear();
      }
      this.groupOffset.Visible = false;
      this.groupTurnoverBrkg.Visible = false;
      this.groupSymbolBrkg.Visible = false;
      this.groupLotwiseExchwise.Visible = false;
      this.groupLotwiseSymwise.Visible = false;
      this.groupSymwiseRs.Visible = false;
    }

    private void cmbOffsetSym_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.txtOffset.Text = string.Empty;
      if (this.cmbOffsetSym.SelectedIndex <= -1)
        return;
      if (this.objdash._ClientOffset.ContainsKey(this.cmbClientcode.Text))
      {
        SortedDictionary<string, double> sortedDictionary = this.objdash._ClientOffset[this.cmbClientcode.Text];
        if (sortedDictionary.ContainsKey(this.cmbOffsetSym.Text))
          this.txtOffset.Text = sortedDictionary[this.cmbOffsetSym.Text].ToString();
      }
      else if (this.objdash._ClientOffset.ContainsKey(this.objdash.objinfo.createdby))
      {
        SortedDictionary<string, double> sortedDictionary = this.objdash._ClientOffset[this.objdash.objinfo.createdby];
        if (sortedDictionary.ContainsKey(this.cmbOffsetSym.Text))
          this.txtOffset.Text = sortedDictionary[this.cmbOffsetSym.Text].ToString();
      }
    }

    private void cmbBrkgSym_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.txtIntraBrkg.Text = string.Empty;
      this.txtdelvBrkg.Text = string.Empty;
      if (this.cmbBrkgSym.SelectedIndex <= -1)
        return;
      SymbolMargin symbolwiseMrgn = this.objdash.GetSymbolwiseMrgn(this.cmbClientcode.Text, this.cmbBrkgSym.Text);
      this.txtIntraBrkg.Text = symbolwiseMrgn.intrabrkg.ToString();
      this.txtdelvBrkg.Text = symbolwiseMrgn.delvbrkg.ToString();
    }

    private void cmbLotwiseSym_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.txtLots.Text = string.Empty;
      if (this.cmbLotwiseSym.SelectedIndex <= -1)
        return;
      this.txtLots.Text = this.objdash.GetSymbolwiseMrgn(this.cmbClientcode.Text, this.cmbLotwiseSym.Text).totlots.ToString();
    }

    private void cmbSymbolwiseRs_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.txtIntraMrgn.Text = string.Empty;
      this.txtDelvMrgn.Text = string.Empty;
      if (this.cmbSymbolwiseRs.SelectedIndex <= -1)
        return;
      SymbolMargin symbolwiseMrgn = this.objdash.GetSymbolwiseMrgn(this.cmbClientcode.Text, this.cmbSymbolwiseRs.Text);
      this.txtIntraMrgn.Text = symbolwiseMrgn.intramrgn.ToString();
      this.txtDelvMrgn.Text = symbolwiseMrgn.delvmrgn.ToString();
    }

    public void Loadwindow()
    {
      this.cmbClientcode.Items.Clear();
      if (this.objdash.objinfo.usertype == 4)
      {
        this.clearcontrols((Control) this);
        this.cmbClientcode.Items.Add((object) this.objdash.objinfo.clientcode);
        this.cmbClientcode.SelectedIndex = 0;
      }
      else
      {
        this.clearcontrols((Control) this);
        foreach (object lstAccount in this.objdash._lstAccounts)
          this.cmbClientcode.Items.Add(lstAccount);
        if (this.cmbClientcode.Items.Count > -1)
          this.cmbClientcode.SelectedIndex = 0;
      }
    }

    private void cmbClientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.cmbClientcode.SelectedIndex <= -1)
        return;
      this.clearcontrols((Control) this);
      this.LoadControls();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.txtMrgnStatus = new TextBox();
      this.label37 = new Label();
      this.txtUserstatus = new TextBox();
      this.label3 = new Label();
      this.groupOffset = new GroupBox();
      this.cmbOffsetSym = new ComboBox();
      this.label35 = new Label();
      this.label36 = new Label();
      this.txtOffset = new TextBox();
      this.lstAddFeatures = new ListBox();
      this.lstExchanges = new ListBox();
      this.label8 = new Label();
      this.txtOddlottrading = new TextBox();
      this.label7 = new Label();
      this.label6 = new Label();
      this.txtusername = new TextBox();
      this.label4 = new Label();
      this.txtname = new TextBox();
      this.label2 = new Label();
      this.cmbClientcode = new ComboBox();
      this.label1 = new Label();
      this.groupBox2 = new GroupBox();
      this.label38 = new Label();
      this.txtTradeAttri = new TextBox();
      this.label17 = new Label();
      this.txtMrgnSqoff = new TextBox();
      this.label5 = new Label();
      this.txtIntrasqoff = new TextBox();
      this.label16 = new Label();
      this.txttrdAttri = new TextBox();
      this.groupTurnoverBrkg = new GroupBox();
      this.label39 = new Label();
      this.label40 = new Label();
      this.groupSymbolBrkg = new GroupBox();
      this.cmbBrkgSym = new ComboBox();
      this.label28 = new Label();
      this.label29 = new Label();
      this.txtIntraBrkg = new TextBox();
      this.label31 = new Label();
      this.txtdelvBrkg = new TextBox();
      this.txtCnfNseCurr = new MaskedTextBox();
      this.txtCnfMcx = new MaskedTextBox();
      this.txtCnfNseFut = new MaskedTextBox();
      this.txtCnfNcdex = new MaskedTextBox();
      this.txtnsecurr = new MaskedTextBox();
      this.lblCommission = new Label();
      this.txtmcx = new MaskedTextBox();
      this.label12 = new Label();
      this.label13 = new Label();
      this.txtnsefut = new MaskedTextBox();
      this.txtncdex = new MaskedTextBox();
      this.label15 = new Label();
      this.label11 = new Label();
      this.txtBrkgtype = new TextBox();
      this.label10 = new Label();
      this.txtBreakupLots = new TextBox();
      this.label14 = new Label();
      this.txtmtmlimit = new TextBox();
      this.txtcashmargin = new TextBox();
      this.label9 = new Label();
      this.btnClose = new Button();
      this.groupBox3 = new GroupBox();
      this.txtTurnLimit = new TextBox();
      this.lblTurnLimit = new Label();
      this.groupLotwiseSymwise = new GroupBox();
      this.cmbLotwiseSym = new ComboBox();
      this.label32 = new Label();
      this.label34 = new Label();
      this.txtLots = new TextBox();
      this.groupSymwiseRs = new GroupBox();
      this.cmbSymbolwiseRs = new ComboBox();
      this.label27 = new Label();
      this.label30 = new Label();
      this.txtIntraMrgn = new TextBox();
      this.label33 = new Label();
      this.txtDelvMrgn = new TextBox();
      this.groupLotwiseExchwise = new GroupBox();
      this.label19 = new Label();
      this.label20 = new Label();
      this.txtnsecurrLots = new TextBox();
      this.label21 = new Label();
      this.label22 = new Label();
      this.label23 = new Label();
      this.txtMcxlots = new TextBox();
      this.label24 = new Label();
      this.label25 = new Label();
      this.label26 = new Label();
      this.txtncxlot = new TextBox();
      this.txtnselot = new TextBox();
      this.txtMrgnType = new TextBox();
      this.label18 = new Label();
      this.groupBox1.SuspendLayout();
      this.groupOffset.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.groupTurnoverBrkg.SuspendLayout();
      this.groupSymbolBrkg.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.groupLotwiseSymwise.SuspendLayout();
      this.groupSymwiseRs.SuspendLayout();
      this.groupLotwiseExchwise.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.txtMrgnStatus);
      this.groupBox1.Controls.Add((Control) this.label37);
      this.groupBox1.Controls.Add((Control) this.txtUserstatus);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.groupOffset);
      this.groupBox1.Controls.Add((Control) this.lstAddFeatures);
      this.groupBox1.Controls.Add((Control) this.lstExchanges);
      this.groupBox1.Controls.Add((Control) this.label8);
      this.groupBox1.Controls.Add((Control) this.txtOddlottrading);
      this.groupBox1.Controls.Add((Control) this.label7);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.txtusername);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.txtname);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.cmbClientcode);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(10, 10);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(221, 417);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Basic Details";
      this.txtMrgnStatus.Location = new Point(87, 116);
      this.txtMrgnStatus.MaxLength = 12;
      this.txtMrgnStatus.Name = "txtMrgnStatus";
      this.txtMrgnStatus.ReadOnly = true;
      this.txtMrgnStatus.Size = new Size(126, 20);
      this.txtMrgnStatus.TabIndex = 82;
      this.label37.AutoSize = true;
      this.label37.Location = new Point(5, 119);
      this.label37.Name = "label37";
      this.label37.Size = new Size(75, 13);
      this.label37.TabIndex = 83;
      this.label37.Text = "Margin Status:";
      this.txtUserstatus.Location = new Point(87, 91);
      this.txtUserstatus.MaxLength = 12;
      this.txtUserstatus.Name = "txtUserstatus";
      this.txtUserstatus.ReadOnly = true;
      this.txtUserstatus.Size = new Size(126, 20);
      this.txtUserstatus.TabIndex = 80;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(5, 94);
      this.label3.Name = "label3";
      this.label3.Size = new Size(65, 13);
      this.label3.TabIndex = 81;
      this.label3.Text = "User Status:";
      this.groupOffset.Controls.Add((Control) this.cmbOffsetSym);
      this.groupOffset.Controls.Add((Control) this.label35);
      this.groupOffset.Controls.Add((Control) this.label36);
      this.groupOffset.Controls.Add((Control) this.txtOffset);
      this.groupOffset.Location = new Point(10, 341);
      this.groupOffset.Name = "groupOffset";
      this.groupOffset.Size = new Size(205, 68);
      this.groupOffset.TabIndex = 79;
      this.groupOffset.TabStop = false;
      this.groupOffset.Text = "Offset Details";
      this.cmbOffsetSym.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbOffsetSym.FormattingEnabled = true;
      this.cmbOffsetSym.Location = new Point(96, 14);
      this.cmbOffsetSym.Name = "cmbOffsetSym";
      this.cmbOffsetSym.Size = new Size(101, 21);
      this.cmbOffsetSym.TabIndex = 76;
      this.cmbOffsetSym.SelectedIndexChanged += new EventHandler(this.cmbOffsetSym_SelectedIndexChanged);
      this.label35.AutoSize = true;
      this.label35.ForeColor = Color.Black;
      this.label35.Location = new Point(6, 20);
      this.label35.Name = "label35";
      this.label35.Size = new Size(77, 13);
      this.label35.TabIndex = 75;
      this.label35.Text = "Select Symbol:";
      this.label35.Visible = false;
      this.label36.AutoSize = true;
      this.label36.ForeColor = Color.Black;
      this.label36.Location = new Point(6, 44);
      this.label36.Name = "label36";
      this.label36.Size = new Size(38, 13);
      this.label36.TabIndex = 73;
      this.label36.Text = "Offset:";
      this.label36.Visible = false;
      this.txtOffset.BackColor = Color.WhiteSmoke;
      this.txtOffset.ForeColor = Color.Black;
      this.txtOffset.Location = new Point(96, 41);
      this.txtOffset.MaxLength = 3;
      this.txtOffset.Name = "txtOffset";
      this.txtOffset.Size = new Size(101, 20);
      this.txtOffset.TabIndex = 74;
      this.txtOffset.Visible = false;
      this.lstAddFeatures.FormattingEnabled = true;
      this.lstAddFeatures.Location = new Point(87, 250);
      this.lstAddFeatures.Name = "lstAddFeatures";
      this.lstAddFeatures.Size = new Size(126, 82);
      this.lstAddFeatures.TabIndex = 71;
      this.lstExchanges.FormattingEnabled = true;
      this.lstExchanges.Location = new Point(87, 141);
      this.lstExchanges.Name = "lstExchanges";
      this.lstExchanges.Size = new Size(126, 82);
      this.lstExchanges.TabIndex = 70;
      this.label8.AutoSize = true;
      this.label8.Location = new Point(5, 250);
      this.label8.Name = "label8";
      this.label8.Size = new Size(53, 26);
      this.label8.TabIndex = 15;
      this.label8.Text = "Additional\r\nFeatures:";
      this.txtOddlottrading.Location = new Point(87, 226);
      this.txtOddlottrading.MaxLength = 10;
      this.txtOddlottrading.Name = "txtOddlottrading";
      this.txtOddlottrading.ReadOnly = true;
      this.txtOddlottrading.Size = new Size(126, 20);
      this.txtOddlottrading.TabIndex = 13;
      this.label7.AutoSize = true;
      this.label7.Location = new Point(5, 229);
      this.label7.Name = "label7";
      this.label7.Size = new Size(83, 13);
      this.label7.TabIndex = 12;
      this.label7.Text = "Odd Lot trading:";
      this.label6.AutoSize = true;
      this.label6.Location = new Point(5, 145);
      this.label6.Name = "label6";
      this.label6.Size = new Size(63, 13);
      this.label6.TabIndex = 11;
      this.label6.Text = "Exchanges:";
      this.txtusername.Location = new Point(87, 66);
      this.txtusername.MaxLength = 18;
      this.txtusername.Name = "txtusername";
      this.txtusername.ReadOnly = true;
      this.txtusername.Size = new Size(126, 20);
      this.txtusername.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(5, 70);
      this.label4.Name = "label4";
      this.label4.Size = new Size(58, 13);
      this.label4.TabIndex = 7;
      this.label4.Text = "Username:";
      this.txtname.Location = new Point(87, 42);
      this.txtname.MaxLength = 12;
      this.txtname.Name = "txtname";
      this.txtname.ReadOnly = true;
      this.txtname.Size = new Size(126, 20);
      this.txtname.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(5, 45);
      this.label2.Name = "label2";
      this.label2.Size = new Size(38, 13);
      this.label2.TabIndex = 3;
      this.label2.Text = "Name:";
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(87, 17);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(126, 21);
      this.cmbClientcode.TabIndex = 0;
      this.cmbClientcode.SelectedIndexChanged += new EventHandler(this.cmbClientcode_SelectedIndexChanged);
      this.label1.AutoSize = true;
      this.label1.Location = new Point(5, 20);
      this.label1.Name = "label1";
      this.label1.Size = new Size(60, 13);
      this.label1.TabIndex = 2;
      this.label1.Text = "Clientcode:";
      this.groupBox2.Controls.Add((Control) this.label38);
      this.groupBox2.Controls.Add((Control) this.txtTradeAttri);
      this.groupBox2.Controls.Add((Control) this.label17);
      this.groupBox2.Controls.Add((Control) this.txtMrgnSqoff);
      this.groupBox2.Controls.Add((Control) this.label5);
      this.groupBox2.Controls.Add((Control) this.txtIntrasqoff);
      this.groupBox2.Controls.Add((Control) this.label16);
      this.groupBox2.Controls.Add((Control) this.txttrdAttri);
      this.groupBox2.Controls.Add((Control) this.groupTurnoverBrkg);
      this.groupBox2.Controls.Add((Control) this.label11);
      this.groupBox2.Controls.Add((Control) this.txtBrkgtype);
      this.groupBox2.Controls.Add((Control) this.label10);
      this.groupBox2.Controls.Add((Control) this.txtBreakupLots);
      this.groupBox2.Controls.Add((Control) this.label14);
      this.groupBox2.Controls.Add((Control) this.txtmtmlimit);
      this.groupBox2.Controls.Add((Control) this.txtcashmargin);
      this.groupBox2.Controls.Add((Control) this.label9);
      this.groupBox2.Location = new Point(237, 10);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(245, 376);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Limits";
      this.label38.AutoSize = true;
      this.label38.ForeColor = Color.Black;
      this.label38.Location = new Point(6, 353);
      this.label38.Name = "label38";
      this.label38.Size = new Size(107, 13);
      this.label38.TabIndex = 80;
      this.label38.Text = "Trade Type Attribute:";
      this.txtTradeAttri.BackColor = Color.WhiteSmoke;
      this.txtTradeAttri.ForeColor = Color.Black;
      this.txtTradeAttri.Location = new Point(111, 350);
      this.txtTradeAttri.Name = "txtTradeAttri";
      this.txtTradeAttri.ReadOnly = true;
      this.txtTradeAttri.Size = new Size(125, 20);
      this.txtTradeAttri.TabIndex = 79;
      this.label17.AutoSize = true;
      this.label17.ForeColor = Color.Black;
      this.label17.Location = new Point(7, 167);
      this.label17.Name = "label17";
      this.label17.Size = new Size(103, 13);
      this.label17.TabIndex = 73;
      this.label17.Text = "Margin Short Sq-Off:";
      this.txtMrgnSqoff.BackColor = Color.WhiteSmoke;
      this.txtMrgnSqoff.ForeColor = Color.Black;
      this.txtMrgnSqoff.Location = new Point(111, 163);
      this.txtMrgnSqoff.Name = "txtMrgnSqoff";
      this.txtMrgnSqoff.ReadOnly = true;
      this.txtMrgnSqoff.Size = new Size(125, 20);
      this.txtMrgnSqoff.TabIndex = 72;
      this.label5.AutoSize = true;
      this.label5.ForeColor = Color.Black;
      this.label5.Location = new Point(7, 138);
      this.label5.Name = "label5";
      this.label5.Size = new Size(81, 13);
      this.label5.TabIndex = 71;
      this.label5.Text = "Intraday Sq-Off:";
      this.txtIntrasqoff.BackColor = Color.WhiteSmoke;
      this.txtIntrasqoff.ForeColor = Color.Black;
      this.txtIntrasqoff.Location = new Point(111, 134);
      this.txtIntrasqoff.Name = "txtIntrasqoff";
      this.txtIntrasqoff.ReadOnly = true;
      this.txtIntrasqoff.Size = new Size(125, 20);
      this.txtIntrasqoff.TabIndex = 70;
      this.label16.AutoSize = true;
      this.label16.ForeColor = Color.Black;
      this.label16.Location = new Point(6, 110);
      this.label16.Name = "label16";
      this.label16.Size = new Size(85, 13);
      this.label16.TabIndex = 69;
      this.label16.Text = "Trade Attributes:";
      this.txttrdAttri.BackColor = Color.WhiteSmoke;
      this.txttrdAttri.ForeColor = Color.Black;
      this.txttrdAttri.Location = new Point(110, 106);
      this.txttrdAttri.Name = "txttrdAttri";
      this.txttrdAttri.ReadOnly = true;
      this.txttrdAttri.Size = new Size(125, 20);
      this.txttrdAttri.TabIndex = 68;
      this.groupTurnoverBrkg.Controls.Add((Control) this.label39);
      this.groupTurnoverBrkg.Controls.Add((Control) this.label40);
      this.groupTurnoverBrkg.Controls.Add((Control) this.groupSymbolBrkg);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtCnfNseCurr);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtCnfMcx);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtCnfNseFut);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtCnfNcdex);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtnsecurr);
      this.groupTurnoverBrkg.Controls.Add((Control) this.lblCommission);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtmcx);
      this.groupTurnoverBrkg.Controls.Add((Control) this.label12);
      this.groupTurnoverBrkg.Controls.Add((Control) this.label13);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtnsefut);
      this.groupTurnoverBrkg.Controls.Add((Control) this.txtncdex);
      this.groupTurnoverBrkg.Controls.Add((Control) this.label15);
      this.groupTurnoverBrkg.Location = new Point(22, 218);
      this.groupTurnoverBrkg.Name = "groupTurnoverBrkg";
      this.groupTurnoverBrkg.Size = new Size(201, 114);
      this.groupTurnoverBrkg.TabIndex = 67;
      this.groupTurnoverBrkg.TabStop = false;
      this.groupTurnoverBrkg.Text = "Turnover Brkg";
      this.label39.AutoSize = true;
      this.label39.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label39.Location = new Point(145, 6);
      this.label39.Name = "label39";
      this.label39.Size = new Size(31, 13);
      this.label39.TabIndex = 19;
      this.label39.Text = "CNF";
      this.label40.AutoSize = true;
      this.label40.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label40.Location = new Point(94, 6);
      this.label40.Name = "label40";
      this.label40.Size = new Size(39, 13);
      this.label40.TabIndex = 18;
      this.label40.Text = "Intrdy";
      this.groupSymbolBrkg.Controls.Add((Control) this.cmbBrkgSym);
      this.groupSymbolBrkg.Controls.Add((Control) this.label28);
      this.groupSymbolBrkg.Controls.Add((Control) this.label29);
      this.groupSymbolBrkg.Controls.Add((Control) this.txtIntraBrkg);
      this.groupSymbolBrkg.Controls.Add((Control) this.label31);
      this.groupSymbolBrkg.Controls.Add((Control) this.txtdelvBrkg);
      this.groupSymbolBrkg.Location = new Point(6, 102);
      this.groupSymbolBrkg.Name = "groupSymbolBrkg";
      this.groupSymbolBrkg.Size = new Size(203, 106);
      this.groupSymbolBrkg.TabIndex = 78;
      this.groupSymbolBrkg.TabStop = false;
      this.groupSymbolBrkg.Text = "Symbolwise Brkg(Rs.)";
      this.groupSymbolBrkg.Visible = false;
      this.cmbBrkgSym.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbBrkgSym.FormattingEnabled = true;
      this.cmbBrkgSym.Location = new Point(96, 21);
      this.cmbBrkgSym.Name = "cmbBrkgSym";
      this.cmbBrkgSym.Size = new Size(101, 21);
      this.cmbBrkgSym.TabIndex = 72;
      this.cmbBrkgSym.SelectedIndexChanged += new EventHandler(this.cmbBrkgSym_SelectedIndexChanged);
      this.label28.AutoSize = true;
      this.label28.ForeColor = Color.Black;
      this.label28.Location = new Point(6, 27);
      this.label28.Name = "label28";
      this.label28.Size = new Size(77, 13);
      this.label28.TabIndex = 53;
      this.label28.Text = "Select Symbol:";
      this.label28.Visible = false;
      this.label29.AutoSize = true;
      this.label29.ForeColor = Color.Black;
      this.label29.Location = new Point(6, 51);
      this.label29.Name = "label29";
      this.label29.Size = new Size(56, 13);
      this.label29.TabIndex = 47;
      this.label29.Text = "Intra Brkg:";
      this.label29.Visible = false;
      this.txtIntraBrkg.BackColor = Color.WhiteSmoke;
      this.txtIntraBrkg.ForeColor = Color.Black;
      this.txtIntraBrkg.Location = new Point(96, 48);
      this.txtIntraBrkg.MaxLength = 3;
      this.txtIntraBrkg.Name = "txtIntraBrkg";
      this.txtIntraBrkg.ReadOnly = true;
      this.txtIntraBrkg.Size = new Size(101, 20);
      this.txtIntraBrkg.TabIndex = 48;
      this.txtIntraBrkg.Visible = false;
      this.label31.AutoSize = true;
      this.label31.ForeColor = Color.Black;
      this.label31.Location = new Point(6, 76);
      this.label31.Name = "label31";
      this.label31.Size = new Size(57, 13);
      this.label31.TabIndex = 50;
      this.label31.Text = "Delv Brkg:";
      this.label31.Visible = false;
      this.txtdelvBrkg.BackColor = Color.WhiteSmoke;
      this.txtdelvBrkg.ForeColor = Color.Black;
      this.txtdelvBrkg.Location = new Point(96, 73);
      this.txtdelvBrkg.MaxLength = 3;
      this.txtdelvBrkg.Name = "txtdelvBrkg";
      this.txtdelvBrkg.ReadOnly = true;
      this.txtdelvBrkg.Size = new Size(101, 20);
      this.txtdelvBrkg.TabIndex = 52;
      this.txtdelvBrkg.Visible = false;
      this.txtCnfNseCurr.Location = new Point(141, 83);
      this.txtCnfNseCurr.Mask = "0.00000";
      this.txtCnfNseCurr.Name = "txtCnfNseCurr";
      this.txtCnfNseCurr.Size = new Size(45, 20);
      this.txtCnfNseCurr.TabIndex = 15;
      this.txtCnfNseCurr.Text = "0";
      this.txtCnfNseCurr.Visible = false;
      this.txtCnfMcx.Location = new Point(141, 19);
      this.txtCnfMcx.Mask = "0.00000";
      this.txtCnfMcx.Name = "txtCnfMcx";
      this.txtCnfMcx.Size = new Size(45, 20);
      this.txtCnfMcx.TabIndex = 12;
      this.txtCnfMcx.Text = "0";
      this.txtCnfMcx.Visible = false;
      this.txtCnfNseFut.Location = new Point(141, 40);
      this.txtCnfNseFut.Mask = "0.00000";
      this.txtCnfNseFut.Name = "txtCnfNseFut";
      this.txtCnfNseFut.Size = new Size(45, 20);
      this.txtCnfNseFut.TabIndex = 13;
      this.txtCnfNseFut.Text = "0";
      this.txtCnfNseFut.Visible = false;
      this.txtCnfNcdex.Location = new Point(141, 61);
      this.txtCnfNcdex.Mask = "0.00000";
      this.txtCnfNcdex.Name = "txtCnfNcdex";
      this.txtCnfNcdex.Size = new Size(45, 20);
      this.txtCnfNcdex.TabIndex = 14;
      this.txtCnfNcdex.Text = "0";
      this.txtCnfNcdex.Visible = false;
      this.txtnsecurr.Location = new Point(90, 83);
      this.txtnsecurr.Mask = "0.00000";
      this.txtnsecurr.Name = "txtnsecurr";
      this.txtnsecurr.Size = new Size(45, 20);
      this.txtnsecurr.TabIndex = 11;
      this.txtnsecurr.Text = "0";
      this.txtnsecurr.Visible = false;
      this.lblCommission.AutoSize = true;
      this.lblCommission.ForeColor = Color.Black;
      this.lblCommission.Location = new Point(18, 22);
      this.lblCommission.Name = "lblCommission";
      this.lblCommission.Size = new Size(33, 13);
      this.lblCommission.TabIndex = 2;
      this.lblCommission.Text = "MCX:";
      this.lblCommission.Visible = false;
      this.txtmcx.Location = new Point(90, 19);
      this.txtmcx.Mask = "0.00000";
      this.txtmcx.Name = "txtmcx";
      this.txtmcx.Size = new Size(45, 20);
      this.txtmcx.TabIndex = 5;
      this.txtmcx.Text = "0";
      this.txtmcx.Visible = false;
      this.label12.AutoSize = true;
      this.label12.ForeColor = Color.Black;
      this.label12.Location = new Point(18, 86);
      this.label12.Name = "label12";
      this.label12.Size = new Size(63, 13);
      this.label12.TabIndex = 10;
      this.label12.Text = "NSECURR:";
      this.label12.Visible = false;
      this.label13.AutoSize = true;
      this.label13.ForeColor = Color.Black;
      this.label13.Location = new Point(18, 43);
      this.label13.Name = "label13";
      this.label13.Size = new Size(53, 13);
      this.label13.TabIndex = 6;
      this.label13.Text = "NSEFUT:";
      this.label13.Visible = false;
      this.txtnsefut.Location = new Point(90, 40);
      this.txtnsefut.Mask = "0.00000";
      this.txtnsefut.Name = "txtnsefut";
      this.txtnsefut.Size = new Size(45, 20);
      this.txtnsefut.TabIndex = 7;
      this.txtnsefut.Text = "0";
      this.txtnsefut.Visible = false;
      this.txtncdex.Location = new Point(90, 61);
      this.txtncdex.Mask = "0.00000";
      this.txtncdex.Name = "txtncdex";
      this.txtncdex.Size = new Size(45, 20);
      this.txtncdex.TabIndex = 9;
      this.txtncdex.Text = "0";
      this.txtncdex.Visible = false;
      this.label15.AutoSize = true;
      this.label15.ForeColor = Color.Black;
      this.label15.Location = new Point(18, 64);
      this.label15.Name = "label15";
      this.label15.Size = new Size(47, 13);
      this.label15.TabIndex = 8;
      this.label15.Text = "NCDEX:";
      this.label15.Visible = false;
      this.label11.AutoSize = true;
      this.label11.ForeColor = Color.Black;
      this.label11.Location = new Point(7, 196);
      this.label11.Name = "label11";
      this.label11.Size = new Size(86, 13);
      this.label11.TabIndex = 66;
      this.label11.Text = "Brokerage Type:";
      this.txtBrkgtype.BackColor = Color.WhiteSmoke;
      this.txtBrkgtype.ForeColor = Color.Black;
      this.txtBrkgtype.Location = new Point(111, 192);
      this.txtBrkgtype.Name = "txtBrkgtype";
      this.txtBrkgtype.ReadOnly = true;
      this.txtBrkgtype.Size = new Size(125, 20);
      this.txtBrkgtype.TabIndex = 65;
      this.label10.AutoSize = true;
      this.label10.ForeColor = Color.Black;
      this.label10.Location = new Point(6, 82);
      this.label10.Name = "label10";
      this.label10.Size = new Size(73, 13);
      this.label10.TabIndex = 64;
      this.label10.Text = "Breakup Lots:";
      this.txtBreakupLots.BackColor = Color.WhiteSmoke;
      this.txtBreakupLots.ForeColor = Color.Black;
      this.txtBreakupLots.Location = new Point(110, 78);
      this.txtBreakupLots.Name = "txtBreakupLots";
      this.txtBreakupLots.ReadOnly = true;
      this.txtBreakupLots.Size = new Size(125, 20);
      this.txtBreakupLots.TabIndex = 63;
      this.label14.AutoSize = true;
      this.label14.ForeColor = Color.Black;
      this.label14.Location = new Point(6, 53);
      this.label14.Name = "label14";
      this.label14.Size = new Size(96, 13);
      this.label14.TabIndex = 62;
      this.label14.Text = "M To M Loss Limit:";
      this.txtmtmlimit.BackColor = Color.WhiteSmoke;
      this.txtmtmlimit.ForeColor = Color.Black;
      this.txtmtmlimit.Location = new Point(110, 49);
      this.txtmtmlimit.Name = "txtmtmlimit";
      this.txtmtmlimit.ReadOnly = true;
      this.txtmtmlimit.Size = new Size(125, 20);
      this.txtmtmlimit.TabIndex = 58;
      this.txtcashmargin.BackColor = Color.WhiteSmoke;
      this.txtcashmargin.ForeColor = Color.Black;
      this.txtcashmargin.Location = new Point(110, 22);
      this.txtcashmargin.MaxLength = 12;
      this.txtcashmargin.Name = "txtcashmargin";
      this.txtcashmargin.ReadOnly = true;
      this.txtcashmargin.Size = new Size(125, 20);
      this.txtcashmargin.TabIndex = 57;
      this.txtcashmargin.Text = "0";
      this.label9.AutoSize = true;
      this.label9.ForeColor = Color.Black;
      this.label9.Location = new Point(6, 24);
      this.label9.Name = "label9";
      this.label9.Size = new Size(69, 13);
      this.label9.TabIndex = 59;
      this.label9.Text = "Cash Margin:";
      this.btnClose.Location = new Point(317, 404);
      this.btnClose.Name = "btnClose";
      this.btnClose.Size = new Size(75, 23);
      this.btnClose.TabIndex = 3;
      this.btnClose.Text = "Close";
      this.btnClose.UseVisualStyleBackColor = true;
      this.btnClose.Click += new EventHandler(this.btnClose_Click);
      this.groupBox3.Controls.Add((Control) this.txtTurnLimit);
      this.groupBox3.Controls.Add((Control) this.lblTurnLimit);
      this.groupBox3.Controls.Add((Control) this.groupLotwiseSymwise);
      this.groupBox3.Controls.Add((Control) this.groupSymwiseRs);
      this.groupBox3.Controls.Add((Control) this.groupLotwiseExchwise);
      this.groupBox3.Controls.Add((Control) this.txtMrgnType);
      this.groupBox3.Controls.Add((Control) this.label18);
      this.groupBox3.Location = new Point(487, 10);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(218, 417);
      this.groupBox3.TabIndex = 4;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Margin";
      this.txtTurnLimit.BackColor = Color.WhiteSmoke;
      this.txtTurnLimit.ForeColor = Color.Black;
      this.txtTurnLimit.Location = new Point(86, 50);
      this.txtTurnLimit.MaxLength = 12;
      this.txtTurnLimit.Name = "txtTurnLimit";
      this.txtTurnLimit.ReadOnly = true;
      this.txtTurnLimit.Size = new Size(125, 20);
      this.txtTurnLimit.TabIndex = 79;
      this.txtTurnLimit.Visible = false;
      this.lblTurnLimit.AutoSize = true;
      this.lblTurnLimit.ForeColor = Color.Black;
      this.lblTurnLimit.Location = new Point(7, 57);
      this.lblTurnLimit.Name = "lblTurnLimit";
      this.lblTurnLimit.Size = new Size(77, 13);
      this.lblTurnLimit.TabIndex = 80;
      this.lblTurnLimit.Text = "Turnover Limit:";
      this.lblTurnLimit.Visible = false;
      this.groupLotwiseSymwise.Controls.Add((Control) this.cmbLotwiseSym);
      this.groupLotwiseSymwise.Controls.Add((Control) this.label32);
      this.groupLotwiseSymwise.Controls.Add((Control) this.label34);
      this.groupLotwiseSymwise.Controls.Add((Control) this.txtLots);
      this.groupLotwiseSymwise.Location = new Point(8, 329);
      this.groupLotwiseSymwise.Name = "groupLotwiseSymwise";
      this.groupLotwiseSymwise.Size = new Size(203, 80);
      this.groupLotwiseSymwise.TabIndex = 78;
      this.groupLotwiseSymwise.TabStop = false;
      this.groupLotwiseSymwise.Text = "Lotwise : Symbolwise";
      this.groupLotwiseSymwise.Visible = false;
      this.cmbLotwiseSym.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbLotwiseSym.FormattingEnabled = true;
      this.cmbLotwiseSym.Location = new Point(96, 21);
      this.cmbLotwiseSym.Name = "cmbLotwiseSym";
      this.cmbLotwiseSym.Size = new Size(101, 21);
      this.cmbLotwiseSym.TabIndex = 72;
      this.cmbLotwiseSym.SelectedIndexChanged += new EventHandler(this.cmbLotwiseSym_SelectedIndexChanged);
      this.label32.AutoSize = true;
      this.label32.ForeColor = Color.Black;
      this.label32.Location = new Point(6, 27);
      this.label32.Name = "label32";
      this.label32.Size = new Size(77, 13);
      this.label32.TabIndex = 53;
      this.label32.Text = "Select Symbol:";
      this.label32.Visible = false;
      this.label34.AutoSize = true;
      this.label34.ForeColor = Color.Black;
      this.label34.Location = new Point(6, 51);
      this.label34.Name = "label34";
      this.label34.Size = new Size(30, 13);
      this.label34.TabIndex = 47;
      this.label34.Text = "Lots:";
      this.label34.Visible = false;
      this.txtLots.BackColor = Color.WhiteSmoke;
      this.txtLots.ForeColor = Color.Black;
      this.txtLots.Location = new Point(96, 48);
      this.txtLots.MaxLength = 3;
      this.txtLots.Name = "txtLots";
      this.txtLots.ReadOnly = true;
      this.txtLots.Size = new Size(101, 20);
      this.txtLots.TabIndex = 48;
      this.txtLots.Visible = false;
      this.groupSymwiseRs.Controls.Add((Control) this.cmbSymbolwiseRs);
      this.groupSymwiseRs.Controls.Add((Control) this.label27);
      this.groupSymwiseRs.Controls.Add((Control) this.label30);
      this.groupSymwiseRs.Controls.Add((Control) this.txtIntraMrgn);
      this.groupSymwiseRs.Controls.Add((Control) this.label33);
      this.groupSymwiseRs.Controls.Add((Control) this.txtDelvMrgn);
      this.groupSymwiseRs.Location = new Point(8, 218);
      this.groupSymwiseRs.Name = "groupSymwiseRs";
      this.groupSymwiseRs.Size = new Size(203, 106);
      this.groupSymwiseRs.TabIndex = 77;
      this.groupSymwiseRs.TabStop = false;
      this.groupSymwiseRs.Text = "Symbolwise(Rs.)";
      this.groupSymwiseRs.Visible = false;
      this.cmbSymbolwiseRs.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSymbolwiseRs.FormattingEnabled = true;
      this.cmbSymbolwiseRs.Location = new Point(96, 21);
      this.cmbSymbolwiseRs.Name = "cmbSymbolwiseRs";
      this.cmbSymbolwiseRs.Size = new Size(101, 21);
      this.cmbSymbolwiseRs.TabIndex = 72;
      this.cmbSymbolwiseRs.SelectedIndexChanged += new EventHandler(this.cmbSymbolwiseRs_SelectedIndexChanged);
      this.label27.AutoSize = true;
      this.label27.ForeColor = Color.Black;
      this.label27.Location = new Point(6, 27);
      this.label27.Name = "label27";
      this.label27.Size = new Size(77, 13);
      this.label27.TabIndex = 53;
      this.label27.Text = "Select Symbol:";
      this.label27.Visible = false;
      this.label30.AutoSize = true;
      this.label30.ForeColor = Color.Black;
      this.label30.Location = new Point(6, 51);
      this.label30.Name = "label30";
      this.label30.Size = new Size(58, 13);
      this.label30.TabIndex = 47;
      this.label30.Text = "Intra Mrgn:";
      this.label30.Visible = false;
      this.txtIntraMrgn.BackColor = Color.WhiteSmoke;
      this.txtIntraMrgn.ForeColor = Color.Black;
      this.txtIntraMrgn.Location = new Point(96, 48);
      this.txtIntraMrgn.MaxLength = 3;
      this.txtIntraMrgn.Name = "txtIntraMrgn";
      this.txtIntraMrgn.ReadOnly = true;
      this.txtIntraMrgn.Size = new Size(101, 20);
      this.txtIntraMrgn.TabIndex = 48;
      this.txtIntraMrgn.Visible = false;
      this.label33.AutoSize = true;
      this.label33.ForeColor = Color.Black;
      this.label33.Location = new Point(6, 76);
      this.label33.Name = "label33";
      this.label33.Size = new Size(59, 13);
      this.label33.TabIndex = 50;
      this.label33.Text = "Delv Mrgn:";
      this.label33.Visible = false;
      this.txtDelvMrgn.BackColor = Color.WhiteSmoke;
      this.txtDelvMrgn.ForeColor = Color.Black;
      this.txtDelvMrgn.Location = new Point(96, 73);
      this.txtDelvMrgn.MaxLength = 3;
      this.txtDelvMrgn.Name = "txtDelvMrgn";
      this.txtDelvMrgn.ReadOnly = true;
      this.txtDelvMrgn.Size = new Size(101, 20);
      this.txtDelvMrgn.TabIndex = 52;
      this.txtDelvMrgn.Visible = false;
      this.groupLotwiseExchwise.Controls.Add((Control) this.label19);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label20);
      this.groupLotwiseExchwise.Controls.Add((Control) this.txtnsecurrLots);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label21);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label22);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label23);
      this.groupLotwiseExchwise.Controls.Add((Control) this.txtMcxlots);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label24);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label25);
      this.groupLotwiseExchwise.Controls.Add((Control) this.label26);
      this.groupLotwiseExchwise.Controls.Add((Control) this.txtncxlot);
      this.groupLotwiseExchwise.Controls.Add((Control) this.txtnselot);
      this.groupLotwiseExchwise.Location = new Point(10, 82);
      this.groupLotwiseExchwise.Name = "groupLotwiseExchwise";
      this.groupLotwiseExchwise.Size = new Size(203, 131);
      this.groupLotwiseExchwise.TabIndex = 76;
      this.groupLotwiseExchwise.TabStop = false;
      this.groupLotwiseExchwise.Text = "Lotwise : Exchwise";
      this.groupLotwiseExchwise.Visible = false;
      this.label19.AutoSize = true;
      this.label19.ForeColor = Color.Black;
      this.label19.Location = new Point(164, 94);
      this.label19.Name = "label19";
      this.label19.Size = new Size(33, 13);
      this.label19.TabIndex = 59;
      this.label19.Text = " Lots.";
      this.label19.Visible = false;
      this.label20.AutoSize = true;
      this.label20.ForeColor = Color.Black;
      this.label20.Location = new Point(6, 94);
      this.label20.Name = "label20";
      this.label20.Size = new Size(63, 13);
      this.label20.TabIndex = 57;
      this.label20.Text = "NSECURR:";
      this.label20.Visible = false;
      this.txtnsecurrLots.BackColor = Color.WhiteSmoke;
      this.txtnsecurrLots.ForeColor = Color.Black;
      this.txtnsecurrLots.Location = new Point(96, 91);
      this.txtnsecurrLots.MaxLength = 3;
      this.txtnsecurrLots.Name = "txtnsecurrLots";
      this.txtnsecurrLots.ReadOnly = true;
      this.txtnsecurrLots.Size = new Size(62, 20);
      this.txtnsecurrLots.TabIndex = 58;
      this.txtnsecurrLots.Visible = false;
      this.label21.AutoSize = true;
      this.label21.ForeColor = Color.Black;
      this.label21.Location = new Point(164, 45);
      this.label21.Name = "label21";
      this.label21.Size = new Size(33, 13);
      this.label21.TabIndex = 55;
      this.label21.Text = " Lots.";
      this.label21.Visible = false;
      this.label22.AutoSize = true;
      this.label22.ForeColor = Color.Black;
      this.label22.Location = new Point(6, 19);
      this.label22.Name = "label22";
      this.label22.Size = new Size(33, 13);
      this.label22.TabIndex = 47;
      this.label22.Text = "MCX:";
      this.label22.Visible = false;
      this.label23.AutoSize = true;
      this.label23.ForeColor = Color.Black;
      this.label23.Location = new Point(164, 70);
      this.label23.Name = "label23";
      this.label23.Size = new Size(33, 13);
      this.label23.TabIndex = 54;
      this.label23.Text = " Lots.";
      this.label23.Visible = false;
      this.txtMcxlots.BackColor = Color.WhiteSmoke;
      this.txtMcxlots.ForeColor = Color.Black;
      this.txtMcxlots.Location = new Point(96, 16);
      this.txtMcxlots.MaxLength = 3;
      this.txtMcxlots.Name = "txtMcxlots";
      this.txtMcxlots.ReadOnly = true;
      this.txtMcxlots.Size = new Size(62, 20);
      this.txtMcxlots.TabIndex = 48;
      this.txtMcxlots.Visible = false;
      this.label24.AutoSize = true;
      this.label24.ForeColor = Color.Black;
      this.label24.Location = new Point(164, 19);
      this.label24.Name = "label24";
      this.label24.Size = new Size(33, 13);
      this.label24.TabIndex = 53;
      this.label24.Text = " Lots.";
      this.label24.Visible = false;
      this.label25.AutoSize = true;
      this.label25.ForeColor = Color.Black;
      this.label25.Location = new Point(6, 44);
      this.label25.Name = "label25";
      this.label25.Size = new Size(53, 13);
      this.label25.TabIndex = 50;
      this.label25.Text = "NSEFUT:";
      this.label25.Visible = false;
      this.label26.AutoSize = true;
      this.label26.ForeColor = Color.Black;
      this.label26.Location = new Point(6, 69);
      this.label26.Name = "label26";
      this.label26.Size = new Size(47, 13);
      this.label26.TabIndex = 49;
      this.label26.Text = "NCDEX:";
      this.label26.Visible = false;
      this.txtncxlot.BackColor = Color.WhiteSmoke;
      this.txtncxlot.ForeColor = Color.Black;
      this.txtncxlot.Location = new Point(96, 66);
      this.txtncxlot.MaxLength = 3;
      this.txtncxlot.Name = "txtncxlot";
      this.txtncxlot.ReadOnly = true;
      this.txtncxlot.Size = new Size(62, 20);
      this.txtncxlot.TabIndex = 51;
      this.txtncxlot.Visible = false;
      this.txtnselot.BackColor = Color.WhiteSmoke;
      this.txtnselot.ForeColor = Color.Black;
      this.txtnselot.Location = new Point(96, 41);
      this.txtnselot.MaxLength = 3;
      this.txtnselot.Name = "txtnselot";
      this.txtnselot.ReadOnly = true;
      this.txtnselot.Size = new Size(62, 20);
      this.txtnselot.TabIndex = 52;
      this.txtnselot.Visible = false;
      this.txtMrgnType.BackColor = Color.WhiteSmoke;
      this.txtMrgnType.ForeColor = Color.Black;
      this.txtMrgnType.Location = new Point(87, 22);
      this.txtMrgnType.MaxLength = 12;
      this.txtMrgnType.Name = "txtMrgnType";
      this.txtMrgnType.ReadOnly = true;
      this.txtMrgnType.Size = new Size(125, 20);
      this.txtMrgnType.TabIndex = 74;
      this.label18.AutoSize = true;
      this.label18.ForeColor = Color.Black;
      this.label18.Location = new Point(6, 24);
      this.label18.Name = "label18";
      this.label18.Size = new Size(69, 13);
      this.label18.TabIndex = 75;
      this.label18.Text = "Margin Type:";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(712, 439);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.btnClose);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmAccountDetails);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Account Details";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupOffset.ResumeLayout(false);
      this.groupOffset.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.groupTurnoverBrkg.ResumeLayout(false);
      this.groupTurnoverBrkg.PerformLayout();
      this.groupSymbolBrkg.ResumeLayout(false);
      this.groupSymbolBrkg.PerformLayout();
      this.groupBox3.ResumeLayout(false);
      this.groupBox3.PerformLayout();
      this.groupLotwiseSymwise.ResumeLayout(false);
      this.groupLotwiseSymwise.PerformLayout();
      this.groupSymwiseRs.ResumeLayout(false);
      this.groupSymwiseRs.PerformLayout();
      this.groupLotwiseExchwise.ResumeLayout(false);
      this.groupLotwiseExchwise.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
