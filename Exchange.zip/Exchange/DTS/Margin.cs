﻿// Decompiled with JetBrains decompiler
// Type: DTS.Margin
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class Margin : Form
  {
    private string _client = string.Empty;
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private SqlConnection conn;
    public DateTime ExDate;
    public Decimal _objLTP;
    private GroupBox groupBox1;
    private GroupBox groupBox2;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private DataGridView dgvContractMargin;
    private Label label5;
    private Label label4;
    private Label label3;
    private Label label2;
    private Label label1;
    private TextBox txtDelvbrkg;
    private TextBox txtDelvMrgn;
    private TextBox txtIntrabrkg;
    private TextBox txtintramrgn;
    private TextBox txtSymbol;
    private CheckBox chkAll;
    private Label label6;
    private TextBox txtLots;
    private Label label7;
    private ComboBox cmbClientcode;
    private Button btnSave;
    private RadioButton rdoNseOpt;
    private TextBox txtBrkupqty;
    private Label label8;
    private DataGridViewTextBoxColumn ColSymbol;
    private DataGridViewTextBoxColumn colIntraMrgn;
    private DataGridViewTextBoxColumn colIntraBrkg;
    private DataGridViewTextBoxColumn coldelvmrgn;
    private DataGridViewTextBoxColumn coldelvbrkg;
    private DataGridViewTextBoxColumn colots;
    private DataGridViewTextBoxColumn coBrkupQty;
    private DataGridViewTextBoxColumn Lotsize;
    private DataGridViewTextBoxColumn LTP;
    private DataGridViewCheckBoxColumn colselect;

    public Margin(Dashboard dash, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = objconn;
      this.Icon = this.objdash.ico;
      this.findExch();
    }

    public void LoadMarginWindow()
    {
      if (this.objdash._lstAccounts.Count > 0)
      {
        this.cmbClientcode.Items.Clear();
        this.cmbClientcode.Items.Add((object) "Default");
        foreach (object lstAccount in this.objdash._lstAccounts)
          this.cmbClientcode.Items.Add(lstAccount);
        this.cmbClientcode.SelectedIndex = 0;
      }
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.rdoMcx.Visible = true;
            break;
          case 2:
            this.rdoNseFut.Visible = true;
            break;
          case 3:
            this.rdoncdex.Visible = true;
            break;
          case 4:
            this.rdoNsecurr.Visible = true;
            break;
          case 5:
            this.rdoNseOpt.Visible = true;
            break;
        }
      }
    }

    private void rdoMcx_CheckedChanged(object sender, EventArgs e)
    {
      this.DisplaySymbol(1);
    }

    private void DisplaySymbol(int exch)
    {
      this.dgvContractMargin.Rows.Clear();
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      SortedDictionary<string, Contracts> exchconctract = this.objdash._Exchconctracts[exch];
      List<string> stringList = new List<string>();
      foreach (KeyValuePair<string, Contracts> keyValuePair in exchconctract)
      {
        Contracts contracts = keyValuePair.Value;
        string key = keyValuePair.Key;
        key.Split(' ');
        if (key == contracts.SymDesp)
        {
          Feeds feed = this.objdash.getFeed(contracts.SymDesp);
          int count = this.dgvContractMargin.Rows.Count;
          if (!stringList.Contains(contracts.symbol))
          {
            stringList.Add(contracts.symbol);
            this.dgvContractMargin.Rows.Add();
            this.dgvContractMargin.Rows[count].Cells[0].Value = (object) contracts.symbol;
            this.dgvContractMargin.Rows[count].Cells[7].Value = (object) contracts.lotsize;
            this.dgvContractMargin.Rows[count].Cells[8].Value = (object) feed.ltp;
            this.dgvContractMargin.Rows[count].Cells[9].Value = (object) false;
          }
        }
      }
    }

    private void rdoNseFut_CheckedChanged(object sender, EventArgs e)
    {
      this.DisplaySymbol(2);
    }

    private void rdoncdex_CheckedChanged(object sender, EventArgs e)
    {
      this.DisplaySymbol(3);
    }

    private void rdoNsecurr_CheckedChanged(object sender, EventArgs e)
    {
      this.DisplaySymbol(4);
    }

    private void rdoMcx_MouseClick(object sender, MouseEventArgs e)
    {
      this.rdoMcx.Checked = true;
      this.DisplaySymbol(1);
    }

    private void rdoNseFut_MouseClick(object sender, MouseEventArgs e)
    {
      this.rdoNseFut.Checked = true;
      this.DisplaySymbol(2);
    }

    private void rdoncdex_MouseClick(object sender, MouseEventArgs e)
    {
      this.rdoncdex.Checked = true;
      this.DisplaySymbol(3);
    }

    private void rdoNsecurr_MouseClick(object sender, MouseEventArgs e)
    {
      this.rdoNsecurr.Checked = true;
      this.DisplaySymbol(4);
    }

    private void chkAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.dgvContractMargin.Rows.Count > 0)
      {
        if (this.chkAll.Checked)
        {
          for (int index = 0; index < this.dgvContractMargin.Rows.Count; ++index)
            this.dgvContractMargin.Rows[index].Cells[9].Value = (object) true;
        }
        else
        {
          for (int index = 0; index < this.dgvContractMargin.Rows.Count; ++index)
            this.dgvContractMargin.Rows[index].Cells[9].Value = (object) false;
        }
      }
      else
        this.objdash.DisplayMessage("No Contracts to Select", 2);
    }

    private void dgvContractMargin_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
      if (e.ColumnIndex != 9)
        return;
      this.dgvContractMargin.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = !this.dgvContractMargin.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.Equals((object) false) ? (object) false : (object) true;
    }

    private string getCLientcode()
    {
      string empty = string.Empty;
      return this.cmbClientcode.SelectedIndex != 0 && !(this.cmbClientcode.Text.ToUpper() == "DEFAULT") ? this.cmbClientcode.Text : this.objdash.objinfo.clientcode;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      string empty = string.Empty;
      if (this.txtintramrgn.Text == string.Empty)
        empty += "Enter Intra Margin or Enter 0 \n";
      if (this.txtIntrabrkg.Text == string.Empty)
        empty += "Enter Intra Brokerage or Enter 0 \n";
      if (this.txtDelvMrgn.Text == string.Empty)
        empty += "Enter Delv Margin or Enter 0 \n";
      if (this.txtDelvbrkg.Text == string.Empty)
        empty += "Enter Delv Brokerage or Enter 0 \n";
      if (this.txtLots.Text == string.Empty)
        empty += "Enter Lots or Enter 0 \n";
      if (this.txtLots.Text == string.Empty)
        empty += "Enter Lots or Enter 0 \n";
      if (this.txtBrkupqty.Text == string.Empty)
        empty += "Enter Breakup Lots/Qty or Enter 0 \n";
      if (this.cmbClientcode.Text == string.Empty)
        empty += "Select Clientcode \n";
      if (this.cmbClientcode.Text.Length > 0 && this.cmbClientcode.SelectedIndex > 0 && !this.objdash._lstAccounts.Contains(this.cmbClientcode.Text))
      {
        this.objdash.DisplayMessage("Client code does not exists.", 2);
        this.cmbClientcode.Text = string.Empty;
      }
      string clientcode = this.getCLientcode();
      if (empty == string.Empty)
      {
        this.conn = this.objdash.getConn();
        if (this.conn.State != ConnectionState.Open)
          return;
        for (int index = 0; index < this.dgvContractMargin.Rows.Count; ++index)
        {
          if (bool.Parse(this.dgvContractMargin.Rows[index].Cells[9].Value.ToString()))
          {
            string str = this.dgvContractMargin.Rows[index].Cells[0].Value.ToString();
            SymbolMargin objmrgn = new SymbolMargin();
            SqlCommand sqlCommand1 = new SqlCommand("SaveMargin", this.conn);
            sqlCommand1.CommandType = CommandType.StoredProcedure;
            using (SqlCommand sqlCommand2 = sqlCommand1)
            {
              sqlCommand2.Parameters.AddWithValue("@clientcode", (object) clientcode);
              objmrgn.clientcode = clientcode;
              sqlCommand2.Parameters.AddWithValue("@symbol", (object) str);
              objmrgn.symbol = str;
              sqlCommand2.Parameters.AddWithValue("@intramrgn", (object) this.txtintramrgn.Text);
              objmrgn.intramrgn = Convert.ToInt32(this.txtintramrgn.Text);
              sqlCommand2.Parameters.AddWithValue("@intrabrkg", (object) this.txtIntrabrkg.Text);
              objmrgn.intrabrkg = Convert.ToInt32(this.txtIntrabrkg.Text);
              sqlCommand2.Parameters.AddWithValue("@delvbrkg", (object) this.txtDelvbrkg.Text);
              objmrgn.delvbrkg = Convert.ToInt32(this.txtDelvbrkg.Text);
              sqlCommand2.Parameters.AddWithValue("@delvmrgn", (object) this.txtDelvMrgn.Text);
              objmrgn.delvmrgn = Convert.ToInt32(this.txtDelvMrgn.Text);
              sqlCommand2.Parameters.AddWithValue("@totlots", (object) this.txtLots.Text);
              objmrgn.totlots = Convert.ToInt32(this.txtLots.Text);
              sqlCommand2.Parameters.AddWithValue("@brkup", (object) this.txtBrkupqty.Text);
              objmrgn.brkupQty = Convert.ToInt32(this.txtBrkupqty.Text);
              if (sqlCommand2.ExecuteNonQuery() > 0)
              {
                this.objdash.ManageMargin(objmrgn);
                this.txtSymbol.Text = str;
                this.dgvContractMargin.Rows[index].Cells[1].Value = (object) objmrgn.intramrgn;
                this.dgvContractMargin.Rows[index].Cells[2].Value = (object) objmrgn.intrabrkg;
                this.dgvContractMargin.Rows[index].Cells[3].Value = (object) objmrgn.delvmrgn;
                this.dgvContractMargin.Rows[index].Cells[4].Value = (object) objmrgn.delvbrkg;
                this.dgvContractMargin.Rows[index].Cells[5].Value = (object) objmrgn.totlots;
                this.dgvContractMargin.Rows[index].Cells[6].Value = (object) objmrgn.brkupQty;
              }
            }
            Application.DoEvents();
            Thread.Sleep(50);
          }
        }
        this.objdash.DisplayMessage("Margin Stored Successfully", 1);
        this.ClearControls();
      }
      else
        this.objdash.DisplayMessage(empty + "These Fields are Mandatory", 2);
    }

    private void ClearControls()
    {
      this.txtSymbol.Text = string.Empty;
      this.txtintramrgn.Text = string.Empty;
      this.txtIntrabrkg.Text = string.Empty;
      this.txtDelvMrgn.Text = string.Empty;
      this.txtDelvbrkg.Text = string.Empty;
      this.txtLots.Text = string.Empty;
      this.chkAll.Checked = false;
      this.txtBrkupqty.Text = string.Empty;
    }

    private void cmbClientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      int index1 = 0;
      string clientcode = this.getCLientcode();
      this.dgvContractMargin.Rows.Clear();
      if (!this.objdash._ClientSymMrgn.ContainsKey(clientcode))
        return;
      Dictionary<string, SymbolMargin> dictionary = this.objdash._ClientSymMrgn[clientcode];
      if (this.rdoMcx.Checked)
        index1 = 1;
      if (this.rdoNseFut.Checked)
        index1 = 2;
      if (this.rdoncdex.Checked)
        index1 = 3;
      if (this.rdoNsecurr.Checked)
        index1 = 4;
      SortedDictionary<string, Contracts> exchconctract = this.objdash._Exchconctracts[index1];
      foreach (KeyValuePair<string, SymbolMargin> keyValuePair in dictionary)
      {
        SymbolMargin symbolMargin = keyValuePair.Value;
        this.dgvContractMargin.Rows.Add();
        int index2 = this.dgvContractMargin.Rows.Count - 1;
        this.dgvContractMargin.Rows[index2].Cells[0].Value = (object) symbolMargin.symbol;
        this.dgvContractMargin.Rows[index2].Cells[1].Value = (object) symbolMargin.intramrgn;
        this.dgvContractMargin.Rows[index2].Cells[2].Value = (object) symbolMargin.intrabrkg;
        this.dgvContractMargin.Rows[index2].Cells[3].Value = (object) symbolMargin.delvmrgn;
        this.dgvContractMargin.Rows[index2].Cells[4].Value = (object) symbolMargin.delvbrkg;
        this.dgvContractMargin.Rows[index2].Cells[5].Value = (object) symbolMargin.totlots;
        this.dgvContractMargin.Rows[index2].Cells[6].Value = (object) symbolMargin.brkupQty;
        this.dgvContractMargin.Rows[index2].Cells[9].Value = (object) false;
      }
      int index3 = 0;
      List<string> stringList = new List<string>();
      foreach (KeyValuePair<string, Contracts> keyValuePair in exchconctract)
      {
        string key = keyValuePair.Key;
        string[] strArray = key.Split(' ');
        if (key != null)
        {
          Contracts contracts = keyValuePair.Value;
          if (strArray[0] == contracts.symbol)
          {
            Feeds feed = this.objdash.getFeed(contracts.SymDesp);
            try
            {
              if (!stringList.Contains(contracts.symbol))
              {
                stringList.Add(contracts.symbol);
                SymbolMargin symbolMargin = dictionary[keyValuePair.Value.symbol];
                this.dgvContractMargin.Rows[index3].Cells[0].Value = (object) strArray[0];
                this.dgvContractMargin.Rows[index3].Cells[1].Value = (object) symbolMargin.intramrgn;
                this.dgvContractMargin.Rows[index3].Cells[2].Value = (object) symbolMargin.intrabrkg;
                this.dgvContractMargin.Rows[index3].Cells[3].Value = (object) symbolMargin.delvmrgn;
                this.dgvContractMargin.Rows[index3].Cells[4].Value = (object) symbolMargin.delvbrkg;
                this.dgvContractMargin.Rows[index3].Cells[5].Value = (object) symbolMargin.totlots;
                this.dgvContractMargin.Rows[index3].Cells[6].Value = (object) symbolMargin.brkupQty;
                this.dgvContractMargin.Rows[index3].Cells[7].Value = (object) contracts.lotsize;
                this.dgvContractMargin.Rows[index3].Cells[8].Value = (object) feed.ltp;
                this.dgvContractMargin.Rows[index3].Cells[9].Value = (object) false;
                ++index3;
              }
            }
            catch
            {
            }
          }
        }
      }
    }

    private void rdoNseOpt_Click(object sender, EventArgs e)
    {
      this.rdoNseOpt.Checked = true;
      this.DisplaySymbol(5);
    }

    private void dgvContractMargin_RowLeave(object sender, DataGridViewCellEventArgs e)
    {
      string clientcode = this.getCLientcode();
      if (!(this._client == clientcode))
        return;
      this.conn = this.objdash.getConn();
      int rowIndex = e.RowIndex;
      if (this.conn.State == ConnectionState.Open)
      {
        for (int index = 0; index < this.dgvContractMargin.Rows.Count; ++index)
        {
          if (rowIndex == index)
          {
            string str1 = this.dgvContractMargin.Rows[index].Cells[0].Value.ToString();
            if (this.dgvContractMargin.Rows[index].Cells[1].Value != null)
            {
              string str2 = this.dgvContractMargin.Rows[index].Cells[1].Value.ToString();
              string str3 = this.dgvContractMargin.Rows[index].Cells[2].Value.ToString();
              string str4 = this.dgvContractMargin.Rows[index].Cells[3].Value.ToString();
              string str5 = this.dgvContractMargin.Rows[index].Cells[4].Value.ToString();
              string str6 = this.dgvContractMargin.Rows[index].Cells[5].Value.ToString();
              string str7 = this.dgvContractMargin.Rows[index].Cells[6].Value.ToString();
              SymbolMargin objmrgn = new SymbolMargin();
              SqlCommand sqlCommand1 = new SqlCommand("SaveMargin", this.conn);
              sqlCommand1.CommandType = CommandType.StoredProcedure;
              using (SqlCommand sqlCommand2 = sqlCommand1)
              {
                sqlCommand2.Parameters.AddWithValue("@clientcode", (object) clientcode);
                objmrgn.clientcode = clientcode;
                this._client = objmrgn.clientcode;
                sqlCommand2.Parameters.AddWithValue("@symbol", (object) str1);
                objmrgn.symbol = str1;
                sqlCommand2.Parameters.AddWithValue("@intramrgn", (object) str2);
                objmrgn.intramrgn = Convert.ToInt32(str2);
                sqlCommand2.Parameters.AddWithValue("@intrabrkg", (object) str3);
                objmrgn.intrabrkg = Convert.ToInt32(str3);
                sqlCommand2.Parameters.AddWithValue("@delvbrkg", (object) str5);
                objmrgn.delvbrkg = Convert.ToInt32(str5);
                sqlCommand2.Parameters.AddWithValue("@delvmrgn", (object) str4);
                objmrgn.delvmrgn = Convert.ToInt32(str4);
                sqlCommand2.Parameters.AddWithValue("@totlots", (object) str6);
                objmrgn.totlots = Convert.ToInt32(str6);
                sqlCommand2.Parameters.AddWithValue("@brkup", (object) str7);
                objmrgn.brkupQty = Convert.ToInt32(str7);
                if (sqlCommand2.ExecuteNonQuery() > 0)
                {
                  this.objdash.ManageMargin(objmrgn);
                  this.txtSymbol.Text = this.dgvContractMargin.Rows[index].Cells[0].Value.ToString();
                  this.dgvContractMargin.Rows[index].Cells[1].Value = (object) objmrgn.intramrgn;
                  this.dgvContractMargin.Rows[index].Cells[2].Value = (object) objmrgn.intrabrkg;
                  this.dgvContractMargin.Rows[index].Cells[3].Value = (object) objmrgn.delvmrgn;
                  this.dgvContractMargin.Rows[index].Cells[4].Value = (object) objmrgn.delvbrkg;
                  this.dgvContractMargin.Rows[index].Cells[5].Value = (object) objmrgn.totlots;
                  this.dgvContractMargin.Rows[index].Cells[6].Value = (object) objmrgn.brkupQty;
                }
              }
            }
            Application.DoEvents();
            Thread.Sleep(50);
          }
        }
      }
    }

    private void dgvContractMargin_CellLeave(object sender, DataGridViewCellEventArgs e)
    {
    }

    private void dgvContractMargin_CellClick(object sender, DataGridViewCellEventArgs e)
    {
    }

    private void dgvContractMargin_RowEnter(object sender, DataGridViewCellEventArgs e)
    {
      int rowIndex = e.RowIndex;
      if (this.dgvContractMargin.Rows[rowIndex].Cells[0].Value != null)
        this.txtSymbol.Text = this.dgvContractMargin.Rows[rowIndex].Cells[0].Value.ToString();
      this._client = this.getCLientcode();
    }

    public void findExch()
    {
      string[] strArray = this.objdash.objinfo.exchange.Split(',');
      if (strArray[0] == "NSEFUT")
        this.rdoNseFut.Checked = true;
      if (strArray[0] == "MCX")
        this.rdoMcx.Checked = true;
      if (strArray[0] == "NSECURR")
        this.rdoNsecurr.Checked = true;
      if (!(strArray[0] == "NCDEX"))
        return;
      this.rdoncdex.Checked = true;
    }

    private void dgvContractMargin_CellValueChanged(object sender, DataGridViewCellEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.txtBrkupqty = new TextBox();
      this.label8 = new Label();
      this.btnSave = new Button();
      this.label7 = new Label();
      this.cmbClientcode = new ComboBox();
      this.label6 = new Label();
      this.txtLots = new TextBox();
      this.chkAll = new CheckBox();
      this.label5 = new Label();
      this.label4 = new Label();
      this.label3 = new Label();
      this.label2 = new Label();
      this.label1 = new Label();
      this.txtDelvbrkg = new TextBox();
      this.txtDelvMrgn = new TextBox();
      this.txtIntrabrkg = new TextBox();
      this.txtintramrgn = new TextBox();
      this.txtSymbol = new TextBox();
      this.dgvContractMargin = new DataGridView();
      this.groupBox2 = new GroupBox();
      this.rdoNseOpt = new RadioButton();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.ColSymbol = new DataGridViewTextBoxColumn();
      this.colIntraMrgn = new DataGridViewTextBoxColumn();
      this.colIntraBrkg = new DataGridViewTextBoxColumn();
      this.coldelvmrgn = new DataGridViewTextBoxColumn();
      this.coldelvbrkg = new DataGridViewTextBoxColumn();
      this.colots = new DataGridViewTextBoxColumn();
      this.coBrkupQty = new DataGridViewTextBoxColumn();
      this.Lotsize = new DataGridViewTextBoxColumn();
      this.LTP = new DataGridViewTextBoxColumn();
      this.colselect = new DataGridViewCheckBoxColumn();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgvContractMargin).BeginInit();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.txtBrkupqty);
      this.groupBox1.Controls.Add((Control) this.label8);
      this.groupBox1.Controls.Add((Control) this.btnSave);
      this.groupBox1.Controls.Add((Control) this.label7);
      this.groupBox1.Controls.Add((Control) this.cmbClientcode);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.txtLots);
      this.groupBox1.Controls.Add((Control) this.chkAll);
      this.groupBox1.Controls.Add((Control) this.label5);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Controls.Add((Control) this.txtDelvbrkg);
      this.groupBox1.Controls.Add((Control) this.txtDelvMrgn);
      this.groupBox1.Controls.Add((Control) this.txtIntrabrkg);
      this.groupBox1.Controls.Add((Control) this.txtintramrgn);
      this.groupBox1.Controls.Add((Control) this.txtSymbol);
      this.groupBox1.Controls.Add((Control) this.dgvContractMargin);
      this.groupBox1.Controls.Add((Control) this.groupBox2);
      this.groupBox1.Location = new Point(10, 7);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(775, 476);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Margin Allocation";
      this.txtBrkupqty.Location = new Point(471, 95);
      this.txtBrkupqty.MaxLength = 8;
      this.txtBrkupqty.Name = "txtBrkupqty";
      this.txtBrkupqty.Size = new Size(59, 20);
      this.txtBrkupqty.TabIndex = 18;
      this.label8.AutoSize = true;
      this.label8.Location = new Point(471, 78);
      this.label8.Name = "label8";
      this.label8.Size = new Size(59, 13);
      this.label8.TabIndex = 17;
      this.label8.Text = "Brkup Qtys";
      this.btnSave.Location = new Point(474, 25);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(69, 33);
      this.btnSave.TabIndex = 7;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.label7.AutoSize = true;
      this.label7.Location = new Point(395, 16);
      this.label7.Name = "label7";
      this.label7.Size = new Size(61, 13);
      this.label7.TabIndex = 16;
      this.label7.Text = "Client Code";
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(398, 36);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(71, 21);
      this.cmbClientcode.TabIndex = 1;
      this.cmbClientcode.SelectedIndexChanged += new EventHandler(this.cmbClientcode_SelectedIndexChanged);
      this.label6.AutoSize = true;
      this.label6.Location = new Point(394, 78);
      this.label6.Name = "label6";
      this.label6.Size = new Size(53, 13);
      this.label6.TabIndex = 14;
      this.label6.Text = "Lots/Qtys";
      this.txtLots.Location = new Point(397, 95);
      this.txtLots.MaxLength = 8;
      this.txtLots.Name = "txtLots";
      this.txtLots.Size = new Size(59, 20);
      this.txtLots.TabIndex = 6;
      this.chkAll.AutoSize = true;
      this.chkAll.Location = new Point(701, 96);
      this.chkAll.Name = "chkAll";
      this.chkAll.Size = new Size(37, 17);
      this.chkAll.TabIndex = 8;
      this.chkAll.Text = "All";
      this.chkAll.UseVisualStyleBackColor = true;
      this.chkAll.CheckedChanged += new EventHandler(this.chkAll_CheckedChanged);
      this.label5.AutoSize = true;
      this.label5.Location = new Point(318, 78);
      this.label5.Name = "label5";
      this.label5.Size = new Size(54, 13);
      this.label5.TabIndex = 11;
      this.label5.Text = "Delv Brkg";
      this.label4.AutoSize = true;
      this.label4.Location = new Point(242, 78);
      this.label4.Name = "label4";
      this.label4.Size = new Size(64, 13);
      this.label4.TabIndex = 10;
      this.label4.Text = "Delv Margin";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(166, 78);
      this.label3.Name = "label3";
      this.label3.Size = new Size(53, 13);
      this.label3.TabIndex = 9;
      this.label3.Text = "Intra Brkg";
      this.label2.AutoSize = true;
      this.label2.Location = new Point(90, 78);
      this.label2.Name = "label2";
      this.label2.Size = new Size(63, 13);
      this.label2.TabIndex = 8;
      this.label2.Text = "Intra Margin";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(13, 78);
      this.label1.Name = "label1";
      this.label1.Size = new Size(41, 13);
      this.label1.TabIndex = 7;
      this.label1.Text = "Symbol";
      this.txtDelvbrkg.Location = new Point(321, 94);
      this.txtDelvbrkg.MaxLength = 8;
      this.txtDelvbrkg.Name = "txtDelvbrkg";
      this.txtDelvbrkg.Size = new Size(66, 20);
      this.txtDelvbrkg.TabIndex = 5;
      this.txtDelvMrgn.Location = new Point(245, 94);
      this.txtDelvMrgn.MaxLength = 8;
      this.txtDelvMrgn.Name = "txtDelvMrgn";
      this.txtDelvMrgn.Size = new Size(66, 20);
      this.txtDelvMrgn.TabIndex = 4;
      this.txtIntrabrkg.Location = new Point(169, 94);
      this.txtIntrabrkg.MaxLength = 8;
      this.txtIntrabrkg.Name = "txtIntrabrkg";
      this.txtIntrabrkg.Size = new Size(66, 20);
      this.txtIntrabrkg.TabIndex = 3;
      this.txtintramrgn.Location = new Point(93, 94);
      this.txtintramrgn.MaxLength = 8;
      this.txtintramrgn.Name = "txtintramrgn";
      this.txtintramrgn.Size = new Size(66, 20);
      this.txtintramrgn.TabIndex = 2;
      this.txtSymbol.Location = new Point(8, 94);
      this.txtSymbol.Name = "txtSymbol";
      this.txtSymbol.ReadOnly = true;
      this.txtSymbol.Size = new Size(75, 20);
      this.txtSymbol.TabIndex = 9;
      this.dgvContractMargin.AllowUserToAddRows = false;
      this.dgvContractMargin.AllowUserToDeleteRows = false;
      this.dgvContractMargin.AllowUserToOrderColumns = true;
      this.dgvContractMargin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvContractMargin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvContractMargin.Columns.AddRange((DataGridViewColumn) this.ColSymbol, (DataGridViewColumn) this.colIntraMrgn, (DataGridViewColumn) this.colIntraBrkg, (DataGridViewColumn) this.coldelvmrgn, (DataGridViewColumn) this.coldelvbrkg, (DataGridViewColumn) this.colots, (DataGridViewColumn) this.coBrkupQty, (DataGridViewColumn) this.Lotsize, (DataGridViewColumn) this.LTP, (DataGridViewColumn) this.colselect);
      this.dgvContractMargin.Location = new Point(7, 120);
      this.dgvContractMargin.Name = "dgvContractMargin";
      this.dgvContractMargin.RowHeadersVisible = false;
      this.dgvContractMargin.Size = new Size(762, 347);
      this.dgvContractMargin.TabIndex = 1;
      this.dgvContractMargin.CellClick += new DataGridViewCellEventHandler(this.dgvContractMargin_CellClick);
      this.dgvContractMargin.CellLeave += new DataGridViewCellEventHandler(this.dgvContractMargin_CellLeave);
      this.dgvContractMargin.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgvContractMargin_CellMouseClick);
      this.dgvContractMargin.CellValueChanged += new DataGridViewCellEventHandler(this.dgvContractMargin_CellValueChanged);
      this.dgvContractMargin.RowEnter += new DataGridViewCellEventHandler(this.dgvContractMargin_RowEnter);
      this.dgvContractMargin.RowLeave += new DataGridViewCellEventHandler(this.dgvContractMargin_RowLeave);
      this.groupBox2.Controls.Add((Control) this.rdoNseOpt);
      this.groupBox2.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox2.Controls.Add((Control) this.rdoncdex);
      this.groupBox2.Controls.Add((Control) this.rdoNseFut);
      this.groupBox2.Controls.Add((Control) this.rdoMcx);
      this.groupBox2.Location = new Point(6, 18);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(381, 40);
      this.groupBox2.TabIndex = 0;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Exchange";
      this.rdoNseOpt.AutoSize = true;
      this.rdoNseOpt.Location = new Point(310, 19);
      this.rdoNseOpt.Name = "rdoNseOpt";
      this.rdoNseOpt.Size = new Size(69, 17);
      this.rdoNseOpt.TabIndex = 4;
      this.rdoNseOpt.Text = "NSEOPT";
      this.rdoNseOpt.UseVisualStyleBackColor = true;
      this.rdoNseOpt.Visible = false;
      this.rdoNseOpt.Click += new EventHandler(this.rdoNseOpt_Click);
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(220, 19);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 3;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNsecurr.CheckedChanged += new EventHandler(this.rdoNsecurr_CheckedChanged);
      this.rdoNsecurr.MouseClick += new MouseEventHandler(this.rdoNsecurr_MouseClick);
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(146, 19);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 2;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoncdex.Visible = false;
      this.rdoncdex.CheckedChanged += new EventHandler(this.rdoncdex_CheckedChanged);
      this.rdoncdex.MouseClick += new MouseEventHandler(this.rdoncdex_MouseClick);
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(66, 19);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 1;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoNseFut.CheckedChanged += new EventHandler(this.rdoNseFut_CheckedChanged);
      this.rdoNseFut.MouseClick += new MouseEventHandler(this.rdoNseFut_MouseClick);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(6, 19);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 0;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.rdoMcx.CheckedChanged += new EventHandler(this.rdoMcx_CheckedChanged);
      this.rdoMcx.MouseClick += new MouseEventHandler(this.rdoMcx_MouseClick);
      this.ColSymbol.HeaderText = "Symbol";
      this.ColSymbol.Name = "ColSymbol";
      this.ColSymbol.ReadOnly = true;
      this.colIntraMrgn.HeaderText = "IntraMargin";
      this.colIntraMrgn.Name = "colIntraMrgn";
      this.colIntraBrkg.HeaderText = "IntraBrkg";
      this.colIntraBrkg.Name = "colIntraBrkg";
      this.coldelvmrgn.HeaderText = "DelvMargin";
      this.coldelvmrgn.Name = "coldelvmrgn";
      this.coldelvbrkg.HeaderText = "DelvBrkg";
      this.coldelvbrkg.Name = "coldelvbrkg";
      this.colots.HeaderText = "Lots/Qtys";
      this.colots.Name = "colots";
      this.coBrkupQty.HeaderText = "Brkup Qtys";
      this.coBrkupQty.Name = "coBrkupQty";
      this.Lotsize.HeaderText = "Lotsize";
      this.Lotsize.Name = "Lotsize";
      this.Lotsize.ReadOnly = true;
      this.LTP.HeaderText = "LTP";
      this.LTP.Name = "LTP";
      this.LTP.ReadOnly = true;
      this.colselect.HeaderText = "Select";
      this.colselect.Name = "colselect";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(792, 491);
      this.Controls.Add((Control) this.groupBox1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (Margin);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Symbolwise Margin";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgvContractMargin).EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
    }
  }
}
