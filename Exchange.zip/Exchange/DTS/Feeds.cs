﻿// Decompiled with JetBrains decompiler
// Type: DTS.Feeds
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public struct Feeds
  {
    public string symbol;
    public int bidqty;
    public Decimal bid;
    public Decimal ask;
    public int askqty;
    public Decimal ltp;
    public Decimal open;
    public Decimal high;
    public Decimal low;
    public Decimal close;
    public Decimal netchange;
    public Decimal perchange;
    public DateTime ltt;
    public Decimal OI;
    public double vol;
  }
}
