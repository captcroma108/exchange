﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmAccMapping
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmAccMapping : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private Label label1;
    private ComboBox cmbDealer;
    private Label label2;
    private Label label3;
    private Button btnAdd;
    private Button btnremove;
    private Button btnSave;
    private CheckedListBox lstClients;
    private CheckBox chkAll;
    private CheckBox chkMappdAll;
    private CheckedListBox lstMappedClients;

    public frmAccMapping(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      this.cmbDealer.Items.Clear();
      foreach (object lstDealer in this.objdash._lstDealers)
        this.cmbDealer.Items.Add(lstDealer);
      this.lstClients.Items.Clear();
      foreach (object lstAccount in this.objdash._lstAccounts)
        this.lstClients.Items.Add(lstAccount);
    }

    private void cmbDealer_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.lstMappedClients.Items.Clear();
      if (this.objdash._Userinformation.ContainsKey(this.cmbDealer.Text) && this.cmbDealer.SelectedIndex > -1)
      {
        Userinfo userinfo = this.objdash._Userinformation[this.cmbDealer.Text];
        if (userinfo.mappedclients != null)
        {
          string[] strArray = userinfo.mappedclients.Split(',');
          for (int index = 0; index < strArray.Length; ++index)
          {
            if (strArray[index] != string.Empty)
              this.lstMappedClients.Items.Add((object) strArray[index]);
          }
        }
      }
      this.chkAll.Checked = false;
      this.chkMappdAll.Checked = false;
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      if (this.lstClients.CheckedItems.Count <= 0)
        return;
      for (int index = 0; index < this.lstClients.Items.Count; ++index)
      {
        if (this.lstClients.GetItemCheckState(index) == CheckState.Checked && !this.lstMappedClients.Items.Contains((object) this.lstClients.Items[index].ToString()))
          this.lstMappedClients.Items.Add((object) this.lstClients.Items[index].ToString());
      }
    }

    private void btnremove_Click(object sender, EventArgs e)
    {
      if (this.chkMappdAll.Checked)
      {
        this.lstMappedClients.Items.Clear();
        this.chkMappdAll.Checked = false;
      }
      else
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
        {
          if (this.lstMappedClients.GetItemCheckState(index) == CheckState.Checked)
            this.lstMappedClients.Items.Remove((object) this.lstMappedClients.Items[index].ToString());
        }
      }
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      SqlConnection conn = this.objdash.getConn();
      if (conn.State == ConnectionState.Open)
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
        {
          using (SqlCommand sqlCommand = new SqlCommand(" insert into MappedIDInfo ([clientcode],[MappedDealerID]) values(@first,@last)", conn))
          {
            try
            {
              sqlCommand.Parameters.AddWithValue("@first", this.lstMappedClients.Items[index]);
              sqlCommand.Parameters.AddWithValue("@last", (object) this.cmbDealer.Text);
              sqlCommand.ExecuteNonQuery();
            }
            catch
            {
            }
            str += string.Format("{0},", this.lstMappedClients.Items[index]);
          }
        }
      }
      if (str.Length > 0)
        str = str.Substring(0, str.Length - 1);
      using (SqlCommand sqlCommand = new SqlCommand("Update Userinformation SET MappedClients = '" + str + "' where ClientCode = '" + this.cmbDealer.Text + "'", conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
          if (this.objdash._Userinformation.ContainsKey(this.cmbDealer.Text))
          {
            Userinfo userinfo = this.objdash._Userinformation[this.cmbDealer.Text];
            userinfo.mappedclients = str;
            this.objdash._Userinformation[this.cmbDealer.Text] = userinfo;
          }
          this.objdash.DisplayMessage("Clients mapped Successfully!!", 1);
        }
        catch
        {
          this.objdash.DisplayMessage("Unable to Map clients", 3);
        }
      }
    }

    private void chkAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkAll.Checked)
      {
        for (int index = 0; index < this.lstClients.Items.Count; ++index)
          this.lstClients.SetItemChecked(index, true);
      }
      else
      {
        for (int index = 0; index < this.lstClients.Items.Count; ++index)
          this.lstClients.SetItemChecked(index, false);
      }
    }

    private void chkMappdAll_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkMappdAll.Checked)
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          this.lstMappedClients.SetItemChecked(index, true);
      }
      else
      {
        for (int index = 0; index < this.lstMappedClients.Items.Count; ++index)
          this.lstMappedClients.SetItemChecked(index, false);
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.cmbDealer = new ComboBox();
      this.label2 = new Label();
      this.label3 = new Label();
      this.btnAdd = new Button();
      this.btnremove = new Button();
      this.btnSave = new Button();
      this.lstClients = new CheckedListBox();
      this.chkAll = new CheckBox();
      this.chkMappdAll = new CheckBox();
      this.lstMappedClients = new CheckedListBox();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(12, 19);
      this.label1.Name = "label1";
      this.label1.Size = new Size(74, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Select Dealer:";
      this.cmbDealer.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbDealer.FormattingEnabled = true;
      this.cmbDealer.Location = new Point(15, 35);
      this.cmbDealer.Name = "cmbDealer";
      this.cmbDealer.Size = new Size(120, 21);
      this.cmbDealer.TabIndex = 1;
      this.cmbDealer.SelectedIndexChanged += new EventHandler(this.cmbDealer_SelectedIndexChanged);
      this.label2.AutoSize = true;
      this.label2.Location = new Point(65, 73);
      this.label2.Name = "label2";
      this.label2.Size = new Size(70, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "No of Clients:";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(252, 73);
      this.label3.Name = "label3";
      this.label3.Size = new Size(83, 13);
      this.label3.TabIndex = 5;
      this.label3.Text = "Mapped Clients:";
      this.btnAdd.Location = new Point(151, 130);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new Size(43, 23);
      this.btnAdd.TabIndex = 6;
      this.btnAdd.Text = ">>";
      this.btnAdd.UseVisualStyleBackColor = true;
      this.btnAdd.Click += new EventHandler(this.btnAdd_Click);
      this.btnremove.Location = new Point(151, 201);
      this.btnremove.Name = "btnremove";
      this.btnremove.Size = new Size(43, 23);
      this.btnremove.TabIndex = 7;
      this.btnremove.Text = "<<";
      this.btnremove.UseVisualStyleBackColor = true;
      this.btnremove.Click += new EventHandler(this.btnremove_Click);
      this.btnSave.Location = new Point(135, 284);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(73, 23);
      this.btnSave.TabIndex = 8;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.lstClients.CheckOnClick = true;
      this.lstClients.FormattingEnabled = true;
      this.lstClients.Location = new Point(15, 89);
      this.lstClients.Name = "lstClients";
      this.lstClients.Size = new Size(120, 184);
      this.lstClients.Sorted = true;
      this.lstClients.TabIndex = 9;
      this.chkAll.AutoSize = true;
      this.chkAll.Location = new Point(18, 71);
      this.chkAll.Name = "chkAll";
      this.chkAll.Size = new Size(45, 17);
      this.chkAll.TabIndex = 10;
      this.chkAll.Text = "ALL";
      this.chkAll.UseVisualStyleBackColor = true;
      this.chkAll.CheckedChanged += new EventHandler(this.chkAll_CheckedChanged);
      this.chkMappdAll.AutoSize = true;
      this.chkMappdAll.Location = new Point(209, 72);
      this.chkMappdAll.Name = "chkMappdAll";
      this.chkMappdAll.Size = new Size(45, 17);
      this.chkMappdAll.TabIndex = 11;
      this.chkMappdAll.Text = "ALL";
      this.chkMappdAll.UseVisualStyleBackColor = true;
      this.chkMappdAll.CheckedChanged += new EventHandler(this.chkMappdAll_CheckedChanged);
      this.lstMappedClients.CheckOnClick = true;
      this.lstMappedClients.FormattingEnabled = true;
      this.lstMappedClients.Location = new Point(207, 89);
      this.lstMappedClients.Name = "lstMappedClients";
      this.lstMappedClients.Size = new Size(120, 184);
      this.lstMappedClients.Sorted = true;
      this.lstMappedClients.TabIndex = 12;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(339, 319);
      this.Controls.Add((Control) this.lstMappedClients);
      this.Controls.Add((Control) this.chkMappdAll);
      this.Controls.Add((Control) this.chkAll);
      this.Controls.Add((Control) this.lstClients);
      this.Controls.Add((Control) this.btnSave);
      this.Controls.Add((Control) this.btnremove);
      this.Controls.Add((Control) this.btnAdd);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.cmbDealer);
      this.Controls.Add((Control) this.label1);
      this.MaximizeBox = false;
      this.Name = nameof (frmAccMapping);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Account Mapping";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
