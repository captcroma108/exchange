﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmTradeHistory
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmTradeHistory : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    public DataGridView dgvTradeHistory;
    private GroupBox groupBox1;
    private DateTimePicker Todate;
    private DateTimePicker Fromdate;
    private Label label2;
    private Label label1;
    private Button btnView;
    private Button btnExport;
    private ComboBox cmbClientcode;
    private Label label3;
    private DataGridViewTextBoxColumn Clientcode;
    private DataGridViewTextBoxColumn Exch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn ColExpiry;
    private DataGridViewTextBoxColumn Productype;
    private DataGridViewTextBoxColumn ColexeType;
    private DataGridViewTextBoxColumn Buysell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn Price;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn UserRemarks;
    private DataGridViewTextBoxColumn TradedBy;
    private DataGridViewTextBoxColumn Orderno;

    public frmTradeHistory(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
    }

    public void Loadwindow()
    {
      this.dgvTradeHistory.Rows.Clear();
      if (this.objmain.objinfo.usertype == 3)
      {
        this.label3.Visible = true;
        this.cmbClientcode.Items.Clear();
        foreach (object lstAccount in this.objmain._lstAccounts)
          this.cmbClientcode.Items.Add(lstAccount);
        if (this.cmbClientcode.Items.Count > 0)
          this.cmbClientcode.SelectedIndex = 0;
        this.cmbClientcode.Visible = true;
      }
      else
      {
        this.label3.Visible = false;
        this.cmbClientcode.Visible = false;
      }
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      this.conn = this.objmain.getConn();
      string str = this.objmain.objinfo.clientcode;
      if (this.objmain.objinfo.usertype == 3)
        str = this.cmbClientcode.Text;
      if (this.conn.State != ConnectionState.Open || str.Length <= 0)
        return;
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("select Clientcode,case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type],ExecType, case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo from Orders_History where  Clientcode = '{0}' and OrdStatus in (1,4,5,6)  and CreateOn BETWEEN '{1}' and '{2}' and Validity = 1 and IsMaintenance = 0 Order by LastModified", (object) str, (object) this.Fromdate.Value.ToString("yyyy-MM-dd 09:00:00"), (object) this.Todate.Value.ToString("yyyy-MM-dd 23:55:00")), this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            int index = this.dgvTradeHistory.Rows.Add();
            if (!sqlDataReader.IsDBNull(0))
              this.dgvTradeHistory.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(0);
            if (!sqlDataReader.IsDBNull(1))
              this.dgvTradeHistory.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
            {
              string[] strArray = sqlDataReader.GetString(2).Split(' ');
              this.dgvTradeHistory.Rows[index].Cells[2].Value = (object) strArray[0];
              this.dgvTradeHistory.Rows[index].Cells[3].Value = (object) strArray[1];
            }
            if (!sqlDataReader.IsDBNull(3))
              this.dgvTradeHistory.Rows[index].Cells[4].Value = (object) sqlDataReader.GetString(3);
            if (!sqlDataReader.IsDBNull(4))
              this.dgvTradeHistory.Rows[index].Cells[5].Value = sqlDataReader.GetInt32(4) != 1 ? (object) "MKT" : (object) "LIMIT";
            if (!sqlDataReader.IsDBNull(5))
              this.dgvTradeHistory.Rows[index].Cells[6].Value = (object) sqlDataReader.GetString(5);
            if (!sqlDataReader.IsDBNull(6))
              this.dgvTradeHistory.Rows[index].Cells[7].Value = (object) sqlDataReader.GetInt32(6);
            if (!sqlDataReader.IsDBNull(7))
              this.dgvTradeHistory.Rows[index].Cells[8].Value = (object) sqlDataReader.GetValue(7).ToString();
            if (!sqlDataReader.IsDBNull(8))
              this.dgvTradeHistory.Rows[index].Cells[9].Value = (object) sqlDataReader.GetString(8);
            if (!sqlDataReader.IsDBNull(9))
              this.dgvTradeHistory.Rows[index].Cells[10].Value = (object) Convert.ToDateTime(sqlDataReader.GetValue(9)).ToString("yyyy-MM-dd HH:mm:ss");
            if (!sqlDataReader.IsDBNull(10))
              this.dgvTradeHistory.Rows[index].Cells[11].Value = (object) sqlDataReader.GetString(10);
            if (!sqlDataReader.IsDBNull(11))
              this.dgvTradeHistory.Rows[index].Cells[12].Value = (object) sqlDataReader.GetString(11);
            if (!sqlDataReader.IsDBNull(12))
              this.dgvTradeHistory.Rows[index].Cells[13].Value = (object) sqlDataReader.GetValue(12).ToString();
            if (sqlDataReader.GetString(5) == "BUY")
              this.dgvTradeHistory.Rows[index].DefaultCellStyle.BackColor = Color.LightBlue;
            else
              this.dgvTradeHistory.Rows[index].DefaultCellStyle.BackColor = Color.Pink;
          }
        }
      }
    }

    private void btnExport_Click(object sender, EventArgs e)
    {
      if (this.dgvTradeHistory.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvTradeHistory, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      this.dgvTradeHistory = new DataGridView();
      this.groupBox1 = new GroupBox();
      this.Todate = new DateTimePicker();
      this.Fromdate = new DateTimePicker();
      this.label2 = new Label();
      this.label1 = new Label();
      this.btnView = new Button();
      this.btnExport = new Button();
      this.cmbClientcode = new ComboBox();
      this.label3 = new Label();
      this.Clientcode = new DataGridViewTextBoxColumn();
      this.Exch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.ColExpiry = new DataGridViewTextBoxColumn();
      this.Productype = new DataGridViewTextBoxColumn();
      this.ColexeType = new DataGridViewTextBoxColumn();
      this.Buysell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.Price = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      this.UserRemarks = new DataGridViewTextBoxColumn();
      this.TradedBy = new DataGridViewTextBoxColumn();
      this.Orderno = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvTradeHistory).BeginInit();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      this.dgvTradeHistory.AllowUserToAddRows = false;
      this.dgvTradeHistory.AllowUserToDeleteRows = false;
      this.dgvTradeHistory.AllowUserToOrderColumns = true;
      this.dgvTradeHistory.AllowUserToResizeRows = false;
      this.dgvTradeHistory.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvTradeHistory.BackgroundColor = Color.White;
      this.dgvTradeHistory.CellBorderStyle = DataGridViewCellBorderStyle.None;
      gridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle1.BackColor = SystemColors.Control;
      gridViewCellStyle1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle1.ForeColor = Color.Black;
      gridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle1.WrapMode = DataGridViewTriState.True;
      this.dgvTradeHistory.ColumnHeadersDefaultCellStyle = gridViewCellStyle1;
      this.dgvTradeHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvTradeHistory.Columns.AddRange((DataGridViewColumn) this.Clientcode, (DataGridViewColumn) this.Exch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.ColExpiry, (DataGridViewColumn) this.Productype, (DataGridViewColumn) this.ColexeType, (DataGridViewColumn) this.Buysell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.Price, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.Time, (DataGridViewColumn) this.UserRemarks, (DataGridViewColumn) this.TradedBy, (DataGridViewColumn) this.Orderno);
      gridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle2.BackColor = SystemColors.Window;
      gridViewCellStyle2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle2.ForeColor = Color.Black;
      gridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle2.WrapMode = DataGridViewTriState.False;
      this.dgvTradeHistory.DefaultCellStyle = gridViewCellStyle2;
      this.dgvTradeHistory.Location = new Point(0, 54);
      this.dgvTradeHistory.Name = "dgvTradeHistory";
      this.dgvTradeHistory.ReadOnly = true;
      this.dgvTradeHistory.RowHeadersVisible = false;
      this.dgvTradeHistory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvTradeHistory.Size = new Size(1028, 246);
      this.dgvTradeHistory.TabIndex = 4;
      this.groupBox1.Controls.Add((Control) this.Todate);
      this.groupBox1.Controls.Add((Control) this.Fromdate);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(1, 4);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(380, 44);
      this.groupBox1.TabIndex = 5;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Date";
      this.Todate.CustomFormat = "dd-MMM-yyyy";
      this.Todate.Format = DateTimePickerFormat.Custom;
      this.Todate.Location = new Point(259, 17);
      this.Todate.Name = "Todate";
      this.Todate.Size = new Size(110, 20);
      this.Todate.TabIndex = 3;
      this.Fromdate.CustomFormat = "dd-MMM-yyyy";
      this.Fromdate.Format = DateTimePickerFormat.Custom;
      this.Fromdate.Location = new Point(66, 16);
      this.Fromdate.Name = "Fromdate";
      this.Fromdate.Size = new Size(110, 20);
      this.Fromdate.TabIndex = 1;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(197, 20);
      this.label2.Name = "label2";
      this.label2.Size = new Size(49, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "To Date:";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(4, 20);
      this.label1.Name = "label1";
      this.label1.Size = new Size(59, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "From Date:";
      this.btnView.FlatStyle = FlatStyle.System;
      this.btnView.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnView.ForeColor = Color.Navy;
      this.btnView.Location = new Point(739, 12);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(109, 34);
      this.btnView.TabIndex = 66;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.btnExport.FlatStyle = FlatStyle.System;
      this.btnExport.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnExport.ForeColor = Color.Navy;
      this.btnExport.Location = new Point(924, 12);
      this.btnExport.Name = "btnExport";
      this.btnExport.Size = new Size(109, 34);
      this.btnExport.TabIndex = 65;
      this.btnExport.Text = "Export";
      this.btnExport.UseVisualStyleBackColor = true;
      this.btnExport.Click += new EventHandler(this.btnExport_Click);
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(399, 27);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(89, 21);
      this.cmbClientcode.Sorted = true;
      this.cmbClientcode.TabIndex = 68;
      this.cmbClientcode.Visible = false;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(398, 9);
      this.label3.Name = "label3";
      this.label3.Size = new Size(64, 13);
      this.label3.TabIndex = 67;
      this.label3.Text = "Client Code ";
      this.label3.Visible = false;
      this.Clientcode.HeaderText = "ClientCode";
      this.Clientcode.Name = "Clientcode";
      this.Clientcode.ReadOnly = true;
      this.Clientcode.Width = 90;
      this.Exch.HeaderText = "Exchange";
      this.Exch.Name = "Exch";
      this.Exch.ReadOnly = true;
      this.Exch.Width = 80;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.ColExpiry.HeaderText = "Expiry";
      this.ColExpiry.Name = "ColExpiry";
      this.ColExpiry.ReadOnly = true;
      this.ColExpiry.Width = 80;
      this.Productype.HeaderText = "ProductType";
      this.Productype.Name = "Productype";
      this.Productype.ReadOnly = true;
      this.Productype.Width = 60;
      this.ColexeType.HeaderText = "ExecType";
      this.ColexeType.Name = "ColexeType";
      this.ColexeType.ReadOnly = true;
      this.ColexeType.Width = 50;
      this.Buysell.HeaderText = "B/S";
      this.Buysell.Name = "Buysell";
      this.Buysell.ReadOnly = true;
      this.Buysell.Width = 40;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 50;
      this.Price.HeaderText = "Exec.Price";
      this.Price.Name = "Price";
      this.Price.ReadOnly = true;
      this.Price.Width = 60;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.Validity.Width = 80;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 70;
      this.UserRemarks.HeaderText = "UserRemarks";
      this.UserRemarks.Name = "UserRemarks";
      this.UserRemarks.ReadOnly = true;
      this.UserRemarks.Width = 70;
      this.TradedBy.HeaderText = "TradedBy";
      this.TradedBy.Name = "TradedBy";
      this.TradedBy.ReadOnly = true;
      this.Orderno.HeaderText = "OrderNo";
      this.Orderno.Name = "Orderno";
      this.Orderno.ReadOnly = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1028, 300);
      this.Controls.Add((Control) this.cmbClientcode);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.btnView);
      this.Controls.Add((Control) this.btnExport);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.dgvTradeHistory);
      this.Name = nameof (frmTradeHistory);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Trade History";
      ((ISupportInitialize) this.dgvTradeHistory).EndInit();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
