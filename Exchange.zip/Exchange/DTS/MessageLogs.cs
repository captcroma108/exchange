﻿// Decompiled with JetBrains decompiler
// Type: DTS.MessageLogs
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class MessageLogs : Form
  {
    public DateTime NPRComexStarttime = DateTime.Now;
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    private DataGridView dgvMsgLogs;
    private DataGridViewTextBoxColumn Time;
    private DataGridViewTextBoxColumn Message;

    public MessageLogs(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
      this.Icon = this.objmain.ico;
    }

    public void LoadMessageLogs()
    {
      this.dgvMsgLogs.Rows.Clear();
      DateTime serverTime = this.objmain.GetServerTime();
      int index = 0;
      string str = string.Empty;
      if (this.objmain.objinfo.usertype == 3)
        str = this.objmain.claccounts;
      else if (this.objmain.objinfo.usertype == 4)
        str = string.Format("'{0}'", (object) this.objmain.objinfo.clientcode);
      if (str == null || str == string.Empty || this.conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand(string.Format("select * from MessageLogs where LogTime > '{0}' and ClientCode in ({1})", (object) serverTime.ToString("yyyy-MM-dd 09:00:00"), (object) str), this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            DateTime now = DateTime.Now;
            this.dgvMsgLogs.Rows.Add();
            if (!sqlDataReader.IsDBNull(2))
            {
              this.dgvMsgLogs.Rows[index].Cells[1].Value = (object) sqlDataReader.GetString(2);
              if (!sqlDataReader.IsDBNull(3))
              {
                DateTime dateTime = Convert.ToDateTime(sqlDataReader.GetValue(3));
                this.dgvMsgLogs.Rows[index].Cells[0].Value = (object) string.Format("{0}:{1}:{2}", (object) dateTime.Hour, (object) dateTime.Minute, (object) dateTime.Second);
              }
              ++index;
            }
          }
        }
      }
    }

    private void dgvMsgLogs_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task1_Click));
      Point client = this.dgvMsgLogs.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvMsgLogs, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      if (this.dgvMsgLogs.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvMsgLogs, false);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvMsgLogs = new DataGridView();
      this.Time = new DataGridViewTextBoxColumn();
      this.Message = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvMsgLogs).BeginInit();
      this.SuspendLayout();
      this.dgvMsgLogs.AllowUserToAddRows = false;
      this.dgvMsgLogs.AllowUserToDeleteRows = false;
      this.dgvMsgLogs.AllowUserToOrderColumns = true;
      this.dgvMsgLogs.BackgroundColor = Color.White;
      this.dgvMsgLogs.CellBorderStyle = DataGridViewCellBorderStyle.None;
      this.dgvMsgLogs.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvMsgLogs.Columns.AddRange((DataGridViewColumn) this.Time, (DataGridViewColumn) this.Message);
      this.dgvMsgLogs.Dock = DockStyle.Fill;
      this.dgvMsgLogs.Location = new Point(0, 0);
      this.dgvMsgLogs.Name = "dgvMsgLogs";
      this.dgvMsgLogs.ReadOnly = true;
      this.dgvMsgLogs.RowHeadersVisible = false;
      this.dgvMsgLogs.Size = new Size(945, 290);
      this.dgvMsgLogs.TabIndex = 0;
      this.dgvMsgLogs.MouseClick += new MouseEventHandler(this.dgvMsgLogs_MouseClick);
      this.Time.HeaderText = "Log Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 80;
      this.Message.HeaderText = "Message";
      this.Message.Name = "Message";
      this.Message.ReadOnly = true;
      this.Message.Width = 850;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvMsgLogs);
      this.MaximizeBox = false;
      this.Name = nameof (MessageLogs);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Message Logs";
      ((ISupportInitialize) this.dgvMsgLogs).EndInit();
      this.ResumeLayout(false);
    }
  }
}
