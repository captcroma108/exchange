﻿// Decompiled with JetBrains decompiler
// Type: DTS.TradeSettings
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

namespace DTS
{
  public class TradeSettings
  {
    public string clientCode { get; set; }

    public int exch { get; set; }

    public string symbol { get; set; }

    public int closeAfterMins { get; set; }

    public double volumePercent { get; set; }
  }
}
