﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDAMargin
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmDAMargin : Form
  {
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private RadioButton rdoPayout;
    private RadioButton rdoPayin;
    private GroupBox groupBox2;
    private TextBox txtComments;
    private Label label4;
    private TextBox txtamount;
    private Label label3;
    private TextBox txtCode;
    private Label label1;
    private Button btnSubmit;
    private DataGridView dgvDAMargin;
    private DataGridViewTextBoxColumn ColDACode;
    private DataGridViewTextBoxColumn ColMargin;
    private Button btnrefresh;
    private Label label2;

    public frmDAMargin(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.Icon;
    }

    public void LoadMargin()
    {
      this.dgvDAMargin.Rows.Clear();
      using (SqlCommand sqlCommand = new SqlCommand("Select D.DACode,D.DACashMargin from DA_Funds D,Userinformation U where U.clientcode = D.DACode and U.Createdby = '" + this.objdash.objinfo.clientcode + "' order by DACode", this.objdash.getConn()))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
            {
              string str = sqlDataReader.GetString(0);
              int index = this.dgvDAMargin.Rows.Add();
              this.dgvDAMargin.Rows[index].Cells[0].Value = (object) str;
              this.dgvDAMargin.Rows[index].Cells[1].Value = sqlDataReader.GetValue(1);
            }
          }
        }
      }
    }

    private void btnSubmit_Click(object sender, EventArgs e)
    {
      SqlConnection conn = this.objdash.getConn();
      if (this.txtCode.Text == string.Empty)
        this.objdash.DisplayMessage("Select Dealer Admin code to process Payin/Payout", 2);
      else if (this.txtamount.Text == string.Empty)
      {
        this.objdash.DisplayMessage("Enter Amount ", 2);
      }
      else
      {
        Decimal result;
        if (!Decimal.TryParse(this.txtamount.Text, out result))
          this.objdash.DisplayMessage("Enter Valid Amount ", 2);
        else if (result < Decimal.Zero)
        {
          this.objdash.DisplayMessage("Amount should be greater than 0.", 2);
        }
        else
        {
          int num = 1;
          if (this.rdoPayout.Checked)
            num = 2;
          SqlCommand sqlCommand1 = new SqlCommand("DA_Payin_Payout", conn);
          sqlCommand1.CommandType = CommandType.StoredProcedure;
          using (SqlCommand sqlCommand2 = sqlCommand1)
          {
            sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.txtCode.Text.Trim());
            sqlCommand2.Parameters.AddWithValue("@amount", (object) this.txtamount.Text.Trim());
            sqlCommand2.Parameters.AddWithValue("@comments", (object) this.txtComments.Text.Trim());
            sqlCommand2.Parameters.AddWithValue("@payinout", (object) num);
            try
            {
              sqlCommand2.ExecuteNonQuery();
              this.LoadMargin();
              this.objdash.DisplayMessage("Payin/Payout processed Successfully!!", 1);
            }
            catch
            {
              this.objdash.DisplayMessage("Unable to process Payin/Payout", 3);
            }
          }
          this.ClearControls();
        }
      }
    }

    private void btnrefresh_Click(object sender, EventArgs e)
    {
      this.LoadMargin();
    }

    private void rdoPayin_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoPayin.Checked)
        this.label3.Text = "Payin Amount";
      else
        this.label3.Text = "Payout Amount";
    }

    private void dgvDAMargin_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1 || this.dgvDAMargin.Rows[e.RowIndex] == null)
        return;
      this.ClearControls();
      this.txtCode.Text = this.dgvDAMargin.Rows[e.RowIndex].Cells[0].Value.ToString();
    }

    private void ClearControls()
    {
      this.txtamount.Text = this.txtCode.Text = this.txtComments.Text = string.Empty;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoPayout = new RadioButton();
      this.rdoPayin = new RadioButton();
      this.groupBox2 = new GroupBox();
      this.btnSubmit = new Button();
      this.txtComments = new TextBox();
      this.label4 = new Label();
      this.txtamount = new TextBox();
      this.label3 = new Label();
      this.txtCode = new TextBox();
      this.label1 = new Label();
      this.dgvDAMargin = new DataGridView();
      this.ColDACode = new DataGridViewTextBoxColumn();
      this.ColMargin = new DataGridViewTextBoxColumn();
      this.btnrefresh = new Button();
      this.label2 = new Label();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((ISupportInitialize) this.dgvDAMargin).BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoPayout);
      this.groupBox1.Controls.Add((Control) this.rdoPayin);
      this.groupBox1.Location = new Point(6, 5);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(149, 51);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Payin/Payout";
      this.rdoPayout.AutoSize = true;
      this.rdoPayout.Location = new Point(81, 23);
      this.rdoPayout.Name = "rdoPayout";
      this.rdoPayout.Size = new Size(58, 17);
      this.rdoPayout.TabIndex = 1;
      this.rdoPayout.Text = "Payout";
      this.rdoPayout.UseVisualStyleBackColor = true;
      this.rdoPayin.AutoSize = true;
      this.rdoPayin.Checked = true;
      this.rdoPayin.Location = new Point(6, 23);
      this.rdoPayin.Name = "rdoPayin";
      this.rdoPayin.Size = new Size(51, 17);
      this.rdoPayin.TabIndex = 0;
      this.rdoPayin.TabStop = true;
      this.rdoPayin.Text = "Payin";
      this.rdoPayin.UseVisualStyleBackColor = true;
      this.rdoPayin.CheckedChanged += new EventHandler(this.rdoPayin_CheckedChanged);
      this.groupBox2.Controls.Add((Control) this.btnSubmit);
      this.groupBox2.Controls.Add((Control) this.txtComments);
      this.groupBox2.Controls.Add((Control) this.label4);
      this.groupBox2.Controls.Add((Control) this.txtamount);
      this.groupBox2.Controls.Add((Control) this.label3);
      this.groupBox2.Controls.Add((Control) this.txtCode);
      this.groupBox2.Controls.Add((Control) this.label1);
      this.groupBox2.Location = new Point(6, 59);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(366, 61);
      this.groupBox2.TabIndex = 2;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Enter Amount";
      this.btnSubmit.Location = new Point(299, 29);
      this.btnSubmit.Name = "btnSubmit";
      this.btnSubmit.Size = new Size(61, 23);
      this.btnSubmit.TabIndex = 7;
      this.btnSubmit.Text = "Submit";
      this.btnSubmit.UseVisualStyleBackColor = true;
      this.btnSubmit.Click += new EventHandler(this.btnSubmit_Click);
      this.txtComments.Location = new Point(201, 32);
      this.txtComments.Name = "txtComments";
      this.txtComments.Size = new Size(92, 20);
      this.txtComments.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(205, 16);
      this.label4.Name = "label4";
      this.label4.Size = new Size(56, 13);
      this.label4.TabIndex = 6;
      this.label4.Text = "Comments";
      this.txtamount.Location = new Point(103, 32);
      this.txtamount.MaxLength = 10;
      this.txtamount.Name = "txtamount";
      this.txtamount.Size = new Size(92, 20);
      this.txtamount.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(107, 16);
      this.label3.Name = "label3";
      this.label3.Size = new Size(72, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Payin Amount";
      this.txtCode.Enabled = false;
      this.txtCode.Location = new Point(6, 32);
      this.txtCode.Name = "txtCode";
      this.txtCode.ReadOnly = true;
      this.txtCode.Size = new Size(92, 20);
      this.txtCode.TabIndex = 0;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(10, 16);
      this.label1.Name = "label1";
      this.label1.Size = new Size(50, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "DA Code";
      this.dgvDAMargin.AllowUserToAddRows = false;
      this.dgvDAMargin.AllowUserToDeleteRows = false;
      this.dgvDAMargin.AllowUserToOrderColumns = true;
      this.dgvDAMargin.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvDAMargin.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvDAMargin.BackgroundColor = Color.White;
      this.dgvDAMargin.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvDAMargin.Columns.AddRange((DataGridViewColumn) this.ColDACode, (DataGridViewColumn) this.ColMargin);
      this.dgvDAMargin.Location = new Point(6, 141);
      this.dgvDAMargin.MultiSelect = false;
      this.dgvDAMargin.Name = "dgvDAMargin";
      this.dgvDAMargin.ReadOnly = true;
      this.dgvDAMargin.RowHeadersVisible = false;
      this.dgvDAMargin.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvDAMargin.Size = new Size(366, 282);
      this.dgvDAMargin.TabIndex = 3;
      this.dgvDAMargin.CellClick += new DataGridViewCellEventHandler(this.dgvDAMargin_CellClick);
      this.ColDACode.HeaderText = "DA_Code";
      this.ColDACode.Name = "ColDACode";
      this.ColDACode.ReadOnly = true;
      this.ColMargin.HeaderText = "Cash_Margin";
      this.ColMargin.Name = "ColMargin";
      this.ColMargin.ReadOnly = true;
      this.btnrefresh.Location = new Point(305, 30);
      this.btnrefresh.Name = "btnrefresh";
      this.btnrefresh.Size = new Size(61, 23);
      this.btnrefresh.TabIndex = 8;
      this.btnrefresh.Text = "Refresh";
      this.btnrefresh.UseVisualStyleBackColor = true;
      this.btnrefresh.Click += new EventHandler(this.btnrefresh_Click);
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = Color.Red;
      this.label2.Location = new Point(12, 125);
      this.label2.Name = "label2";
      this.label2.Size = new Size(157, 13);
      this.label2.TabIndex = 9;
      this.label2.Text = "*Click on the cell to select";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(378, 426);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.btnrefresh);
      this.Controls.Add((Control) this.dgvDAMargin);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmDAMargin);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Dealer Admin Margin Payin/Payout";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((ISupportInitialize) this.dgvDAMargin).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
