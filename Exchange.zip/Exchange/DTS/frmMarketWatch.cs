﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmMarketWatch
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmMarketWatch : Form
  {
    public Dictionary<string, int> _ColumnOnOff = new Dictionary<string, int>();
    public Dictionary<string, int> _SymbolRowind = new Dictionary<string, int>();
    public string aplhabets = "abcdefgijkmnopqrstwxyz";
    public string ALPBAETS = "ABCDEFGHJKLMNPQRSTWXYZ";
    public Dictionary<string, int> _InvisibleSym = new Dictionary<string, int>();
    public string sym = string.Empty;
    private IContainer components = (IContainer) null;
    public BuySellOrder objbuysell;
    public Dashboard objmain;
    public DateTime LUT;
    private bool iswait;
    private bool bidflag;
    private bool askflag;
    private Rectangle dragBoxFromMouseDown;
    private int rowIndexFromMouseDown;
    private int rowIndexOfItemUnderMouseToDrop;
    public Market_Watch_Settings objmwsettings;
    private ToolStrip toolStrip1;
    private ToolStripComboBox cmbExchange;
    private ToolStripComboBox cmbSymbol;
    private ToolStripButton btnAddsymbols;
    private ToolStripButton btnSaveportfolio;
    private ToolStripButton btnUploadPortfolio;
    public DataGridView dgvMarketwatch;
    private ToolStripComboBox cmbExpiry;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem marketWatchSettingsToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem clearMarketWatchToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripMenuItem gridToolStripMenuItem;
    private ToolStripMenuItem toolStripFittoSize;
    private ToolStripMenuItem saveAsDefaultToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripMenuItem addSymbolsPanelToolStripMenuItem;
    private DataGridViewTextBoxColumn ColExch;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Expiry;
    private DataGridViewTextBoxColumn StrikePrice;
    private DataGridViewTextBoxColumn OptType;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn bid;
    private DataGridViewTextBoxColumn ask;
    private DataGridViewTextBoxColumn AskQty;
    private DataGridViewTextBoxColumn LTP;
    private DataGridViewTextBoxColumn Open;
    private DataGridViewTextBoxColumn High;
    private DataGridViewTextBoxColumn Low;
    private DataGridViewTextBoxColumn Close;
    private DataGridViewTextBoxColumn Netchange;
    private DataGridViewTextBoxColumn Percenchange;
    private DataGridViewTextBoxColumn OI;
    private System.Windows.Forms.Timer timer1;

    public frmMarketWatch(Dashboard main)
    {
      this.InitializeComponent();
      this.iswait = false;
      this.objmain = main;
      new Thread(new ThreadStart(((ThreadStart) (() => this.RefreshRates())).Invoke)).Start();
      this.bidflag = true;
      this.askflag = false;
      this.Icon = this.objmain.ico;
      this.setwidth();
    }

    private void ShuffleSymbols()
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: method pointer
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      this._SymbolRowind = (Dictionary<string, int>) Enumerable.ToDictionary<KeyValuePair<string, int>, string, int>((IEnumerable<M0>) Enumerable.OrderBy<KeyValuePair<string, int>, int>((IEnumerable<M0>) this._SymbolRowind, (Func<M0, M1>) new Func<KeyValuePair<string, int>, int>((object) new frmMarketWatch.\u003C\u003Ec__DisplayClass12_0()
      {
        rand = new Random()
      }, __methodptr(\u003CShuffleSymbols\u003Eb__0))), (Func<M0, M1>) (frmMarketWatch.\u003C\u003Ec.\u003C\u003E9__12_1 ?? (frmMarketWatch.\u003C\u003Ec.\u003C\u003E9__12_1 = new Func<KeyValuePair<string, int>, string>((object) frmMarketWatch.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CShuffleSymbols\u003Eb__12_1)))), (Func<M0, M2>) (frmMarketWatch.\u003C\u003Ec.\u003C\u003E9__12_2 ?? (frmMarketWatch.\u003C\u003Ec.\u003C\u003E9__12_2 = new Func<KeyValuePair<string, int>, int>((object) frmMarketWatch.\u003C\u003Ec.\u003C\u003E9, __methodptr(\u003CShuffleSymbols\u003Eb__12_2)))));
    }

    private void RefreshRates()
    {
      while (true)
      {
        try
        {
          Dictionary<string, int> dictionary = new Dictionary<string, int>();
          foreach (KeyValuePair<string, int> keyValuePair in this._SymbolRowind)
          {
            string index = keyValuePair.Key;
            string key = keyValuePair.Key;
            if (this.objmain._Symconctracts.ContainsKey(index) && this.objmain._Symconctracts[index].symbol == "GOLDMM")
              index = index.Replace("GOLDMM", "GOLD");
            else if (this.objmain._Symconctracts.ContainsKey(index) && this.objmain._Symconctracts[index].symbol == "SILVERMM")
              index = index.Replace("SILVERMM", "SILVER");
            Feeds feed = this.objmain.getFeed(index);
            if (!this.iswait)
              this.UpdateGridValue(feed, key);
            Thread.Sleep(2);
          }
        }
        catch
        {
        }
        Thread.Sleep(100);
      }
    }

    private void ManageUpdates()
    {
      while (true)
      {
        for (int index1 = 0; index1 < this.dgvMarketwatch.Rows.Count; ++index1)
        {
          string[] strArray = this.dgvMarketwatch.Rows[index1].Cells[13].Value.ToString().Split(':');
          if (strArray.Length > 1 && (int) (new DateTime(this.LUT.Year, this.LUT.Month, this.LUT.Day, Convert.ToInt32(strArray[0]), Convert.ToInt32(strArray[1]), Convert.ToInt32(strArray[2])) - this.LUT).TotalSeconds > 50)
          {
            for (int index2 = 2; index2 < this.dgvMarketwatch.Columns.Count - 1; ++index2)
              this.dgvMarketwatch.Rows[index1].DefaultCellStyle.BackColor = Settings.Default.MWBackcolor;
          }
        }
        Thread.Sleep(60000);
      }
    }

    public void LoadMarketWatch()
    {
      this._ColumnOnOff = new Dictionary<string, int>();
      string mwColumnProfile = Settings.Default.MWColumnProfile;
      try
      {
        if (mwColumnProfile != string.Empty)
        {
          string[] strArray1 = mwColumnProfile.Split(',');
          if (this.dgvMarketwatch.Columns.Count == strArray1.Length)
          {
            for (int index1 = 0; index1 < strArray1.Length; ++index1)
            {
              string[] strArray2 = strArray1[index1].Split('_');
              string index2 = strArray2[0];
              int int32_1 = Convert.ToInt32(strArray2[1]);
              int int32_2 = Convert.ToInt32(strArray2[2]);
              if (index2 == "Exchange")
                index2 = "ColExch";
              if (index2 == "BidQty")
                index2 = "Qty";
              if (index2 == "Bid")
                index2 = "bid";
              if (index2 == "Ask")
                index2 = "ask";
              if (index2 == "Net Change")
                index2 = "Netchange";
              if (index2 == "% Change")
                index2 = "PercenChange";
              if (int32_2 == 1)
              {
                this.dgvMarketwatch.Columns[index2].DisplayIndex = int32_1;
              }
              else
              {
                this.dgvMarketwatch.Columns[index2].DisplayIndex = int32_1;
                this.dgvMarketwatch.Columns[index2].Visible = false;
              }
              switch (int32_2)
              {
                case 0:
                  this.dgvMarketwatch.Columns[int32_1].Visible = false;
                  if (!this._ColumnOnOff.ContainsKey(strArray2[0]))
                  {
                    this._ColumnOnOff.Add(strArray2[0], 0);
                    break;
                  }
                  break;
                case 1:
                  this.dgvMarketwatch.Columns[int32_1].Visible = true;
                  if (!this._ColumnOnOff.ContainsKey(strArray2[0]))
                  {
                    this._ColumnOnOff.Add(strArray2[0], 1);
                    break;
                  }
                  break;
              }
            }
          }
          else
          {
            for (int index = 0; index < this.dgvMarketwatch.Columns.Count; ++index)
            {
              if (!this._ColumnOnOff.ContainsKey(this.dgvMarketwatch.Columns[index].HeaderText))
              {
                if (this.dgvMarketwatch.Columns[index].Visible)
                  this._ColumnOnOff.Add(this.dgvMarketwatch.Columns[index].HeaderText, 1);
                else
                  this._ColumnOnOff.Add(this.dgvMarketwatch.Columns[index].HeaderText, 0);
              }
            }
          }
        }
        else
        {
          for (int index = 0; index < this.dgvMarketwatch.Columns.Count; ++index)
          {
            if (!this._ColumnOnOff.ContainsKey(this.dgvMarketwatch.Columns[index].HeaderText))
            {
              if (this.dgvMarketwatch.Columns[index].Visible)
                this._ColumnOnOff.Add(this.dgvMarketwatch.Columns[index].HeaderText, 1);
              else
                this._ColumnOnOff.Add(this.dgvMarketwatch.Columns[index].HeaderText, 0);
            }
          }
        }
      }
      catch
      {
      }
      if (this.objmain.objinfo.exchange.Length > 0)
      {
        string exchange = this.objmain.objinfo.exchange;
        char[] chArray = new char[1]{ ',' };
        foreach (object obj in exchange.Split(chArray))
          this.cmbExchange.Items.Add(obj);
      }
      Application.DoEvents();
      this.LoadDefaultPortfolio();
    }

    private void dgvMarketwatch_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      Point client = this.dgvMarketwatch.PointToClient(Control.MousePosition);
      this.contextMenuStrip1.Show((Control) this.dgvMarketwatch, client.X, client.Y);
    }

    private void dgvMarketwatch_MouseDown(object sender, MouseEventArgs e)
    {
      this.rowIndexFromMouseDown = this.dgvMarketwatch.HitTest(e.X, e.Y).RowIndex;
      if (this.rowIndexFromMouseDown != -1)
      {
        Size dragSize = SystemInformation.DragSize;
        this.dragBoxFromMouseDown = new Rectangle(new Point(e.X - dragSize.Width / 2, e.Y - dragSize.Height / 2), dragSize);
      }
      else
        this.dragBoxFromMouseDown = Rectangle.Empty;
    }

    private void dgvMarketwatch_MouseMove(object sender, MouseEventArgs e)
    {
      if ((e.Button & MouseButtons.Left) != MouseButtons.Left || (!(this.dragBoxFromMouseDown != Rectangle.Empty) || this.dragBoxFromMouseDown.Contains(e.X, e.Y)))
        return;
      this.dgvMarketwatch.DoDragDrop((object) this.dgvMarketwatch.Rows[this.rowIndexFromMouseDown], DragDropEffects.Move);
    }

    private void dgvMarketwatch_DragOver(object sender, DragEventArgs e)
    {
      e.Effect = DragDropEffects.Move;
    }

    private void dgvMarketwatch_DragDrop(object sender, DragEventArgs e)
    {
      Point client = this.dgvMarketwatch.PointToClient(new Point(e.X, e.Y));
      this.rowIndexOfItemUnderMouseToDrop = this.dgvMarketwatch.HitTest(client.X, client.Y).RowIndex;
      if (e.Effect != DragDropEffects.Move)
        return;
      DataGridViewRow data = e.Data.GetData(typeof (DataGridViewRow)) as DataGridViewRow;
      this.dgvMarketwatch.Rows.RemoveAt(this.rowIndexFromMouseDown);
      this.dgvMarketwatch.Rows.Insert(this.rowIndexOfItemUnderMouseToDrop, data);
      for (int index = 0; index < this.dgvMarketwatch.Rows.Count; ++index)
        this._SymbolRowind[this.dgvMarketwatch.Rows[index].Cells[1].Value.ToString() + " " + this.dgvMarketwatch.Rows[index].Cells[2].Value] = index;
    }

    private void Task5_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.dgvMarketwatch.Columns.Count; ++index)
        str = !this.dgvMarketwatch.Columns[index].Visible ? str + string.Format("{0}_{1}_{2},", (object) this.dgvMarketwatch.Columns[index].HeaderText, (object) index, (object) 0) : str + string.Format("{0}_{1}_{2},", (object) this.dgvMarketwatch.Columns[index].HeaderText, (object) index, (object) 1);
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.MWColumnProfile = str;
      Settings.Default.Save();
    }

    private void frmMarketWatch_Load(object sender, EventArgs e)
    {
      this.dgvMarketwatch.BackgroundColor = Settings.Default.MWBackcolor;
      this.dgvMarketwatch.ForeColor = Settings.Default.MWForecolor;
      this.dgvMarketwatch.Font = Settings.Default.MWFont;
    }

    private void cmbExchange_SelectedIndexChanged(object sender, EventArgs e)
    {
      int index = (int) Enum.Parse(typeof (Exch), this.cmbExchange.Text.ToString().ToUpper());
      this.cmbSymbol.Items.Clear();
      if (!this.objmain._Exchconctracts.ContainsKey(index))
        return;
      SortedDictionary<string, Contracts> exchconctract = this.objmain._Exchconctracts[index];
      this.cmbSymbol.Items.Add((object) "-- Symbol --");
      foreach (KeyValuePair<string, Contracts> keyValuePair in exchconctract)
      {
        if (this.objmain.ValidateContractStatus(keyValuePair.Value.SymDesp, 3, this.objmain.objinfo.clientcode, index))
          this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      }
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void btnAddsymbols_Click(object sender, EventArgs e)
    {
      if (this.cmbSymbol.SelectedIndex > 0 && this.cmbSymbol.Text != string.Empty)
        this.InsertSymbol(this.cmbSymbol.Text, this.cmbExchange.Text);
      this.dgvMarketwatch.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
      this.dgvMarketwatch.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
    }

    private void InsertSymbol(string symbol, string exch)
    {
      if (!this._SymbolRowind.ContainsKey(symbol))
      {
        int index1 = this.dgvMarketwatch.Rows.Add();
        string[] strArray = symbol.Split(' ');
        this.dgvMarketwatch.Rows[index1].Cells[0].Value = (object) exch;
        this.dgvMarketwatch.Rows[index1].Cells[1].Value = (object) strArray[0];
        this.dgvMarketwatch.Rows[index1].Cells[2].Value = (object) strArray[1];
        if (exch == Exch.NSEOPT.ToString())
        {
          this.dgvMarketwatch.Rows[index1].Cells[3].Value = (object) strArray[2];
          this.dgvMarketwatch.Rows[index1].Cells[4].Value = (object) strArray[3];
        }
        for (int index2 = 5; index2 < this.dgvMarketwatch.Columns.Count - 3; ++index2)
          this.dgvMarketwatch.Rows[index1].Cells[index2].Value = (object) "0";
        this.dgvMarketwatch.Rows[index1].DefaultCellStyle.BackColor = Settings.Default.MWBackcolor;
        this._SymbolRowind.Add(symbol, index1);
        if (this.objmain.SubscribedSymbols == string.Empty)
          this.objmain.SubscribedSymbols += string.Format("'{0}'", (object) symbol);
        else
          this.objmain.SubscribedSymbols += string.Format(",'{0}'", (object) symbol);
        Feeds feed = this.objmain.getFeed(symbol);
        string gridsymbol = symbol;
        if (this.objmain._Symconctracts.ContainsKey(symbol) && this.objmain._Symconctracts[symbol].symbol == "GOLDMM")
          symbol = symbol.Replace("GOLDMM", "GOLD");
        else if (this.objmain._Symconctracts.ContainsKey(symbol) && this.objmain._Symconctracts[symbol].symbol == "SILVERMM")
          symbol = symbol.Replace("SILVERMM", "SILVER");
        this.UpdateGridValue(feed, gridsymbol);
        this.ShuffleSymbols();
        this.objmain.SubcribeSymbol(symbol);
        this.objmain.SubsribeExchFeeds(exch);
      }
      else if (this._InvisibleSym.ContainsKey(symbol))
        this.dgvMarketwatch.Rows[this._InvisibleSym[symbol]].Visible = true;
    }

    public void UpdateGridValue(Feeds objfeeds, string gridsymbol)
    {
      if (objfeeds.symbol == null || !this._SymbolRowind.ContainsKey(gridsymbol))
        return;
      if (this.bidflag)
      {
        this.bidflag = false;
        this.askflag = true;
      }
      else
      {
        this.bidflag = true;
        this.askflag = false;
      }
      Thread.Sleep(1);
      Application.DoEvents();
      int rowcount = this._SymbolRowind[gridsymbol];
      Contracts objcon = this.objmain.GetContract(gridsymbol);
      this.Invoke((Delegate) (() =>
      {
        try
        {
          if (rowcount <= -1)
            return;
          if (objfeeds.bidqty != Convert.ToInt32(this.dgvMarketwatch.Rows[rowcount].Cells[5].Value))
          {
            if (objfeeds.bidqty > Convert.ToInt32(this.dgvMarketwatch.Rows[rowcount].Cells[5].Value))
            {
              this.dgvMarketwatch.Rows[rowcount].Cells[5].Style.BackColor = Settings.Default.MWUPcolor;
              this.dgvMarketwatch.Rows[rowcount].Cells[5].Value = (object) objfeeds.bidqty;
            }
            else
            {
              this.dgvMarketwatch.Rows[rowcount].Cells[5].Value = (object) objfeeds.bidqty;
              this.dgvMarketwatch.Rows[rowcount].Cells[5].Style.BackColor = Settings.Default.MWDOWNcolor;
            }
          }
          else if (this.bidflag)
            this.dgvMarketwatch.Rows[rowcount].Cells[5].Style.BackColor = Settings.Default.MWBackcolor;
          if (objfeeds.bid != Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[6].Value))
          {
            this.dgvMarketwatch.Rows[rowcount].Cells[6].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.bid, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.bid, (object) 4);
            this.dgvMarketwatch.Rows[rowcount].Cells[6].Style.BackColor = !(objfeeds.bid > Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[4].Value)) ? Settings.Default.MWDOWNcolor : Settings.Default.MWUPcolor;
          }
          else if (this.bidflag)
            this.dgvMarketwatch.Rows[rowcount].Cells[6].Style.BackColor = Settings.Default.MWBackcolor;
          if (objfeeds.ask != Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[7].Value))
          {
            this.dgvMarketwatch.Rows[rowcount].Cells[7].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.ask, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.ask, (object) 4);
            this.dgvMarketwatch.Rows[rowcount].Cells[7].Style.BackColor = !(objfeeds.ask > Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[5].Value)) ? Settings.Default.MWDOWNcolor : Settings.Default.MWUPcolor;
          }
          else if (this.askflag)
            this.dgvMarketwatch.Rows[rowcount].Cells[7].Style.BackColor = Settings.Default.MWBackcolor;
          if (objfeeds.askqty != Convert.ToInt32(this.dgvMarketwatch.Rows[rowcount].Cells[8].Value))
          {
            if (objfeeds.askqty > Convert.ToInt32(this.dgvMarketwatch.Rows[rowcount].Cells[8].Value))
            {
              this.dgvMarketwatch.Rows[rowcount].Cells[8].Style.BackColor = Settings.Default.MWUPcolor;
              this.dgvMarketwatch.Rows[rowcount].Cells[8].Value = (object) objfeeds.askqty;
            }
            else
            {
              this.dgvMarketwatch.Rows[rowcount].Cells[8].Value = (object) objfeeds.askqty;
              this.dgvMarketwatch.Rows[rowcount].Cells[8].Style.BackColor = Settings.Default.MWDOWNcolor;
            }
          }
          else if (this.askflag)
            this.dgvMarketwatch.Rows[rowcount].Cells[8].Style.BackColor = Settings.Default.MWBackcolor;
          if (objfeeds.ltp != Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[9].Value))
          {
            this.dgvMarketwatch.Rows[rowcount].Cells[9].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.ltp, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.ltp, (object) 4);
            this.dgvMarketwatch.Rows[rowcount].Cells[9].Style.BackColor = !(objfeeds.ltp > Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[7].Value)) ? Settings.Default.MWDOWNcolor : Settings.Default.MWUPcolor;
          }
          else
            this.dgvMarketwatch.Rows[rowcount].Cells[9].Style.BackColor = Settings.Default.MWBackcolor;
          this.dgvMarketwatch.Rows[rowcount].Cells[10].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.open, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.open, (object) 4);
          if (objfeeds.high != Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[11].Value))
          {
            this.dgvMarketwatch.Rows[rowcount].Cells[11].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.high, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.high, (object) 4);
            this.dgvMarketwatch.Rows[rowcount].Cells[11].Style.BackColor = !(objfeeds.high > Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[9].Value)) ? Settings.Default.MWDOWNcolor : Settings.Default.MWUPcolor;
          }
          else
            this.dgvMarketwatch.Rows[rowcount].Cells[11].Style.BackColor = Settings.Default.MWBackcolor;
          if (objfeeds.low != Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[12].Value))
          {
            this.dgvMarketwatch.Rows[rowcount].Cells[12].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.low, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.low, (object) 4);
            this.dgvMarketwatch.Rows[rowcount].Cells[12].Style.BackColor = !(objfeeds.low > Convert.ToDecimal(this.dgvMarketwatch.Rows[rowcount].Cells[10].Value)) ? Settings.Default.MWDOWNcolor : Settings.Default.MWUPcolor;
          }
          else
            this.dgvMarketwatch.Rows[rowcount].Cells[12].Style.BackColor = Settings.Default.MWBackcolor;
          this.dgvMarketwatch.Rows[rowcount].Cells[13].Value = objcon.exch != 4 ? (object) string.Format("{0:0.00}", (object) objfeeds.close, (object) 2) : (object) string.Format("{0:0.0000}", (object) objfeeds.close, (object) 4);
          this.dgvMarketwatch.Rows[rowcount].Cells[14].Value = (object) objfeeds.netchange;
          this.dgvMarketwatch.Rows[rowcount].Cells[15].Value = (object) objfeeds.perchange;
          this.dgvMarketwatch.Rows[rowcount].Cells[16].Value = (object) objfeeds.OI;
          this.dgvMarketwatch.Rows[rowcount].Cells[1].Style.BackColor = !(objfeeds.perchange < Decimal.Zero) ? Color.Blue : Color.Red;
        }
        catch
        {
        }
      }));
    }

    private void btnUploadPortfolio_Click(object sender, EventArgs e)
    {
      OpenFileDialog openFileDialog1 = new OpenFileDialog();
      openFileDialog1.CheckPathExists = true;
      openFileDialog1.InitialDirectory = Application.StartupPath + "\\Portfolio";
      openFileDialog1.Filter = "(*.EXT)|*.ext|All Files (*.*)|*.*";
      openFileDialog1.Title = "Browse XML file";
      using (OpenFileDialog openFileDialog2 = openFileDialog1)
      {
        if (openFileDialog2.ShowDialog() == DialogResult.Cancel)
          return;
        try
        {
          using (StreamReader streamReader = new StreamReader(openFileDialog2.FileName))
          {
            this.dgvMarketwatch.Rows.Clear();
            this._SymbolRowind.Clear();
            while (true)
            {
              string str = streamReader.ReadLine();
              if (str != null && str != " ")
              {
                string[] strArray = str.Split(',');
                if (!this._SymbolRowind.ContainsKey(strArray[1]) && this.objmain._Symconctracts.ContainsKey(strArray[1]))
                {
                  Contracts symconctract = this.objmain._Symconctracts[strArray[1]];
                  this.InsertSymbol(strArray[1], strArray[0]);
                }
              }
              else if (str == " ")
                this.dgvMarketwatch.Rows.Insert(this.dgvMarketwatch.Rows.Count, new DataGridViewRow());
              else
                break;
            }
          }
        }
        catch
        {
        }
      }
    }

    private void btnSaveportfolio_Click(object sender, EventArgs e)
    {
      if (this.dgvMarketwatch.Rows.Count <= 0)
        return;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.InitialDirectory = Application.StartupPath + "\\Portfolio";
      saveFileDialog1.Filter = "(*.EXT)|*.ext|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() == DialogResult.OK)
        {
          string fileName = saveFileDialog2.FileName;
          StreamWriter streamWriter;
          if (File.Exists(fileName))
          {
            new FileStream(fileName, FileMode.Truncate).Close();
            streamWriter = new StreamWriter(fileName);
          }
          else
            streamWriter = new StreamWriter(fileName);
          for (int index = 0; index < this.dgvMarketwatch.Rows.Count; ++index)
          {
            if (this.dgvMarketwatch.Rows[index].Visible)
            {
              DataGridViewRow row = this.dgvMarketwatch.Rows[index];
              if (this.dgvMarketwatch.Rows[row.Index].Cells[1].Value != null)
              {
                string str1 = this.dgvMarketwatch.Rows[row.Index].Cells[0].Value.ToString();
                string str2 = string.Format("{0} {1}", (object) this.dgvMarketwatch.Rows[row.Index].Cells[1].Value.ToString(), (object) this.dgvMarketwatch.Rows[row.Index].Cells[2].Value.ToString());
                if (str1 == Exch.NSEOPT.ToString())
                {
                  string str3 = this.dgvMarketwatch.Rows[row.Index].Cells[3].Value.ToString();
                  string str4 = this.dgvMarketwatch.Rows[row.Index].Cells[4].Value.ToString();
                  str2 += string.Format(" {0} {1}", (object) str3, (object) str4);
                }
                string str5 = string.Format("{0},{1}\n", (object) str1, (object) str2);
                streamWriter.Write(str5);
              }
              else
                streamWriter.Write(" \n");
            }
          }
          streamWriter.Flush();
          streamWriter.Close();
        }
      }
    }

    private void frmMarketWatch_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (!this.objmain._lstMktwatchObjs.Contains(this))
        return;
      this.objmain._lstMktwatchObjs.Remove(this);
    }

    private void dgvMarketwatch_KeyUp(object sender, KeyEventArgs e)
    {
      if (this.dgvMarketwatch.Rows.Count > 0)
      {
        DataGridView dataGridView = (DataGridView) sender;
        if (e.KeyCode == Keys.Delete)
        {
          if (dataGridView == null)
            return;
          try
          {
            DataGridViewRow currentRow = dataGridView.CurrentRow;
            int index = currentRow.Index;
            if (dataGridView.Rows[currentRow.Index].Cells[1].Value != null)
            {
              this.iswait = true;
              this.dgvMarketwatch.Rows.RemoveAt(index);
              this._SymbolRowind = new Dictionary<string, int>();
              foreach (DataGridViewRow row in (IEnumerable) this.dgvMarketwatch.Rows)
              {
                if (row.Cells[1].Value != null)
                {
                  string str1 = row.Cells[0].Value.ToString();
                  string str2 = row.Cells[1].Value.ToString();
                  string str3 = row.Cells[2].Value.ToString();
                  string key = string.Format("{0} {1}", (object) str2, (object) str3);
                  if (str1 == Exch.NSEOPT.ToString())
                  {
                    string str4 = dataGridView.Rows[currentRow.Index].Cells[3].Value.ToString();
                    string str5 = dataGridView.Rows[currentRow.Index].Cells[4].Value.ToString();
                    key += string.Format(" {0} {1}", (object) str4, (object) str5);
                  }
                  if (!(str2 == string.Empty) && !this._SymbolRowind.ContainsKey(key))
                    this._SymbolRowind.Add(key, row.Index);
                }
              }
              this.iswait = false;
            }
            else
            {
              this.iswait = true;
              this.dgvMarketwatch.Rows.RemoveAt(index);
              this._SymbolRowind = new Dictionary<string, int>();
              foreach (DataGridViewRow row in (IEnumerable) this.dgvMarketwatch.Rows)
              {
                if (row.Cells[1].Value != null)
                {
                  string str1 = row.Cells[1].Value.ToString();
                  string str2 = row.Cells[2].Value.ToString();
                  string key = string.Format("{0} {1}", (object) str1, (object) str2);
                  if (!(str1 == string.Empty) && !this._SymbolRowind.ContainsKey(key))
                    this._SymbolRowind.Add(key, row.Index);
                }
              }
              this.iswait = false;
            }
          }
          catch
          {
          }
          return;
        }
        if (e.KeyCode == Keys.F3)
        {
          if (this.dgvMarketwatch.Rows.Count > 0 && dataGridView != null)
          {
            DataGridViewRow currentRow = dataGridView.CurrentRow;
            int index = currentRow.Index;
            if (dataGridView.Rows[index].Cells[1].Value != null)
            {
              string str1 = dataGridView.Rows[currentRow.Index].Cells[0].Value.ToString();
              string symbol = string.Format("{0} {1}", (object) this.dgvMarketwatch.Rows[index].Cells[1].Value.ToString(), (object) this.dgvMarketwatch.Rows[index].Cells[2].Value.ToString());
              if (str1 == Exch.NSEOPT.ToString())
              {
                string str2 = dataGridView.Rows[currentRow.Index].Cells[3].Value.ToString();
                string str3 = dataGridView.Rows[currentRow.Index].Cells[4].Value.ToString();
                symbol += string.Format(" {0} {1}", (object) str2, (object) str3);
              }
              if (this.objmain.objordbook == null || this.objmain.objordbook.IsDisposed)
              {
                Dashboard objmain = this.objmain;
                Orderbook orderbook = new Orderbook(this.objmain);
                orderbook.MdiParent = (Form) this.objmain;
                objmain.objordbook = orderbook;
                this.objmain.objordbook.LoadSpecificSymbol(symbol);
                this.objmain.objordbook.Show();
              }
              else
              {
                this.objmain.objordbook.LoadSpecificSymbol(symbol);
                this.objmain.objordbook.MdiParent = (Form) this.objmain;
                this.objmain.objordbook.Show();
              }
            }
          }
        }
        else if (e.KeyCode == Keys.F8 && this.dgvMarketwatch.Rows.Count > 0 && dataGridView != null)
        {
          int index = dataGridView.CurrentRow.Index;
          if (dataGridView.Rows[index].Cells[1].Value != null)
          {
            string symbol = string.Format("{0} {1}", (object) this.dgvMarketwatch.Rows[index].Cells[1].Value.ToString(), (object) this.dgvMarketwatch.Rows[index].Cells[2].Value.ToString());
            if (this.objmain.objtrdbook == null || this.objmain.objtrdbook.IsDisposed)
            {
              Dashboard objmain = this.objmain;
              Tradebook tradebook = new Tradebook(this.objmain);
              tradebook.MdiParent = (Form) this.objmain;
              objmain.objtrdbook = tradebook;
              this.objmain.objtrdbook.LoadSpecficSymbol(symbol);
              this.objmain.objtrdbook.Show();
            }
            else
            {
              this.objmain.objtrdbook.LoadSpecficSymbol(symbol);
              this.objmain.objtrdbook.MdiParent = (Form) this.objmain;
              this.objmain.objtrdbook.Show();
            }
          }
        }
        if (this.objmain.objinfo.usertype == 3 | this.objmain.objinfo.usertype == 4)
        {
          if (e.KeyCode == Keys.F1 | e.KeyCode == Keys.Oemplus | e.KeyCode == Keys.Add)
          {
            if (dataGridView != null)
            {
              int index = dataGridView.CurrentRow.Index;
              if (dataGridView.Rows[index].Cells[1].Value != null)
              {
                string exch = this.dgvMarketwatch.Rows[index].Cells[0].Value.ToString();
                string symbol = string.Format("{0} {1}", (object) this.dgvMarketwatch.Rows[index].Cells[1].Value.ToString(), (object) this.dgvMarketwatch.Rows[index].Cells[2].Value.ToString());
                Decimal price = Convert.ToDecimal(this.dgvMarketwatch.Rows[index].Cells[7].Value);
                if (this.objbuysell == null || this.objbuysell.IsDisposed)
                {
                  BuySellOrder buySellOrder = new BuySellOrder(this.objmain);
                  buySellOrder.MdiParent = (Form) this.objmain;
                  this.objbuysell = buySellOrder;
                }
                this.objbuysell.LoadWindow(1, exch, symbol, price, false, 0, Decimal.Zero, 0, string.Empty, 0);
                this.objbuysell.Location = new Point(0, !(this.objmain.objinfo.usertype == 3 | this.objmain.objinfo.usertype == 4) ? this.objmain.Height - 330 : this.objmain.Height - 380);
                this.objbuysell.BringToFront();
                this.objbuysell.Show();
              }
            }
          }
          else if (e.KeyCode == Keys.F2 | e.KeyCode == Keys.OemMinus | e.KeyCode == Keys.Subtract && this.dgvMarketwatch.Rows.Count > 0 && dataGridView != null)
          {
            int index = dataGridView.CurrentRow.Index;
            if (dataGridView.Rows[index].Cells[1].Value != null)
            {
              string exch = this.dgvMarketwatch.Rows[index].Cells[0].Value.ToString();
              string symbol = string.Format("{0} {1}", (object) this.dgvMarketwatch.Rows[index].Cells[1].Value.ToString(), (object) this.dgvMarketwatch.Rows[index].Cells[2].Value.ToString());
              Decimal price = Convert.ToDecimal(this.dgvMarketwatch.Rows[index].Cells[6].Value);
              if (this.objbuysell == null || this.objbuysell.IsDisposed)
              {
                BuySellOrder buySellOrder = new BuySellOrder(this.objmain);
                buySellOrder.MdiParent = (Form) this.objmain;
                this.objbuysell = buySellOrder;
              }
              this.objbuysell.LoadWindow(2, exch, symbol, price, false, 0, Decimal.Zero, 0, string.Empty, 0);
              this.objbuysell.Location = new Point(0, !(this.objmain.objinfo.usertype == 3 | this.objmain.objinfo.usertype == 4) ? this.objmain.Height - 330 : this.objmain.Height - 380);
              this.objbuysell.BringToFront();
              this.objbuysell.Show();
            }
          }
        }
        if (e.KeyCode == Keys.Home)
        {
          this.dgvMarketwatch.Rows[0].Selected = true;
          this.dgvMarketwatch.FirstDisplayedScrollingRowIndex = 0;
        }
        else if (e.KeyCode == Keys.End)
        {
          this.dgvMarketwatch.Rows[this.dgvMarketwatch.Rows.Count - 1].Selected = true;
          this.dgvMarketwatch.FirstDisplayedScrollingRowIndex = this.dgvMarketwatch.Rows.Count - 1;
        }
      }
      if (e.KeyCode != Keys.Space)
        return;
      this.iswait = true;
      this.dgvMarketwatch.Rows.Insert(((DataGridView) sender).CurrentRow.Index, new DataGridViewRow());
      this._SymbolRowind = new Dictionary<string, int>();
      foreach (DataGridViewRow row in (IEnumerable) this.dgvMarketwatch.Rows)
      {
        if (row.Cells[1].Value != null)
        {
          string str1 = row.Cells[1].Value.ToString();
          string str2 = row.Cells[2].Value.ToString();
          string key = string.Format("{0} {1}", (object) str1, (object) str2);
          if (!(str1 == string.Empty) && !this._SymbolRowind.ContainsKey(key))
            this._SymbolRowind.Add(key, row.Index);
        }
      }
      this.iswait = false;
    }

    private void frmMarketWatch_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode != Keys.Return)
        return;
      if (this.cmbSymbol.SelectedIndex > 0 && this.cmbSymbol.Text != string.Empty)
        this.InsertSymbol(this.cmbSymbol.Text, this.cmbExchange.Text);
      this.dgvMarketwatch.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
      this.dgvMarketwatch.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
    }

    private void dgvMarketwatch_ColumnHeaderMouseClick(
      object sender,
      DataGridViewCellMouseEventArgs e)
    {
      if (e.ColumnIndex != 1)
        return;
      this.iswait = true;
      this._SymbolRowind.Clear();
      foreach (DataGridViewRow row in (IEnumerable) this.dgvMarketwatch.Rows)
      {
        string str1 = row.Cells[1].Value.ToString();
        string str2 = row.Cells[2].Value.ToString();
        string index = string.Format("{0} {1}", (object) str1, (object) str2);
        if (!this._SymbolRowind.ContainsKey(index))
        {
          this._SymbolRowind.Add(index, row.Index);
          string gridsymbol = index;
          if (this.objmain._Symconctracts.ContainsKey(index) && this.objmain._Symconctracts[index].symbol == "GOLDMM")
            index = str1.Replace("GOLDMM", "GOLD");
          else if (this.objmain._Symconctracts.ContainsKey(index) && this.objmain._Symconctracts[index].symbol == "SILVERMM")
            index = str1.Replace("SILVERMM", "SILVER");
          this.UpdateGridValue(this.objmain.getFeed(index), gridsymbol);
        }
      }
      this.ShuffleSymbols();
      this.iswait = false;
    }

    private void marketWatchSettingsToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.objmwsettings == null || this.objmwsettings.IsDisposed)
      {
        Market_Watch_Settings marketWatchSettings = new Market_Watch_Settings(this);
        marketWatchSettings.MdiParent = (Form) this.objmain;
        this.objmwsettings = marketWatchSettings;
        this.objmwsettings.LoadMWSettings(this.dgvMarketwatch);
        this.objmwsettings.Show();
      }
      else
      {
        this.objmwsettings.MdiParent = (Form) this.objmain;
        this.objmwsettings.LoadMWSettings(this.dgvMarketwatch);
        this.objmwsettings.Activate();
        this.objmwsettings.Show();
      }
    }

    private void clearMarketWatchToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this._SymbolRowind.Clear();
      this.dgvMarketwatch.Rows.Clear();
    }

    private void gridToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.gridToolStripMenuItem.Checked)
        this.dgvMarketwatch.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
      else
        this.dgvMarketwatch.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void toolStripFittoSize_Click(object sender, EventArgs e)
    {
      this.dgvMarketwatch.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
      this.dgvMarketwatch.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
    }

    private void addSymbolsPanelToolStripMenuItem_Click(object sender, EventArgs e)
    {
      if (this.toolStrip1.Visible)
      {
        this.toolStrip1.Visible = false;
        this.addSymbolsPanelToolStripMenuItem.CheckState = CheckState.Unchecked;
      }
      else
      {
        this.toolStrip1.Visible = true;
        this.addSymbolsPanelToolStripMenuItem.CheckState = CheckState.Checked;
      }
    }

    private void frmMarketWatch_KeyPress(object sender, KeyPressEventArgs e)
    {
      this.sym += (string) (object) e.KeyChar;
      foreach (char c in this.sym)
      {
        if (!char.IsLetter(c))
          this.sym = string.Empty;
      }
      foreach (DataGridViewRow row in (IEnumerable) this.dgvMarketwatch.Rows)
      {
        if (row.Cells[1].Value != null)
        {
          row.Cells[0].Value.ToString();
          string str1 = row.Cells[1].Value.ToString();
          string str2 = row.Cells[2].Value.ToString();
          string.Format("{0} {1}", (object) str1, (object) str2);
          if (this.sym.Length == 3)
          {
            string str3 = str1.Substring(0, 3);
            if (this.sym == str3 || this.sym == str3.ToLower())
            {
              this.dgvMarketwatch.Rows[row.Index].Selected = true;
              this.dgvMarketwatch.FirstDisplayedScrollingRowIndex = row.Index;
              this.dgvMarketwatch.CurrentCell = this.dgvMarketwatch.Rows[row.Index].Cells[1];
              this.sym = string.Empty;
              break;
            }
          }
        }
      }
      if (this.sym.Length != 3)
        return;
      this.sym = string.Empty;
    }

    public void getwidth()
    {
      Settings.Default.col0 = this.dgvMarketwatch.Columns[0].Width;
      Settings.Default.col1 = this.dgvMarketwatch.Columns[1].Width;
      Settings.Default.col2 = this.dgvMarketwatch.Columns[2].Width;
      Settings.Default.col3 = this.dgvMarketwatch.Columns[3].Width;
      Settings.Default.col4 = this.dgvMarketwatch.Columns[4].Width;
      Settings.Default.col5 = this.dgvMarketwatch.Columns[5].Width;
      Settings.Default.col6 = this.dgvMarketwatch.Columns[6].Width;
      Settings.Default.col7 = this.dgvMarketwatch.Columns[7].Width;
      Settings.Default.col8 = this.dgvMarketwatch.Columns[8].Width;
      Settings.Default.col9 = this.dgvMarketwatch.Columns[9].Width;
      Settings.Default.col10 = this.dgvMarketwatch.Columns[10].Width;
      Settings.Default.col11 = this.dgvMarketwatch.Columns[11].Width;
      Settings.Default.col12 = this.dgvMarketwatch.Columns[12].Width;
      Settings.Default.col13 = this.dgvMarketwatch.Columns[13].Width;
      Settings.Default.col14 = this.dgvMarketwatch.Columns[14].Width;
      Settings.Default.col15 = this.dgvMarketwatch.Columns[15].Width;
      Settings.Default.col16 = this.dgvMarketwatch.Columns[16].Width;
      Settings.Default.Save();
    }

    public void setwidth()
    {
      this.dgvMarketwatch.Columns[0].Width = Settings.Default.col0;
      this.dgvMarketwatch.Columns[1].Width = Settings.Default.col1;
      this.dgvMarketwatch.Columns[2].Width = Settings.Default.col2;
      this.dgvMarketwatch.Columns[3].Width = Settings.Default.col3;
      this.dgvMarketwatch.Columns[4].Width = Settings.Default.col4;
      this.dgvMarketwatch.Columns[5].Width = Settings.Default.col5;
      this.dgvMarketwatch.Columns[6].Width = Settings.Default.col6;
      this.dgvMarketwatch.Columns[7].Width = Settings.Default.col7;
      this.dgvMarketwatch.Columns[8].Width = Settings.Default.col8;
      this.dgvMarketwatch.Columns[9].Width = Settings.Default.col9;
      this.dgvMarketwatch.Columns[10].Width = Settings.Default.col10;
      this.dgvMarketwatch.Columns[11].Width = Settings.Default.col11;
      this.dgvMarketwatch.Columns[12].Width = Settings.Default.col12;
      this.dgvMarketwatch.Columns[13].Width = Settings.Default.col13;
      this.dgvMarketwatch.Columns[14].Width = Settings.Default.col14;
      this.dgvMarketwatch.Columns[15].Width = Settings.Default.col15;
      this.dgvMarketwatch.Columns[16].Width = Settings.Default.col16;
    }

    private void dgvMarketwatch_ColumnWidthChanged(object sender, DataGridViewColumnEventArgs e)
    {
      this.getwidth();
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      this.sym = string.Empty;
    }

    private void saveAsDefaultToolStripMenuItem_Click(object sender, EventArgs e)
    {
      string str1 = string.Empty;
      for (int index = 0; index < this.dgvMarketwatch.Rows.Count; ++index)
      {
        if (this.dgvMarketwatch.Rows[index].Visible)
        {
          DataGridViewRow row = this.dgvMarketwatch.Rows[index];
          if (this.dgvMarketwatch.Rows[index].Cells[1].Value != null)
          {
            string str2 = this.dgvMarketwatch.Rows[row.Index].Cells[0].Value.ToString();
            string str3 = string.Format("{0} {1}", (object) this.dgvMarketwatch.Rows[row.Index].Cells[1].Value.ToString(), (object) this.dgvMarketwatch.Rows[row.Index].Cells[2].Value.ToString());
            if (str2 == Exch.NSEOPT.ToString())
            {
              string str4 = this.dgvMarketwatch.Rows[row.Index].Cells[3].Value.ToString();
              string str5 = this.dgvMarketwatch.Rows[row.Index].Cells[4].Value.ToString();
              str3 += string.Format(" {0} {1}", (object) str4, (object) str5);
            }
            str1 += string.Format("{0},{1}_", (object) str2, (object) str3);
          }
          else
            str1 += " _";
        }
      }
      if (str1.Length > 0)
        str1 = str1.Substring(0, str1.Length - 1);
      Settings.Default.DefaultPortfolio = str1;
      Settings.Default.Save();
      this.dgvMarketwatch.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
      this.dgvMarketwatch.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCells);
    }

    private void LoadDefaultPortfolio()
    {
      string[] strArray1 = Settings.Default.DefaultPortfolio.Split('_');
      if ((uint) strArray1.Length <= 0U)
        return;
      for (int index = 0; index < strArray1.Length; ++index)
      {
        string str = strArray1[index];
        if (strArray1[index].Contains(","))
        {
          string[] strArray2 = strArray1[index].Split(',');
          if (!this._SymbolRowind.ContainsKey(strArray2[1]) && this.objmain._Symconctracts.ContainsKey(strArray2[1]))
          {
            Contracts symconctract = this.objmain._Symconctracts[strArray2[1]];
            this.InsertSymbol(strArray2[1], strArray2[0]);
          }
        }
        else if ((str == string.Empty || str == " ") && strArray1.Length > 1)
          this.dgvMarketwatch.Rows.Insert(this.dgvMarketwatch.Rows.Count, new DataGridViewRow());
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (frmMarketWatch));
      DataGridViewCellStyle gridViewCellStyle = new DataGridViewCellStyle();
      this.toolStrip1 = new ToolStrip();
      this.cmbExchange = new ToolStripComboBox();
      this.cmbSymbol = new ToolStripComboBox();
      this.cmbExpiry = new ToolStripComboBox();
      this.btnAddsymbols = new ToolStripButton();
      this.btnSaveportfolio = new ToolStripButton();
      this.btnUploadPortfolio = new ToolStripButton();
      this.dgvMarketwatch = new DataGridView();
      this.ColExch = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Expiry = new DataGridViewTextBoxColumn();
      this.StrikePrice = new DataGridViewTextBoxColumn();
      this.OptType = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.bid = new DataGridViewTextBoxColumn();
      this.ask = new DataGridViewTextBoxColumn();
      this.AskQty = new DataGridViewTextBoxColumn();
      this.LTP = new DataGridViewTextBoxColumn();
      this.Open = new DataGridViewTextBoxColumn();
      this.High = new DataGridViewTextBoxColumn();
      this.Low = new DataGridViewTextBoxColumn();
      this.Close = new DataGridViewTextBoxColumn();
      this.Netchange = new DataGridViewTextBoxColumn();
      this.Percenchange = new DataGridViewTextBoxColumn();
      this.OI = new DataGridViewTextBoxColumn();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.marketWatchSettingsToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripFittoSize = new ToolStripMenuItem();
      this.saveAsDefaultToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator1 = new ToolStripSeparator();
      this.clearMarketWatchToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator2 = new ToolStripSeparator();
      this.gridToolStripMenuItem = new ToolStripMenuItem();
      this.toolStripSeparator3 = new ToolStripSeparator();
      this.addSymbolsPanelToolStripMenuItem = new ToolStripMenuItem();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.toolStrip1.SuspendLayout();
      ((ISupportInitialize) this.dgvMarketwatch).BeginInit();
      this.contextMenuStrip1.SuspendLayout();
      this.SuspendLayout();
      this.toolStrip1.Items.AddRange(new ToolStripItem[6]
      {
        (ToolStripItem) this.cmbExchange,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.cmbExpiry,
        (ToolStripItem) this.btnAddsymbols,
        (ToolStripItem) this.btnSaveportfolio,
        (ToolStripItem) this.btnUploadPortfolio
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(1028, 25);
      this.toolStrip1.TabIndex = 0;
      this.toolStrip1.Text = "toolStrip1";
      this.cmbExchange.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbExchange.Name = "cmbExchange";
      this.cmbExchange.Size = new Size(110, 25);
      this.cmbExchange.SelectedIndexChanged += new EventHandler(this.cmbExchange_SelectedIndexChanged);
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(180, 25);
      this.cmbExpiry.Name = "cmbExpiry";
      this.cmbExpiry.Size = new Size(110, 25);
      this.cmbExpiry.Visible = false;
      this.btnAddsymbols.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnAddsymbols.Image = (Image) componentResourceManager.GetObject("btnAddsymbols.Image");
      this.btnAddsymbols.ImageTransparentColor = Color.Magenta;
      this.btnAddsymbols.Name = "btnAddsymbols";
      this.btnAddsymbols.Size = new Size(23, 22);
      this.btnAddsymbols.Text = "Add Symbol";
      this.btnAddsymbols.Click += new EventHandler(this.btnAddsymbols_Click);
      this.btnSaveportfolio.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSaveportfolio.Image = (Image) componentResourceManager.GetObject("btnSaveportfolio.Image");
      this.btnSaveportfolio.ImageTransparentColor = Color.Magenta;
      this.btnSaveportfolio.Name = "btnSaveportfolio";
      this.btnSaveportfolio.Size = new Size(23, 22);
      this.btnSaveportfolio.Text = "Save Portfolio";
      this.btnSaveportfolio.Click += new EventHandler(this.btnSaveportfolio_Click);
      this.btnUploadPortfolio.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnUploadPortfolio.Image = (Image) componentResourceManager.GetObject("btnUploadPortfolio.Image");
      this.btnUploadPortfolio.ImageTransparentColor = Color.Magenta;
      this.btnUploadPortfolio.Name = "btnUploadPortfolio";
      this.btnUploadPortfolio.Size = new Size(23, 22);
      this.btnUploadPortfolio.Text = "Load Portfolio";
      this.btnUploadPortfolio.Click += new EventHandler(this.btnUploadPortfolio_Click);
      this.dgvMarketwatch.AllowDrop = true;
      this.dgvMarketwatch.AllowUserToAddRows = false;
      this.dgvMarketwatch.AllowUserToDeleteRows = false;
      this.dgvMarketwatch.AllowUserToOrderColumns = true;
      this.dgvMarketwatch.AllowUserToResizeRows = false;
      this.dgvMarketwatch.BackgroundColor = Color.Black;
      this.dgvMarketwatch.CellBorderStyle = DataGridViewCellBorderStyle.None;
      this.dgvMarketwatch.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvMarketwatch.Columns.AddRange((DataGridViewColumn) this.ColExch, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Expiry, (DataGridViewColumn) this.StrikePrice, (DataGridViewColumn) this.OptType, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.bid, (DataGridViewColumn) this.ask, (DataGridViewColumn) this.AskQty, (DataGridViewColumn) this.LTP, (DataGridViewColumn) this.Open, (DataGridViewColumn) this.High, (DataGridViewColumn) this.Low, (DataGridViewColumn) this.Close, (DataGridViewColumn) this.Netchange, (DataGridViewColumn) this.Percenchange, (DataGridViewColumn) this.OI);
      gridViewCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle.BackColor = Color.Black;
      gridViewCellStyle.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      gridViewCellStyle.ForeColor = SystemColors.ControlLightLight;
      gridViewCellStyle.SelectionBackColor = SystemColors.GrayText;
      gridViewCellStyle.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle.WrapMode = DataGridViewTriState.False;
      this.dgvMarketwatch.DefaultCellStyle = gridViewCellStyle;
      this.dgvMarketwatch.Dock = DockStyle.Fill;
      this.dgvMarketwatch.EditMode = DataGridViewEditMode.EditOnF2;
      this.dgvMarketwatch.GridColor = SystemColors.Control;
      this.dgvMarketwatch.Location = new Point(0, 25);
      this.dgvMarketwatch.MultiSelect = false;
      this.dgvMarketwatch.Name = "dgvMarketwatch";
      this.dgvMarketwatch.ReadOnly = true;
      this.dgvMarketwatch.RowHeadersVisible = false;
      this.dgvMarketwatch.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvMarketwatch.Size = new Size(1028, 310);
      this.dgvMarketwatch.TabIndex = 2;
      this.dgvMarketwatch.ColumnHeaderMouseClick += new DataGridViewCellMouseEventHandler(this.dgvMarketwatch_ColumnHeaderMouseClick);
      this.dgvMarketwatch.ColumnWidthChanged += new DataGridViewColumnEventHandler(this.dgvMarketwatch_ColumnWidthChanged);
      this.dgvMarketwatch.DragDrop += new DragEventHandler(this.dgvMarketwatch_DragDrop);
      this.dgvMarketwatch.DragOver += new DragEventHandler(this.dgvMarketwatch_DragOver);
      this.dgvMarketwatch.KeyUp += new KeyEventHandler(this.dgvMarketwatch_KeyUp);
      this.dgvMarketwatch.MouseClick += new MouseEventHandler(this.dgvMarketwatch_MouseClick);
      this.dgvMarketwatch.MouseDown += new MouseEventHandler(this.dgvMarketwatch_MouseDown);
      this.dgvMarketwatch.MouseMove += new MouseEventHandler(this.dgvMarketwatch_MouseMove);
      this.ColExch.HeaderText = "Exchange";
      this.ColExch.Name = "ColExch";
      this.ColExch.ReadOnly = true;
      this.ColExch.Width = 70;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Symbol.Width = 110;
      this.Expiry.HeaderText = "Expiry";
      this.Expiry.Name = "Expiry";
      this.Expiry.ReadOnly = true;
      this.Expiry.Width = 80;
      this.StrikePrice.HeaderText = "StrikePrice";
      this.StrikePrice.Name = "StrikePrice";
      this.StrikePrice.ReadOnly = true;
      this.StrikePrice.Width = 60;
      this.OptType.HeaderText = "OptType";
      this.OptType.Name = "OptType";
      this.OptType.ReadOnly = true;
      this.OptType.Width = 60;
      this.Qty.HeaderText = "BidQty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.Qty.Width = 70;
      this.bid.HeaderText = "Bid";
      this.bid.Name = "bid";
      this.bid.ReadOnly = true;
      this.bid.Width = 70;
      this.ask.HeaderText = "Ask";
      this.ask.Name = "ask";
      this.ask.ReadOnly = true;
      this.ask.Width = 70;
      this.AskQty.HeaderText = "AskQty";
      this.AskQty.Name = "AskQty";
      this.AskQty.ReadOnly = true;
      this.AskQty.Width = 70;
      this.LTP.HeaderText = "LTP";
      this.LTP.Name = "LTP";
      this.LTP.ReadOnly = true;
      this.LTP.Width = 70;
      this.Open.HeaderText = "Open";
      this.Open.Name = "Open";
      this.Open.ReadOnly = true;
      this.Open.Width = 60;
      this.High.HeaderText = "High";
      this.High.Name = "High";
      this.High.ReadOnly = true;
      this.High.Width = 60;
      this.Low.HeaderText = "Low";
      this.Low.Name = "Low";
      this.Low.ReadOnly = true;
      this.Low.Width = 60;
      this.Close.HeaderText = "Close";
      this.Close.Name = "Close";
      this.Close.ReadOnly = true;
      this.Close.Width = 60;
      this.Netchange.HeaderText = "Net Change";
      this.Netchange.Name = "Netchange";
      this.Netchange.ReadOnly = true;
      this.Netchange.Width = 70;
      this.Percenchange.HeaderText = "% Change";
      this.Percenchange.Name = "Percenchange";
      this.Percenchange.ReadOnly = true;
      this.Percenchange.Width = 70;
      this.OI.HeaderText = "OI";
      this.OI.Name = "OI";
      this.OI.ReadOnly = true;
      this.OI.Width = 70;
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[9]
      {
        (ToolStripItem) this.marketWatchSettingsToolStripMenuItem,
        (ToolStripItem) this.toolStripFittoSize,
        (ToolStripItem) this.saveAsDefaultToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator1,
        (ToolStripItem) this.clearMarketWatchToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator2,
        (ToolStripItem) this.gridToolStripMenuItem,
        (ToolStripItem) this.toolStripSeparator3,
        (ToolStripItem) this.addSymbolsPanelToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(194, 154);
      this.marketWatchSettingsToolStripMenuItem.Name = "marketWatchSettingsToolStripMenuItem";
      this.marketWatchSettingsToolStripMenuItem.Size = new Size(193, 22);
      this.marketWatchSettingsToolStripMenuItem.Text = "Market Watch Settings";
      this.marketWatchSettingsToolStripMenuItem.Click += new EventHandler(this.marketWatchSettingsToolStripMenuItem_Click);
      this.toolStripFittoSize.Name = "toolStripFittoSize";
      this.toolStripFittoSize.Size = new Size(193, 22);
      this.toolStripFittoSize.Text = "Columns Fit to Size";
      this.toolStripFittoSize.Click += new EventHandler(this.toolStripFittoSize_Click);
      this.saveAsDefaultToolStripMenuItem.Name = "saveAsDefaultToolStripMenuItem";
      this.saveAsDefaultToolStripMenuItem.Size = new Size(193, 22);
      this.saveAsDefaultToolStripMenuItem.Text = "Save as Default";
      this.saveAsDefaultToolStripMenuItem.Click += new EventHandler(this.saveAsDefaultToolStripMenuItem_Click);
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new Size(190, 6);
      this.clearMarketWatchToolStripMenuItem.Name = "clearMarketWatchToolStripMenuItem";
      this.clearMarketWatchToolStripMenuItem.Size = new Size(193, 22);
      this.clearMarketWatchToolStripMenuItem.Text = "Clear Market Watch";
      this.clearMarketWatchToolStripMenuItem.Click += new EventHandler(this.clearMarketWatchToolStripMenuItem_Click);
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new Size(190, 6);
      this.gridToolStripMenuItem.CheckOnClick = true;
      this.gridToolStripMenuItem.Name = "gridToolStripMenuItem";
      this.gridToolStripMenuItem.Size = new Size(193, 22);
      this.gridToolStripMenuItem.Text = "Grid";
      this.gridToolStripMenuItem.Click += new EventHandler(this.gridToolStripMenuItem_Click);
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new Size(190, 6);
      this.addSymbolsPanelToolStripMenuItem.Checked = true;
      this.addSymbolsPanelToolStripMenuItem.CheckOnClick = true;
      this.addSymbolsPanelToolStripMenuItem.CheckState = CheckState.Checked;
      this.addSymbolsPanelToolStripMenuItem.Name = "addSymbolsPanelToolStripMenuItem";
      this.addSymbolsPanelToolStripMenuItem.Size = new Size(193, 22);
      this.addSymbolsPanelToolStripMenuItem.Text = "Add Symbols Panel";
      this.addSymbolsPanelToolStripMenuItem.Click += new EventHandler(this.addSymbolsPanelToolStripMenuItem_Click);
      this.timer1.Interval = 15000;
      this.timer1.Tick += new EventHandler(this.timer1_Tick);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1028, 335);
      this.Controls.Add((Control) this.dgvMarketwatch);
      this.Controls.Add((Control) this.toolStrip1);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.Name = nameof (frmMarketWatch);
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Market Watch";
      this.FormClosing += new FormClosingEventHandler(this.frmMarketWatch_FormClosing);
      this.Load += new EventHandler(this.frmMarketWatch_Load);
      this.KeyPress += new KeyPressEventHandler(this.frmMarketWatch_KeyPress);
      this.KeyUp += new KeyEventHandler(this.frmMarketWatch_KeyUp);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      ((ISupportInitialize) this.dgvMarketwatch).EndInit();
      this.contextMenuStrip1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
