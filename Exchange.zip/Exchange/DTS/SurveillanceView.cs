﻿// Decompiled with JetBrains decompiler
// Type: DTS.SurveillanceView
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class SurveillanceView : Form
  {
    private IContainer components = (IContainer) null;
    public SqlConnection conn;
    public Dashboard objmain;
    private Thread threadObjRTSurveilance;
    private DataGridView dgvSurveillanceMsg;
    private DataGridViewTextBoxColumn RegulationCode;
    private DataGridViewTextBoxColumn Message;
    private DataGridViewTextBoxColumn Time;

    public SurveillanceView(Dashboard main)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.Icon = this.objmain.ico;
    }

    private void dgvSurveillanceMsg_MouseClick(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Right)
        return;
      ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
      contextMenuStrip.Items.Add("Grid", (Image) null, new EventHandler(this.Task1_Click));
      contextMenuStrip.Items.Add("Ungrid", (Image) null, new EventHandler(this.Task2_Click));
      contextMenuStrip.Items.Add("Export To CSV", (Image) null, new EventHandler(this.Task3_Click));
      Point client = this.dgvSurveillanceMsg.PointToClient(Control.MousePosition);
      contextMenuStrip.Show((Control) this.dgvSurveillanceMsg, client.X, client.Y);
    }

    private void Task1_Click(object sender, EventArgs e)
    {
      this.dgvSurveillanceMsg.CellBorderStyle = DataGridViewCellBorderStyle.Raised;
    }

    private void Task2_Click(object sender, EventArgs e)
    {
      this.dgvSurveillanceMsg.CellBorderStyle = DataGridViewCellBorderStyle.None;
    }

    private void Task3_Click(object sender, EventArgs e)
    {
      if (this.dgvSurveillanceMsg.Rows.Count <= 0)
        return;
      Export.ExportToExcel(this.dgvSurveillanceMsg, false);
    }

    public void LoadWindow()
    {
      if (this.threadObjRTSurveilance != null && this.threadObjRTSurveilance.ThreadState == ThreadState.Running)
        this.threadObjRTSurveilance.Abort();
      this.threadObjRTSurveilance = new Thread((ThreadStart) (() => this.LoadSurvellainceMsg()));
      this.threadObjRTSurveilance.Start();
    }

    private void LoadSurvellainceMsg()
    {
      DateTime dateTime1;
      ref DateTime local = ref dateTime1;
      DateTime now = DateTime.Now;
      int year = now.Year;
      now = DateTime.Now;
      int month = now.Month;
      now = DateTime.Now;
      int day = now.Day;
      local = new DateTime(year, month, day, 0, 0, 0);
      int rowcount = 0;
      this.conn = this.objmain.getConn();
      while (true)
      {
        if (this.conn.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand(string.Format("Select ClientCode,Message,Timestamp from RejectionMessages where Clientcode in ({0}) and Timestamp > '{1:yyyy-MM-dd HH:mm:ss.fff}'", (object) this.objmain.claccounts, (object) dateTime1), this.conn))
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                this.Invoke((Delegate) (() => rowcount = this.dgvSurveillanceMsg.Rows.Add()));
                if (!sqlDataReader.IsDBNull(0))
                {
                  this.dgvSurveillanceMsg.Rows[rowcount].Cells[0].Value = (object) sqlDataReader.GetString(0);
                  if (!sqlDataReader.IsDBNull(1))
                    this.dgvSurveillanceMsg.Rows[rowcount].Cells[1].Value = (object) sqlDataReader.GetString(1);
                  if (!sqlDataReader.IsDBNull(2))
                  {
                    DateTime dateTime2 = Convert.ToDateTime(sqlDataReader.GetValue(2));
                    dateTime1 = dateTime2;
                    this.dgvSurveillanceMsg.Rows[rowcount].Cells[2].Value = (object) string.Format("{0}:{1}:{2}", (object) dateTime2.Hour, (object) dateTime2.Minute, (object) dateTime2.Second);
                  }
                }
              }
            }
          }
        }
        Thread.Sleep(30000);
      }
    }

    private void SurveillanceView_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (this.threadObjRTSurveilance == null || this.threadObjRTSurveilance.ThreadState != ThreadState.Running)
        return;
      this.threadObjRTSurveilance.Abort();
    }

    private void SurveillanceView_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode != Keys.Escape || this.threadObjRTSurveilance == null || this.threadObjRTSurveilance.ThreadState != ThreadState.Running)
        return;
      this.threadObjRTSurveilance.Abort();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvSurveillanceMsg = new DataGridView();
      this.RegulationCode = new DataGridViewTextBoxColumn();
      this.Message = new DataGridViewTextBoxColumn();
      this.Time = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvSurveillanceMsg).BeginInit();
      this.SuspendLayout();
      this.dgvSurveillanceMsg.AllowUserToAddRows = false;
      this.dgvSurveillanceMsg.AllowUserToDeleteRows = false;
      this.dgvSurveillanceMsg.AllowUserToOrderColumns = true;
      this.dgvSurveillanceMsg.BackgroundColor = Color.White;
      this.dgvSurveillanceMsg.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvSurveillanceMsg.Columns.AddRange((DataGridViewColumn) this.RegulationCode, (DataGridViewColumn) this.Message, (DataGridViewColumn) this.Time);
      this.dgvSurveillanceMsg.Dock = DockStyle.Fill;
      this.dgvSurveillanceMsg.Location = new Point(0, 0);
      this.dgvSurveillanceMsg.Name = "dgvSurveillanceMsg";
      this.dgvSurveillanceMsg.ReadOnly = true;
      this.dgvSurveillanceMsg.RowHeadersVisible = false;
      this.dgvSurveillanceMsg.Size = new Size(945, 290);
      this.dgvSurveillanceMsg.TabIndex = 0;
      this.dgvSurveillanceMsg.MouseClick += new MouseEventHandler(this.dgvSurveillanceMsg_MouseClick);
      this.RegulationCode.HeaderText = "ClientCode";
      this.RegulationCode.Name = "RegulationCode";
      this.RegulationCode.ReadOnly = true;
      this.Message.HeaderText = "Message";
      this.Message.Name = "Message";
      this.Message.ReadOnly = true;
      this.Message.Width = 700;
      this.Time.HeaderText = "Time";
      this.Time.Name = "Time";
      this.Time.ReadOnly = true;
      this.Time.Width = 80;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(945, 290);
      this.Controls.Add((Control) this.dgvSurveillanceMsg);
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (SurveillanceView);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Rejection Messages";
      this.FormClosing += new FormClosingEventHandler(this.SurveillanceView_FormClosing);
      this.KeyUp += new KeyEventHandler(this.SurveillanceView_KeyUp);
      ((ISupportInitialize) this.dgvSurveillanceMsg).EndInit();
      this.ResumeLayout(false);
    }
  }
}
