﻿// Decompiled with JetBrains decompiler
// Type: DTS.ServerSwitch
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class ServerSwitch : Form
  {
    private string _msg = string.Empty;
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    public DialogResult result;
    private Button button_Yes;
    private Button button_No;
    private Label labelMSG;

    public ServerSwitch(Dashboard dash)
    {
      this._msg = "Please select server";
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    private void button_Yes_Click(object sender, EventArgs e)
    {
      this.result = DialogResult.OK;
      this.Close();
    }

    private void button_No_Click(object sender, EventArgs e)
    {
      this.result = DialogResult.No;
      this.Close();
    }

    private void ServerSwitch_Load(object sender, EventArgs e)
    {
      this.labelMSG.Text = this._msg;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.button_Yes = new Button();
      this.button_No = new Button();
      this.labelMSG = new Label();
      this.SuspendLayout();
      this.button_Yes.Location = new Point(36, 44);
      this.button_Yes.Name = "button_Yes";
      this.button_Yes.Size = new Size(75, 23);
      this.button_Yes.TabIndex = 0;
      this.button_Yes.Text = "Server1";
      this.button_Yes.UseVisualStyleBackColor = true;
      this.button_Yes.Click += new EventHandler(this.button_Yes_Click);
      this.button_No.Location = new Point(155, 44);
      this.button_No.Name = "button_No";
      this.button_No.Size = new Size(75, 23);
      this.button_No.TabIndex = 1;
      this.button_No.Text = "Server2";
      this.button_No.UseVisualStyleBackColor = true;
      this.button_No.Click += new EventHandler(this.button_No_Click);
      this.labelMSG.AutoSize = true;
      this.labelMSG.Location = new Point(12, 18);
      this.labelMSG.Name = "labelMSG";
      this.labelMSG.Size = new Size(0, 13);
      this.labelMSG.TabIndex = 2;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(284, 79);
      this.Controls.Add((Control) this.labelMSG);
      this.Controls.Add((Control) this.button_No);
      this.Controls.Add((Control) this.button_Yes);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (ServerSwitch);
      this.StartPosition = FormStartPosition.CenterParent;
      this.Text = nameof (ServerSwitch);
      this.Load += new EventHandler(this.ServerSwitch_Load);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
