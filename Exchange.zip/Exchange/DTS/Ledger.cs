﻿// Decompiled with JetBrains decompiler
// Type: DTS.Ledger
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public struct Ledger
  {
    public string accountno;
    public double orderno;
    public int buyqty;
    public double buyprice;
    public int sellqty;
    public double sellprice;
    public DateTime OpenTime;
    public DateTime CloseTime;
    public Decimal comm;
    public double profitLoss;
    public Decimal NettPl;
    public string symbol;
  }
}
