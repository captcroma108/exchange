﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmPosGoinLive
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmPosGoinLive : Form
  {
    public Dictionary<string, int> _NetPosList = new Dictionary<string, int>();
    private SortedDictionary<string, Decimal> _ClientwisePFLS = new SortedDictionary<string, Decimal>();
    private SortedDictionary<string, int> _PositionIndex = new SortedDictionary<string, int>();
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private bool isUpdatedgv;
    private Thread threadObjRT;
    public DataGridView dgvNetPosition;
    private ContextMenuStrip contextMenuStrip1;
    private ToolStripMenuItem sortToolStripMenuItem;
    private ToolStripMenuItem ascendingToolStripMenuItem;
    private ToolStripMenuItem descendingToolStripMenuItem;
    private DataGridViewTextBoxColumn Regulation;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn Validity;
    private DataGridViewTextBoxColumn CMP;
    private DataGridViewTextBoxColumn NetMTM;
    private ToolStrip toolStrip1;
    private ToolStripLabel toolStripLabel2;
    private ToolStripComboBox cmbclientcode;
    private ToolStripLabel toolStripLabel4;
    private ToolStripComboBox cmbSymbol;
    private ToolStripButton btnSearch;

    public frmPosGoinLive(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.isUpdatedgv = false;
      this.Icon = this.objdash.ico;
    }

    public void Loadwindow()
    {
      this.dgvNetPosition.Rows.Clear();
      this._ClientwisePFLS = new SortedDictionary<string, Decimal>();
      if (this.threadObjRT != null)
        return;
      this.threadObjRT = new Thread(new ThreadStart(((ThreadStart) (() => this.LoadRTPrftLs())).Invoke));
      this.threadObjRT.Start();
    }

    private void LoadRTPrftLs()
    {
      this.Invoke((Delegate) (() =>
      {
        this.cmbSymbol.Items.Clear();
        this.cmbSymbol.Items.Add((object) "");
        this.cmbclientcode.Items.Clear();
        this.cmbclientcode.Items.Add((object) "");
      }));
      while (true)
      {
        Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>();
        Dictionary<string, buysellnetpospfls> netProftLoss = this.objdash._NetProftLoss;
        try
        {
          foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in netProftLoss)
          {
            string[] strArray = keyValuePair.Key.Split('_');
            string str1 = strArray[0];
            string str2 = strArray[1];
            int int32 = Convert.ToInt32(strArray[2]);
            string str3 = string.Format("{0}_{1}_{2}", (object) str2, (object) str1, (object) int32);
            buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
            Decimal num1 = buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l;
            string key1 = string.Format("{0}_{1}", (object) str3, (object) 1);
            if (num1 > Decimal.Zero)
            {
              if (!this._ClientwisePFLS.ContainsKey(key1))
                this._ClientwisePFLS.Add(key1, num1);
              else
                this._ClientwisePFLS[key1] = num1;
            }
            else if (this._ClientwisePFLS.ContainsKey(key1))
            {
              string key2 = string.Format("{0}_{1}", (object) str3, (object) 0);
              Decimal num2 = this._ClientwisePFLS[key1];
              this._ClientwisePFLS.Remove(key1);
              this._ClientwisePFLS.Add(key2, num2);
            }
          }
          foreach (KeyValuePair<string, Decimal> keyValuePair in this._ClientwisePFLS)
          {
            string[] strArray = keyValuePair.Key.Split('_');
            string symbol = strArray[1];
            string account = strArray[0];
            int validity = Convert.ToInt32(strArray[2]);
            int visibility = Convert.ToInt32(strArray[3]);
            Decimal netmtmpl = keyValuePair.Value;
            string key = string.Format("{0}_{1}_{2}", (object) account, (object) symbol, (object) validity);
            string str1 = symbol;
            Contracts symconctract = this.objdash._Symconctracts[symbol];
            string str2;
            if (symconctract.symbol == "GOLDMM")
              str2 = str1.Replace("GOLDMM", "GOLD");
            else if (symconctract.symbol == "SILVERMM")
              str2 = str1.Replace("SILVERMM", "SILVER");
            Feeds objfeeds = this.objdash.getFeed(symbol);
            this.Invoke((Delegate) (() =>
            {
              if (!this.cmbclientcode.Items.Contains((object) account))
                this.cmbclientcode.Items.Add((object) account);
              if (!this.cmbSymbol.Items.Contains((object) symbol))
                this.cmbSymbol.Items.Add((object) symbol);
              if (this.isUpdatedgv)
                return;
              if (visibility == 1)
              {
                if (!this._PositionIndex.ContainsKey(key))
                {
                  int index = this.dgvNetPosition.Rows.Add();
                  this.dgvNetPosition.Rows[index].Cells[0].Value = (object) account;
                  this.dgvNetPosition.Rows[index].Cells[1].Value = (object) symbol;
                  this.dgvNetPosition.Rows[index].Cells[2].Value = (object) Utils.GetValidity(validity);
                  this.dgvNetPosition.Rows[index].Cells[3].Value = (object) objfeeds.ltp;
                  this.dgvNetPosition.Rows[index].Cells[4].Value = (object) netmtmpl;
                  this._PositionIndex.Add(key, index);
                }
                else
                {
                  int index = this._PositionIndex[key];
                  this.dgvNetPosition.Rows[index].Visible = true;
                  this.dgvNetPosition.Rows[index].Cells[3].Value = (object) objfeeds.ltp;
                  this.dgvNetPosition.Rows[index].Cells[4].Value = (object) netmtmpl;
                }
              }
              else if (this._PositionIndex.ContainsKey(key))
                this.dgvNetPosition.Rows[this._PositionIndex[key]].Visible = false;
            }));
          }
          Thread.Sleep(5000);
        }
        catch
        {
        }
      }
    }

    private void ascendingToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.isUpdatedgv = true;
      this.dgvNetPosition.Rows.Clear();
      this._PositionIndex = new SortedDictionary<string, int>();
      foreach (KeyValuePair<string, Decimal> keyValuePair in this._ClientwisePFLS)
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string symbol = strArray[1];
        string account = strArray[0];
        int validity = Convert.ToInt32(strArray[2]);
        int int32 = Convert.ToInt32(strArray[3]);
        Decimal netmtmpl = keyValuePair.Value;
        string key = string.Format("{0}_{1}_{2}", (object) account, (object) symbol, (object) validity);
        string symbol1 = symbol;
        Contracts symconctract = this.objdash._Symconctracts[symbol];
        if (symconctract.symbol == "GOLDMM")
          symbol1 = symbol1.Replace("GOLDMM", "GOLD");
        else if (symconctract.symbol == "SILVERMM")
          symbol1 = symbol1.Replace("SILVERMM", "SILVER");
        Feeds objfeeds = this.objdash.getFeed(symbol1);
        if (int32 == 1 && !this._PositionIndex.ContainsKey(key))
          this.Invoke((Delegate) (() =>
          {
            int index = this.dgvNetPosition.Rows.Add();
            this.dgvNetPosition.Rows[index].Cells[0].Value = (object) account;
            this.dgvNetPosition.Rows[index].Cells[1].Value = (object) symbol;
            this.dgvNetPosition.Rows[index].Cells[2].Value = (object) Utils.GetValidity(validity);
            this.dgvNetPosition.Rows[index].Cells[3].Value = (object) objfeeds.ltp;
            this.dgvNetPosition.Rows[index].Cells[4].Value = (object) netmtmpl;
            this._PositionIndex.Add(key, index);
          }));
      }
      this.isUpdatedgv = false;
    }

    private void descendingToolStripMenuItem_Click(object sender, EventArgs e)
    {
      this.isUpdatedgv = true;
      this.dgvNetPosition.Rows.Clear();
      this._PositionIndex = new SortedDictionary<string, int>();
      foreach (KeyValuePair<string, Decimal> keyValuePair in this._ClientwisePFLS.Reverse<KeyValuePair<string, Decimal>>())
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string symbol = strArray[1];
        string account = strArray[0];
        int validity = Convert.ToInt32(strArray[2]);
        int int32 = Convert.ToInt32(strArray[3]);
        Decimal netmtmpl = keyValuePair.Value;
        string key = string.Format("{0}_{1}_{2}", (object) account, (object) symbol, (object) validity);
        string symbol1 = symbol;
        Contracts symconctract = this.objdash._Symconctracts[symbol];
        if (symconctract.symbol == "GOLDMM")
          symbol1 = symbol1.Replace("GOLDMM", "GOLD");
        else if (symconctract.symbol == "SILVERMM")
          symbol1 = symbol1.Replace("SILVERMM", "SILVER");
        Feeds objfeeds = this.objdash.getFeed(symbol1);
        if (int32 == 1 && !this._PositionIndex.ContainsKey(key))
          this.Invoke((Delegate) (() =>
          {
            int index = this.dgvNetPosition.Rows.Add();
            this.dgvNetPosition.Rows[index].Cells[0].Value = (object) account;
            this.dgvNetPosition.Rows[index].Cells[1].Value = (object) symbol;
            this.dgvNetPosition.Rows[index].Cells[2].Value = (object) Utils.GetValidity(validity);
            this.dgvNetPosition.Rows[index].Cells[3].Value = (object) objfeeds.ltp;
            this.dgvNetPosition.Rows[index].Cells[4].Value = (object) netmtmpl;
            this._PositionIndex.Add(key, index);
          }));
      }
      this.isUpdatedgv = false;
    }

    private void btnSearch_Click(object sender, EventArgs e)
    {
      if (this.cmbclientcode.Text == string.Empty && this.cmbSymbol.Text == string.Empty)
      {
        foreach (DataGridViewBand row in (IEnumerable) this.dgvNetPosition.Rows)
          row.Visible = true;
      }
      else if (this.cmbclientcode.Text == string.Empty && this.cmbSymbol.Text != string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[1].Value.ToString() == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else if (this.cmbclientcode.Text != string.Empty && this.cmbSymbol.Text == string.Empty)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
      else
      {
        if (!(this.cmbclientcode.Text != string.Empty) || !(this.cmbSymbol.Text != string.Empty))
          return;
        foreach (DataGridViewRow row in (IEnumerable) this.dgvNetPosition.Rows)
        {
          if (row.Cells[0].Value.ToString() == this.cmbclientcode.Text && row.Cells[1].Value.ToString() == this.cmbSymbol.Text)
            row.Visible = true;
          else
            row.Visible = false;
        }
      }
    }

    private void frmPosGoinLive_KeyUp(object sender, KeyEventArgs e)
    {
      if (e.KeyCode == Keys.C)
        this.cmbclientcode.Focus();
      else if (e.KeyCode == Keys.S)
      {
        this.cmbSymbol.Focus();
      }
      else
      {
        if (e.KeyCode != Keys.Escape || this.threadObjRT == null)
          return;
        this.threadObjRT.Abort();
        this.threadObjRT = (Thread) null;
      }
    }

    private void frmPosGoinLive_FormClosing(object sender, FormClosingEventArgs e)
    {
      if (this.threadObjRT == null)
        return;
      this.threadObjRT.Abort();
      this.threadObjRT = (Thread) null;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (frmPosGoinLive));
      this.dgvNetPosition = new DataGridView();
      this.Regulation = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.CMP = new DataGridViewTextBoxColumn();
      this.NetMTM = new DataGridViewTextBoxColumn();
      this.contextMenuStrip1 = new ContextMenuStrip(this.components);
      this.sortToolStripMenuItem = new ToolStripMenuItem();
      this.ascendingToolStripMenuItem = new ToolStripMenuItem();
      this.descendingToolStripMenuItem = new ToolStripMenuItem();
      this.toolStrip1 = new ToolStrip();
      this.toolStripLabel2 = new ToolStripLabel();
      this.cmbclientcode = new ToolStripComboBox();
      this.toolStripLabel4 = new ToolStripLabel();
      this.cmbSymbol = new ToolStripComboBox();
      this.btnSearch = new ToolStripButton();
      ((ISupportInitialize) this.dgvNetPosition).BeginInit();
      this.contextMenuStrip1.SuspendLayout();
      this.toolStrip1.SuspendLayout();
      this.SuspendLayout();
      this.dgvNetPosition.AllowUserToAddRows = false;
      this.dgvNetPosition.AllowUserToDeleteRows = false;
      this.dgvNetPosition.AllowUserToOrderColumns = true;
      this.dgvNetPosition.AllowUserToResizeRows = false;
      this.dgvNetPosition.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvNetPosition.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvNetPosition.BackgroundColor = Color.White;
      this.dgvNetPosition.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvNetPosition.Columns.AddRange((DataGridViewColumn) this.Regulation, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.Validity, (DataGridViewColumn) this.CMP, (DataGridViewColumn) this.NetMTM);
      this.dgvNetPosition.Location = new Point(0, 28);
      this.dgvNetPosition.Name = "dgvNetPosition";
      this.dgvNetPosition.ReadOnly = true;
      this.dgvNetPosition.RowHeadersVisible = false;
      this.dgvNetPosition.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvNetPosition.Size = new Size(974, 311);
      this.dgvNetPosition.TabIndex = 1;
      this.Regulation.HeaderText = "ClientCode";
      this.Regulation.Name = "Regulation";
      this.Regulation.ReadOnly = true;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.CMP.HeaderText = "CMP";
      this.CMP.Name = "CMP";
      this.CMP.ReadOnly = true;
      this.NetMTM.HeaderText = "NetMTMP/L";
      this.NetMTM.Name = "NetMTM";
      this.NetMTM.ReadOnly = true;
      this.contextMenuStrip1.Items.AddRange(new ToolStripItem[1]
      {
        (ToolStripItem) this.sortToolStripMenuItem
      });
      this.contextMenuStrip1.Name = "contextMenuStrip1";
      this.contextMenuStrip1.Size = new Size(96, 26);
      this.sortToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[2]
      {
        (ToolStripItem) this.ascendingToolStripMenuItem,
        (ToolStripItem) this.descendingToolStripMenuItem
      });
      this.sortToolStripMenuItem.Name = "sortToolStripMenuItem";
      this.sortToolStripMenuItem.Size = new Size(95, 22);
      this.sortToolStripMenuItem.Text = "Sort";
      this.ascendingToolStripMenuItem.Name = "ascendingToolStripMenuItem";
      this.ascendingToolStripMenuItem.Size = new Size(136, 22);
      this.ascendingToolStripMenuItem.Text = "Ascending";
      this.ascendingToolStripMenuItem.Click += new EventHandler(this.ascendingToolStripMenuItem_Click);
      this.descendingToolStripMenuItem.Name = "descendingToolStripMenuItem";
      this.descendingToolStripMenuItem.Size = new Size(136, 22);
      this.descendingToolStripMenuItem.Text = "Descending";
      this.descendingToolStripMenuItem.Click += new EventHandler(this.descendingToolStripMenuItem_Click);
      this.toolStrip1.Items.AddRange(new ToolStripItem[5]
      {
        (ToolStripItem) this.toolStripLabel2,
        (ToolStripItem) this.cmbclientcode,
        (ToolStripItem) this.toolStripLabel4,
        (ToolStripItem) this.cmbSymbol,
        (ToolStripItem) this.btnSearch
      });
      this.toolStrip1.Location = new Point(0, 0);
      this.toolStrip1.Name = "toolStrip1";
      this.toolStrip1.Size = new Size(974, 25);
      this.toolStrip1.TabIndex = 2;
      this.toolStrip1.Text = "toolStrip1";
      this.toolStripLabel2.Name = "toolStripLabel2";
      this.toolStripLabel2.Size = new Size(66, 22);
      this.toolStripLabel2.Text = "ClientCode";
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(121, 25);
      this.cmbclientcode.Sorted = true;
      this.toolStripLabel4.Name = "toolStripLabel4";
      this.toolStripLabel4.Size = new Size(47, 22);
      this.toolStripLabel4.Text = "Symbol";
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(121, 25);
      this.cmbSymbol.Sorted = true;
      this.btnSearch.DisplayStyle = ToolStripItemDisplayStyle.Image;
      this.btnSearch.Image = (Image) componentResourceManager.GetObject("btnSearch.Image");
      this.btnSearch.ImageTransparentColor = Color.Magenta;
      this.btnSearch.Name = "btnSearch";
      this.btnSearch.Size = new Size(23, 22);
      this.btnSearch.Text = "toolStripButton1";
      this.btnSearch.Click += new EventHandler(this.btnSearch_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(974, 339);
      this.Controls.Add((Control) this.toolStrip1);
      this.Controls.Add((Control) this.dgvNetPosition);
      this.KeyPreview = true;
      this.Name = nameof (frmPosGoinLive);
      this.Text = "Positions Going Positive";
      this.FormClosing += new FormClosingEventHandler(this.frmPosGoinLive_FormClosing);
      this.KeyUp += new KeyEventHandler(this.frmPosGoinLive_KeyUp);
      ((ISupportInitialize) this.dgvNetPosition).EndInit();
      this.contextMenuStrip1.ResumeLayout(false);
      this.toolStrip1.ResumeLayout(false);
      this.toolStrip1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
