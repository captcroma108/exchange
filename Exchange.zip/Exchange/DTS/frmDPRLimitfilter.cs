﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDPRLimitfilter
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmDPRLimitfilter : Form
  {
    private int gridIndex = 0;
    private IContainer components = (IContainer) null;
    private Dashboard objdash;
    private GroupBox groupBox1;
    private RadioButton rdoNsecurr;
    private RadioButton rdoncdex;
    private RadioButton rdoNseFut;
    private RadioButton rdoMcx;
    private DataGridView dgvContracts;
    private DataGridViewTextBoxColumn ColSymbol;
    private DataGridViewTextBoxColumn ColStatus;
    private TextBox txtSymbol;
    private NumericUpDown DPRupdown;
    private Label label1;
    private Label label2;
    private Button btnSave;
    private GroupBox groupBox2;
    private Label label3;

    public frmDPRLimitfilter(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.rdoMcx.Visible = true;
            break;
          case 2:
            this.rdoNseFut.Visible = true;
            break;
          case 3:
            this.rdoncdex.Visible = true;
            break;
          case 4:
            this.rdoNsecurr.Visible = true;
            break;
        }
      }
    }

    private void LoadSymbols(int exch)
    {
      this.dgvContracts.Rows.Clear();
      List<string> stringList = new List<string>();
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
      {
        if (!stringList.Contains(keyValuePair.Value.SymDesp))
        {
          int index = this.dgvContracts.Rows.Add();
          this.dgvContracts.Rows[index].Cells[0].Value = (object) keyValuePair.Value.SymDesp;
          this.dgvContracts.Rows[index].Cells[1].Value = !this.objdash._SymbolwiseDPRLimit.ContainsKey(keyValuePair.Value.SymDesp) ? (object) "0" : (object) this.objdash._SymbolwiseDPRLimit[keyValuePair.Value.SymDesp];
          stringList.Add(keyValuePair.Value.symbol);
        }
      }
    }

    private void rdoMcx_Click(object sender, EventArgs e)
    {
      this.rdoMcx.Checked = true;
      this.LoadSymbols(1);
    }

    private void rdoNseFut_Click(object sender, EventArgs e)
    {
      this.rdoNseFut.Checked = true;
      this.LoadSymbols(2);
    }

    private void rdoncdex_Click(object sender, EventArgs e)
    {
      this.rdoncdex.Checked = true;
      this.LoadSymbols(3);
    }

    private void rdoNsecurr_Click(object sender, EventArgs e)
    {
      this.rdoNsecurr.Checked = true;
      this.LoadSymbols(4);
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.txtSymbol.Text == string.Empty)
        this.objdash.DisplayMessage("Select Symbol to save DPR Limit", 2);
      else if (this.DPRupdown.Value < Decimal.Zero)
      {
        this.objdash.DisplayMessage("DPRLimit should be higher than 0", 2);
      }
      else
      {
        SqlCommand sqlCommand1 = new SqlCommand("SaveDPRLimit", this.objdash.getConn());
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@dacode", (object) this.objdash.objinfo.clientcode);
          sqlCommand2.Parameters.AddWithValue("@dprlimit", (object) this.DPRupdown.Value);
          sqlCommand2.Parameters.AddWithValue("@symbol", (object) this.txtSymbol.Text);
          try
          {
            sqlCommand2.ExecuteNonQuery();
            this.dgvContracts.Rows[this.gridIndex].Cells[1].Value = (object) this.DPRupdown.Value;
            this.objdash.ManageDPRLimit(this.txtSymbol.Text, Convert.ToDouble(this.DPRupdown.Value));
            this.objdash.DisplayMessage("DPR Limit saved Successfully!!", 1);
          }
          catch
          {
            this.objdash.DisplayMessage("Unable to save DPR Limit", 3);
          }
        }
      }
    }

    private void dgvContracts_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (this.dgvContracts.Rows.Count <= 0)
        return;
      this.gridIndex = e.RowIndex;
      this.txtSymbol.Text = this.dgvContracts.Rows[this.gridIndex].Cells[0].Value.ToString();
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoNsecurr = new RadioButton();
      this.rdoncdex = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.dgvContracts = new DataGridView();
      this.ColSymbol = new DataGridViewTextBoxColumn();
      this.ColStatus = new DataGridViewTextBoxColumn();
      this.txtSymbol = new TextBox();
      this.DPRupdown = new NumericUpDown();
      this.label1 = new Label();
      this.label2 = new Label();
      this.btnSave = new Button();
      this.groupBox2 = new GroupBox();
      this.label3 = new Label();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgvContracts).BeginInit();
      this.DPRupdown.BeginInit();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoncdex);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(7, 5);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(285, 42);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchanges";
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(202, 16);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 7;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNsecurr.Click += new EventHandler(this.rdoNsecurr_Click);
      this.rdoncdex.AutoSize = true;
      this.rdoncdex.Location = new Point(134, 16);
      this.rdoncdex.Name = "rdoncdex";
      this.rdoncdex.Size = new Size(62, 17);
      this.rdoncdex.TabIndex = 6;
      this.rdoncdex.Text = "NCDEX";
      this.rdoncdex.UseVisualStyleBackColor = true;
      this.rdoncdex.Visible = false;
      this.rdoncdex.Click += new EventHandler(this.rdoncdex_Click);
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(60, 16);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 5;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoNseFut.Click += new EventHandler(this.rdoNseFut_Click);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(6, 16);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 4;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.rdoMcx.Click += new EventHandler(this.rdoMcx_Click);
      this.dgvContracts.AllowUserToAddRows = false;
      this.dgvContracts.AllowUserToDeleteRows = false;
      this.dgvContracts.AllowUserToOrderColumns = true;
      this.dgvContracts.AllowUserToResizeRows = false;
      this.dgvContracts.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
      this.dgvContracts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvContracts.Columns.AddRange((DataGridViewColumn) this.ColSymbol, (DataGridViewColumn) this.ColStatus);
      this.dgvContracts.Location = new Point(7, 134);
      this.dgvContracts.Name = "dgvContracts";
      this.dgvContracts.ReadOnly = true;
      this.dgvContracts.RowHeadersVisible = false;
      this.dgvContracts.Size = new Size(285, 344);
      this.dgvContracts.TabIndex = 4;
      this.dgvContracts.CellClick += new DataGridViewCellEventHandler(this.dgvContracts_CellClick);
      this.ColSymbol.HeaderText = "Symbol";
      this.ColSymbol.Name = "ColSymbol";
      this.ColSymbol.ReadOnly = true;
      this.ColSymbol.Width = 180;
      this.ColStatus.HeaderText = "DPR_Limit";
      this.ColStatus.Name = "ColStatus";
      this.ColStatus.ReadOnly = true;
      this.txtSymbol.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.txtSymbol.Location = new Point(6, 32);
      this.txtSymbol.Name = "txtSymbol";
      this.txtSymbol.ReadOnly = true;
      this.txtSymbol.Size = new Size(139, 20);
      this.txtSymbol.TabIndex = 5;
      this.DPRupdown.DecimalPlaces = 2;
      this.DPRupdown.Increment = new Decimal(new int[4]
      {
        5,
        0,
        0,
        131072
      });
      this.DPRupdown.Location = new Point(151, 32);
      this.DPRupdown.Name = "DPRupdown";
      this.DPRupdown.Size = new Size(69, 20);
      this.DPRupdown.TabIndex = 6;
      this.label1.AutoSize = true;
      this.label1.Location = new Point(6, 16);
      this.label1.Name = "label1";
      this.label1.Size = new Size(41, 13);
      this.label1.TabIndex = 7;
      this.label1.Text = "Symbol";
      this.label2.AutoSize = true;
      this.label2.Location = new Point(148, 16);
      this.label2.Name = "label2";
      this.label2.Size = new Size(54, 13);
      this.label2.TabIndex = 8;
      this.label2.Text = "DPR Limit";
      this.btnSave.Location = new Point(225, 29);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(60, 23);
      this.btnSave.TabIndex = 9;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.groupBox2.Controls.Add((Control) this.label1);
      this.groupBox2.Controls.Add((Control) this.btnSave);
      this.groupBox2.Controls.Add((Control) this.txtSymbol);
      this.groupBox2.Controls.Add((Control) this.label2);
      this.groupBox2.Controls.Add((Control) this.DPRupdown);
      this.groupBox2.Location = new Point(7, 51);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(285, 61);
      this.groupBox2.TabIndex = 10;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "DPR Settings";
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label3.ForeColor = Color.Red;
      this.label3.Location = new Point(10, 117);
      this.label3.Name = "label3";
      this.label3.Size = new Size(148, 15);
      this.label3.TabIndex = 11;
      this.label3.Text = "* Click on symbol to select";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(304, 493);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.dgvContracts);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (frmDPRLimitfilter);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "DPR Limit Settings";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgvContracts).EndInit();
      this.DPRupdown.EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
