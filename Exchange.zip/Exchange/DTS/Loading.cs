﻿// Decompiled with JetBrains decompiler
// Type: DTS.Loading
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class Loading : Form
  {
    public int conflag = 0;
    public int feedconflag = 0;
    private IContainer components = (IContainer) null;
    private SqlConnection conn;
    private SqlConnection feedconn;
    private Dashboard objdash;
    private PictureBox pictureBox1;
    private ProgressBar progressBar1;
    private Label label1;

    public Loading(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    private void Loading_Load(object sender, EventArgs e)
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.ConnectServer())).Invoke)).Start();
    }

    private void ConnectServer()
    {
      this.Invoke((Delegate) (() => this.label1.Text = "Connecting..."));
      ServerSwitch serverSwitch = new ServerSwitch(this.objdash);
      serverSwitch.ShowDialog();
      DialogResult result = serverSwitch.result;
      if (result.ToString() == "OK")
      {
        this.conn = new SqlConnection(Utils.Getconnsss());
        try
        {
          this.conn.Open();
          this.objdash.InsertMsgBoard(" Connected to Trading server 1 Successfully!!", 2);
          this.conflag = 1;
        }
        catch (SqlException ex)
        {
          if (this.conn.State == ConnectionState.Closed)
          {
            int num = (int) MessageBox.Show("Unable to connect to Trading Server 1, Please check you internet connection and try again later", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return;
          }
        }
        this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstringNEW));
        try
        {
          this.feedconn.Open();
          this.objdash.InsertMsgBoard(" Connected to Feed server 1 Successfully!!", 2);
          this.feedconflag = 1;
        }
        catch
        {
          if (this.feedconn.State == ConnectionState.Closed)
          {
            int num = (int) MessageBox.Show("Unable to connect to FeedServer 1, Please check you internet connection and try again later", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return;
          }
        }
        this.objdash.flag = this.conflag;
      }
      if (result.ToString() == "No")
      {
        if (this.conflag != 1 && this.feedconflag != 1)
        {
          this.conn = new SqlConnection(Utils.Get_SERVER2connsss());
          try
          {
            this.conn.Open();
            this.objdash.InsertMsgBoard(" Connected to Trading server 2 Successfully!!", 2);
            this.conflag = 2;
          }
          catch (SqlException ex)
          {
            if (this.conn.State == ConnectionState.Closed)
            {
              int num = (int) MessageBox.Show("Unable to connect to Trading Server 2, Please check you internet connection and try again later", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
          }
          this.feedconn = new SqlConnection(Dashboard.Decryptdata(Settings.Default.FeedConnstring_236));
          try
          {
            this.feedconn.Open();
            this.objdash.InsertMsgBoard(" Connected to Feed server 2 Successfully!!", 2);
            this.feedconflag = 2;
          }
          catch
          {
            if (this.feedconn.State == ConnectionState.Closed)
            {
              int num = (int) MessageBox.Show("Unable to connect to FeedServer 2, Please check you internet connection and try again later", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
          }
        }
        this.objdash.flag = this.conflag;
      }
      this.objdash.conn = this.conn;
      this.objdash.feedconn = this.feedconn;
      this.Invoke((Delegate) (() =>
      {
        if (Settings.Default.Autologin)
        {
          this.Invoke((Delegate) (() =>
          {
            this.label1.Text = "Attempting Auto-Login...";
            Application.DoEvents();
          }));
          if (this.objdash.ValidateLogin(Settings.Default.Username, this.objdash.Encryptdata(Settings.Default.Password)))
          {
            if (this.objdash.objinfo.userstatus == 0)
            {
              this.objdash.DisplayMessage("Your ID has been Blocked, Please Contact Admin.", 2);
              this.Hide();
            }
            else if (Convert.ToInt32((this.objdash.GetServerTime() - this.objdash.objinfo.Lastlogin).TotalSeconds) < 25)
            {
              this.objdash.DisplayMessage("You are already logged in on some other terminal.", 2);
              this.Hide();
            }
            else
            {
              this.Hide();
              this.objdash.UpdateLoginStatus(this.objdash.objinfo);
            }
          }
          else
          {
            this.objdash.DisplayMessage("Invalid Login credentials found, please enter login credentials.", 2);
            this.Hide();
            Login login = new Login(this.objdash, this.conn)
            {
              MdiParent = (Form) this.objdash
            };
            login.Loadwindow();
            login.Show();
          }
        }
        else
        {
          this.Hide();
          Login login = new Login(this.objdash, this.conn)
          {
            MdiParent = (Form) this.objdash
          };
          login.Loadwindow();
          login.Show();
        }
      }));
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.pictureBox1 = new PictureBox();
      this.progressBar1 = new ProgressBar();
      this.label1 = new Label();
      ((ISupportInitialize) this.pictureBox1).BeginInit();
      this.SuspendLayout();
      this.pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
      this.pictureBox1.Location = new Point(12, 12);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new Size(59, 48);
      this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
      this.pictureBox1.TabIndex = 3;
      this.pictureBox1.TabStop = false;
      this.progressBar1.Location = new Point(89, 47);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new Size(198, 10);
      this.progressBar1.Style = ProgressBarStyle.Marquee;
      this.progressBar1.TabIndex = 5;
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(86, 12);
      this.label1.Name = "label1";
      this.label1.Size = new Size(82, 18);
      this.label1.TabIndex = 4;
      this.label1.Text = "Loading...";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(299, 78);
      this.Controls.Add((Control) this.progressBar1);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.pictureBox1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (Loading);
      this.ShowIcon = false;
      this.ShowInTaskbar = false;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = nameof (Loading);
      this.Load += new EventHandler(this.Loading_Load);
      ((ISupportInitialize) this.pictureBox1).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
