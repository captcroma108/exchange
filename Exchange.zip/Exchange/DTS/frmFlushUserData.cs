﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmFlushUserData
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmFlushUserData : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public SqlConnection conn;
    private RadioButton rdoAll;
    private RadioButton rdoUserwise;
    private GroupBox groupBox1;
    private Button btnFlushData;
    private ProgressBar progressBar1;
    private ComboBox cmbClientCode;

    public frmFlushUserData(Dashboard dash, SqlConnection db)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = db;
      this.Icon = this.objdash.ico;
    }

    public void LoadWindow()
    {
      this.cmbClientCode.Items.Clear();
      if (this.objdash.objinfo.usertype == 1)
      {
        foreach (KeyValuePair<string, Dictionary<string, Userinfo>> keyValuePair in this.objdash._DAHierarchy)
          this.cmbClientCode.Items.Add((object) keyValuePair.Key);
      }
      if (this.cmbClientCode.Items.Count <= 0)
        return;
      this.cmbClientCode.SelectedIndex = 0;
    }

    private void btnFlushData_Click(object sender, EventArgs e)
    {
      this.btnFlushData.Enabled = false;
      if (this.rdoAll.Checked)
      {
        this.progressBar1.Maximum = 27;
        this.progressBar1.Minimum = 0;
        this.progressBar1.Value = 1;
        string clientCodes = this.objdash.GetClientCodes(1, "");
        Utils.SaveMiscLogs(this.objdash.objinfo.clientcode, string.Format("All user data deleted by: {0} from Flush User Data window.", (object) this.objdash.objinfo.clientcode), this.conn);
        if (clientCodes != string.Empty)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Brokerage where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where ClientCode = '" + this.objdash.objinfo.clientcode + "'", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from ExchwiseMarginLots where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from IntraSqOffTiming where ClientCode = '" + this.objdash.objinfo.clientcode + "'", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from LogIn_OffReports where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageBoard where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Offset where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Offset where ClientCode = '" + this.objdash.objinfo.clientcode + "'", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Payin_Payout where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Profit_Loss_Archive where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from RejectionMessages where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from SymbolwiseMargin where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from SymbolwiseMargin where ClientCode = '" + this.objdash.objinfo.clientcode + "'", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from TurnoverUtilised where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Userinformation where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
        }
      }
      else if (this.rdoUserwise.Checked)
      {
        this.progressBar1.Maximum = 23;
        this.progressBar1.Minimum = 0;
        this.progressBar1.Value = 1;
        string clientCodes = this.objdash.GetClientCodes(0, this.cmbClientCode.Text);
        Utils.SaveMiscLogs(this.objdash.objinfo.clientcode, string.Format("ClientCode: {0} data deleted by: {1} from Flush User Data window.", (object) clientCodes, (object) this.objdash.objinfo.clientcode), this.conn);
        if (clientCodes != string.Empty)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Brokerage where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from ContractStatus where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from ExchwiseMarginLots where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Limitset_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from LogIn_OffReports where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageBoard where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from MessageLogs_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Modified_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Offset where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Orders_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Payin_Payout where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Profit_Loss_Archive where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from RejectionMessages where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from SymbolwiseMargin where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Trade_History where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from TurnoverUtilised where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
          Thread.Sleep(300);
          using (SqlCommand sqlCommand = new SqlCommand("Delete from Userinformation where ClientCode in (" + clientCodes + ")", this.conn))
          {
            try
            {
              sqlCommand.ExecuteNonQuery();
              this.progressBar1.PerformStep();
            }
            catch
            {
            }
          }
        }
      }
      this.btnFlushData.Enabled = true;
      this.progressBar1.Value = 0;
    }

    private void rdoAll_Click(object sender, EventArgs e)
    {
      if (!this.rdoAll.Checked)
        return;
      this.groupBox1.Visible = false;
    }

    private void rdoUserwise_Click(object sender, EventArgs e)
    {
      if (!this.rdoUserwise.Checked)
        return;
      this.groupBox1.Visible = true;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.rdoAll = new RadioButton();
      this.rdoUserwise = new RadioButton();
      this.groupBox1 = new GroupBox();
      this.cmbClientCode = new ComboBox();
      this.btnFlushData = new Button();
      this.progressBar1 = new ProgressBar();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      this.rdoAll.AutoSize = true;
      this.rdoAll.Location = new Point(12, 12);
      this.rdoAll.Name = "rdoAll";
      this.rdoAll.Size = new Size(115, 17);
      this.rdoAll.TabIndex = 0;
      this.rdoAll.Text = "Flush All User Data";
      this.rdoAll.UseVisualStyleBackColor = true;
      this.rdoAll.Click += new EventHandler(this.rdoAll_Click);
      this.rdoUserwise.AutoSize = true;
      this.rdoUserwise.Location = new Point(156, 12);
      this.rdoUserwise.Name = "rdoUserwise";
      this.rdoUserwise.Size = new Size(139, 17);
      this.rdoUserwise.TabIndex = 1;
      this.rdoUserwise.Text = "Flush User ID wise Data";
      this.rdoUserwise.UseVisualStyleBackColor = true;
      this.rdoUserwise.Click += new EventHandler(this.rdoUserwise_Click);
      this.groupBox1.Controls.Add((Control) this.cmbClientCode);
      this.groupBox1.Location = new Point(12, 35);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(302, 59);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Dealer Admin id";
      this.groupBox1.Visible = false;
      this.cmbClientCode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientCode.FormattingEnabled = true;
      this.cmbClientCode.Location = new Point(91, 19);
      this.cmbClientCode.Name = "cmbClientCode";
      this.cmbClientCode.Size = new Size(121, 21);
      this.cmbClientCode.TabIndex = 0;
      this.btnFlushData.Location = new Point(122, 110);
      this.btnFlushData.Name = "btnFlushData";
      this.btnFlushData.Size = new Size(82, 23);
      this.btnFlushData.TabIndex = 3;
      this.btnFlushData.Text = "Flush Data";
      this.btnFlushData.UseVisualStyleBackColor = true;
      this.btnFlushData.Click += new EventHandler(this.btnFlushData_Click);
      this.progressBar1.Dock = DockStyle.Bottom;
      this.progressBar1.Location = new Point(0, 146);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new Size(326, 17);
      this.progressBar1.Step = 1;
      this.progressBar1.TabIndex = 4;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(326, 163);
      this.Controls.Add((Control) this.progressBar1);
      this.Controls.Add((Control) this.btnFlushData);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.rdoUserwise);
      this.Controls.Add((Control) this.rdoAll);
      this.MaximizeBox = false;
      this.Name = nameof (frmFlushUserData);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Flush UserData";
      this.groupBox1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
