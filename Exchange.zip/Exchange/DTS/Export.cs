﻿// Decompiled with JetBrains decompiler
// Type: DTS.Export
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using Microsoft.CSharp.RuntimeBinder;
using Microsoft.Office.Interop.Excel;
using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace DTS
{
  public class Export
  {
    public static int i = 0;

    public static void ExportToExcel(DataGridView objgrid, bool iscnf = false)
    {
      string empty = string.Empty;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.CheckPathExists = true;
      saveFileDialog1.InitialDirectory = "C:\\";
      saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        string fileName = saveFileDialog2.FileName;
        using (StreamWriter streamWriter = new StreamWriter(fileName))
        {
          if (true)
          {
            string str1 = string.Empty;
            for (int index = 0; index < objgrid.Columns.Count; ++index)
            {
              if (objgrid.Columns[index].Visible)
                str1 = str1 + objgrid.Columns[index].HeaderText + ",";
            }
            string str2 = str1.Substring(0, str1.Length - 1) + "\r";
            streamWriter.Write(str2);
          }
          int count = objgrid.Rows.Count;
          for (int index1 = 0; index1 < count; ++index1)
          {
            string str1 = string.Empty;
            if (objgrid.Rows[index1].Visible)
            {
              for (int index2 = 0; index2 < objgrid.Columns.Count; ++index2)
              {
                if (objgrid.Columns[index2].Visible)
                  str1 = str1 + objgrid[index2, index1].Value + ",";
              }
              string str2 = str1.Replace("\n", "");
              string str3 = str2.Substring(0, str2.Length - 1) + "\r";
              streamWriter.Write(str3);
            }
          }
        }
        int num = (int) MessageBox.Show(string.Format("Excel file Created {0}", (object) fileName), "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
      }
    }

    public static void ExportText(
      DataGridView objgrid,
      Dashboard objdash,
      string exchange,
      bool isMIS)
    {
      string empty = string.Empty;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.CheckPathExists = true;
      saveFileDialog1.InitialDirectory = "C:\\";
      saveFileDialog1.Filter = "(*.txt)|*.txt|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        string fileName = saveFileDialog2.FileName;
        using (StreamWriter streamWriter = new StreamWriter(fileName))
        {
          if (isMIS)
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string str1 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str2 = objgrid.Rows[index].Cells[0].Value.ToString();
                string exch = objgrid.Rows[index].Cells[1].Value.ToString();
                string[] strArray = objgrid.Rows[index].Cells[2].Value.ToString().Split(' ');
                string str3 = strArray[0];
                string str4 = strArray[1];
                Contracts contract = objdash.GetContract(str3 + " " + str4);
                string str5 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str6 = objgrid.Rows[index].Cells[4].Value.ToString();
                int num1 = 1;
                if (str6.Substring(0, 1).ToUpper() == "S")
                  num1 = 2;
                string str7 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[13].Value.ToString();
                objgrid.Rows[index].Cells[6].Value.ToString();
                DateTime dateTime = Convert.ToDateTime(objgrid.Rows[index].Cells[9].Value);
                string str9 = string.Format("{0}:{1}:{2}", (object) dateTime.Hour, (object) dateTime.Minute, (object) dateTime.Second);
                int num2 = dateTime.Day;
                string str10 = num2.ToString();
                if (str10.Length == 1)
                  str10 = "0" + str10;
                string str11 = string.Format("{0} {1} {2} {3}", (object) str10, (object) Utils.GetMonth(dateTime.Month), (object) dateTime.Year, (object) str9);
                string str12 = objgrid.Rows[index].Cells[9].Value.ToString();
                if (str12.ToUpper() == "ADMIN")
                  str12 = str2;
                string str13 = objgrid.Rows[index].Cells[10].Value.ToString();
                string instrument = Export.GetInstrument(exch, contract.symbol);
                string symbol = contract.symbol;
                num2 = contract.expiry.Year;
                string str14 = num2.ToString().Substring(2, 2);
                string str15 = string.Format("{0}{1}FUT", (object) symbol, (object) str14);
                if (exch == exchange)
                {
                  string upper = exchange.ToUpper();
                  if (!(upper == "MCX"))
                  {
                    if (!(upper == "NCDEX"))
                    {
                      if (!(upper == "NSEFUT"))
                      {
                        if (!(upper == "NSEOPT"))
                        {
                          if (upper == "NSECURR")
                            str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,3293,1,{6},{7},{8},1,{9},13797,OPEN,UNCOVER,{10},{11},{12},13797,{13},110034000000000\r\n", (object) 0, (object) "FUTCUR", (object) str3, (object) str4, (object) str15, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11);
                        }
                        else
                          str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,{6},1,{7},{8},{9},1,{10},13797,OPEN,UNCOVER,{11},{12},{13},13797,{14},111111111111113\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str15, (object) str5, (object) str2, (object) num1, (object) str7, (object) str8, (object) str12, (object) str11, (object) str11, (object) str13, (object) str11);
                      }
                      else
                        str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,{6},1,{7},{8},{9},1,{10},13797,OPEN,UNCOVER,{11},{12},{13},13797,{14},111111111111113\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str15, (object) str5, (object) str2, (object) num1, (object) str7, (object) str8, (object) str12, (object) str11, (object) str11, (object) str13, (object) str11);
                    }
                    else
                      str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,11108,1,{6},{7},{8},1,{9},900,OPEN,UNCOVER,{10},{11},{12}\r\n", (object) 0, (object) "FUTCOM", (object) str3, (object) str4, (object) str3, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13);
                  }
                  else
                    str1 = string.Format("{0},11,4,{1},{2},{3},,,,{4},1,{5},1,35557,0,{6},{7},{8},1,{9},35555,,35555,,{10},{11},{12},NIL,,{13},{14},,,0,0,,0\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str3, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11, (object) str11);
                }
                streamWriter.Write(str1);
              }
            }
          }
          else
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string str1 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str2 = objgrid.Rows[index].Cells[0].Value.ToString();
                string exch = objgrid.Rows[index].Cells[2].Value.ToString();
                string str3 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str4 = objgrid.Rows[index].Cells[4].Value.ToString();
                Contracts contract = objdash.GetContract(str3 + " " + str4);
                string str5 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str6 = objgrid.Rows[index].Cells[7].Value.ToString();
                int num1 = 1;
                if (str6.Substring(0, 1).ToUpper() == "S")
                  num1 = 2;
                string str7 = objgrid.Rows[index].Cells[8].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[10].Value.ToString();
                objgrid.Rows[index].Cells[11].Value.ToString();
                string str9 = objgrid.Rows[index].Cells[12].Value.ToString();
                int num2 = DateTime.Now.Day;
                string str10 = num2.ToString();
                if (str10.Length == 1)
                  str10 = "0" + str10;
                object[] objArray = new object[4]
                {
                  (object) str10,
                  null,
                  null,
                  null
                };
                DateTime now = DateTime.Now;
                objArray[1] = (object) Utils.GetMonth(now.Month);
                now = DateTime.Now;
                objArray[2] = (object) now.Year;
                objArray[3] = (object) str9;
                string str11 = string.Format("{0} {1} {2} {3}", objArray);
                string str12 = objgrid.Rows[index].Cells[14].Value.ToString();
                if (str12.ToUpper() == "ADMIN")
                  str12 = str2;
                string str13 = objgrid.Rows[index].Cells[15].Value.ToString();
                string instrument = Export.GetInstrument(exch, contract.symbol);
                string symbol = contract.symbol;
                num2 = contract.expiry.Year;
                string str14 = num2.ToString().Substring(2, 2);
                string str15 = string.Format("{0}{1}FUT", (object) symbol, (object) str14);
                if (exch == exchange)
                {
                  string upper = exchange.ToUpper();
                  if (!(upper == "MCX"))
                  {
                    if (!(upper == "NCDEX"))
                    {
                      if (!(upper == "NSEFUT"))
                      {
                        if (!(upper == "NSEOPT"))
                        {
                          if (upper == "NSECURR")
                            str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,3293,1,{6},{7},{8},1,{9},13797,OPEN,UNCOVER,{10},{11},{12},13797,{13},110034000000000\r\n", (object) 0, (object) "FUTCUR", (object) str3, (object) str4, (object) str15, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11);
                        }
                        else
                          str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,{6},1,{7},{8},{9},1,{10},13797,OPEN,UNCOVER,{11},{12},{13},13797,{14},111111111111113\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str15, (object) str5, (object) str2, (object) num1, (object) str7, (object) str8, (object) str12, (object) str11, (object) str11, (object) str13, (object) str11);
                      }
                      else
                        str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,{6},1,{7},{8},{9},1,{10},13797,OPEN,UNCOVER,{11},{12},{13},13797,{14},111111111111113\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str15, (object) str5, (object) str2, (object) num1, (object) str7, (object) str8, (object) str12, (object) str11, (object) str11, (object) str13, (object) str11);
                    }
                    else
                      str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,11108,1,{6},{7},{8},1,{9},900,OPEN,UNCOVER,{10},{11},{12}\r\n", (object) 0, (object) "FUTCOM", (object) str3, (object) str4, (object) str3, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13);
                  }
                  else
                    str1 = string.Format("{0},11,4,{1},{2},{3},,,,{4},1,{5},1,35557,0,{6},{7},{8},1,{9},35555,,35555,,{10},{11},{12},NIL,,{13},{14},,,0,0,,0\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str3, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11, (object) str11);
                }
                streamWriter.Write(str1);
              }
            }
          }
          int num = (int) MessageBox.Show(string.Format("Txt file Created {0}", (object) fileName), "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
      }
    }

    public static void ExporttoSauda(DataGridView objgrid, Dashboard objdash, bool isMIS)
    {
      string empty1 = string.Empty;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.CheckPathExists = true;
      saveFileDialog1.InitialDirectory = "C:\\";
      saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        string fileName = saveFileDialog2.FileName;
        using (StreamWriter streamWriter = new StreamWriter(fileName))
        {
          streamWriter.Write("Clientcode,Createon,Buysell,Symbol,ExpiryDate,Qty,Price,Exchange,Ordertype,Validity,Lastmodified,Userremarks,Traderid,Orderno,Orderstatus\r\n");
          if (isMIS)
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string empty2 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str1 = objgrid.Rows[index].Cells[0].Value.ToString();
                objgrid.Rows[index].Cells[1].Value.ToString();
                string symbol = objgrid.Rows[index].Cells[2].Value.ToString();
                Contracts contract = objdash.GetContract(symbol);
                string str2 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str3 = objgrid.Rows[index].Cells[4].Value.ToString();
                string str4 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str5 = objgrid.Rows[index].Cells[6].Value.ToString();
                string str6 = objgrid.Rows[index].Cells[7].Value.ToString();
                DateTime dateTime = Convert.ToDateTime(objgrid.Rows[index].Cells[8].Value);
                Convert.ToDateTime(objgrid.Rows[index].Cells[9].Value);
                string str7 = objgrid.Rows[index].Cells[10].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[11].Value.ToString();
                if (str8.ToUpper() == "ADMIN")
                  str8 = str1;
                string str9 = objgrid.Rows[index].Cells[12].Value.ToString();
                string str10 = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}\r\n", (object) str1, (object) dateTime.ToString("dd/MM/yyyy HH:mm"), (object) str3, (object) symbol, (object) contract.expiry.ToString("dd/MM/yyyy"), (object) str4, (object) str5, (object) Utils.GetExch(contract.exch), (object) str2, (object) str6, (object) dateTime.ToString("dd/MM/yyyy HH:mm"), (object) str7, (object) str8, (object) str9, (object) "1");
                streamWriter.Write(str10);
              }
            }
          }
          else
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string empty2 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str1 = objgrid.Rows[index].Cells[0].Value.ToString();
                string exch = objgrid.Rows[index].Cells[2].Value.ToString();
                string str2 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str3 = objgrid.Rows[index].Cells[4].Value.ToString();
                Contracts contract = objdash.GetContract(str2 + " " + str3);
                string str4 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str5 = objgrid.Rows[index].Cells[7].Value.ToString();
                int num1 = 1;
                if (str5.Substring(0, 1).ToUpper() == "S")
                  num1 = 2;
                string str6 = objgrid.Rows[index].Cells[8].Value.ToString();
                string str7 = objgrid.Rows[index].Cells[10].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[11].Value.ToString();
                string str9 = objgrid.Rows[index].Cells[12].Value.ToString();
                DateTime now1 = DateTime.Now;
                int num2 = now1.Day;
                string str10 = num2.ToString();
                if (str10.Length == 1)
                  str10 = "0" + str10;
                object[] objArray = new object[4]
                {
                  (object) str10,
                  null,
                  null,
                  null
                };
                now1 = DateTime.Now;
                objArray[1] = (object) Utils.GetMonth(now1.Month);
                now1 = DateTime.Now;
                objArray[2] = (object) now1.Year;
                objArray[3] = (object) str9;
                string.Format("{0} {1} {2} {3}", objArray);
                string str11 = objgrid.Rows[index].Cells[13].Value.ToString();
                string str12 = objgrid.Rows[index].Cells[14].Value.ToString();
                if (str12.ToUpper() == "ADMIN")
                  str12 = str1;
                string orderno = objgrid.Rows[index].Cells[15].Value.ToString();
                Export.GetInstrument(exch, contract.symbol);
                string symbol = contract.symbol;
                num2 = contract.expiry.Year;
                string str13 = num2.ToString().Substring(2, 2);
                string.Format("{0}{1}FUT", (object) symbol, (object) str13);
                DateTime now2 = DateTime.Now;
                DateTime now3 = DateTime.Now;
                objdash.GetOrdernowiseDatetime(ref now2, ref now3, orderno);
                string str14 = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}\r\n", (object) str1, (object) now2.ToString("dd/MM/yyyy HH:mm"), (object) num1, (object) str2, (object) contract.expiry.ToString("dd/MM/yyyy"), (object) str6, (object) str7, (object) Utils.GetExch(contract.exch), (object) str4, (object) str8, (object) now2.ToString("dd/MM/yyyy HH:mm"), (object) str11, (object) str12, (object) orderno, (object) "1");
                streamWriter.Write(str14);
              }
            }
          }
          int num = (int) MessageBox.Show(string.Format("Excel file Created {0}", (object) fileName), "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
      }
    }

    public static void ExporttoSaudaNew(DataGridView objgrid, Dashboard objdash, bool isMIS)
    {
      string empty1 = string.Empty;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.CheckPathExists = true;
      saveFileDialog1.InitialDirectory = "C:\\";
      saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        string fileName = saveFileDialog2.FileName;
        using (StreamWriter streamWriter = new StreamWriter(fileName))
        {
          streamWriter.Write("tradedate,party,scipt name,expiry,qty buy/sell,rate,rate,brokercode\r\n");
          if (isMIS)
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string empty2 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str1 = objgrid.Rows[index].Cells[0].Value.ToString();
                string symbol = objgrid.Rows[index].Cells[2].Value.ToString();
                Contracts contract = objdash.GetContract(symbol);
                string str2 = objgrid.Rows[index].Cells[4].Value.ToString();
                string str3 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str4 = objgrid.Rows[index].Cells[6].Value.ToString();
                Convert.ToDateTime(objgrid.Rows[index].Cells[8].Value);
                DateTime dateTime = Convert.ToDateTime(objgrid.Rows[index].Cells[9].Value);
                if (objgrid.Rows[index].Cells[11].Value.ToString().ToUpper() == "ADMIN")
                  ;
                if (contract.exch == 1)
                  str3 = (Convert.ToInt32(str3) * contract.lotsize).ToString();
                if (str2.ToUpper() == "SELL")
                  str3 = "-" + str3;
                string str5 = string.Format("{0},{1},{2},{3},{4},{5},{6},{7}\r\n", (object) dateTime.ToString("dd/MM/yyyy"), (object) str1, (object) contract.symbol, (object) contract.expiry.ToString("dd/MM/yyyy"), (object) str3, (object) str4, (object) str4, (object) 121);
                streamWriter.Write(str5);
              }
            }
          }
          else
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string empty2 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str1 = objgrid.Rows[index].Cells[0].Value.ToString();
                string exch = objgrid.Rows[index].Cells[2].Value.ToString();
                string str2 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str3 = objgrid.Rows[index].Cells[4].Value.ToString();
                Contracts contract = objdash.GetContract(str2 + " " + str3);
                string str4 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str5 = objgrid.Rows[index].Cells[7].Value.ToString();
                int num1 = 1;
                if (str5.Substring(0, 1).ToUpper() == "S")
                  num1 = 2;
                string str6 = objgrid.Rows[index].Cells[8].Value.ToString();
                string str7 = objgrid.Rows[index].Cells[10].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[11].Value.ToString();
                string str9 = objgrid.Rows[index].Cells[12].Value.ToString();
                DateTime now1 = DateTime.Now;
                int num2 = now1.Day;
                string str10 = num2.ToString();
                if (str10.Length == 1)
                  str10 = "0" + str10;
                object[] objArray = new object[4]
                {
                  (object) str10,
                  null,
                  null,
                  null
                };
                now1 = DateTime.Now;
                objArray[1] = (object) Utils.GetMonth(now1.Month);
                now1 = DateTime.Now;
                objArray[2] = (object) now1.Year;
                objArray[3] = (object) str9;
                string.Format("{0} {1} {2} {3}", objArray);
                string str11 = objgrid.Rows[index].Cells[13].Value.ToString();
                string str12 = objgrid.Rows[index].Cells[14].Value.ToString();
                if (str12.ToUpper() == "ADMIN")
                  str12 = str1;
                string orderno = objgrid.Rows[index].Cells[15].Value.ToString();
                Export.GetInstrument(exch, contract.symbol);
                string symbol = contract.symbol;
                num2 = contract.expiry.Year;
                string str13 = num2.ToString().Substring(2, 2);
                string.Format("{0}{1}FUT", (object) symbol, (object) str13);
                DateTime now2 = DateTime.Now;
                DateTime now3 = DateTime.Now;
                objdash.GetOrdernowiseDatetime(ref now2, ref now3, orderno);
                string str14 = string.Format("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14}\r\n", (object) str1, (object) now2.ToString("dd/MM/yyyy HH:mm"), (object) num1, (object) str2, (object) contract.expiry.ToString("dd/MM/yyyy"), (object) str6, (object) str7, (object) Utils.GetExch(contract.exch), (object) str4, (object) str8, (object) now2.ToString("dd/MM/yyyy HH:mm"), (object) str11, (object) str12, (object) orderno, (object) "1");
                streamWriter.Write(str14);
              }
            }
          }
          int num = (int) MessageBox.Show(string.Format("Excel file Created {0}", (object) fileName), "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
      }
    }

    private static string GetInstrument(string exch, string symbol)
    {
      string upper = exch.ToUpper();
      if (upper == "MCX")
        return "FUTCOM";
      if (!(upper == "NSEFUT"))
      {
        if (upper == "NCDEX")
          return "FUTCOM";
        if (upper == "NSECURR")
          return "FUTCUR";
        if (!(upper == "NSEOPT"))
          return "";
        return symbol == "NIFTY" || symbol == "BANKNIFTY" ? "OPTIDX" : "OPTSTK";
      }
      return symbol == "NIFTY" || symbol == "BANKNIFTY" ? "FUTIDX" : "FUTSTK";
    }

    public static void ExporttoShilpi(DataGridView objgrid, Dashboard objdash)
    {
      string empty1 = string.Empty;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.CheckPathExists = true;
      saveFileDialog1.InitialDirectory = "C:\\";
      saveFileDialog1.Filter = "(*.CSV)|*.csv|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        using (StreamWriter streamWriter = new StreamWriter(saveFileDialog2.FileName))
        {
          for (int index = 0; index < objgrid.Rows.Count; ++index)
          {
            string empty2 = string.Empty;
            if (objgrid.Rows[index].Visible)
            {
              string str1 = objgrid.Rows[index].Cells[0].Value.ToString();
              string exch = objgrid.Rows[index].Cells[1].Value.ToString();
              string symbol = objgrid.Rows[index].Cells[2].Value.ToString();
              Contracts contract = objdash.GetContract(symbol);
              string instrument = Export.GetInstrument(exch, contract.symbol);
              string str2 = objgrid.Rows[index].Cells[3].Value.ToString();
              int num1 = 1;
              if (str2 == "SL")
                num1 = 2;
              string str3 = objgrid.Rows[index].Cells[4].Value.ToString();
              int num2 = 1;
              if (str3 == "SELL")
                num2 = 2;
              string str4 = objgrid.Rows[index].Cells[5].Value.ToString();
              string str5 = objgrid.Rows[index].Cells[6].Value.ToString();
              objgrid.Rows[index].Cells[7].Value.ToString();
              DateTime dateTime1 = Convert.ToDateTime(objgrid.Rows[index].Cells[8].Value);
              DateTime dateTime2 = Convert.ToDateTime(objgrid.Rows[index].Cells[9].Value);
              objgrid.Rows[index].Cells[10].Value.ToString();
              if (objgrid.Rows[index].Cells[11].Value.ToString().ToUpper() == "ADMIN")
                ;
              string str6 = objgrid.Rows[index].Cells[12].Value.ToString();
              string str7 = string.Format("{0},11,4,{1},{2},{3},,,,{4},{5},{6},1,16594,0,{7},{8},{9},1,{10},16590,,16590,,{11},{12},{13},NIL,,{14},,,,\r\n", (object) (index + 1), (object) instrument, (object) contract.symbol, (object) contract.expiry.ToString("dd-MMM-yyyy"), (object) contract.symbol, (object) num1, (object) str2, (object) num2, (object) str4, (object) str5, (object) str1, (object) dateTime1.ToString("dd/MM/yyyy HH:mm"), (object) dateTime2.ToString("dd/MM/yyyy HH:mm"), (object) str6, (object) dateTime2.ToString("dd/MM/yyyy HH:mm"));
              streamWriter.Write(str7);
            }
          }
        }
      }
    }

    public static void ExporttoLogics(DataGridView objgrid, bool isMIS, Dashboard objdash)
    {
      string empty = string.Empty;
      SaveFileDialog saveFileDialog1 = new SaveFileDialog();
      saveFileDialog1.CheckPathExists = true;
      saveFileDialog1.InitialDirectory = "C:\\";
      saveFileDialog1.Filter = "(*.txt)|*.txt|All Files (*.*)|*.*";
      saveFileDialog1.FilterIndex = 1;
      using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
      {
        if (saveFileDialog2.ShowDialog() != DialogResult.OK)
          return;
        string fileName = saveFileDialog2.FileName;
        using (StreamWriter streamWriter = new StreamWriter(fileName))
        {
          if (isMIS)
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string str1 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str2 = objgrid.Rows[index].Cells[0].Value.ToString();
                string exch = objgrid.Rows[index].Cells[1].Value.ToString();
                string[] strArray = objgrid.Rows[index].Cells[2].Value.ToString().Split(' ');
                string str3 = strArray[0];
                string str4 = strArray[1];
                Contracts contract = objdash.GetContract(str3 + " " + str4);
                string str5 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str6 = objgrid.Rows[index].Cells[4].Value.ToString();
                int num = 1;
                if (str6.Substring(0, 1).ToUpper() == "S")
                  num = 2;
                string str7 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[13].Value.ToString();
                objgrid.Rows[index].Cells[6].Value.ToString();
                DateTime dateTime = Convert.ToDateTime(objgrid.Rows[index].Cells[8].Value);
                string str9 = dateTime.ToString("HH:mm:ss");
                dateTime = DateTime.Now;
                string str10 = dateTime.Day.ToString();
                if (str10.Length == 1)
                  str10 = "0" + str10;
                object[] objArray = new object[4]
                {
                  (object) str10,
                  null,
                  null,
                  null
                };
                dateTime = DateTime.Now;
                objArray[1] = (object) Utils.GetMonth(dateTime.Month);
                dateTime = DateTime.Now;
                objArray[2] = (object) dateTime.Year;
                objArray[3] = (object) str9;
                string str11 = string.Format("{0} {1} {2} {3}", objArray);
                string str12 = objgrid.Rows[index].Cells[9].Value.ToString();
                if (str12.ToUpper() == "ADMIN")
                  str12 = str2;
                string str13 = objgrid.Rows[index].Cells[10].Value.ToString();
                string instrument = Export.GetInstrument(exch, contract.symbol);
                string str14 = string.Format("{0}{1}FUT", (object) contract.symbol, (object) contract.expiry.Year.ToString().Substring(2, 2));
                if (exch == "NSEFUT")
                {
                  string upper = exch.ToUpper();
                  if (!(upper == "MCX"))
                  {
                    if (!(upper == "NCDEX"))
                    {
                      if (!(upper == "NSEFUT"))
                      {
                        if (!(upper == "NSEOPT"))
                        {
                          if (upper == "NSECURR")
                            str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,3293,1,{6},{7},{8},1,{9},13797,OPEN,UNCOVER,{10},{11},{12},13797,{13},110034000000000\r\n", (object) 0, (object) "FUTCUR", (object) str3, (object) str4, (object) str14, (object) str5, (object) num, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11);
                        }
                        else
                          str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,{6},1,{7},{8},{9},1,{10},13797,OPEN,UNCOVER,{11},{12},{13},13797,{14},111111111111113\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str14, (object) str5, (object) str2, (object) num, (object) str7, (object) str8, (object) str12, (object) str11, (object) str11, (object) str13, (object) str11);
                      }
                      else
                        str1 = string.Format("{0},11,{1},{2},{3},0.00,,{4},1,{5},1,{6},1,{7},{8},{9},2,TERMINA 1-CREAM,T001,OPEN,UNCOVER,{10},{11},{12},NIL,{13},{14}\r\n", (object) (index + 1), (object) instrument, (object) str3, (object) str4, (object) str3, (object) str5, (object) str2, (object) num, (object) str7, (object) str8, (object) str11, (object) str11, (object) (index + 1), (object) str11, (object) str2);
                    }
                    else
                      str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,11108,1,{6},{7},{8},1,{9},900,OPEN,UNCOVER,{10},{11},{12}\r\n", (object) 0, (object) "FUTCOM", (object) str3, (object) str4, (object) str3, (object) str5, (object) num, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13);
                  }
                  else
                    str1 = string.Format("{0},11,4,{1},{2},{3},,,,{4},1,{5},1,35557,0,{6},{7},{8},1,{9},35555,,35555,,{10},{11},{12},NIL,,{13},{14},,,0,0,,0\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str3, (object) str5, (object) num, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11, (object) str11);
                }
                streamWriter.Write(str1);
              }
            }
          }
          else
          {
            for (int index = 0; index < objgrid.Rows.Count; ++index)
            {
              string str1 = string.Empty;
              if (objgrid.Rows[index].Visible)
              {
                string str2 = objgrid.Rows[index].Cells[0].Value.ToString();
                string exch = objgrid.Rows[index].Cells[2].Value.ToString();
                string str3 = objgrid.Rows[index].Cells[3].Value.ToString();
                string str4 = objgrid.Rows[index].Cells[4].Value.ToString();
                Contracts contract = objdash.GetContract(str3 + " " + str4);
                string str5 = objgrid.Rows[index].Cells[5].Value.ToString();
                string str6 = objgrid.Rows[index].Cells[7].Value.ToString();
                int num1 = 1;
                if (str6.Substring(0, 1).ToUpper() == "S")
                  num1 = 2;
                string str7 = objgrid.Rows[index].Cells[8].Value.ToString();
                string str8 = objgrid.Rows[index].Cells[10].Value.ToString();
                objgrid.Rows[index].Cells[11].Value.ToString();
                string str9 = objgrid.Rows[index].Cells[12].Value.ToString();
                int num2 = DateTime.Now.Day;
                string str10 = num2.ToString();
                if (str10.Length == 1)
                  str10 = "0" + str10;
                object[] objArray = new object[4]
                {
                  (object) str10,
                  null,
                  null,
                  null
                };
                DateTime now = DateTime.Now;
                objArray[1] = (object) Utils.GetMonth(now.Month);
                now = DateTime.Now;
                objArray[2] = (object) now.Year;
                objArray[3] = (object) str9;
                string str11 = string.Format("{0} {1} {2} {3}", objArray);
                string str12 = objgrid.Rows[index].Cells[14].Value.ToString();
                if (str12.ToUpper() == "ADMIN")
                  str12 = str2;
                string str13 = objgrid.Rows[index].Cells[15].Value.ToString();
                string instrument = Export.GetInstrument(exch, contract.symbol);
                string symbol = contract.symbol;
                num2 = contract.expiry.Year;
                string str14 = num2.ToString().Substring(2, 2);
                string str15 = string.Format("{0}{1}FUT", (object) symbol, (object) str14);
                if (exch == "NSEFUT")
                {
                  string upper = exch.ToUpper();
                  if (!(upper == "MCX"))
                  {
                    if (!(upper == "NCDEX"))
                    {
                      if (!(upper == "NSEFUT"))
                      {
                        if (!(upper == "NSEOPT"))
                        {
                          if (upper == "NSECURR")
                            str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,3293,1,{6},{7},{8},1,{9},13797,OPEN,UNCOVER,{10},{11},{12},13797,{13},110034000000000\r\n", (object) 0, (object) "FUTCUR", (object) str3, (object) str4, (object) str15, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11);
                        }
                        else
                          str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,{6},1,{7},{8},{9},1,{10},13797,OPEN,UNCOVER,{11},{12},{13},13797,{14},111111111111113\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str15, (object) str5, (object) str2, (object) num1, (object) str7, (object) str8, (object) str12, (object) str11, (object) str11, (object) str13, (object) str11);
                      }
                      else
                        str1 = string.Format("{0},11,{1},{2},{3},0.00,,{4},1,{5},1,{6},1,{7},{8},{9},2,TERMINA 1-CREAM,T001,OPEN,UNCOVER,{10},{11},{12},NIL,{13},{14}\r\n", (object) (index + 1), (object) instrument, (object) str3, (object) str4, (object) str3, (object) str5, (object) str2, (object) num1, (object) str7, (object) str8, (object) str11, (object) str11, (object) (index + 1), (object) str11, (object) str2);
                    }
                    else
                      str1 = string.Format("{0},11,{1},{2},{3},,,{4},1,{5},1,11108,1,{6},{7},{8},1,{9},900,OPEN,UNCOVER,{10},{11},{12}\r\n", (object) 0, (object) "FUTCOM", (object) str3, (object) str4, (object) str3, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13);
                  }
                  else
                    str1 = string.Format("{0},11,4,{1},{2},{3},,,,{4},1,{5},1,35557,0,{6},{7},{8},1,{9},35555,,35555,,{10},{11},{12},NIL,,{13},{14},,,0,0,,0\r\n", (object) 0, (object) instrument, (object) str3, (object) str4, (object) str3, (object) str5, (object) num1, (object) str7, (object) str8, (object) str2, (object) str11, (object) str11, (object) str13, (object) str11, (object) str11);
                }
                streamWriter.Write(str1);
              }
            }
          }
          int num3 = (int) MessageBox.Show(string.Format("Txt file Created {0}", (object) fileName), "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
      }
    }

    public static void ExporttoVipulbhai(DataGridView objgrid, bool isMIS, Dashboard objdash)
    {
      using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
      {
        if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
          return;
        string selectedPath = folderBrowserDialog.SelectedPath;
        for (int index = 0; index < objgrid.Rows.Count; ++index)
        {
          string str1 = string.Empty;
          if (objgrid.Rows[index].Visible)
          {
            string str2 = objgrid.Rows[index].Cells[0].Value.ToString();
            string exch = objgrid.Rows[index].Cells[1].Value.ToString();
            string symbol = objgrid.Rows[index].Cells[2].Value.ToString();
            Contracts contract = objdash.GetContract(symbol);
            string instrument = Export.GetInstrument(exch, contract.symbol);
            string str3 = objgrid.Rows[index].Cells[4].Value.ToString();
            int num = 1;
            if (str3 == "SELL")
              num = 2;
            string str4 = objgrid.Rows[index].Cells[5].Value.ToString();
            string str5 = objgrid.Rows[index].Cells[6].Value.ToString();
            DateTime dateTime1 = Convert.ToDateTime(objgrid.Rows[index].Cells[8].Value);
            DateTime dateTime2 = Convert.ToDateTime(objgrid.Rows[index].Cells[9].Value);
            string str6 = objgrid.Rows[index].Cells[12].Value.ToString();
            string path = "NSE.txt";
            if (contract.exch == 1)
            {
              path = string.Format("{0}//MCX_{1}{2}{3}TRD.txt", (object) selectedPath, (object) dateTime1.Day, (object) dateTime1.Month, (object) dateTime1.Year);
              str1 = string.Format("{0},,,{1},{2},{3},,,,,,,,,,{4},{5},{6},,{7},,,,,,,{8},,,{9}\r\n", (object) (index + 1), (object) instrument, (object) contract.symbol, (object) contract.expiry.ToString("ddMMMyyyy").ToUpper(), (object) num, (object) str4, (object) str5, (object) str2, (object) str6, (object) dateTime2.ToString("dd/MMM/yyyy HH:mm"));
            }
            else if (contract.exch == 2)
            {
              path = string.Format("{0}//NSEFUT_{1}{2}{3}TRD.txt", (object) selectedPath, (object) dateTime1.Day, (object) dateTime1.Month, (object) dateTime1.Year);
              str1 = string.Format("{0},,{1},{2},{3},0,,,,,,,,{4},{5},{6},,{7},,,,,{8},{9}\r\n", (object) (index + 1), (object) instrument, (object) contract.symbol, (object) contract.expiry.ToString("ddMMMyyyy").ToUpper(), (object) num, (object) str4, (object) str5, (object) str2, (object) dateTime2.ToString("dd/MMM/yyyy HH:mm"), (object) str6);
            }
            using (StreamWriter streamWriter = File.AppendText(path))
              streamWriter.Write(str1);
          }
        }
      }
    }

    public static void ExporttoExchange(DataGridView objgrid, bool isMIS, Dashboard objdash)
    {
      using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
      {
        if (folderBrowserDialog.ShowDialog() != DialogResult.OK)
          return;
        string selectedPath = folderBrowserDialog.SelectedPath;
        for (int index = 0; index < objgrid.Rows.Count; ++index)
        {
          string str1 = string.Empty;
          if (objgrid.Rows[index].Visible)
          {
            string str2 = objgrid.Rows[index].Cells[0].Value.ToString();
            string exch = objgrid.Rows[index].Cells[1].Value.ToString();
            string symbol = objgrid.Rows[index].Cells[2].Value.ToString();
            string str3 = objgrid.Rows[index].Cells[3].Value.ToString();
            int num1 = 1;
            if (str3 == "SL")
              num1 = 2;
            Contracts contract = objdash.GetContract(symbol);
            string instrument = Export.GetInstrument(exch, contract.symbol);
            string str4 = objgrid.Rows[index].Cells[4].Value.ToString();
            int num2 = 1;
            if (str4 == "SELL")
              num2 = 2;
            string str5 = objgrid.Rows[index].Cells[5].Value.ToString();
            string str6 = objgrid.Rows[index].Cells[6].Value.ToString();
            DateTime dateTime1 = Convert.ToDateTime(objgrid.Rows[index].Cells[8].Value);
            DateTime dateTime2 = Convert.ToDateTime(objgrid.Rows[index].Cells[9].Value);
            string str7 = objgrid.Rows[index].Cells[12].Value.ToString();
            string path = "NSE.txt";
            if (contract.exch == 1)
            {
              path = string.Format("{0}//MCX_{1}{2}{3}TRD.txt", (object) selectedPath, (object) dateTime1.Day, (object) dateTime1.Month, (object) dateTime1.Year);
              str1 = string.Format("{0},11,,{1},{2},{3},,,,,1,RL,1,{4},,{5},{6},{7},1,,,,,{8},{9},{10},,,{11},,,,,,,,\r\n", (object) (index + 1), (object) instrument, (object) contract.symbol, (object) contract.expiry.ToString("dd-MMM-yyyy"), (object) str2, (object) num2, (object) str5, (object) str6, (object) dateTime2.ToString("dd/MM/yyyy HH:mm"), (object) dateTime2.ToString("dd/MM/yyyy HH:mm"), (object) str7, (object) dateTime2.ToString("dd/MM/yyyy HH:mm"));
            }
            else if (contract.exch == 2)
            {
              path = string.Format("{0}//NSEFUT_{1}{2}{3}TRD.txt", (object) selectedPath, (object) dateTime1.Day, (object) dateTime1.Month, (object) dateTime1.Year);
              str1 = string.Format("{0},11,,{1},,{2},,0,,{3},,1,,{4},,,{5},,{6},{7},,1,,{8},,,,,,,{9},{10},,{11},,,{12}\r\n", (object) (index + 1), (object) contract.symbol, (object) symbol, (object) num1, (object) str2, (object) num2, (object) str5, (object) str6, (object) str2, (object) dateTime1.ToString("dd/MM/yyyy HH:mm"), (object) dateTime2.ToString("dd/MM/yyyy HH:mm"), (object) str7, (object) dateTime2.ToString("dd/MM/yyyy HH:mm"));
            }
            else if (contract.exch == 3)
            {
              path = string.Format("{0}//TRADE{1}{2}{3}.txt", (object) selectedPath, (object) dateTime1.Day, (object) dateTime1.Month, (object) dateTime1.Year);
              str1 = string.Format("{0},11,{1},{2},{3},,,{4},{5},RL,1,{6},0,{7},{8},{9},1,{10},,OPEN,UNCOVER,{11},{12},{13},,,\r\n", (object) (index + 1), (object) instrument, (object) contract.symbol, (object) contract.expiry.ToString("ddMMMYYYY"), (object) symbol, (object) num1, (object) str2, (object) num2, (object) str5, (object) str6, (object) str2, (object) dateTime1.ToString("dd/MM/yyyy HH:mm"), (object) dateTime2.ToString("dd/MM/yyyy HH:mm"), (object) str7);
            }
            using (StreamWriter streamWriter = File.AppendText(path))
              streamWriter.Write(str1);
          }
        }
      }
    }

    public static void ExportRTTradesText(string location, string data)
    {
      if (!Directory.Exists(System.Windows.Forms.Application.StartupPath + "\\Trades"))
        Directory.CreateDirectory(System.Windows.Forms.Application.StartupPath + "\\Trades");
      if (!File.Exists(location))
        File.Create(location);
      else if (Export.i == 0)
      {
        File.WriteAllText(location, string.Empty);
        Export.i = 1;
      }
      using (StreamWriter streamWriter = new StreamWriter(location, true))
      {
        streamWriter.WriteLine(data);
        streamWriter.Close();
      }
    }

    public static void ExporttoTB(DataGridView objgrid)
    {
      // ISSUE: variable of a compiler-generated type
      Microsoft.Office.Interop.Excel.Application instance = (Microsoft.Office.Interop.Excel.Application) Activator.CreateInstance(System.Type.GetTypeFromCLSID(new Guid("00024500-0000-0000-C000-000000000046")));
      if (instance == null)
      {
        int num1 = (int) MessageBox.Show("Excel is not properly installed!!");
      }
      else
      {
        object obj = (object) Missing.Value;
        // ISSUE: reference to a compiler-generated method
        // ISSUE: variable of a compiler-generated type
        Workbook workbook = instance.Workbooks.Add(obj);
        // ISSUE: reference to a compiler-generated field
        if (Export.\u003C\u003Eo__11.\u003C\u003Ep__0 == null)
        {
          // ISSUE: reference to a compiler-generated field
          Export.\u003C\u003Eo__11.\u003C\u003Ep__0 = CallSite<Func<CallSite, object, Worksheet>>.Create(Microsoft.CSharp.RuntimeBinder.Binder.Convert(CSharpBinderFlags.ConvertExplicit, typeof (Worksheet), typeof (Export)));
        }
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated method
        // ISSUE: variable of a compiler-generated type
        Worksheet worksheet = ((Func<CallSite, object, Worksheet>) Export.\u003C\u003Eo__11.\u003C\u003Ep__0.Target).Invoke((CallSite) Export.\u003C\u003Eo__11.\u003C\u003Ep__0, workbook.Worksheets.get_Item((object) 1));
        worksheet.Cells[(object) 1, (object) 1] = (object) "date";
        worksheet.Cells[(object) 1, (object) 2] = (object) "month";
        worksheet.Cells[(object) 1, (object) 3] = (object) "year";
        worksheet.Cells[(object) 1, (object) 4] = (object) "expdate";
        worksheet.Cells[(object) 1, (object) 5] = (object) "expmonth";
        worksheet.Cells[(object) 1, (object) 6] = (object) "expyear";
        worksheet.Cells[(object) 1, (object) 7] = (object) "symbol";
        worksheet.Cells[(object) 1, (object) 8] = (object) "QTY";
        worksheet.Cells[(object) 1, (object) 9] = (object) "RATE";
        worksheet.Cells[(object) 1, (object) 10] = (object) "PARTYCODE";
        worksheet.Cells[(object) 1, (object) 11] = (object) "BROKERCODE";
        int count = objgrid.Rows.Count;
        for (int index = 0; index < count; ++index)
        {
          DateTime dateTime = Convert.ToDateTime(objgrid[9, index].Value);
          string str1 = objgrid[2, index].Value.ToString();
          string str2 = str1.Split(' ')[0];
          string str3 = str1.Split(' ')[1];
          string str4 = objgrid[4, index].Value.ToString();
          string str5 = objgrid[5, index].Value.ToString();
          if (str4 == "SELL")
            str5 = "-" + str5;
          worksheet.Cells[(object) (index + 2), (object) 1] = (object) dateTime.Day;
          worksheet.Cells[(object) (index + 2), (object) 2] = (object) dateTime.Month;
          worksheet.Cells[(object) (index + 2), (object) 3] = (object) dateTime.Year;
          worksheet.Cells[(object) (index + 2), (object) 4] = (object) str3.Substring(0, 2);
          worksheet.Cells[(object) (index + 2), (object) 5] = (object) str3.Substring(2, 3);
          worksheet.Cells[(object) (index + 2), (object) 6] = (object) str3.Substring(5, 4);
          worksheet.Cells[(object) (index + 2), (object) 7] = (object) str2;
          worksheet.Cells[(object) (index + 2), (object) 8] = (object) str5;
          worksheet.Cells[(object) (index + 2), (object) 9] = (object) objgrid[6, index].Value.ToString();
          worksheet.Cells[(object) (index + 2), (object) 10] = (object) objgrid[0, index].Value.ToString();
          worksheet.Cells[(object) (index + 2), (object) 11] = (object) "1111";
        }
        string empty = string.Empty;
        SaveFileDialog saveFileDialog1 = new SaveFileDialog();
        saveFileDialog1.CheckPathExists = true;
        saveFileDialog1.InitialDirectory = "C:\\";
        saveFileDialog1.Filter = "(*.XLS)|*.xls|All Files (*.*)|*.*";
        saveFileDialog1.FilterIndex = 1;
        using (SaveFileDialog saveFileDialog2 = saveFileDialog1)
        {
          if (saveFileDialog2.ShowDialog() != DialogResult.OK)
            return;
          string fileName = saveFileDialog2.FileName;
          // ISSUE: reference to a compiler-generated method
          workbook.SaveAs((object) fileName, (object) XlFileFormat.xlWorkbookNormal, obj, obj, obj, obj, XlSaveAsAccessMode.xlExclusive, obj, obj, obj, obj, obj);
          // ISSUE: reference to a compiler-generated method
          workbook.Close((object) true, obj, obj);
          // ISSUE: reference to a compiler-generated method
          instance.Quit();
          Marshal.ReleaseComObject((object) worksheet);
          Marshal.ReleaseComObject((object) workbook);
          Marshal.ReleaseComObject((object) instance);
          int num2 = (int) MessageBox.Show("Excel file created , you can find the file " + fileName ?? "");
        }
      }
    }

    public static DateTime GetlastUpdateTradeTime(string filename)
    {
      DateTime dateTime;
      ref DateTime local = ref dateTime;
      DateTime now = DateTime.Now;
      int year = now.Year;
      now = DateTime.Now;
      int month = now.Month;
      now = DateTime.Now;
      int day = now.Day;
      local = new DateTime(year, month, day, 9, 0, 0);
      File.Exists(filename);
      if (File.Exists(filename) && File.ReadAllLines(filename).Length > 0)
      {
        string str = File.ReadLines(filename).Last<string>();
        if (str.Contains(","))
          dateTime = Convert.ToDateTime(str.Split(',')[12]);
      }
      return dateTime;
    }
  }
}
