﻿// Decompiled with JetBrains decompiler
// Type: DTS.Market_Watch_Settings
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class Market_Watch_Settings : Form
  {
    public Dictionary<string, string> _ColumnsHeaderMap = new Dictionary<string, string>();
    private IContainer components = (IContainer) null;
    public frmMarketWatch objmktwatch;
    private Label label1;
    private Label label2;
    private Label label3;
    private Label label4;
    private Button btnforecolor;
    private Button btnBackcolor;
    private Button btnUpColor;
    private Button btnDownColor;
    private GroupBox groupBox1;
    private Button button5;
    private Button button6;
    private ColorDialog colorDialog1;
    private Button btnFont;
    private Label label5;
    private FontDialog fontDialog1;
    private TabControl tabControl1;
    private TabPage tabPage1;
    private TabPage tabPage2;
    private CheckedListBox chkColumns;
    private Button btnMoveDown;
    private Button btnMoveUP;
    private Button btnClose;
    private Button btnSave1;
    private Button btnApply;

    public Market_Watch_Settings(frmMarketWatch objmktwatch)
    {
      this.InitializeComponent();
      this.objmktwatch = objmktwatch;
      this.Icon = objmktwatch.objmain.ico;
    }

    private void button6_Click(object sender, EventArgs e)
    {
      this.Close();
    }

    public void LoadMWSettings(DataGridView objgridview)
    {
      this.btnforecolor.BackColor = Settings.Default.MWForecolor;
      this.btnBackcolor.BackColor = Settings.Default.MWBackcolor;
      this.btnUpColor.BackColor = Settings.Default.MWUPcolor;
      this.btnDownColor.BackColor = Settings.Default.MWDOWNcolor;
      this.chkColumns.Items.Clear();
      for (int index = 0; index < objgridview.Columns.Count; ++index)
      {
        this.chkColumns.Items.Add((object) objgridview.Columns[index].HeaderText);
        if (objgridview.Columns[index].Visible)
          this.chkColumns.SetItemCheckState(index, CheckState.Checked);
        if (!this._ColumnsHeaderMap.ContainsKey(objgridview.Columns[index].HeaderText))
          this._ColumnsHeaderMap.Add(objgridview.Columns[index].HeaderText, objgridview.Columns[index].Name);
      }
    }

    private void btnforecolor_Click(object sender, EventArgs e)
    {
      if (this.colorDialog1.ShowDialog() != DialogResult.OK)
        return;
      this.btnforecolor.BackColor = this.colorDialog1.Color;
    }

    private void btnBackcolor_Click(object sender, EventArgs e)
    {
      if (this.colorDialog1.ShowDialog() != DialogResult.OK)
        return;
      this.btnBackcolor.BackColor = this.colorDialog1.Color;
    }

    private void btnUpColor_Click(object sender, EventArgs e)
    {
      if (this.colorDialog1.ShowDialog() != DialogResult.OK)
        return;
      this.btnUpColor.BackColor = this.colorDialog1.Color;
    }

    private void btnDownColor_Click(object sender, EventArgs e)
    {
      if (this.colorDialog1.ShowDialog() != DialogResult.OK)
        return;
      this.btnDownColor.BackColor = this.colorDialog1.Color;
    }

    private void button5_Click(object sender, EventArgs e)
    {
      Settings.Default.MWForecolor = this.btnforecolor.BackColor;
      Settings.Default.MWBackcolor = this.btnBackcolor.BackColor;
      Settings.Default.MWUPcolor = this.btnUpColor.BackColor;
      Settings.Default.MWDOWNcolor = this.btnDownColor.BackColor;
      this.objmktwatch.dgvMarketwatch.BackgroundColor = this.btnBackcolor.BackColor;
      this.objmktwatch.dgvMarketwatch.ForeColor = this.btnforecolor.BackColor;
      for (int index = 0; index < this.objmktwatch.dgvMarketwatch.Rows.Count; ++index)
        this.objmktwatch.dgvMarketwatch.Rows[index].DefaultCellStyle.BackColor = this.btnBackcolor.BackColor;
      Settings.Default.Save();
      this.Close();
    }

    private void btnFont_Click(object sender, EventArgs e)
    {
      if (this.fontDialog1.ShowDialog() != DialogResult.OK)
        return;
      Settings.Default.MWFont = this.fontDialog1.Font;
      this.objmktwatch.dgvMarketwatch.Font = this.fontDialog1.Font;
      Settings.Default.Save();
    }

    private void btnApply_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.chkColumns.Items.Count; ++index)
      {
        if (this.chkColumns.GetItemCheckState(index) == CheckState.Checked)
        {
          str += string.Format("{0}_{1}_{2},", (object) this.chkColumns.Items[index].ToString(), (object) index, (object) 1);
          string columnsHeader = this._ColumnsHeaderMap[this.chkColumns.Items[index].ToString()];
          this.objmktwatch.dgvMarketwatch.Columns[columnsHeader].DisplayIndex = index;
          this.objmktwatch.dgvMarketwatch.Columns[columnsHeader].Visible = true;
        }
        else
        {
          str += string.Format("{0}_{1}_{2},", (object) this.chkColumns.Items[index].ToString(), (object) index, (object) 0);
          this.objmktwatch.dgvMarketwatch.Columns[this._ColumnsHeaderMap[this.chkColumns.Items[index].ToString()]].Visible = false;
        }
      }
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.MWColumnProfile = str;
      Settings.Default.Save();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      if (this.chkColumns.Items.Count <= 0)
        return;
      this.Moveitem(-1);
    }

    private void Moveitem(int direction)
    {
      if (this.chkColumns.SelectedItem == null || this.chkColumns.SelectedIndex < 0)
        return;
      int index = this.chkColumns.SelectedIndex + direction;
      if (index <= 0 || index >= this.chkColumns.Items.Count)
        return;
      object selectedItem = this.chkColumns.SelectedItem;
      this.chkColumns.Items.Remove(selectedItem);
      this.chkColumns.Items.Insert(index, selectedItem);
      this.chkColumns.SetSelected(index, true);
      this.chkColumns.SetItemChecked(index, true);
    }

    private void btnMoveDown_Click(object sender, EventArgs e)
    {
      if (this.chkColumns.Items.Count <= 0)
        return;
      this.Moveitem(1);
    }

    private void btnSave1_Click(object sender, EventArgs e)
    {
      string str = string.Empty;
      for (int index = 0; index < this.chkColumns.Items.Count; ++index)
      {
        if (this.chkColumns.GetItemCheckState(index) == CheckState.Checked)
        {
          str += string.Format("{0}_{1}_{2},", (object) this.chkColumns.Items[index].ToString(), (object) index, (object) 1);
          string columnsHeader = this._ColumnsHeaderMap[this.chkColumns.Items[index].ToString()];
          this.objmktwatch.dgvMarketwatch.Columns[columnsHeader].DisplayIndex = index;
          this.objmktwatch.dgvMarketwatch.Columns[columnsHeader].Visible = true;
        }
        else
        {
          str += string.Format("{0}_{1}_{2},", (object) this.chkColumns.Items[index].ToString(), (object) index, (object) 0);
          this.objmktwatch.dgvMarketwatch.Columns[this._ColumnsHeaderMap[this.chkColumns.Items[index].ToString()]].Visible = false;
        }
      }
      if (str != string.Empty)
        str = str.Substring(0, str.Length - 1);
      Settings.Default.MWColumnProfile = str;
      Settings.Default.Save();
    }

    private void btnClose_Click(object sender, EventArgs e)
    {
      this.Close();
      Settings.Default.Save();
    }

    private void chkColumns_ItemCheck(object sender, ItemCheckEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.label2 = new Label();
      this.label3 = new Label();
      this.label4 = new Label();
      this.btnforecolor = new Button();
      this.btnBackcolor = new Button();
      this.btnUpColor = new Button();
      this.btnDownColor = new Button();
      this.groupBox1 = new GroupBox();
      this.btnFont = new Button();
      this.label5 = new Label();
      this.button5 = new Button();
      this.button6 = new Button();
      this.colorDialog1 = new ColorDialog();
      this.fontDialog1 = new FontDialog();
      this.tabControl1 = new TabControl();
      this.tabPage1 = new TabPage();
      this.tabPage2 = new TabPage();
      this.btnClose = new Button();
      this.btnSave1 = new Button();
      this.btnApply = new Button();
      this.btnMoveDown = new Button();
      this.btnMoveUP = new Button();
      this.chkColumns = new CheckedListBox();
      this.groupBox1.SuspendLayout();
      this.tabControl1.SuspendLayout();
      this.tabPage1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label1.Location = new Point(8, 27);
      this.label1.Name = "label1";
      this.label1.Size = new Size(67, 15);
      this.label1.TabIndex = 0;
      this.label1.Text = "Fore Color:";
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(8, 68);
      this.label2.Name = "label2";
      this.label2.Size = new Size(69, 15);
      this.label2.TabIndex = 1;
      this.label2.Text = "Back Color:";
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label3.Location = new Point(8, 109);
      this.label3.Name = "label3";
      this.label3.Size = new Size(59, 15);
      this.label3.TabIndex = 2;
      this.label3.Text = "UP Color:";
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label4.Location = new Point(8, 150);
      this.label4.Name = "label4";
      this.label4.Size = new Size(80, 15);
      this.label4.TabIndex = 3;
      this.label4.Text = "DOWN Color:";
      this.btnforecolor.FlatStyle = FlatStyle.Flat;
      this.btnforecolor.Location = new Point(164, 17);
      this.btnforecolor.Name = "btnforecolor";
      this.btnforecolor.Size = new Size(57, 33);
      this.btnforecolor.TabIndex = 4;
      this.btnforecolor.UseVisualStyleBackColor = true;
      this.btnforecolor.Click += new EventHandler(this.btnforecolor_Click);
      this.btnBackcolor.FlatStyle = FlatStyle.Flat;
      this.btnBackcolor.Location = new Point(164, 58);
      this.btnBackcolor.Name = "btnBackcolor";
      this.btnBackcolor.Size = new Size(57, 33);
      this.btnBackcolor.TabIndex = 5;
      this.btnBackcolor.UseVisualStyleBackColor = true;
      this.btnBackcolor.Click += new EventHandler(this.btnBackcolor_Click);
      this.btnUpColor.FlatStyle = FlatStyle.Flat;
      this.btnUpColor.Location = new Point(164, 99);
      this.btnUpColor.Name = "btnUpColor";
      this.btnUpColor.Size = new Size(57, 33);
      this.btnUpColor.TabIndex = 6;
      this.btnUpColor.UseVisualStyleBackColor = true;
      this.btnUpColor.Click += new EventHandler(this.btnUpColor_Click);
      this.btnDownColor.FlatStyle = FlatStyle.Flat;
      this.btnDownColor.Location = new Point(164, 140);
      this.btnDownColor.Name = "btnDownColor";
      this.btnDownColor.Size = new Size(57, 33);
      this.btnDownColor.TabIndex = 7;
      this.btnDownColor.UseVisualStyleBackColor = true;
      this.btnDownColor.Click += new EventHandler(this.btnDownColor_Click);
      this.groupBox1.Controls.Add((Control) this.btnFont);
      this.groupBox1.Controls.Add((Control) this.label5);
      this.groupBox1.Controls.Add((Control) this.btnDownColor);
      this.groupBox1.Controls.Add((Control) this.btnUpColor);
      this.groupBox1.Controls.Add((Control) this.btnBackcolor);
      this.groupBox1.Controls.Add((Control) this.btnforecolor);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Location = new Point(7, 6);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(228, 218);
      this.groupBox1.TabIndex = 8;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Customize MarketWatch";
      this.btnFont.Location = new Point(164, 179);
      this.btnFont.Name = "btnFont";
      this.btnFont.Size = new Size(57, 33);
      this.btnFont.TabIndex = 9;
      this.btnFont.Text = "FONT";
      this.btnFont.UseVisualStyleBackColor = true;
      this.btnFont.Click += new EventHandler(this.btnFont_Click);
      this.label5.AutoSize = true;
      this.label5.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label5.Location = new Point(8, 189);
      this.label5.Name = "label5";
      this.label5.Size = new Size(42, 15);
      this.label5.TabIndex = 8;
      this.label5.Text = "FONT:";
      this.button5.Location = new Point(31, 230);
      this.button5.Name = "button5";
      this.button5.Size = new Size(75, 23);
      this.button5.TabIndex = 9;
      this.button5.Text = "Save";
      this.button5.UseVisualStyleBackColor = true;
      this.button5.Click += new EventHandler(this.button5_Click);
      this.button6.Location = new Point(128, 230);
      this.button6.Name = "button6";
      this.button6.Size = new Size(75, 23);
      this.button6.TabIndex = 10;
      this.button6.Text = "Close";
      this.button6.UseVisualStyleBackColor = true;
      this.button6.Click += new EventHandler(this.button6_Click);
      this.tabControl1.Controls.Add((Control) this.tabPage1);
      this.tabControl1.Controls.Add((Control) this.tabPage2);
      this.tabControl1.Dock = DockStyle.Fill;
      this.tabControl1.Location = new Point(0, 0);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new Size(263, 286);
      this.tabControl1.TabIndex = 11;
      this.tabPage1.Controls.Add((Control) this.groupBox1);
      this.tabPage1.Controls.Add((Control) this.button6);
      this.tabPage1.Controls.Add((Control) this.button5);
      this.tabPage1.Location = new Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new Padding(3);
      this.tabPage1.Size = new Size((int) byte.MaxValue, 260);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Visual Settings";
      this.tabPage1.UseVisualStyleBackColor = true;
      this.tabPage2.Controls.Add((Control) this.btnClose);
      this.tabPage2.Controls.Add((Control) this.btnSave1);
      this.tabPage2.Controls.Add((Control) this.btnApply);
      this.tabPage2.Controls.Add((Control) this.btnMoveDown);
      this.tabPage2.Controls.Add((Control) this.btnMoveUP);
      this.tabPage2.Controls.Add((Control) this.chkColumns);
      this.tabPage2.Location = new Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Padding = new Padding(3);
      this.tabPage2.Size = new Size((int) byte.MaxValue, 260);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Column Settings";
      this.tabPage2.UseVisualStyleBackColor = true;
      this.btnClose.Location = new Point(192, 177);
      this.btnClose.Name = "btnClose";
      this.btnClose.Size = new Size(55, 23);
      this.btnClose.TabIndex = 12;
      this.btnClose.Text = "Close";
      this.btnClose.UseVisualStyleBackColor = true;
      this.btnClose.Click += new EventHandler(this.btnClose_Click);
      this.btnSave1.Location = new Point(192, 119);
      this.btnSave1.Name = "btnSave1";
      this.btnSave1.Size = new Size(55, 23);
      this.btnSave1.TabIndex = 11;
      this.btnSave1.Text = "Save";
      this.btnSave1.UseVisualStyleBackColor = true;
      this.btnSave1.Click += new EventHandler(this.btnSave1_Click);
      this.btnApply.Location = new Point(192, 61);
      this.btnApply.Name = "btnApply";
      this.btnApply.Size = new Size(55, 23);
      this.btnApply.TabIndex = 10;
      this.btnApply.Text = "Apply";
      this.btnApply.UseVisualStyleBackColor = true;
      this.btnApply.Click += new EventHandler(this.btnApply_Click);
      this.btnMoveDown.Location = new Point(134, 144);
      this.btnMoveDown.Name = "btnMoveDown";
      this.btnMoveDown.Size = new Size(40, 31);
      this.btnMoveDown.TabIndex = 2;
      this.btnMoveDown.Text = "DN";
      this.btnMoveDown.UseVisualStyleBackColor = true;
      this.btnMoveDown.Click += new EventHandler(this.btnMoveDown_Click);
      this.btnMoveUP.Location = new Point(134, 86);
      this.btnMoveUP.Name = "btnMoveUP";
      this.btnMoveUP.Size = new Size(40, 31);
      this.btnMoveUP.TabIndex = 1;
      this.btnMoveUP.Text = "UP";
      this.btnMoveUP.UseVisualStyleBackColor = true;
      this.btnMoveUP.Click += new EventHandler(this.button1_Click);
      this.chkColumns.CheckOnClick = true;
      this.chkColumns.FormattingEnabled = true;
      this.chkColumns.Location = new Point(8, 16);
      this.chkColumns.Name = "chkColumns";
      this.chkColumns.Size = new Size(120, 229);
      this.chkColumns.TabIndex = 0;
      this.chkColumns.ItemCheck += new ItemCheckEventHandler(this.chkColumns_ItemCheck);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(263, 286);
      this.Controls.Add((Control) this.tabControl1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (Market_Watch_Settings);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Market Watch Settings";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.tabControl1.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      this.ResumeLayout(false);
    }
  }
}
