﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmClntSymbolPos
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmClntSymbolPos : Form
  {
    public Dashboard objdash = (Dashboard) null;
    private IContainer components = (IContainer) null;
    private DataGridView dgvOpenPos;
    private DataGridViewTextBoxColumn Regulationcode;
    private DataGridViewTextBoxColumn Symbol;
    private DataGridViewTextBoxColumn BuySell;
    private DataGridViewTextBoxColumn Qty;
    private DataGridViewTextBoxColumn AvgPrice;

    public frmClntSymbolPos(Dashboard objdash)
    {
      this.InitializeComponent();
      this.objdash = objdash;
      this.Icon = objdash.ico;
    }

    public void Loadwindow(string Displaysymbol)
    {
      this.dgvOpenPos.Rows.Clear();
      Dictionary<string, buysellPos> _BuySellAvgPos = new Dictionary<string, buysellPos>();
      this.objdash.GetTradePosition(ref _BuySellAvgPos, this.objdash.claccounts, false);
      Dictionary<string, buysellnetpospfls> dictionary1 = this.objdash.ProcessProfitLoss(_BuySellAvgPos);
      Dictionary<string, buysellnetpospfls> dictionary2 = new Dictionary<string, buysellnetpospfls>();
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dictionary1)
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string key1 = strArray[0];
        string key2 = strArray[1];
        Convert.ToInt32(strArray[2]);
        if (!(Displaysymbol != key1) && this.objdash._Symconctracts.ContainsKey(key1))
        {
          Contracts symconctract = this.objdash._Symconctracts[key1];
          buysellnetpospfls buysellnetpospfls1 = keyValuePair.Value;
          if (buysellnetpospfls1.buy_sell > 0)
          {
            if (!dictionary2.ContainsKey(key2))
            {
              buysellnetpospfls buysellnetpospfls2 = new buysellnetpospfls();
              if (buysellnetpospfls1.buy_sell == 1)
              {
                buysellnetpospfls2.BQty = buysellnetpospfls1.Qty;
                buysellnetpospfls2.buyprice = Decimal.Round(buysellnetpospfls1.buyprice, 2);
              }
              else
              {
                buysellnetpospfls2.SQty = buysellnetpospfls1.Qty;
                buysellnetpospfls2.sellprice = Decimal.Round(buysellnetpospfls1.sellprice, 2);
              }
              dictionary2.Add(key2, buysellnetpospfls2);
            }
            else
            {
              buysellnetpospfls buysellnetpospfls2 = dictionary2[key2];
              if (buysellnetpospfls1.buy_sell == 1)
              {
                if (buysellnetpospfls2.BQty > 0)
                {
                  Decimal num = Decimal.Round(((Decimal) buysellnetpospfls2.BQty * buysellnetpospfls2.buyprice + (Decimal) buysellnetpospfls1.Qty * buysellnetpospfls1.buyprice) / (Decimal) (buysellnetpospfls1.Qty + buysellnetpospfls2.BQty), 2);
                  buysellnetpospfls2.BQty += buysellnetpospfls1.Qty;
                  buysellnetpospfls2.buyprice = num;
                }
                else
                {
                  buysellnetpospfls2.BQty += buysellnetpospfls1.Qty;
                  buysellnetpospfls2.buyprice = Decimal.Round(buysellnetpospfls1.buyprice, 2);
                }
              }
              else if (buysellnetpospfls2.SQty > 0)
              {
                Decimal num = Decimal.Round(((Decimal) buysellnetpospfls2.SQty * buysellnetpospfls2.sellprice + (Decimal) buysellnetpospfls1.Qty * buysellnetpospfls1.sellprice) / (Decimal) (buysellnetpospfls1.Qty + buysellnetpospfls2.SQty), 2);
                buysellnetpospfls2.SQty += buysellnetpospfls1.Qty;
                buysellnetpospfls2.sellprice = num;
              }
              else
              {
                buysellnetpospfls2.SQty += buysellnetpospfls1.Qty;
                buysellnetpospfls2.sellprice = Decimal.Round(buysellnetpospfls1.sellprice, 2);
              }
              dictionary2[key2] = buysellnetpospfls2;
            }
          }
        }
      }
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dictionary2)
      {
        if (keyValuePair.Value.BQty > keyValuePair.Value.SQty)
        {
          int index = this.dgvOpenPos.Rows.Add();
          this.dgvOpenPos.Rows[index].Cells[0].Value = (object) keyValuePair.Key;
          this.dgvOpenPos.Rows[index].Cells[1].Value = (object) Displaysymbol;
          this.dgvOpenPos.Rows[index].Cells[2].Value = (object) "BUY";
          this.dgvOpenPos.Rows[index].Cells[3].Value = (object) (keyValuePair.Value.BQty - keyValuePair.Value.SQty);
          this.dgvOpenPos.Rows[index].Cells[4].Value = (object) keyValuePair.Value.buyprice;
        }
        else if (keyValuePair.Value.SQty > keyValuePair.Value.BQty)
        {
          int index = this.dgvOpenPos.Rows.Add();
          this.dgvOpenPos.Rows[index].Cells[0].Value = (object) keyValuePair.Key;
          this.dgvOpenPos.Rows[index].Cells[1].Value = (object) Displaysymbol;
          this.dgvOpenPos.Rows[index].Cells[2].Value = (object) "SELL";
          this.dgvOpenPos.Rows[index].Cells[3].Value = (object) (keyValuePair.Value.SQty - keyValuePair.Value.BQty);
          this.dgvOpenPos.Rows[index].Cells[4].Value = (object) keyValuePair.Value.sellprice;
        }
      }
    }

    private void dgvOpenPos_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
    {
    }

    private void dgvOpenPos_MouseClick(object sender, MouseEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dgvOpenPos = new DataGridView();
      this.Regulationcode = new DataGridViewTextBoxColumn();
      this.Symbol = new DataGridViewTextBoxColumn();
      this.BuySell = new DataGridViewTextBoxColumn();
      this.Qty = new DataGridViewTextBoxColumn();
      this.AvgPrice = new DataGridViewTextBoxColumn();
      ((ISupportInitialize) this.dgvOpenPos).BeginInit();
      this.SuspendLayout();
      this.dgvOpenPos.AllowUserToAddRows = false;
      this.dgvOpenPos.AllowUserToDeleteRows = false;
      this.dgvOpenPos.AllowUserToOrderColumns = true;
      this.dgvOpenPos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvOpenPos.BackgroundColor = Color.White;
      this.dgvOpenPos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvOpenPos.Columns.AddRange((DataGridViewColumn) this.Regulationcode, (DataGridViewColumn) this.Symbol, (DataGridViewColumn) this.BuySell, (DataGridViewColumn) this.Qty, (DataGridViewColumn) this.AvgPrice);
      this.dgvOpenPos.Dock = DockStyle.Fill;
      this.dgvOpenPos.Location = new Point(0, 0);
      this.dgvOpenPos.Name = "dgvOpenPos";
      this.dgvOpenPos.ReadOnly = true;
      this.dgvOpenPos.RowHeadersVisible = false;
      this.dgvOpenPos.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvOpenPos.Size = new Size(560, 290);
      this.dgvOpenPos.TabIndex = 1;
      this.dgvOpenPos.CellMouseClick += new DataGridViewCellMouseEventHandler(this.dgvOpenPos_CellMouseClick);
      this.dgvOpenPos.MouseClick += new MouseEventHandler(this.dgvOpenPos_MouseClick);
      this.Regulationcode.HeaderText = "ClientCode";
      this.Regulationcode.Name = "Regulationcode";
      this.Regulationcode.ReadOnly = true;
      this.Symbol.HeaderText = "Symbol";
      this.Symbol.Name = "Symbol";
      this.Symbol.ReadOnly = true;
      this.BuySell.HeaderText = "B/S";
      this.BuySell.Name = "BuySell";
      this.BuySell.ReadOnly = true;
      this.Qty.HeaderText = "Qty";
      this.Qty.Name = "Qty";
      this.Qty.ReadOnly = true;
      this.AvgPrice.HeaderText = "AvgPrice";
      this.AvgPrice.Name = "AvgPrice";
      this.AvgPrice.ReadOnly = true;
      this.AvgPrice.Visible = false;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(560, 290);
      this.Controls.Add((Control) this.dgvOpenPos);
      this.Name = nameof (frmClntSymbolPos);
      this.Text = "Client Symbol Position";
      ((ISupportInitialize) this.dgvOpenPos).EndInit();
      this.ResumeLayout(false);
    }
  }
}
