﻿// Decompiled with JetBrains decompiler
// Type: DTS.Utils
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using DTS.Properties;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Sockets;
using System.Web;
using System.Windows.Forms;

namespace DTS
{
  public class Utils
  {
    public static string GetExch(int exch)
    {
      switch (exch)
      {
        case 1:
          return "MCX";
        case 2:
          return "NSEFUT";
        case 3:
          return "NCDEX";
        case 4:
          return "NSECURR";
        case 5:
          return "NSEOPT";
        default:
          return "";
      }
    }

    public static int GetIntExch(string exch)
    {
      string str = exch;
      if (str == "MCX")
        return 1;
      if (str == "NSEFUT")
        return 2;
      if (str == "NCDEX")
        return 3;
      if (str == "NSECURR")
        return 4;
      return str == "NSEOPT" ? 5 : 0;
    }

    public static string GetProductType(int type)
    {
      switch (type)
      {
        case 1:
          return "RL";
        case 2:
          return "SL";
        default:
          return string.Empty;
      }
    }

    public static string GetBuysell(int buysell)
    {
      return buysell == 1 ? "B" : "S";
    }

    public static string GetValidity(int valid)
    {
      return valid == 2 ? "Day" : "CarryForward";
    }

    public static string GetStringStatus(int status)
    {
      switch (status)
      {
        case 1:
          return "Active";
        case 2:
          return "Ban";
        case 3:
          return "Suspend";
        default:
          return "ExchBan";
      }
    }

    public static Decimal GetTickprice(int tick)
    {
      switch (tick)
      {
        case 5:
          return new Decimal(5, 0, 0, false, (byte) 2);
        case 10:
          return new Decimal(10, 0, 0, false, (byte) 2);
        case 100:
          return Decimal.One;
        case 200:
          return new Decimal(2);
        case 250:
          return new Decimal(25, 0, 0, false, (byte) 1);
        case 1000:
          return new Decimal(10);
        case 25000:
          return new Decimal(25, 0, 0, false, (byte) 4);
        default:
          return new Decimal(5, 0, 0, false, (byte) 2);
      }
    }

    public static int GetRoundoff(int tick)
    {
      if (tick == 5 || tick == 10)
        return 2;
      if (tick == 100 || tick == 200 || tick == 1000)
        return 0;
      if (tick == 25000)
        return 4;
      return tick == 250 ? 1 : 0;
    }

    public static string GetMonth(int month)
    {
      switch (month)
      {
        case 1:
          return "JAN";
        case 2:
          return "FEB";
        case 3:
          return "MAR";
        case 4:
          return "APR";
        case 5:
          return "MAY";
        case 6:
          return "JUN";
        case 7:
          return "JUL";
        case 8:
          return "AUG";
        case 9:
          return "SEP";
        case 10:
          return "OCT";
        case 11:
          return "NOV";
        case 12:
          return "DEC";
        default:
          return "";
      }
    }

    public static string Getconnsss()
    {
      return Dashboard.Decryptdata(Settings.Default.QQQ) + Dashboard.Decryptdata(Settings.Default.A) + Dashboard.Decryptdata(Settings.Default.N) + Dashboard.Decryptdata(Settings.Default.kKK) + Dashboard.Decryptdata(Settings.Default.U);
    }

    public static string Get_SERVER2connsss()
    {
      return Dashboard.Decryptdata(Settings.Default.Qq) + Dashboard.Decryptdata(Settings.Default.A) + Dashboard.Decryptdata(Settings.Default.Nn) + Dashboard.Decryptdata(Settings.Default.kk) + Dashboard.Decryptdata(Settings.Default.U);
    }

    public static string Get_SERVER3connsss()
    {
      return Dashboard.Encryptdata1("Data Source=45.32.154.182\\NSE_CASH_MAIN\\SQLEXPRESS,1433;User ID=sa;Password=Jiyakiyan@9;Initial Catalog=DTS1;Integrated Security=false;MultipleActiveResultSets = True;Connect Timeout=500000000");
    }

    public static string LocalIPAddress()
    {
      IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
      string str = "";
      foreach (IPAddress address in hostEntry.AddressList)
      {
        if (address.AddressFamily == AddressFamily.InterNetwork)
        {
          str = address.ToString();
          break;
        }
      }
      return str;
    }

    public static string getPublicIPAddress()
    {
      return new WebClient().DownloadString("http://icanhazip.com") ?? Utils.LocalIPAddress();
    }

    public static void DisplayMessage(string msg, int level)
    {
      switch (level)
      {
        case 1:
          int num1 = (int) MessageBox.Show(msg, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
          break;
        case 2:
          int num2 = (int) MessageBox.Show(msg, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
          break;
        case 3:
          int num3 = (int) MessageBox.Show(msg, "Alert", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          break;
      }
    }

    public static void SaveMiscLogs(string userid, string log, SqlConnection conn)
    {
      SqlCommand sqlCommand1 = new SqlCommand(nameof (SaveMiscLogs), conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@userid", (object) userid);
        sqlCommand2.Parameters.AddWithValue("@logs", (object) log);
        try
        {
          sqlCommand2.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }

    public static bool ValidateRateUpdate(int exch, SqlConnection conn)
    {
      if (conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("ValidateDataUpdate", conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@exch", (object) exch);
          try
          {
            using (SqlDataReader sqlDataReader = sqlCommand2.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                if (!sqlDataReader.IsDBNull(0))
                  return sqlDataReader.GetInt32(0) == 1;
              }
            }
          }
          catch
          {
          }
        }
      }
      return false;
    }

    public static string GetIPAddress()
    {
      HttpContext current = HttpContext.Current;
      string userHostAddress = HttpContext.Current.Request.UserHostAddress;
      if (!string.IsNullOrEmpty(userHostAddress))
      {
        string[] strArray = userHostAddress.Split(',');
        if ((uint) strArray.Length > 0U)
          return strArray[0];
      }
      return current.Request.ServerVariables["REMOTE_ADDR"];
    }
  }
}
