﻿// Decompiled with JetBrains decompiler
// Type: DTS.FrmPayout
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class FrmPayout : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public SqlConnection conn;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
    private DataGridView dgvPayinOutHistory;
    private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private GroupBox groupBox1;
    private DataGridViewTextBoxColumn Date;
    private DataGridViewTextBoxColumn DealerIDFund;
    private DataGridViewTextBoxColumn ClientCode;
    private DataGridView dvgpayout;
    private Label label5;
    private ComboBox cmbclientcode;
    private TextBox txtwdrw;
    private Label label4;
    private Button btnupdate;
    private TextBox txtamount;
    private Label label3;
    private Label label1;
    private GroupBox groupBox2;

    public FrmPayout(Dashboard main, SqlConnection objconn)
    {
      this.InitializeComponent();
      this.objmain = main;
      this.conn = objconn;
    }

    public void loaddata()
    {
      using (SqlCommand sqlCommand = new SqlCommand("  SELECT D.[Clientcode],D.[Brokerage],D.[DABrokerage],D.[DIBrokerage],D.[DealerClientcode],[Date]FROM [DealerIDBrokerage] D,[Userinformation] U where U.createdby='" + this.objmain.objinfo.clientcode + "' and D.[DealerClientcode]=U.Clientcode", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          this.dvgpayout.Rows.Clear();
          while (sqlDataReader.Read())
          {
            int index = this.dvgpayout.Rows.Add();
            if (!sqlDataReader.IsDBNull(4))
              this.dvgpayout.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(4);
            if (!sqlDataReader.IsDBNull(3))
              this.dvgpayout.Rows[index].Cells[1].Value = (object) Decimal.Round(Convert.ToDecimal(sqlDataReader.GetValue(3)), 2);
            if (!sqlDataReader.IsDBNull(5))
              this.dvgpayout.Rows[index].Cells[2].Value = (object) sqlDataReader.GetDateTime(5);
          }
        }
      }
      this.cmbclientcode.Items.Clear();
      using (SqlCommand sqlCommand = new SqlCommand("SELECT [Clientcode]FROM [Userinformation] where [createdby]='" + this.objmain.objinfo.clientcode + "' and Usertype=3", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              this.cmbclientcode.Items.Add((object) sqlDataReader.GetString(0));
          }
        }
      }
      this.payouthistory();
    }

    private void btnupdate_Click(object sender, EventArgs e)
    {
      int num = 0;
      string msg = string.Empty;
      if (this.cmbclientcode.Text == null || this.cmbclientcode.Text == string.Empty)
      {
        msg = "Please Select Dealer ID";
        Utils.DisplayMessage(msg, 3);
      }
      else if (this.txtwdrw.Text == null || this.txtwdrw.Text == string.Empty)
      {
        msg = "Please Enter payout Amount";
        Utils.DisplayMessage(msg, 3);
      }
      else if ((this.txtwdrw.Text != null || this.txtwdrw.Text != string.Empty) && Convert.ToDecimal(this.txtamount.Text) - Convert.ToDecimal(this.txtwdrw.Text) < Decimal.Zero)
      {
        msg = "Please Enter payout Amount Less Than or Equal to Total Ammount";
        Utils.DisplayMessage(msg, 3);
      }
      if (!(msg == string.Empty))
        return;
      if (this.conn.State == ConnectionState.Open)
      {
        SqlCommand sqlCommand1 = new SqlCommand("StoreDIBrokerage", this.conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@clientcode", (object) this.cmbclientcode.Text);
          sqlCommand2.Parameters.AddWithValue("@DAcode", (object) this.objmain.objinfo.clientcode);
          sqlCommand2.Parameters.AddWithValue("@brkg", (object) this.txtwdrw.Text);
          sqlCommand2.Parameters.AddWithValue("@timestamp", (object) Convert.ToDateTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")));
          try
          {
            num = sqlCommand2.ExecuteNonQuery();
          }
          catch (Exception ex)
          {
            Utils.DisplayMessage("Unable to Payout: " + ex.Message ?? "", 3);
          }
        }
      }
      if (num > 0)
        Utils.DisplayMessage("Payout Successfully", 1);
      this.payouthistory();
      this.updatepayouttable();
      this.loaddata();
    }

    private void cmbclientcode_SelectedIndexChanged(object sender, EventArgs e)
    {
      int num = 0;
      using (SqlCommand sqlCommand = new SqlCommand("SELECT [Clientcode],[Brokerage],[DABrokerage],[DIBrokerage],[DealerClientcode],[Date]FROM [DealerIDBrokerage]where[DealerClientcode]='" + this.cmbclientcode.Text + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(3))
              num += Convert.ToInt32(sqlDataReader.GetValue(3));
          }
        }
        this.txtamount.Text = num.ToString();
      }
    }

    public void payouthistory()
    {
      using (SqlCommand sqlCommand = new SqlCommand("SELECT [ID],[ClientCode],[DA_Code],[PayOut],[Timestamp]FROM [DI_PayOut] where [DA_Code]='" + this.objmain.objinfo.clientcode + "'", this.conn))
      {
        this.dgvPayinOutHistory.Rows.Clear();
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            int index = this.dgvPayinOutHistory.Rows.Add();
            if (!sqlDataReader.IsDBNull(1))
              this.dgvPayinOutHistory.Rows[index].Cells[0].Value = (object) sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(3))
              this.dgvPayinOutHistory.Rows[index].Cells[1].Value = sqlDataReader.GetValue(3);
            if (!sqlDataReader.IsDBNull(4))
              this.dgvPayinOutHistory.Rows[index].Cells[2].Value = (object) sqlDataReader.GetDateTime(4);
          }
        }
      }
    }

    public void updatepayouttable()
    {
      int num1 = 0;
      using (SqlCommand sqlCommand = new SqlCommand("DELETE FROM [DealerIDBrokerage] WHERE [DealerClientcode] = '" + this.cmbclientcode.Text + "'", this.conn))
        num1 = sqlCommand.ExecuteNonQuery();
      if (num1 <= 0)
        return;
      SqlCommand sqlCommand1 = new SqlCommand("SaveDealerIDBrokerage", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        Decimal num2 = Convert.ToDecimal(this.txtamount.Text) - Convert.ToDecimal(this.txtwdrw.Text);
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) "WD");
        sqlCommand2.Parameters.AddWithValue("@brkg", (object) 0);
        sqlCommand2.Parameters.AddWithValue("@dabrkg", (object) 0);
        sqlCommand2.Parameters.AddWithValue("@dibrkg", (object) num2);
        sqlCommand2.Parameters.AddWithValue("@dealerclientcode", (object) this.cmbclientcode.Text);
        SqlParameterCollection parameters = sqlCommand2.Parameters;
        DateTime now = DateTime.Now;
        int year = now.Year;
        now = DateTime.Now;
        int month = now.Month;
        now = DateTime.Now;
        int day = now.Day;
        // ISSUE: variable of a boxed type
        __Boxed<DateTime> local = (System.ValueType) new DateTime(year, month, day, 0, 0, 0);
        parameters.AddWithValue("@timestamp", (object) local);
        try
        {
          sqlCommand2.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
        }
      }
    }

    private void dgvPayinOutHistory_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      this.dgvPayinOutHistory = new DataGridView();
      this.dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      this.groupBox1 = new GroupBox();
      this.Date = new DataGridViewTextBoxColumn();
      this.DealerIDFund = new DataGridViewTextBoxColumn();
      this.ClientCode = new DataGridViewTextBoxColumn();
      this.dvgpayout = new DataGridView();
      this.label5 = new Label();
      this.cmbclientcode = new ComboBox();
      this.txtwdrw = new TextBox();
      this.label4 = new Label();
      this.btnupdate = new Button();
      this.txtamount = new TextBox();
      this.label3 = new Label();
      this.label1 = new Label();
      this.groupBox2 = new GroupBox();
      ((ISupportInitialize) this.dgvPayinOutHistory).BeginInit();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dvgpayout).BeginInit();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      this.dataGridViewTextBoxColumn5.HeaderText = "Timestamp";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      this.dataGridViewTextBoxColumn5.Width = 120;
      this.dataGridViewTextBoxColumn1.HeaderText = "ClientCode";
      this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
      this.dataGridViewTextBoxColumn1.ReadOnly = true;
      this.dgvPayinOutHistory.AllowUserToAddRows = false;
      this.dgvPayinOutHistory.AllowUserToDeleteRows = false;
      this.dgvPayinOutHistory.AllowUserToOrderColumns = true;
      this.dgvPayinOutHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvPayinOutHistory.Columns.AddRange((DataGridViewColumn) this.dataGridViewTextBoxColumn1, (DataGridViewColumn) this.dataGridViewTextBoxColumn4, (DataGridViewColumn) this.dataGridViewTextBoxColumn5);
      this.dgvPayinOutHistory.Dock = DockStyle.Fill;
      this.dgvPayinOutHistory.Location = new Point(3, 16);
      this.dgvPayinOutHistory.Name = "dgvPayinOutHistory";
      this.dgvPayinOutHistory.ReadOnly = true;
      this.dgvPayinOutHistory.RowHeadersVisible = false;
      this.dgvPayinOutHistory.Size = new Size(312, 415);
      this.dgvPayinOutHistory.TabIndex = 17;
      this.dgvPayinOutHistory.CellContentClick += new DataGridViewCellEventHandler(this.dgvPayinOutHistory_CellContentClick);
      this.dataGridViewTextBoxColumn4.HeaderText = "Amount";
      this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
      this.dataGridViewTextBoxColumn4.ReadOnly = true;
      this.dataGridViewTextBoxColumn4.Width = 80;
      this.groupBox1.Controls.Add((Control) this.dgvPayinOutHistory);
      this.groupBox1.Location = new Point(393, 2);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(318, 434);
      this.groupBox1.TabIndex = 15;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "PayOut History";
      this.Date.HeaderText = "Date";
      this.Date.Name = "Date";
      this.DealerIDFund.HeaderText = "DealerID Fund";
      this.DealerIDFund.Name = "DealerIDFund";
      this.DealerIDFund.ReadOnly = true;
      this.ClientCode.HeaderText = "Dealer ClientCode";
      this.ClientCode.Name = "ClientCode";
      this.ClientCode.ReadOnly = true;
      this.dvgpayout.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dvgpayout.Columns.AddRange((DataGridViewColumn) this.ClientCode, (DataGridViewColumn) this.DealerIDFund, (DataGridViewColumn) this.Date);
      this.dvgpayout.Location = new Point(3, 82);
      this.dvgpayout.Name = "dvgpayout";
      this.dvgpayout.Size = new Size(384, 354);
      this.dvgpayout.TabIndex = 14;
      this.label5.AutoSize = true;
      this.label5.ForeColor = Color.Red;
      this.label5.Location = new Point(0, 66);
      this.label5.Name = "label5";
      this.label5.Size = new Size(150, 13);
      this.label5.TabIndex = 13;
      this.label5.Text = "*Click on the Record to Select";
      this.cmbclientcode.FormattingEnabled = true;
      this.cmbclientcode.Location = new Point(6, 31);
      this.cmbclientcode.Name = "cmbclientcode";
      this.cmbclientcode.Size = new Size(92, 21);
      this.cmbclientcode.TabIndex = 11;
      this.cmbclientcode.SelectedIndexChanged += new EventHandler(this.cmbclientcode_SelectedIndexChanged);
      this.txtwdrw.Location = new Point(202, 32);
      this.txtwdrw.Name = "txtwdrw";
      this.txtwdrw.Size = new Size(92, 20);
      this.txtwdrw.TabIndex = 3;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(199, 16);
      this.label4.Name = "label4";
      this.label4.Size = new Size(81, 13);
      this.label4.TabIndex = 6;
      this.label4.Text = "PayOut Amount";
      this.btnupdate.Location = new Point(300, 14);
      this.btnupdate.Name = "btnupdate";
      this.btnupdate.Size = new Size(75, 41);
      this.btnupdate.TabIndex = 3;
      this.btnupdate.Text = "Withdraw Fund";
      this.btnupdate.UseVisualStyleBackColor = true;
      this.btnupdate.Click += new EventHandler(this.btnupdate_Click);
      this.txtamount.Location = new Point(104, 32);
      this.txtamount.MaxLength = 10;
      this.txtamount.Name = "txtamount";
      this.txtamount.Size = new Size(92, 20);
      this.txtamount.TabIndex = 2;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(101, 16);
      this.label3.Name = "label3";
      this.label3.Size = new Size(70, 13);
      this.label3.TabIndex = 4;
      this.label3.Text = "Total Amount";
      this.label1.AutoSize = true;
      this.label1.Location = new Point(10, 16);
      this.label1.Name = "label1";
      this.label1.Size = new Size(61, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Client Code";
      this.groupBox2.Controls.Add((Control) this.cmbclientcode);
      this.groupBox2.Controls.Add((Control) this.txtwdrw);
      this.groupBox2.Controls.Add((Control) this.label4);
      this.groupBox2.Controls.Add((Control) this.btnupdate);
      this.groupBox2.Controls.Add((Control) this.txtamount);
      this.groupBox2.Controls.Add((Control) this.label3);
      this.groupBox2.Controls.Add((Control) this.label1);
      this.groupBox2.Location = new Point(3, 2);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(384, 61);
      this.groupBox2.TabIndex = 12;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Enter Amount";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(708, 438);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.dvgpayout);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.groupBox2);
      this.Name = nameof (FrmPayout);
      this.Text = "DI Payout";
      ((ISupportInitialize) this.dgvPayinOutHistory).EndInit();
      this.groupBox1.ResumeLayout(false);
      ((ISupportInitialize) this.dvgpayout).EndInit();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
