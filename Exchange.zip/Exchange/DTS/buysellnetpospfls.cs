﻿// Decompiled with JetBrains decompiler
// Type: DTS.buysellnetpospfls
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;

namespace DTS
{
  public struct buysellnetpospfls
  {
    public int buy_sell;
    public int Qty;
    public Decimal Commision;
    public Decimal Comm_Tax;
    public Decimal margin;
    public Decimal p_l;
    public Decimal p_ltax;
    public int BQty;
    public int SQty;
    public Decimal buyprice;
    public Decimal sellprice;
    public string symbol;
    public Decimal UnrealisedP_l;
    public double TurnoverUtilised;
  }
}
