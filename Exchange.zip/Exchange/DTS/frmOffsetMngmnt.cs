﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmOffsetMngmnt
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmOffsetMngmnt : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    private GroupBox groupBox1;
    private RadioButton rdoNsecurr;
    private RadioButton rdoNseFut;
    private RadioButton rdoNcdex;
    private RadioButton rdoMcx;
    private GroupBox groupBox2;
    private Button btnView;
    private ComboBox cmbClientcode;
    private DataGridView dgvOffset;
    private GroupBox groupBox3;
    private Button btnSave;
    private NumericUpDown Spinoffset;
    private DataGridViewTextBoxColumn ColSymbol;
    private DataGridViewTextBoxColumn Coloffset;
    private DataGridViewCheckBoxColumn colSelect;
    private CheckBox chkSelectall;
    private RadioButton rdoAll;
    private RadioButton rdoNseOpt;

    public frmOffsetMngmnt(Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.Icon = this.objdash.ico;
    }

    public void LoadControls()
    {
      this.dgvOffset.Rows.Clear();
      this.cmbClientcode.Items.Clear();
      this.cmbClientcode.Items.Add((object) "--Select--");
      this.cmbClientcode.Items.Add((object) "Default");
      foreach (object lstAccount in this.objdash._lstAccounts)
        this.cmbClientcode.Items.Add(lstAccount);
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objdash._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.rdoMcx.Visible = true;
            break;
          case 2:
            this.rdoNseFut.Visible = true;
            break;
          case 3:
            this.rdoNcdex.Visible = true;
            break;
          case 4:
            this.rdoNsecurr.Visible = true;
            break;
          case 5:
            this.rdoNseOpt.Visible = true;
            break;
        }
      }
    }

    private void LoadSymbols(int exch)
    {
      this.dgvOffset.Rows.Clear();
      List<string> stringList = new List<string>();
      if (!this.objdash._Exchconctracts.ContainsKey(exch))
        return;
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objdash._Exchconctracts[exch])
      {
        if (!stringList.Contains(keyValuePair.Value.symbol))
        {
          int index = this.dgvOffset.Rows.Add();
          this.dgvOffset.Rows[index].Cells[0].Value = (object) keyValuePair.Value.symbol;
          this.dgvOffset.Rows[index].Cells[1].Value = (object) "0";
          this.dgvOffset.Rows[index].Cells[2].Value = (object) false;
          stringList.Add(keyValuePair.Value.symbol);
        }
      }
      this.chkSelectall.Checked = false;
    }

    private void rdoMcx_Click(object sender, EventArgs e)
    {
      this.rdoMcx.Checked = true;
      this.LoadSymbols(1);
    }

    private void rdoNseFut_Click(object sender, EventArgs e)
    {
      this.rdoNseFut.Checked = true;
      this.LoadSymbols(2);
    }

    private void rdoNcdex_Click(object sender, EventArgs e)
    {
      this.rdoNcdex.Checked = true;
      this.LoadSymbols(3);
    }

    private void rdoNsecurr_Click(object sender, EventArgs e)
    {
      this.rdoNsecurr.Checked = true;
      this.LoadSymbols(4);
    }

    private void rdoAll_Click(object sender, EventArgs e)
    {
      this.rdoAll.Checked = true;
      this.dgvOffset.Rows.Clear();
      foreach (KeyValuePair<string, Contracts> symconctract in this.objdash._Symconctracts)
      {
        int index = this.dgvOffset.Rows.Add();
        this.dgvOffset.Rows[index].Cells[0].Value = (object) symconctract.Value.symbol;
        this.dgvOffset.Rows[index].Cells[1].Value = (object) "0";
        this.dgvOffset.Rows[index].Cells[2].Value = (object) false;
      }
    }

    private void chkSelectall_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkSelectall.Checked)
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOffset.Rows)
          row.Cells[2].Value = (object) true;
      }
      else
      {
        foreach (DataGridViewRow row in (IEnumerable) this.dgvOffset.Rows)
          row.Cells[2].Value = (object) false;
      }
    }

    private void dgvOffset_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.ColumnIndex != 2 || e.RowIndex <= -1)
        return;
      this.dgvOffset.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = !this.dgvOffset.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.Equals((object) false) ? (object) false : (object) true;
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      if (this.cmbClientcode.SelectedIndex > 0)
      {
        string key = this.Getclientcode();
        this.dgvOffset.Rows.Clear();
        if (!this.objdash._ClientOffset.ContainsKey(key))
          return;
        foreach (KeyValuePair<string, double> keyValuePair in this.objdash._ClientOffset[key])
        {
          int index = this.dgvOffset.Rows.Add();
          this.dgvOffset.Rows[index].Cells[0].Value = (object) keyValuePair.Key;
          this.dgvOffset.Rows[index].Cells[1].Value = (object) keyValuePair.Value;
          this.dgvOffset.Rows[index].Cells[2].Value = (object) false;
        }
        this.chkSelectall.Checked = false;
      }
      else
        this.objdash.DisplayMessage("Select Clientcode to view Offset", 2);
    }

    private string Getclientcode()
    {
      string str = this.cmbClientcode.Text;
      if (str == "Default")
        str = this.objdash.objinfo.clientcode;
      return str;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.cmbClientcode.SelectedIndex > 0)
      {
        string clientcode = this.Getclientcode();
        if (this.dgvOffset.Rows.Count > 0)
        {
          SqlConnection conn = this.objdash.getConn();
          if (conn.State == ConnectionState.Open)
          {
            foreach (DataGridViewRow row in (IEnumerable) this.dgvOffset.Rows)
            {
              if (row.Cells[2].Value.Equals((object) true))
              {
                string symbol = row.Cells[0].Value.ToString();
                Decimal num = this.Spinoffset.Value;
                SqlCommand sqlCommand1 = new SqlCommand("SaveOffset", conn);
                sqlCommand1.CommandType = CommandType.StoredProcedure;
                using (SqlCommand sqlCommand2 = sqlCommand1)
                {
                  try
                  {
                    sqlCommand2.Parameters.AddWithValue("@clientcode", (object) clientcode);
                    sqlCommand2.Parameters.AddWithValue("@symbol", (object) symbol);
                    sqlCommand2.Parameters.AddWithValue("@offset", (object) num);
                    sqlCommand2.ExecuteNonQuery();
                    row.Cells[1].Value = (object) num;
                    Thread.Sleep(10);
                    Application.DoEvents();
                    this.objdash.ManageOffset(clientcode, symbol, Convert.ToDouble(num));
                  }
                  catch
                  {
                    break;
                  }
                }
              }
            }
          }
          this.objdash.DisplayMessage("Offset saved Successfully!!", 1);
        }
        else
          this.objdash.DisplayMessage("Select Symbol to Save Offset", 2);
      }
      else
        this.objdash.DisplayMessage("Select Clientcode to Save Offset", 2);
    }

    private void rdoNseOpt_Click(object sender, EventArgs e)
    {
      this.rdoNseOpt.Checked = true;
      this.LoadSymbols(5);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.rdoNseOpt = new RadioButton();
      this.rdoAll = new RadioButton();
      this.rdoNsecurr = new RadioButton();
      this.rdoNseFut = new RadioButton();
      this.rdoNcdex = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.groupBox2 = new GroupBox();
      this.btnView = new Button();
      this.cmbClientcode = new ComboBox();
      this.dgvOffset = new DataGridView();
      this.ColSymbol = new DataGridViewTextBoxColumn();
      this.Coloffset = new DataGridViewTextBoxColumn();
      this.colSelect = new DataGridViewCheckBoxColumn();
      this.groupBox3 = new GroupBox();
      this.btnSave = new Button();
      this.Spinoffset = new NumericUpDown();
      this.chkSelectall = new CheckBox();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((ISupportInitialize) this.dgvOffset).BeginInit();
      this.groupBox3.SuspendLayout();
      this.Spinoffset.BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.rdoNseOpt);
      this.groupBox1.Controls.Add((Control) this.rdoAll);
      this.groupBox1.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox1.Controls.Add((Control) this.rdoNseFut);
      this.groupBox1.Controls.Add((Control) this.rdoNcdex);
      this.groupBox1.Controls.Add((Control) this.rdoMcx);
      this.groupBox1.Location = new Point(8, 4);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(305, 64);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Exchange";
      this.rdoNseOpt.AutoSize = true;
      this.rdoNseOpt.Location = new Point(2, 41);
      this.rdoNseOpt.Name = "rdoNseOpt";
      this.rdoNseOpt.Size = new Size(69, 17);
      this.rdoNseOpt.TabIndex = 5;
      this.rdoNseOpt.TabStop = true;
      this.rdoNseOpt.Text = "NSEOPT";
      this.rdoNseOpt.UseVisualStyleBackColor = true;
      this.rdoNseOpt.Visible = false;
      this.rdoNseOpt.Click += new EventHandler(this.rdoNseOpt_Click);
      this.rdoAll.AutoSize = true;
      this.rdoAll.Location = new Point(266, 19);
      this.rdoAll.Name = "rdoAll";
      this.rdoAll.Size = new Size(36, 17);
      this.rdoAll.TabIndex = 4;
      this.rdoAll.TabStop = true;
      this.rdoAll.Text = "All";
      this.rdoAll.UseVisualStyleBackColor = true;
      this.rdoAll.Visible = false;
      this.rdoAll.Click += new EventHandler(this.rdoAll_Click);
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(186, 19);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 3;
      this.rdoNsecurr.TabStop = true;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNsecurr.Click += new EventHandler(this.rdoNsecurr_Click);
      this.rdoNseFut.AutoSize = true;
      this.rdoNseFut.Location = new Point(52, 19);
      this.rdoNseFut.Name = "rdoNseFut";
      this.rdoNseFut.Size = new Size(68, 17);
      this.rdoNseFut.TabIndex = 2;
      this.rdoNseFut.TabStop = true;
      this.rdoNseFut.Text = "NSEFUT";
      this.rdoNseFut.UseVisualStyleBackColor = true;
      this.rdoNseFut.Visible = false;
      this.rdoNseFut.Click += new EventHandler(this.rdoNseFut_Click);
      this.rdoNcdex.AutoSize = true;
      this.rdoNcdex.Location = new Point(122, 19);
      this.rdoNcdex.Name = "rdoNcdex";
      this.rdoNcdex.Size = new Size(62, 17);
      this.rdoNcdex.TabIndex = 1;
      this.rdoNcdex.TabStop = true;
      this.rdoNcdex.Text = "NCDEX";
      this.rdoNcdex.UseVisualStyleBackColor = true;
      this.rdoNcdex.Visible = false;
      this.rdoNcdex.Click += new EventHandler(this.rdoNcdex_Click);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Location = new Point(2, 19);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 0;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.rdoMcx.Click += new EventHandler(this.rdoMcx_Click);
      this.groupBox2.Controls.Add((Control) this.btnView);
      this.groupBox2.Controls.Add((Control) this.cmbClientcode);
      this.groupBox2.Location = new Point(8, 74);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(305, 48);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "ClientCode";
      this.btnView.Location = new Point(188, 17);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(75, 23);
      this.btnView.TabIndex = 1;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.cmbClientcode.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbClientcode.FormattingEnabled = true;
      this.cmbClientcode.Location = new Point(19, 19);
      this.cmbClientcode.Name = "cmbClientcode";
      this.cmbClientcode.Size = new Size(121, 21);
      this.cmbClientcode.Sorted = true;
      this.cmbClientcode.TabIndex = 0;
      this.dgvOffset.AllowUserToAddRows = false;
      this.dgvOffset.AllowUserToDeleteRows = false;
      this.dgvOffset.AllowUserToOrderColumns = true;
      this.dgvOffset.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvOffset.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
      this.dgvOffset.BackgroundColor = Color.White;
      this.dgvOffset.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvOffset.Columns.AddRange((DataGridViewColumn) this.ColSymbol, (DataGridViewColumn) this.Coloffset, (DataGridViewColumn) this.colSelect);
      this.dgvOffset.Location = new Point(6, 201);
      this.dgvOffset.Name = "dgvOffset";
      this.dgvOffset.ReadOnly = true;
      this.dgvOffset.RowHeadersVisible = false;
      this.dgvOffset.Size = new Size(307, 289);
      this.dgvOffset.TabIndex = 2;
      this.dgvOffset.CellClick += new DataGridViewCellEventHandler(this.dgvOffset_CellClick);
      this.ColSymbol.HeaderText = "Symbol";
      this.ColSymbol.Name = "ColSymbol";
      this.ColSymbol.ReadOnly = true;
      this.Coloffset.HeaderText = "Offset";
      this.Coloffset.Name = "Coloffset";
      this.Coloffset.ReadOnly = true;
      this.colSelect.HeaderText = "";
      this.colSelect.Name = "colSelect";
      this.colSelect.ReadOnly = true;
      this.groupBox3.Controls.Add((Control) this.btnSave);
      this.groupBox3.Controls.Add((Control) this.Spinoffset);
      this.groupBox3.Location = new Point(8, 128);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new Size(305, 48);
      this.groupBox3.TabIndex = 3;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Enter Offset";
      this.btnSave.Location = new Point(188, 16);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 23);
      this.btnSave.TabIndex = 2;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.Spinoffset.DecimalPlaces = 2;
      this.Spinoffset.Increment = new Decimal(new int[4]
      {
        5,
        0,
        0,
        131072
      });
      this.Spinoffset.Location = new Point(78, 16);
      this.Spinoffset.Maximum = new Decimal(new int[4]
      {
        1000,
        0,
        0,
        0
      });
      this.Spinoffset.Name = "Spinoffset";
      this.Spinoffset.Size = new Size(62, 20);
      this.Spinoffset.TabIndex = 0;
      this.chkSelectall.AutoSize = true;
      this.chkSelectall.Location = new Point(250, 182);
      this.chkSelectall.Name = "chkSelectall";
      this.chkSelectall.Size = new Size(37, 17);
      this.chkSelectall.TabIndex = 4;
      this.chkSelectall.Text = "All";
      this.chkSelectall.UseVisualStyleBackColor = true;
      this.chkSelectall.CheckedChanged += new EventHandler(this.chkSelectall_CheckedChanged);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(318, 495);
      this.Controls.Add((Control) this.chkSelectall);
      this.Controls.Add((Control) this.groupBox3);
      this.Controls.Add((Control) this.dgvOffset);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.groupBox1);
      this.MaximizeBox = false;
      this.Name = nameof (frmOffsetMngmnt);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Offset Management";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      ((ISupportInitialize) this.dgvOffset).EndInit();
      this.groupBox3.ResumeLayout(false);
      this.Spinoffset.EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
