﻿// Decompiled with JetBrains decompiler
// Type: DTS.UserinfoMain
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Data;
using System.Data.SqlClient;

namespace DTS
{
  public class UserinfoMain
  {
    public static int saveUserinfo(Userinfo objinfo, SqlConnection conn)
    {
      SqlCommand sqlCommand1 = new SqlCommand("Saveuserinfo", conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@clientcode", (object) objinfo.clientcode);
        sqlCommand2.Parameters.AddWithValue("@name", (object) objinfo.name);
        sqlCommand2.Parameters.AddWithValue("@username", (object) objinfo.username);
        sqlCommand2.Parameters.AddWithValue("@password", (object) objinfo.password);
        sqlCommand2.Parameters.AddWithValue("@userstatus", (object) objinfo.userstatus);
        sqlCommand2.Parameters.AddWithValue("@marginstaus", (object) objinfo.marginstatus);
        sqlCommand2.Parameters.AddWithValue("@productype", (object) objinfo.productype);
        sqlCommand2.Parameters.AddWithValue("@usertype", (object) objinfo.usertype);
        sqlCommand2.Parameters.AddWithValue("@createdby", (object) objinfo.createdby);
        sqlCommand2.Parameters.AddWithValue("@pivots", (object) objinfo.pivots);
        sqlCommand2.Parameters.AddWithValue("@stockperform", (object) objinfo.stockperform);
        sqlCommand2.Parameters.AddWithValue("@charts", (object) objinfo.charts);
        sqlCommand2.Parameters.AddWithValue("@exchanges", (object) objinfo.exchange);
        sqlCommand2.Parameters.AddWithValue("@offset", (object) objinfo.offset);
        sqlCommand2.Parameters.AddWithValue("@oddlot", (object) objinfo.oddlot);
        sqlCommand2.Parameters.AddWithValue("@appname", (object) objinfo.AppName);
        sqlCommand2.Parameters.AddWithValue("@ismodtrd", (object) objinfo.isModTrd);
        sqlCommand2.Parameters.AddWithValue("@dapfls", (object) objinfo.DApflsPercent);
        sqlCommand2.Parameters.AddWithValue("@emailid", (object) objinfo.emailid);
        sqlCommand2.Parameters.AddWithValue("@mobno", (object) objinfo.Mobno);
        sqlCommand2.Parameters.AddWithValue("@offsetexch", (object) objinfo.OffsetExch);
        sqlCommand2.Parameters.AddWithValue("@ishltrading", (object) objinfo.isHLTrading);
        sqlCommand2.Parameters.AddWithValue("@highlowexch", (object) objinfo.HighLowExch);
        sqlCommand2.Parameters.AddWithValue("@dafunds", (object) objinfo.DAfund);
        sqlCommand2.Parameters.AddWithValue("@issms", (object) objinfo.isSMS);
        sqlCommand2.Parameters.AddWithValue("@DIplis", (object) objinfo.DIpflsPercent);
        try
        {
          return sqlCommand2.ExecuteNonQuery();
        }
        catch (Exception ex)
        {
          return 0;
        }
      }
    }

    private static Userinfo GetEntity1(SqlDataReader reader)
    {
      Userinfo userinfo = (Userinfo) null;
      while (reader.Read())
      {
        userinfo = new Userinfo();
        if (!reader.IsDBNull(0))
          userinfo.userstatus = Convert.ToInt32(reader.GetValue(0));
      }
      return userinfo;
    }

    private static Userinfo GetEntity(SqlDataReader reader)
    {
      Userinfo userinfo = (Userinfo) null;
      while (reader.Read())
      {
        userinfo = new Userinfo();
        if (!reader.IsDBNull(0))
          userinfo.name = reader.GetString(0);
        if (!reader.IsDBNull(1))
          userinfo.clientcode = reader.GetString(1);
        if (!reader.IsDBNull(2))
          userinfo.username = reader.GetString(2);
        if (!reader.IsDBNull(3))
          userinfo.password = reader.GetString(3);
        if (!reader.IsDBNull(4))
          userinfo.regdate = Convert.ToDateTime(reader.GetValue(4));
        if (!reader.IsDBNull(5))
          userinfo.userstatus = Convert.ToInt32(reader.GetValue(5));
        if (!reader.IsDBNull(6))
          userinfo.marginstatus = Convert.ToInt32(reader.GetValue(6));
        if (!reader.IsDBNull(7))
          userinfo.productype = Convert.ToInt32(reader.GetValue(7));
        if (!reader.IsDBNull(8))
          userinfo.usertype = Convert.ToInt32(reader.GetValue(8));
        if (!reader.IsDBNull(9))
          userinfo.createdby = reader.GetString(9);
        if (!reader.IsDBNull(10))
          userinfo.Lastlogin = Convert.ToDateTime(reader.GetValue(10));
        if (!reader.IsDBNull(11))
          userinfo.pivots = reader.GetInt32(11);
        if (!reader.IsDBNull(12))
          userinfo.stockperform = reader.GetInt32(12);
        if (!reader.IsDBNull(13))
          userinfo.charts = reader.GetInt32(13);
        if (!reader.IsDBNull(14))
          userinfo.exchange = reader.GetString(14);
        if (!reader.IsDBNull(15))
          userinfo.offset = reader.GetInt32(15);
        if (!reader.IsDBNull(16))
          userinfo.mappedclients = reader.GetString(16);
        if (!reader.IsDBNull(17))
          userinfo.oddlot = reader.GetInt32(17);
        if (!reader.IsDBNull(18))
          userinfo.BlastPassword = reader.GetString(18);
        if (!reader.IsDBNull(19))
          userinfo.AppName = reader.GetString(19);
        if (!reader.IsDBNull(20))
          userinfo.isModTrd = reader.GetInt32(20);
        if (!reader.IsDBNull(21))
          userinfo.DApflsPercent = Convert.ToInt32(reader.GetValue(21));
        if (!reader.IsDBNull(22))
          userinfo.emailid = reader.GetString(22);
        if (!reader.IsDBNull(23))
          userinfo.Mobno = Convert.ToInt64(reader.GetValue(23));
        userinfo.OffsetExch = reader.IsDBNull(25) ? string.Empty : reader.GetString(25);
        if (!reader.IsDBNull(26))
          userinfo.isHLTrading = reader.GetInt32(26);
        userinfo.HighLowExch = reader.IsDBNull(27) ? string.Empty : reader.GetString(27);
        if (!reader.IsDBNull(28))
          userinfo.ischngpwd = reader.GetInt32(28);
        if (!reader.IsDBNull(29))
          userinfo.isSMS = reader.GetInt32(29);
      }
      return userinfo;
    }

    public static Userinfo ValidateandGetUserinfo(
      string username,
      string password,
      SqlConnection conn)
    {
      Userinfo userinfo = (Userinfo) null;
      SqlCommand sqlCommand1 = new SqlCommand("ValidateLogin", conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@username", (object) username);
        sqlCommand2.Parameters.AddWithValue("@password", (object) password);
        sqlCommand2.Parameters.AddWithValue("@ipaddr", (object) Utils.LocalIPAddress());
        using (SqlDataReader reader = sqlCommand2.ExecuteReader())
          userinfo = UserinfoMain.GetEntity(reader);
      }
      return userinfo;
    }

    public static int validateadmin(string clientCode, SqlConnection conn)
    {
      int num = 1;
      try
      {
        using (SqlCommand sqlCommand = new SqlCommand("Select [Userstatus] from [DTS1].[dbo].[Userinformation] where Clientcode = '" + clientCode + "';", conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(0))
                num = Convert.ToInt32(sqlDataReader.GetValue(0));
            }
          }
        }
      }
      catch
      {
      }
      return num;
    }

    public static void UpdateLogoff(string username, SqlConnection conn)
    {
      using (SqlCommand sqlCommand = new SqlCommand("insert into LogIn_OffReports (Clientcode,IPaddr,LogIN_OFF,Timestamp) values ('" + username + "','" + Utils.LocalIPAddress() + "',2,Getdate())", conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
        }
        catch
        {
        }
      }
    }
  }
}
