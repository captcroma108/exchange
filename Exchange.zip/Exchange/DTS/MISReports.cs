﻿// Decompiled with JetBrains decompiler
// Type: DTS.MISReports
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class MISReports : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objmain;
    public DateTime MktStartTime;
    private GroupBox groupBox1;
    private CheckBox chkMisDtw;
    private Label label2;
    private Label label1;
    private DateTimePicker Todate;
    private DateTimePicker Fromdate;
    private TreeView treeView1;
    private ListBox lstCommon;
    private DataGridView dgvReports;
    private TabControl tabControl1;
    private TabPage tabPage1;
    private TabPage tabPage2;
    private ListBox lstTrades;
    private TabPage tabPage3;
    private ListBox lstOrders;
    private TabPage tabPage4;
    private ListBox lstAccounts;
    private Button btnView;
    private Button btnExport;
    private GroupBox groupBox2;
    private ComboBox cmbSymbol;
    private RadioButton rdoNcdex;
    private RadioButton rdoNsecurr;
    private RadioButton rdoNseopt;
    private RadioButton rdoNsefut;
    private RadioButton rdoMcx;
    private CheckBox chkSymbolwise;
    private CheckBox chkExchwise;
    private RadioButton rdoTxtFrmt;
    private RadioButton rdoCsvFrmt;
    private ComboBox cmbExch;
    private RadioButton rdoSauda;
    private RadioButton rdoShilpi;
    private RadioButton rdoLogics;
    private RadioButton rdo_SaudaNew;
    private RadioButton rdo_Exch;
    private RadioButton rdo_Vijaya;
    private RadioButton rdo_FMT;
    private RadioButton rdo_TB;

    public MISReports(Dashboard mainobj)
    {
      this.InitializeComponent();
      this.objmain = mainobj;
      this.Icon = this.objmain.ico;
    }

    public void LoadHierarchy()
    {
      DateTime serverTime = this.objmain.GetServerTime();
      this.MktStartTime = new DateTime(serverTime.Year, serverTime.Month, serverTime.Day, 9, 0, 0);
      this.treeView1.Nodes.Clear();
      switch (this.objmain.objinfo.usertype)
      {
        case 1:
          this.treeView1.Nodes.Add("DEALER ADMIN");
          int index1 = 0;
          using (Dictionary<string, Dictionary<string, Userinfo>>.Enumerator enumerator = this.objmain._DAHierarchy.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              KeyValuePair<string, Dictionary<string, Userinfo>> current = enumerator.Current;
              this.treeView1.Nodes[0].Nodes.Add(current.Key);
              this.treeView1.Nodes[0].Nodes[index1].Nodes.Add("DEALER");
              this.treeView1.Nodes[0].Nodes[index1].Nodes.Add("CIENT");
              int index2 = 0;
              foreach (KeyValuePair<string, Userinfo> keyValuePair in current.Value)
              {
                Userinfo userinfo = keyValuePair.Value;
                if (userinfo.usertype == 3)
                {
                  this.treeView1.Nodes[0].Nodes[index1].Nodes[0].Nodes.Add(userinfo.clientcode);
                  if (userinfo.mappedclients != null && userinfo.mappedclients.Contains(","))
                  {
                    string[] strArray = userinfo.mappedclients.Split(',');
                    for (int index3 = 0; index3 < strArray.Length; ++index3)
                    {
                      if (strArray[index3] != string.Empty)
                        this.treeView1.Nodes[0].Nodes[index1].Nodes[0].Nodes[index2].Nodes.Add(strArray[index3]);
                    }
                  }
                  ++index2;
                }
                else
                  this.treeView1.Nodes[0].Nodes[index1].Nodes[1].Nodes.Add(userinfo.clientcode);
              }
              ++index1;
            }
            break;
          }
        case 2:
          this.treeView1.Nodes.Add("DEALER");
          this.treeView1.Nodes.Add("CLIENT");
          int index4 = 0;
          using (Dictionary<string, Userinfo>.Enumerator enumerator = this.objmain._Userinformation.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              KeyValuePair<string, Userinfo> current = enumerator.Current;
              string key = current.Key;
              Userinfo userinfo = current.Value;
              if (userinfo.usertype == 3)
              {
                this.treeView1.Nodes[0].Nodes.Add(userinfo.clientcode);
                if (userinfo.mappedclients != null && userinfo.mappedclients.Contains(","))
                {
                  string[] strArray = userinfo.mappedclients.Split(',');
                  for (int index2 = 0; index2 < strArray.Length; ++index2)
                  {
                    if (strArray[index2] != string.Empty)
                      this.treeView1.Nodes[0].Nodes[index4].Nodes.Add(strArray[index2]);
                  }
                }
                ++index4;
              }
              else
                this.treeView1.Nodes[1].Nodes.Add(userinfo.clientcode);
            }
            break;
          }
      }
      this.cmbExch.Items.Clear();
      foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objmain._Exchconctracts)
      {
        switch (exchconctract.Key)
        {
          case 1:
            this.cmbExch.Items.Add((object) "MCX");
            break;
          case 2:
            this.cmbExch.Items.Add((object) "NSEFUT");
            break;
          case 3:
            this.cmbExch.Items.Add((object) "NCDEX");
            break;
          case 4:
            this.cmbExch.Items.Add((object) "NSECUR");
            break;
          case 5:
            this.cmbExch.Items.Add((object) "NSEOPT");
            break;
        }
      }
    }

    private string GetAccounts(ref List<string> _lstAccounts, ref string DACode)
    {
      string str = string.Empty;
      _lstAccounts = new List<string>();
      foreach (TreeNode node1 in this.treeView1.Nodes)
      {
        switch (this.objmain.objinfo.usertype)
        {
          case 1:
            if (node1.Text == "DEALER ADMIN")
            {
              IEnumerator enumerator = node1.Nodes.GetEnumerator();
              try
              {
                while (enumerator.MoveNext())
                {
                  TreeNode current = (TreeNode) enumerator.Current;
                  if (current.Checked)
                    DACode += string.Format("'{0}',", (object) current.Text);
                  foreach (TreeNode node2 in current.Nodes)
                  {
                    if (node2.Text == "DEALER")
                    {
                      foreach (TreeNode node3 in node2.Nodes)
                      {
                        foreach (TreeNode node4 in node3.Nodes)
                        {
                          if (!_lstAccounts.Contains(node4.Text) && node4.Checked)
                          {
                            _lstAccounts.Add(node4.Text);
                            str += string.Format("'{0}',", (object) node4.Text);
                          }
                        }
                      }
                    }
                    else
                    {
                      foreach (TreeNode node3 in node2.Nodes)
                      {
                        if (!_lstAccounts.Contains(node3.Text) && node3.Checked)
                        {
                          _lstAccounts.Add(node3.Text);
                          str += string.Format("'{0}',", (object) node3.Text);
                        }
                      }
                    }
                  }
                }
                break;
              }
              finally
              {
                if (enumerator is IDisposable disposable)
                  disposable.Dispose();
              }
            }
            else
              break;
          case 2:
            string text = node1.Text;
            if (!(text == "DEALER"))
            {
              if (text == "CLIENT")
              {
                IEnumerator enumerator = node1.Nodes.GetEnumerator();
                try
                {
                  while (enumerator.MoveNext())
                  {
                    TreeNode current = (TreeNode) enumerator.Current;
                    if (!_lstAccounts.Contains(current.Text) && current.Checked)
                    {
                      _lstAccounts.Add(current.Text);
                      str += string.Format("'{0}',", (object) current.Text);
                    }
                  }
                  break;
                }
                finally
                {
                  if (enumerator is IDisposable disposable)
                    disposable.Dispose();
                }
              }
              else
                break;
            }
            else
            {
              IEnumerator enumerator = node1.Nodes.GetEnumerator();
              try
              {
                while (enumerator.MoveNext())
                {
                  foreach (TreeNode node2 in ((TreeNode) enumerator.Current).Nodes)
                  {
                    if (!_lstAccounts.Contains(node2.Text) && node2.Checked)
                    {
                      _lstAccounts.Add(node2.Text);
                      str += string.Format("'{0}',", (object) node2.Text);
                    }
                  }
                }
                break;
              }
              finally
              {
                if (enumerator is IDisposable disposable)
                  disposable.Dispose();
              }
            }
        }
      }
      if (str.Length > 0)
        str = str.Substring(0, str.Length - 1);
      if (DACode.Length > 0)
        DACode = DACode.Substring(0, DACode.Length - 1);
      return str;
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      List<string> _lstAccounts = new List<string>();
      string empty = string.Empty;
      string accounts = this.GetAccounts(ref _lstAccounts, ref empty);
      this.dgvReports.DataSource = (object) null;
      this.dgvReports.Rows.Clear();
      this.dgvReports.Columns.Clear();
      if ((this.tabControl1.SelectedIndex != 0 || !(this.lstCommon.SelectedItem.ToString() == "Accounts Deleted")) && accounts.Length == 0)
        this.objmain.DisplayMessage("Select Account to View Report", 2);
      else if (this.chkSymbolwise.Checked && this.cmbSymbol.SelectedIndex <= 0)
      {
        this.objmain.DisplayMessage("Select Symbol to View Symbolwise Report", 2);
      }
      else
      {
        switch (this.tabControl1.SelectedIndex)
        {
          case 0:
            if (this.chkMisDtw.Checked && (this.lstCommon.SelectedItem.ToString() == "Allocated Margin" || this.lstCommon.SelectedItem.ToString() == "Registration Logs"))
            {
              this.objmain.DisplayMessage("DateWise Report Unavailable for this Type of report.", 2);
              break;
            }
            if (this.lstCommon.SelectedItem != null)
            {
              this.dgvReports.DataSource = (object) this.GetReport(this.lstCommon.SelectedItem.ToString(), accounts, empty).Tables[0];
              break;
            }
            this.objmain.DisplayMessage("Select Report to View", 2);
            break;
          case 1:
            if (this.lstTrades.SelectedItem != null)
            {
              this.dgvReports.DataSource = (object) this.GetReport(this.lstTrades.SelectedItem.ToString(), accounts, empty).Tables[0];
              break;
            }
            this.objmain.DisplayMessage("Select Report to View", 2);
            break;
          case 2:
            if (this.lstOrders.SelectedItem != null)
            {
              this.dgvReports.DataSource = (object) this.GetReport(this.lstOrders.SelectedItem.ToString(), accounts, empty).Tables[0];
              break;
            }
            this.objmain.DisplayMessage("Select Report to View", 2);
            break;
          case 3:
            if (this.lstAccounts.SelectedItem != null)
            {
              string s = this.lstAccounts.SelectedItem.ToString();
              // ISSUE: reference to a compiler-generated method
              switch (\u003CPrivateImplementationDetails\u003E.ComputeStringHash(s))
              {
                case 881825452:
                  if (!(s == "Ledger"))
                    return;
                  if (_lstAccounts.Count == 1)
                  {
                    if (this.chkMisDtw.Checked)
                    {
                      string str1 = _lstAccounts[0];
                      DateTime dateTime = this.Fromdate.Value;
                      string fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                      dateTime = this.Fromdate.Value;
                      switch (dateTime.DayOfWeek)
                      {
                        case DayOfWeek.Sunday:
                          dateTime = this.Fromdate.Value;
                          dateTime = dateTime.AddDays(-1.0);
                          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                          break;
                        case DayOfWeek.Monday:
                          dateTime = this.Fromdate.Value;
                          dateTime = dateTime.AddDays(-2.0);
                          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                          break;
                      }
                      dateTime = this.Fromdate.Value;
                      string startdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                      dateTime = this.Todate.Value;
                      string str2 = dateTime.ToString("yyyy-MM-dd 23:59:00");
                      dateTime = this.Fromdate.Value;
                      dateTime.ToString("yyyy-MM-dd 23:59:00");
                      Dictionary<string, Ledger> ledger = this.objmain.GetLedger(str1, startdate, str2);
                      SortedDictionary<DateTime, payinoutDetails> payinPayout = this.objmain.GetPayinPayout(str1, fromdate, str2);
                      Decimal begningBal = this.objmain.GetBegningBal(str1, this.Fromdate.Value, str2);
                      this.DisplayLedger(ledger, begningBal, payinPayout, str1);
                      return;
                    }
                    this.objmain.DisplayMessage("Please Select Date to View Ledger.", 2);
                    return;
                  }
                  this.objmain.DisplayMessage("Individual Client Ledger view Available,Please Select Single Client Code", 2);
                  return;
                case 1016449447:
                  if (!(s == "Profit/Loss"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.dgvReports.DataSource = (object) this.GetReport("Profit/Loss", accounts, empty).Tables[0];
                    return;
                  }
                  this.GetProfitLoss(_lstAccounts);
                  return;
                case 1101164762:
                  if (!(s == "DA Profit/Loss") || this.objmain.objinfo.usertype != 1 || !this.chkMisDtw.Checked)
                    return;
                  DataSet report1 = this.GetReport("DA Profit/Loss", accounts, empty);
                  this.AddDAPLCols();
                  double num1 = 0.0;
                  double num2 = 0.0;
                  double num3 = 0.0;
                  if (report1 != null && report1.Tables[0].Rows.Count > 0)
                  {
                    for (int index1 = 0; index1 < report1.Tables[0].Rows.Count; ++index1)
                    {
                      int index2 = this.dgvReports.Rows.Add();
                      this.dgvReports.Rows[index2].Cells[0].Value = (object) report1.Tables[0].Rows[index1].ItemArray[0].ToString();
                      this.dgvReports.Rows[index2].Cells[1].Value = (object) report1.Tables[0].Rows[index1].ItemArray[1].ToString();
                      num1 += Convert.ToDouble(report1.Tables[0].Rows[index1].ItemArray[1]);
                      this.dgvReports.Rows[index2].Cells[2].Value = (object) report1.Tables[0].Rows[index1].ItemArray[2].ToString();
                      num2 += Convert.ToDouble(report1.Tables[0].Rows[index1].ItemArray[2]);
                      this.dgvReports.Rows[index2].Cells[3].Value = (object) report1.Tables[0].Rows[index1].ItemArray[3].ToString();
                      num3 += Convert.ToDouble(report1.Tables[0].Rows[index1].ItemArray[3]);
                      this.dgvReports.Rows[index2].Cells[4].Value = (object) Convert.ToDateTime(report1.Tables[0].Rows[index1].ItemArray[4]).ToString("dd-MM-yyyy");
                    }
                    int index = this.dgvReports.Rows.Add();
                    this.dgvReports.Rows[index].Cells[1].Value = (object) Math.Round(num1, 2);
                    this.dgvReports.Rows[index].Cells[2].Value = (object) Math.Round(num2, 2);
                    this.dgvReports.Rows[index].Cells[3].Value = (object) Math.Round(num3, 2);
                  }
                  return;
                case 1485688774:
                  if (!(s == "Loss Accounts"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.objmain.DisplayMessage("DateWise Report Available for this Type of report.", 2);
                    return;
                  }
                  this.GetLossAccounts(_lstAccounts, false);
                  return;
                case 1665338598:
                  if (!(s == "Ledger(average)"))
                    return;
                  if (_lstAccounts.Count == 1)
                  {
                    if (this.chkMisDtw.Checked)
                    {
                      string str1 = _lstAccounts[0];
                      DateTime dateTime = this.Fromdate.Value;
                      string fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                      dateTime = this.Fromdate.Value;
                      switch (dateTime.DayOfWeek)
                      {
                        case DayOfWeek.Sunday:
                          dateTime = this.Fromdate.Value;
                          dateTime = dateTime.AddDays(-1.0);
                          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                          break;
                        case DayOfWeek.Monday:
                          dateTime = this.Fromdate.Value;
                          dateTime = dateTime.AddDays(-2.0);
                          fromdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                          break;
                      }
                      dateTime = this.Fromdate.Value;
                      string startdate = dateTime.ToString("yyyy-MM-dd 00:00:00");
                      dateTime = this.Todate.Value;
                      string str2 = dateTime.ToString("yyyy-MM-dd 23:59:00");
                      dateTime = this.Fromdate.Value;
                      dateTime.ToString("yyyy-MM-dd 23:59:00");
                      Dictionary<string, LedgerAVG> ledgerAvg = this.objmain.GetLedgerAVG(str1, startdate, str2);
                      SortedDictionary<DateTime, payinoutDetails> payinPayout = this.objmain.GetPayinPayout(str1, fromdate, str2);
                      Decimal begningBal = this.objmain.GetBegningBal(str1, this.Fromdate.Value, str2);
                      this.DisplayLedgerAVG(ledgerAvg, begningBal, payinPayout, str1);
                      return;
                    }
                    this.objmain.DisplayMessage("Please Select Date to View Ledger.", 2);
                    return;
                  }
                  this.objmain.DisplayMessage("Individual Client Ledger view Available,Please Select Single Client Code", 2);
                  return;
                case 1898188666:
                  if (!(s == "Cash Balance"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.objmain.DisplayMessage("DateWise Report Available for this Type of report.", 2);
                    return;
                  }
                  this.GetCashBalance(_lstAccounts);
                  return;
                case 2088051329:
                  if (!(s == "Open Positions"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.objmain.DisplayMessage("DateWise Report Available for this Type of report.", 2);
                    return;
                  }
                  this.GetOpenPos(accounts);
                  return;
                case 2495656413:
                  if (!(s == "Turnover Utilised"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.dgvReports.DataSource = (object) this.GetReport("Turnover Utilised", accounts, empty).Tables[0];
                    return;
                  }
                  this.GetTurnover(_lstAccounts);
                  return;
                case 2916733981:
                  if (!(s == "Profit Accounts"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.objmain.DisplayMessage("DateWise Report Available for this Type of report.", 2);
                    return;
                  }
                  this.GetLossAccounts(_lstAccounts, true);
                  return;
                case 3079089607:
                  if (!(s == "Brokerage"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.dgvReports.DataSource = (object) this.GetReport("Brokerage", accounts, empty).Tables[0];
                    return;
                  }
                  this.GetCommissions(_lstAccounts);
                  return;
                case 3338964900:
                  if (!(s == "Net MTM Profit/Loss"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    DataSet report2 = this.GetReport("Net MTM Profit/Loss", accounts, empty);
                    this.AddNETmtmPFlsCols();
                    double num4 = 0.0;
                    if (report2 == null || report2.Tables[0].Rows.Count <= 0)
                      return;
                    for (int index1 = 0; index1 < report2.Tables[0].Rows.Count; ++index1)
                    {
                      int index2 = this.dgvReports.Rows.Add();
                      this.dgvReports.Rows[index2].Cells[0].Value = (object) report2.Tables[0].Rows[index1].ItemArray[0].ToString();
                      this.dgvReports.Rows[index2].Cells[1].Value = (object) report2.Tables[0].Rows[index1].ItemArray[1].ToString();
                      num4 += Convert.ToDouble(report2.Tables[0].Rows[index1].ItemArray[1]);
                      this.dgvReports.Rows[index2].Cells[2].Value = (object) Convert.ToDateTime(report2.Tables[0].Rows[index1].ItemArray[2]).ToString("dd-MM-yyyy");
                    }
                    int index = this.dgvReports.Rows.Add();
                    this.dgvReports.Rows[index].Cells[0].Value = (object) "Total:";
                    this.dgvReports.Rows[index].Cells[1].Value = (object) Math.Round(num4, 2);
                    return;
                  }
                  this.GetNetMTMPL(_lstAccounts);
                  return;
                case 3865021924:
                  if (!(s == "Margin Utilised"))
                    return;
                  if (this.chkMisDtw.Checked)
                  {
                    this.objmain.DisplayMessage("DateWise Report Available for this Type of report.", 2);
                    return;
                  }
                  this.GetMarginUtilised(_lstAccounts);
                  return;
                default:
                  return;
              }
            }
            else
            {
              this.objmain.DisplayMessage("Select Report to View", 2);
              break;
            }
        }
      }
    }

    private int GetExch()
    {
      if (this.rdoMcx.Checked)
        return 1;
      if (this.rdoNsefut.Checked)
        return 2;
      if (this.rdoNcdex.Checked)
        return 3;
      return this.rdoNsecurr.Checked ? 4 : 5;
    }

    private DataSet GetReport(string ReportType, string RegulationCode, string DACode)
    {
      string selectCommandText = string.Empty;
      DataSet dataSet = new DataSet();
      int exch = this.GetExch();
      DateTime dateTime1;
      ref DateTime local1 = ref dateTime1;
      DateTime dateTime2 = this.Fromdate.Value;
      int year1 = dateTime2.Year;
      dateTime2 = this.Fromdate.Value;
      int month1 = dateTime2.Month;
      dateTime2 = this.Fromdate.Value;
      int day1 = dateTime2.Day;
      int hour = this.MktStartTime.Hour;
      int minute = this.MktStartTime.Minute;
      int second = this.MktStartTime.Second;
      local1 = new DateTime(year1, month1, day1, hour, minute, second);
      DateTime dateTime3;
      ref DateTime local2 = ref dateTime3;
      DateTime dateTime4 = this.Todate.Value;
      int year2 = dateTime4.Year;
      dateTime4 = this.Todate.Value;
      int month2 = dateTime4.Month;
      dateTime4 = this.Todate.Value;
      int day2 = dateTime4.Day;
      local2 = new DateTime(year2, month2, day2, 23, 55, 0);
      switch (ReportType)
      {
        case "Accounts Deleted":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select Userid as ClientCode,[Log],Timestamp from MiscLogs where Userid = '" + this.objmain.objinfo.clientcode + "' and  Timestamp BETWEEN '" + dateTime1.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dateTime3.ToString("yyyy-MM-dd 23:59:00") + "' order by Timestamp", (object) RegulationCode);
            break;
          }
          selectCommandText = string.Format("Select Userid as ClientCode,[Log],Timestamp from MiscLogs where  Userid = '" + this.objmain.objinfo.clientcode + "' and Timestamp > '" + DateTime.Now.ToString("yyyy-MM-dd 00:00:00") + "' order by Timestamp", (object) RegulationCode);
          break;
        case "Admin Messages":
          selectCommandText = !this.chkMisDtw.Checked ? string.Format("Select ClientCode, TextMsg as AdminMessage,Timestamp from MessageBoard where ClientCode in ({0}) and Flag = 0  Order by Timestamp", (object) RegulationCode) : string.Format("Select ClientCode, TextMsg as AdminMessage,Timestamp from MessageBoard where ClientCode in ({0}) and Flag = 0  and Timestamp BETWEEN '{1}' and '{2}' Order by Timestamp", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Allocated Margin":
          if (this.chkSymbolwise.Checked)
          {
            selectCommandText = "Select ClientCode, Symbol,Intramrgn as [IntraMargin], Intrabrkg as [IntraBrkg.],Delvmrgn as [DelvMargin],Delvbrkg as DelvBrkg,Totlots as TotalLots from [SymbolwiseMargin] where ClientCode in (" + RegulationCode + ") and Symbol = '" + this.cmbSymbol.Text + "'";
            break;
          }
          if (this.chkExchwise.Checked)
          {
            selectCommandText = "Select S.ClientCode, S.Symbol,S.Intramrgn as [IntraMargin], S.Intrabrkg as [IntraBrkg.],S.Delvmrgn as [DelvMargin],S.Delvbrkg as DelvBrkg,s.Totlots as TotalLots from [SymbolwiseMargin] S,Contracts C where S.ClientCode in (" + RegulationCode + ") and S.Symbol = C.SymDescription and C.Exch = " + (object) exch ?? "";
            break;
          }
          selectCommandText = "Select ClientCode, Symbol,Intramrgn as [IntraMargin], Intrabrkg as [IntraBrkg.],Delvmrgn as [DelvMargin],Delvbrkg as DelvBrkg,Totlots as TotalLots from [SymbolwiseMargin] where ClientCode in (" + RegulationCode + ")";
          break;
        case "Auto Square Off":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders  where Clientcode in ({0}) and OrdStatus = 5  and CreateOn > '{1}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders where  Clientcode in ({0}) and OrdStatus = 5  and CreateOn > '{1}' and Exch = {2} Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders where Clientcode in ({0}) and OrdStatus = 5  and CreateOn > '{1}' and Symbol = '{2}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders_History  where Clientcode in ({0}) and OrdStatus = 5  and CreateOn Between '{1}' and '{2}'  Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Brokerage":
          selectCommandText = string.Format("Select Clientcode, Brokerage,(case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' END) as Exchange,Timestamp from Brokerage where Clientcode in ({0}) and  Timestamp BETWEEN '{1}' and '{2}'", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd 00:00:00"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "CANCELLED":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  = 3  and CreateOn > '{1}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  = 3  and CreateOn > '{1}' and Exch = '{2}'  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  = 3  and CreateOn > '{1}' and Symbol = '{2}'  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders_History  where  Clientcode in ({0}) and OrdStatus  = 3  and CreateOn BETWEEN '{1}' and '{2}' Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "CNF":
          if (this.chkMisDtw.Checked)
          {
            if (this.rdo_FMT.Checked)
            {
              selectCommandText = "Select O.Clientcode,U.Name,(case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' END) as  Exchange,case when CHARINDEX(' ', O.Symbol) > 0 then SUBSTRING(O.Symbol, 1, CHARINDEX(' ', O.Symbol) - 1) else O.Symbol end Symbol,  CASE WHEN CHARINDEX(' ', O.Symbol) > 0 THEN SUBSTRING(O.Symbol, CHARINDEX(' ', O.Symbol) + 1, len(O.Symbol)) ELSE NULL END as Expiry,(case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END) as ProductType,(case O.ExecType WHEN 1 THEN 'MKT' WHEN 2 THEN 'LMT' END) as ExecType, (case O.BuySell WHEN 1 THEN 'B'  WHEN 2 THEN 'S' END) as [B/S],O.Qty,O.OrdPrice,O.Price as ExecPrice,(case O.Validity WHEN 1 THEN 'CarryForward' WHEN 2  THEN 'Day' WHEN 3 THEN 'GTC' END) as Validity,T.[Timestamp] ,O.Userremarks,O.Traderid as TradedBy,T.Orderno,O.Ipaddress from  Orders_History O,Userinformation U,Trade_History T where O.Clientcode = U.Clientcode and T.Orderno = O.Orderno and O.OrdStatus in  (1,4,5,6) and T.[Timestamp] between '" + dateTime1.ToString("yyyy-MM-dd HH:mm:ss") + "' and '" + dateTime3.ToString("yyyy-MM-dd HH:mm:ss") + "'  and O.Clientcode in (" + RegulationCode + ") and O.IsMaintenance = 0 order by T.Timestamp asc";
              break;
            }
            selectCommandText = string.Format("select Clientcode,case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders_History where  Clientcode in ({0}) and OrdStatus in (1,4,5,6)  and CreateOn BETWEEN '{1}' and '{2}' and Validity = 1 and IsMaintenance = 0 Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
            break;
          }
          if (this.rdo_FMT.Checked)
            selectCommandText = "Select O.Clientcode,U.Name,(case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' END) as  Exchange,case when CHARINDEX(' ', O.Symbol) > 0 then SUBSTRING(O.Symbol, 1, CHARINDEX(' ', O.Symbol) - 1) else O.Symbol end Symbol,  CASE WHEN CHARINDEX(' ', O.Symbol) > 0 THEN SUBSTRING(O.Symbol, CHARINDEX(' ', O.Symbol) + 1, len(O.Symbol)) ELSE NULL END as Expiry,(case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END) as ProductType,(case O.ExecType WHEN 1 THEN 'MKT' WHEN 2 THEN 'LMT' END) as ExecType, (case O.BuySell WHEN 1 THEN 'B'  WHEN 2 THEN 'S' END) as [B/S],O.Qty,O.OrdPrice,O.Price as ExecPrice,(case O.Validity WHEN 1 THEN 'CarryForward' WHEN 2  THEN 'Day' WHEN 3 THEN 'GTC' END) as Validity,T.[Timestamp] ,O.Userremarks,O.Traderid as TradedBy,T.Orderno,O.Ipaddress from  Orders O,Userinformation U,Trade T where O.Clientcode = U.Clientcode and T.Orderno = O.Orderno and O.OrdStatus in  (1,4,5,6) and T.[Timestamp] between '" + dateTime1.ToString("yyyy-MM-dd HH:mm:ss") + "' and '" + dateTime3.ToString("yyyy-MM-dd HH:mm:ss") + "'  and O.Clientcode in (" + RegulationCode + ") and O.IsMaintenance = 0 order by T.Timestamp asc";
          else
            selectCommandText = !this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn > '{1}' and Validity = 1 Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn > '{1}' and Validity = 1 and Exch = {2} Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn > '{1}' and Validity = 1 and Symbol = '{2}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text);
          break;
        case "DA Profit/Loss":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select DACode,NetPfls,DAPfls,SAPfls,Timestamp from DAwiseProfitLoss where DACode in ({0}) and Timestamp between '{1}' and '{2}'", (object) DACode, (object) dateTime1.ToString("yyyy-MM-dd 00:00:00"), (object) dateTime3.ToString("yyyy-MM-dd 23:59:00"));
            break;
          }
          break;
        case "DAY":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'MP' WHEN 2 THEN 'RL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6)  and CreateOn > '{1}' and Validity = 2 Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'MP' WHEN 2 THEN 'RL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6)  and CreateOn > '{1}' and Validity = 2 and Exch = {2} Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'MP' WHEN 2 THEN 'RL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6)  and CreateOn > '{1}' and Validity = 2 and Symbol = '{2}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode,case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, Price, case Validity WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus,Ipaddress from Orders_History  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6)  and CreateOn BETWEEN '{1}' and '{2}' and Validity = 2 and IsMaintenance = 0 Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "DELETED TRADE":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select [Clientcode],[Symbol],[Qty],[OrderNo],[Price],[Timestamp],[BuySell],[Exch],[IPaddress] from TradeDelete where Clientcode in ({0}) and Timestamp between '{1}' and '{2}'", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd 00:00:00"), (object) dateTime3.ToString("yyyy-MM-dd 23:59:00"));
            break;
          }
          string str1 = RegulationCode;
          DateTime now1 = DateTime.Now;
          string str2 = now1.ToString("yyyy-MM-dd 00:00:00");
          now1 = DateTime.Now;
          string str3 = now1.ToString("yyyy-MM-dd 23:59:00");
          selectCommandText = string.Format("Select [Clientcode],[Symbol],[Qty],[OrderNo],[Price],[Timestamp],[BuySell],[Exch],[IPaddress] from TradeDelete where Clientcode in ({0}) and Timestamp between '{1}' and '{2}'", (object) str1, (object) str2, (object) str3);
          break;
        case "EXECUTED":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [ProductType], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty,Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  in (1,4,5,6)  and CreateOn > '{1}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [ProductType], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, Price,case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  in (1,4,5,6)  and CreateOn > '{1}' and Exch = '{2}'  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [ProductType], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty,Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], CreateOn, LastModified, UserRemarks,TraderId,OrderNo,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  in (1,4,5,6)  and CreateOn > '{1}' and Symbol = '{2}'  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [ProductType], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty,Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity],CreateOn, LastModified, UserRemarks,TraderId,OrderNo,Ipaddress from Orders_History  where  Clientcode in ({0}) and OrdStatus  in (1,4,5,6)  and CreateOn BETWEEN '{1}' and '{2}' Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Force Square Off":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders  where Clientcode in ({0}) and OrdStatus = 4  and CreateOn > '{1}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY'  WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders  where Clientcode in ({0}) and OrdStatus = 4  and CreateOn > '{1}' and Exch = {2} Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders  where Clientcode in ({0}) and OrdStatus = 4  and CreateOn > '{1}' and Symbol = '{2}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price,LastModified as [Timestamp] from Orders_History  where Clientcode in ({0}) and OrdStatus = 4  and CreateOn Between '{1}' and '{2}'  Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "GTC":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn > '{1}' and Validity = 3  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn > '{1}' and Validity = 3 and Exch = {2} Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn > '{1}' and Validity = 3 and Symbol = '{2}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price,Ipaddress from Orders_History  where  Clientcode in ({0}) and OrdStatus in (1,4,5,6) and CreateOn BETWEEN '{1}' and '{2}' and Validity = 3 and IsMaintenance = 0 Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "GTC PENDING":
          selectCommandText = string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as BuySell ,Qty, case Validity WHEN 3  THEN 'GTC' END as Validity, LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price from Orders  where  Clientcode in ({0}) and OrdStatus = 2   and Validity = 3 Order by LastModified", (object) RegulationCode);
          break;
        case "INSERT":
          selectCommandText = !this.chkMisDtw.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'CARRYFORWARD' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price from Orders  where  Clientcode in ({0}) and OrdStatus = 1  and CreateOn > '{1}' and isAdmin = 1 Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, Price from Orders_History  where  Clientcode in ({0}) and OrdStatus = 1  and CreateOn BETWEEN '{1}' and '{2}' and isAdmin = 1 Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Intraday Square Off":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol,case BuySell WHEN 1 THEN 'BUY'  WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price from Orders  where  Clientcode in ({0}) and OrdStatus = 6  and CreateOn > '{1}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol,case BuySell WHEN 1 THEN 'BUY'  WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price from Orders  where  Clientcode in ({0}) and OrdStatus = 6  and CreateOn > '{1}' and Exch = {2} Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol,case BuySell WHEN 1 THEN 'BUY'  WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price from Orders  where  Clientcode in ({0}) and OrdStatus = 6  and CreateOn > '{1}' and Symbol = '{2}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange ,Symbol,case BuySell WHEN 1 THEN 'BUY'  WHEN 2 THEN 'SELL' END as [BuySell],case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, Qty ,Price from Orders_History  where  Clientcode in ({0}) and OrdStatus = 6  and CreateOn Between '{1}' and '{2}'  Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Login/Logoff":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select Clientcode, IPaddr,case LogIN_OFF WHEN 1 THEN 'LOGIN' WHEN 2 THEN 'LOGOFF' end as [Login/Logoff], Timestamp from LogIn_OffReports where Clientcode in ({0}) and Timestamp BETWEEN '{1}' and '{2}' order by Timestamp", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
            break;
          }
          string str4 = RegulationCode;
          DateTime now2 = DateTime.Now;
          string str5 = now2.ToString("yyyy-MM-dd 00:00:00");
          now2 = DateTime.Now;
          string str6 = now2.ToString("yyyy-MM-dd 23:59:00");
          selectCommandText = string.Format("Select Clientcode, IPaddr,case LogIN_OFF WHEN 1 THEN 'LOGIN' WHEN 2 THEN 'LOGOFF' end as [Login/Logoff], Timestamp from LogIn_OffReports where Clientcode in ({0}) and Timestamp BETWEEN '{1}' and '{2}' order by Timestamp", (object) str4, (object) str5, (object) str6);
          break;
        case "MAINTENANCE":
          selectCommandText = !this.chkMisDtw.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'CARRYFORWARD' WHEN 3 THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,CreateOn from Orders  where  Clientcode in ({0}) and OrdStatus = 1 and IsMaintenance = 1 Order by LastModified", (object) RegulationCode) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, Price, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3 THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,CreateOn from Orders_History  where  Clientcode in ({0}) and OrdStatus = 1 and CreateOn BETWEEN '{1}' and '{2}' and Validity = 1 and IsMaintenance = 1 Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "MODIFIED":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("Select M.Clientcode,case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,O.Symbol, case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as [Order Type], case O.BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as BuySell,M.OldQty,M.OldPrice,M.ModifiedQty, M.ModifiedPrice, case O.Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, M.ModifiedTime, O.UserRemarks,O.TraderId,M.OrderNo, O.CreateOn from Orders O, Modified M where  M.Clientcode in ({0}) and M.Orderno = O.Orderno  and M.ModifiedTime > '{1}' Order by M.ModifiedTime", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("Select M.Clientcode,case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,O.Symbol, case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as [Order Type], case O.BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as BuySell,M.OldQty,M.OldPrice,M.ModifiedQty, M.ModifiedPrice, case O.Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, M.ModifiedTime, O.UserRemarks,O.TraderId,M.OrderNo, O.CreateOn from Orders O, Modified M where  M.Clientcode in ({0}) and M.Orderno = O.Orderno  and M.ModifiedTime > '{1}' and O.Exch = {2} Order by M.ModifiedTime", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("Select M.Clientcode,case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,O.Symbol, case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as [Order Type], case O.BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as BuySell,M.OldQty,M.OldPrice,M.ModifiedQty, M.ModifiedPrice, case O.Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, M.ModifiedTime, O.UserRemarks,O.TraderId,M.OrderNo, O.CreateOn from Orders O, Modified M where  M.Clientcode in ({0}) and M.Orderno = O.Orderno  and M.ModifiedTime > '{1}' and O.Symbol = '{2}' Order by M.ModifiedTime", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("Select M.Clientcode,case O.Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,O.Symbol, case O.Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL' END as [Order Type], case O.BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END as BuySell,M.OldQty,M.OldPrice,M.ModifiedQty, M.ModifiedPrice, case O.Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as Validity, M.ModifiedTime, O.UserRemarks, O.TraderId,M.OrderNo, O.CreateOn from Orders_History O, Modified_History M   where  M.Clientcode in ({0}) and M.Orderno = O.Orderno  and M.ModifiedTime BETWEEN '{1}' and '{2}' Order by M.ModifiedTime", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Message Logs":
          selectCommandText = !this.chkMisDtw.Checked ? string.Format("Select ClientCode, LogMsg,LogTime from MessageLogs where ClientCode in ({0}) and LogTime > '{1}' Order by LogTime", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("Select ClientCode, LogMsg,LogTime from MessageLogs_History where ClientCode in ({0}) and LogTime BETWEEN '{1}' and '{2}' Order by LogTime", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Net MTM Profit/Loss":
          selectCommandText = string.Format("Select ClientCode,Amount,Timestamp from [ClientAccounting] where Flag = 2 and ClientCode in (" + RegulationCode + ") and Timestamp between '" + dateTime1.ToString("yyyy-MM-dd 00:00:00") + "' and '" + dateTime3.ToString("yyyy-MM-dd 23:59:00") + "' order by Timestamp");
          break;
        case "PENDING":
          selectCommandText = !this.chkMisDtw.Checked ? (!this.chkSymbolwise.Checked ? (!this.chkExchwise.Checked ? string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  = 2  and CreateOn > '{1}' Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  = 2  and CreateOn > '{1}' and Exch = '{2}'  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'   END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders  where  Clientcode in ({0}) and OrdStatus  = 2  and CreateOn > '{1}' and Symbol = '{2}'  Order by LastModified", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text)) : string.Format("select Clientcode, case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' WHEN 5 THEN 'NSEOPT' END as Exchange,Symbol, case Productype WHEN 1 THEN 'RL' WHEN 2 THEN 'SL'  END as [Order Type], case BuySell WHEN 1 THEN 'BUY' WHEN 2 THEN 'SELL' END  as [BuySell],Qty, case Validity WHEN 1 THEN 'CARRYFORWARD' WHEN 2 THEN 'DAY' WHEN 3  THEN 'GTC' END as [Validity], LastModified, UserRemarks,TraderId,OrderNo,  OrdStatus, CreateOn, OrdPrice,Ipaddress from Orders_History  where  Clientcode in ({0}) and OrdStatus  = 2  and CreateOn BETWEEN '{1}' and '{2}' Order by LastModified", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Payin":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select ClientCode,Name,Amount,Comments,Timestamp from Payin_Payout where ClientCode in ({0}) and PayinPayout = 1 and Timestamp BETWEEN '" + dateTime1.ToString("yyyy-MM-dd HH:mm:ss") + "' and '" + dateTime3.ToString("yyyy-MM-dd HH:mm:ss") + "'", (object) RegulationCode);
            break;
          }
          selectCommandText = string.Format("Select ClientCode,Name,Amount,Comments,Timestamp from Payin_Payout where ClientCode in ({0}) and PayinPayout = 1", (object) RegulationCode);
          break;
        case "Payout":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select ClientCode,Name,Amount,Comments,Timestamp from Payin_Payout where ClientCode in ({0}) and  PayinPayout = 2 and Timestamp BETWEEN '" + dateTime1.ToString("yyyy-MM-dd HH:mm:ss") + "' and '" + dateTime3.ToString("yyyy-MM-dd HH:mm:ss") + "'", (object) RegulationCode);
            break;
          }
          selectCommandText = string.Format("Select ClientCode,Name,Amount,Comments,Timestamp from Payin_Payout where ClientCode in ({0}) and PayinPayout = 2", (object) RegulationCode);
          break;
        case "Profit/Loss":
          if (this.chkSymbolwise.Checked)
          {
            selectCommandText = string.Format("Select ClientCode, Exch, Symbol, Validity,Lotsize,BQty,BAvgPrice,SQty,SAvgPrice,NetLot,ClosePrice, RealisedPL,  UnrealisedPL, Brkg, NetMTMPL,Timestamp from Profit_Loss_Archive where ClientCode in ({0}) and Timestamp BETWEEN '{1}' and '{2}' and Symbol = '{3]'", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"), (object) this.cmbSymbol.Text);
            break;
          }
          if (this.chkExchwise.Checked)
          {
            selectCommandText = string.Format("Select ClientCode, Exch, Symbol, Validity,Lotsize,BQty,BAvgPrice,SQty,SAvgPrice,NetLot,ClosePrice, RealisedPL,  UnrealisedPL, Brkg, NetMTMPL,Timestamp from Profit_Loss_Archive where ClientCode in ({0}) and Timestamp BETWEEN '{1}' and '{2}' and Exch = '{3}'", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"), (object) exch);
            break;
          }
          selectCommandText = string.Format("Select ClientCode, Exch, Symbol, Validity,Lotsize,BQty,BAvgPrice,SQty,SAvgPrice,NetLot,ClosePrice, RealisedPL, UnrealisedPL, Brkg, NetMTMPL,Timestamp from Profit_Loss_Archive where ClientCode in ({0}) and Timestamp BETWEEN '{1}' and '{2}'", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd 00:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Registration Logs":
          selectCommandText = "Select Clientcode,Username,RegisterDate,DATEDIFF(day,RegisterDate , GETDATE()) as 'No of Days' from Userinformation where Clientcode in (" + RegulationCode + ")";
          break;
        case "Rejection Messages":
          selectCommandText = !this.chkMisDtw.Checked ? string.Format("Select ClientCode, Message,Timestamp from RejectionMessages where ClientCode in ({0}) and Timestamp > '{1}'  Order by Timestamp", (object) RegulationCode, (object) this.MktStartTime.ToString("yyyy-MM-dd HH:mm:ss")) : string.Format("Select ClientCode, Message,Timestamp from RejectionMessages where ClientCode in ({0}) and Timestamp Between '{1}' and '{2}' Order by Timestamp", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd HH:mm:ss"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
          break;
        case "Turnover Utilised":
          if (this.chkMisDtw.Checked)
          {
            selectCommandText = string.Format("Select ClientCode, TurnoverUtilise,Timestamp,case Exch WHEN 1 THEN 'MCX' WHEN 2 THEN 'NSEFUT' WHEN 3 THEN 'NCDEX' WHEN 4 THEN 'NSECURR' end as Exchanges from TurnoverUtilised where ClientCode in ({0}) and Timestamp BETWEEN '{1}' and '{2}'", (object) RegulationCode, (object) dateTime1.ToString("yyyy-MM-dd 00:00:00"), (object) dateTime3.ToString("yyyy-MM-dd HH:mm:ss"));
            break;
          }
          break;
      }
      if (selectCommandText != string.Empty)
      {
        SqlConnection conn = this.objmain.getConn();
        if (conn.State == ConnectionState.Open)
        {
          using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, conn))
            sqlDataAdapter.Fill(dataSet);
        }
      }
      return dataSet;
    }

    private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
    {
      foreach (TreeNode node in e.Node.Nodes)
        node.Checked = e.Node.Checked;
    }

    private void AddOpenPosCols()
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Exchange";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Symbol";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Validity";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "Buy/Sell";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn6.HeaderText = "Qty";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn6);
      DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn7.HeaderText = "AvgPrice";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn7);
    }

    private void AddDAPLCols()
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "DACode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "NetPfls";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "DA_Pfls";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "SA_Pfls";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "Timestamp";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
    }

    private void AddNETmtmPFlsCols()
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Amount";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Timestamp";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
    }

    private void GetOpenPos(string accounts)
    {
      this.AddOpenPosCols();
      Dictionary<string, buysellPos> _BuySellAvgPos = new Dictionary<string, buysellPos>();
      this.objmain.GetTradePosition(ref _BuySellAvgPos, accounts, false);
      Dictionary<string, buysellnetpospfls> dictionary = this.objmain.ProcessProfitLoss(_BuySellAvgPos);
      int index = 0;
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dictionary)
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string key = strArray[0];
        string str = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        if (this.objmain._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objmain._Symconctracts[key];
          buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
          if (buysellnetpospfls.buy_sell > 0 && accounts.Contains(str))
          {
            this.dgvReports.Rows.Add();
            this.dgvReports.Rows[index].Cells[0].Value = (object) str;
            this.dgvReports.Rows[index].Cells[1].Value = (object) Utils.GetExch(symconctract.exch);
            this.dgvReports.Rows[index].Cells[2].Value = (object) key;
            this.dgvReports.Rows[index].Cells[3].Value = (object) Utils.GetValidity(int32);
            this.dgvReports.Rows[index].Cells[4].Value = (object) Utils.GetBuysell(buysellnetpospfls.buy_sell);
            this.dgvReports.Rows[index].Cells[5].Value = (object) buysellnetpospfls.Qty;
            this.dgvReports.Rows[index].Cells[6].Value = buysellnetpospfls.buy_sell != 1 ? (object) Decimal.Round(buysellnetpospfls.sellprice, 2) : (object) Decimal.Round(buysellnetpospfls.buyprice, 2);
            ++index;
          }
        }
      }
    }

    private void GetTurnover(List<string> accounts)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "TurnoverUtilised";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetMTMProftLoss);
      int index = 0;
      double num = 0.0;
      foreach (string account in accounts)
      {
        if (dictionary.ContainsKey(account))
        {
          buysellnetpospfls buysellnetpospfls = dictionary[account];
          this.dgvReports.Rows.Add();
          this.dgvReports.Rows[index].Cells[0].Value = (object) account;
          this.dgvReports.Rows[index].Cells[1].Value = (object) buysellnetpospfls.TurnoverUtilised;
          num += buysellnetpospfls.TurnoverUtilised;
          ++index;
        }
      }
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index].Cells[0].Value = (object) "Total";
      this.dgvReports.Rows[index].Cells[1].Value = (object) num;
    }

    private void GetMarginUtilised(List<string> _lstaccounts)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "MarginUtilised";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetMTMProftLoss);
      int index = 0;
      Decimal num = new Decimal();
      foreach (string lstaccount in _lstaccounts)
      {
        if (dictionary.ContainsKey(lstaccount))
        {
          buysellnetpospfls buysellnetpospfls = dictionary[lstaccount];
          this.dgvReports.Rows.Add();
          this.dgvReports.Rows[index].Cells[0].Value = (object) lstaccount;
          this.dgvReports.Rows[index].Cells[1].Value = (object) buysellnetpospfls.margin;
          num += buysellnetpospfls.margin;
          ++index;
        }
      }
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index].Cells[0].Value = (object) "Total";
      this.dgvReports.Rows[index].Cells[1].Value = (object) num;
    }

    private void GetLossAccounts(List<string> _lstAccounts, bool isprofit)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      if (isprofit)
      {
        DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
        viewTextBoxColumn2.HeaderText = "Profit";
        this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      }
      else
      {
        DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
        viewTextBoxColumn2.HeaderText = "Loss";
        this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      }
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetMTMProftLoss);
      int index = 0;
      Decimal num = new Decimal();
      foreach (string lstAccount in _lstAccounts)
      {
        if (dictionary.ContainsKey(lstAccount))
        {
          buysellnetpospfls buysellnetpospfls = dictionary[lstAccount];
          if (buysellnetpospfls.p_l < Decimal.Zero && !isprofit)
          {
            this.dgvReports.Rows.Add();
            this.dgvReports.Rows[index].Cells[0].Value = (object) lstAccount;
            this.dgvReports.Rows[index].Cells[1].Value = (object) buysellnetpospfls.p_l;
            num += buysellnetpospfls.p_l;
            ++index;
          }
          else if (buysellnetpospfls.p_l > Decimal.Zero & isprofit)
          {
            this.dgvReports.Rows.Add();
            this.dgvReports.Rows[index].Cells[0].Value = (object) lstAccount;
            this.dgvReports.Rows[index].Cells[1].Value = (object) buysellnetpospfls.p_l;
            num += buysellnetpospfls.p_l;
            ++index;
          }
        }
      }
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index].Cells[0].Value = (object) "Total";
      this.dgvReports.Rows[index].Cells[1].Value = (object) num;
    }

    private void GetCommissions(List<string> _lstaccounts)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Brokerage";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "DA Brokerage";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "DI Brokerage";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "DealerID code";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetMTMProftLoss);
      int index = 0;
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      Decimal num4 = new Decimal();
      foreach (string lstaccount in _lstaccounts)
      {
        if (dictionary.ContainsKey(lstaccount))
        {
          buysellnetpospfls buysellnetpospfls = dictionary[lstaccount];
          this.dgvReports.Rows.Add();
          this.dgvReports.Rows[index].Cells[0].Value = (object) lstaccount;
          this.dgvReports.Rows[index].Cells[1].Value = (object) buysellnetpospfls.Commision;
          SqlConnection conn = this.objmain.getConn();
          string empty = string.Empty;
          Decimal num5 = new Decimal();
          if (conn.State == ConnectionState.Open)
          {
            using (SqlCommand sqlCommand = new SqlCommand("Select [MappedDealerID] From [MappedIDInfo] where clientcode='" + lstaccount + "'", conn))
            {
              using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  if (!sqlDataReader.IsDBNull(0))
                    empty = sqlDataReader.GetString(0);
                }
              }
            }
            using (SqlCommand sqlCommand = new SqlCommand("Select [DIpfls] From [Userinformation] where clientcode='" + empty + "'", conn))
            {
              using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
              {
                while (sqlDataReader.Read())
                {
                  if (!sqlDataReader.IsDBNull(0))
                    num5 = (Decimal) Convert.ToInt32(sqlDataReader.GetValue(0));
                }
                num4 = buysellnetpospfls.Commision / new Decimal(100) * num5;
                this.dgvReports.Rows[index].Cells[2].Value = (object) (buysellnetpospfls.Commision - num4);
                this.dgvReports.Rows[index].Cells[3].Value = (object) num4;
                this.dgvReports.Rows[index].Cells[4].Value = (object) empty;
              }
            }
          }
          num1 += buysellnetpospfls.Commision;
          num2 += buysellnetpospfls.Commision - num4;
          num3 += num4;
          ++index;
        }
      }
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index].Cells[0].Value = (object) "Total";
      this.dgvReports.Rows[index].Cells[1].Value = (object) num1;
      this.dgvReports.Rows[index].Cells[2].Value = (object) num2;
      this.dgvReports.Rows[index].Cells[3].Value = (object) num3;
    }

    private void GetCashBalance(List<string> _lstaccounts)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Cash Margin";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "MTM Net Profit/Loss";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Available Balance";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetMTMProftLoss);
      int index = 0;
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      foreach (string lstaccount in _lstaccounts)
      {
        if (this.objmain._ClientLimits.ContainsKey(lstaccount))
        {
          Limits clientLimit = this.objmain._ClientLimits[lstaccount];
          this.dgvReports.Rows.Add();
          this.dgvReports.Rows[index].Cells[0].Value = (object) lstaccount;
          this.dgvReports.Rows[index].Cells[1].Value = (object) clientLimit.cashmrgn;
          Decimal num4 = new Decimal();
          if (dictionary.ContainsKey(lstaccount))
          {
            buysellnetpospfls buysellnetpospfls = dictionary[lstaccount];
            num4 = Decimal.Round(buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l - buysellnetpospfls.p_ltax - buysellnetpospfls.Commision - buysellnetpospfls.Comm_Tax, 2);
          }
          this.dgvReports.Rows[index].Cells[2].Value = (object) num4;
          this.dgvReports.Rows[index].Cells[3].Value = (object) (clientLimit.cashmrgn + num4);
          num1 += clientLimit.cashmrgn;
          num2 += num4;
          num3 += clientLimit.cashmrgn + num4;
          ++index;
        }
      }
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index].Cells[0].Value = (object) "Total";
      this.dgvReports.Rows[index].Cells[1].Value = (object) num1;
      this.dgvReports.Rows[index].Cells[2].Value = (object) num2;
      this.dgvReports.Rows[index].Cells[3].Value = (object) num3;
    }

    private void GetNetMTMPL(List<string> _lstaccounts)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Realised P/L";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Unrealised P/L";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Brokerage";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "Net MTM P/L";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetMTMProftLoss);
      int index = 0;
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      Decimal num4 = new Decimal();
      foreach (string lstaccount in _lstaccounts)
      {
        if (dictionary.ContainsKey(lstaccount))
        {
          buysellnetpospfls buysellnetpospfls = dictionary[lstaccount];
          this.dgvReports.Rows.Add();
          this.dgvReports.Rows[index].Cells[0].Value = (object) lstaccount;
          this.dgvReports.Rows[index].Cells[1].Value = (object) buysellnetpospfls.p_l;
          this.dgvReports.Rows[index].Cells[2].Value = (object) buysellnetpospfls.UnrealisedP_l;
          this.dgvReports.Rows[index].Cells[3].Value = (object) buysellnetpospfls.Commision;
          Decimal num5 = Decimal.Round(buysellnetpospfls.p_l + buysellnetpospfls.UnrealisedP_l - buysellnetpospfls.Commision - buysellnetpospfls.Comm_Tax - buysellnetpospfls.p_ltax, 2);
          this.dgvReports.Rows[index].Cells[4].Value = (object) num5;
          num1 += buysellnetpospfls.p_l;
          num3 += buysellnetpospfls.UnrealisedP_l;
          num4 += buysellnetpospfls.Commision;
          num2 += num5;
          ++index;
        }
      }
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index].Cells[0].Value = (object) "Total";
      this.dgvReports.Rows[index].Cells[1].Value = (object) num1;
      this.dgvReports.Rows[index].Cells[2].Value = (object) num3;
      this.dgvReports.Rows[index].Cells[3].Value = (object) num4;
      this.dgvReports.Rows[index].Cells[4].Value = (object) num2;
    }

    private void GetProfitLoss(List<string> _lstaccounts)
    {
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Exchange";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Symbol";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Validity";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "Lotsize";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn6.HeaderText = "BQty";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn6);
      DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn7.HeaderText = "BuyPrice";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn7);
      DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn8.HeaderText = "SQty";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn8);
      DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn9.HeaderText = "SellPrice";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn9);
      DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn10.HeaderText = "Net";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn10);
      DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn11.HeaderText = "CMP";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn11);
      DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn12.HeaderText = "Realised P/L";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn12);
      DataGridViewTextBoxColumn viewTextBoxColumn13 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn13.HeaderText = "Unrealised P/L";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn13);
      DataGridViewTextBoxColumn viewTextBoxColumn14 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn14.HeaderText = "Brokerage";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn14);
      DataGridViewTextBoxColumn viewTextBoxColumn15 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn15.HeaderText = "Net MTM P/L";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn15);
      Dictionary<string, buysellnetpospfls> dictionary = new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetProftLoss);
      int index = 0;
      foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in dictionary)
      {
        string[] strArray = keyValuePair.Key.Split('_');
        string key = strArray[0];
        string str = strArray[1];
        int int32 = Convert.ToInt32(strArray[2]);
        if (_lstaccounts.Contains(str) && this.objmain._Symconctracts.ContainsKey(key))
        {
          Contracts symconctract = this.objmain._Symconctracts[key];
          buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
          this.dgvReports.Rows.Add();
          this.dgvReports.Rows[index].Cells[0].Value = (object) str;
          this.dgvReports.Rows[index].Cells[1].Value = (object) Utils.GetExch(symconctract.exch);
          this.dgvReports.Rows[index].Cells[2].Value = (object) key;
          this.dgvReports.Rows[index].Cells[3].Value = (object) Utils.GetValidity(int32);
          this.dgvReports.Rows[index].Cells[4].Value = (object) symconctract.lotsize;
          this.dgvReports.Rows[index].Cells[5].Value = (object) buysellnetpospfls.BQty;
          this.dgvReports.Rows[index].Cells[6].Value = (object) Decimal.Round(buysellnetpospfls.buyprice, 2);
          this.dgvReports.Rows[index].Cells[7].Value = (object) buysellnetpospfls.SQty;
          this.dgvReports.Rows[index].Cells[8].Value = (object) Decimal.Round(buysellnetpospfls.sellprice, 2);
          this.dgvReports.Rows[index].Cells[9].Value = (object) (buysellnetpospfls.BQty - buysellnetpospfls.SQty);
          string symbol = symconctract.SymDesp;
          if (symconctract.symbol == "GOLDMM")
            symbol = symbol.Replace("GOLDMM", "GOLD");
          else if (symconctract.symbol == "SILVERMM")
            symbol = symbol.Replace("SILVERMM", "SILVER");
          Feeds feed = this.objmain.getFeed(symbol);
          if (buysellnetpospfls.BQty > buysellnetpospfls.SQty)
          {
            Decimal d = Decimal.Round(buysellnetpospfls.p_l, 2) + buysellnetpospfls.UnrealisedP_l - buysellnetpospfls.Commision;
            this.dgvReports.Rows[index].Cells[10].Value = (object) feed.bid;
            this.dgvReports.Rows[index].Cells[12].Value = (object) Decimal.Round(buysellnetpospfls.UnrealisedP_l, 2);
            this.dgvReports.Rows[index].Cells[14].Value = (object) Decimal.Round(d, 2);
          }
          else
          {
            Decimal d = Decimal.Round(buysellnetpospfls.p_l, 2) + buysellnetpospfls.UnrealisedP_l - buysellnetpospfls.Commision;
            this.dgvReports.Rows[index].Cells[10].Value = (object) feed.ask;
            this.dgvReports.Rows[index].Cells[12].Value = (object) Decimal.Round(buysellnetpospfls.UnrealisedP_l, 2);
            this.dgvReports.Rows[index].Cells[14].Value = (object) Decimal.Round(d, 2);
          }
          this.dgvReports.Rows[index].Cells[11].Value = (object) Decimal.Round(buysellnetpospfls.p_l, 2);
          this.dgvReports.Rows[index].Cells[13].Value = (object) buysellnetpospfls.Commision;
          ++index;
        }
      }
    }

    private void AddLedgerCols()
    {
      this.dgvReports.DataSource = (object) null;
      this.dgvReports.Columns.Clear();
      this.dgvReports.Rows.Clear();
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Closed Date/Time";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Type";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Ticket";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "Symbol";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn6.HeaderText = "Amount";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn6);
      DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn7.HeaderText = "B/S";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn7);
      DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn8.HeaderText = "Open Date/Time";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn8);
      DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn9.HeaderText = "Open/SL";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn9);
      DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn10.HeaderText = "Close/TP";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn10);
      DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn11.HeaderText = "DP/WD";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn11);
      DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn12.HeaderText = "Comm";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn12);
      DataGridViewTextBoxColumn viewTextBoxColumn13 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn13.HeaderText = "Profit/Desc";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn13);
      DataGridViewTextBoxColumn viewTextBoxColumn14 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn14.HeaderText = "Net Profit";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn14);
    }

    private void AddLedgerColsAVG()
    {
      this.dgvReports.DataSource = (object) null;
      this.dgvReports.Columns.Clear();
      this.dgvReports.Rows.Clear();
      DataGridViewTextBoxColumn viewTextBoxColumn1 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn1.HeaderText = "ClientCode";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn1);
      DataGridViewTextBoxColumn viewTextBoxColumn2 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn2.HeaderText = "Closed Date/Time";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn2);
      DataGridViewTextBoxColumn viewTextBoxColumn3 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn3.HeaderText = "Type";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn3);
      DataGridViewTextBoxColumn viewTextBoxColumn4 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn4.HeaderText = "Symbol";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn4);
      DataGridViewTextBoxColumn viewTextBoxColumn5 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn5.HeaderText = "BUY QTY";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn5);
      DataGridViewTextBoxColumn viewTextBoxColumn6 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn6.HeaderText = "SELL QTY";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn6);
      DataGridViewTextBoxColumn viewTextBoxColumn7 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn7.HeaderText = "Open/SL";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn7);
      DataGridViewTextBoxColumn viewTextBoxColumn8 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn8.HeaderText = "Close/TP";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn8);
      DataGridViewTextBoxColumn viewTextBoxColumn9 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn9.HeaderText = "DP/WD";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn9);
      DataGridViewTextBoxColumn viewTextBoxColumn10 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn10.HeaderText = "Profit/Desc";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn10);
      DataGridViewTextBoxColumn viewTextBoxColumn11 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn11.HeaderText = "Comm";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn11);
      DataGridViewTextBoxColumn viewTextBoxColumn12 = new DataGridViewTextBoxColumn();
      viewTextBoxColumn12.HeaderText = "Net Profit";
      this.dgvReports.Columns.Add((DataGridViewColumn) viewTextBoxColumn12);
    }

    private void DisplayLedgerAVG(
      Dictionary<string, LedgerAVG> _Ledgervalues,
      Decimal begbal,
      SortedDictionary<DateTime, payinoutDetails> _PayinOutDetails,
      string codee)
    {
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      double num4 = 0.0;
      if (_Ledgervalues.Count <= 0)
        return;
      this.AddLedgerColsAVG();
      int index1 = 0;
      foreach (KeyValuePair<string, LedgerAVG> ledgervalue in _Ledgervalues)
      {
        LedgerAVG ledgerAvg = ledgervalue.Value;
        this.dgvReports.Rows.Add();
        this.dgvReports.Rows[index1].Cells[0].Value = (object) ledgerAvg.accountno;
        this.dgvReports.Rows[index1].Cells[1].Value = (object) ledgerAvg.CloseTime.ToString("dd/MM/yyyy 23:55:00");
        this.dgvReports.Rows[index1].Cells[2].Value = (object) "L";
        this.dgvReports.Rows[index1].Cells[3].Value = (object) ledgerAvg.symbol;
        this.dgvReports.Rows[index1].Cells[4].Value = (object) ledgerAvg.buyqty;
        this.dgvReports.Rows[index1].Cells[5].Value = (object) ledgerAvg.sellqty;
        this.dgvReports.Rows[index1].Cells[6].Value = (object) ledgerAvg.buyprice;
        this.dgvReports.Rows[index1].Cells[7].Value = (object) ledgerAvg.sellprice;
        this.dgvReports.Rows[index1].Cells[10].Value = (object) ledgerAvg.comm;
        this.dgvReports.Rows[index1].Cells[9].Value = (object) ledgerAvg.RealisedPL;
        this.dgvReports.Rows[index1].Cells[11].Value = (object) ledgerAvg.NettPl;
        num1 += ledgerAvg.comm;
        num2 += Convert.ToDecimal(ledgerAvg.RealisedPL);
        num3 += ledgerAvg.NettPl;
        ++index1;
      }
      foreach (KeyValuePair<DateTime, payinoutDetails> payinOutDetail in _PayinOutDetails)
      {
        int index2 = this.dgvReports.Rows.Add();
        this.dgvReports.Rows[index2].Cells[0].Value = (object) codee;
        this.dgvReports.Rows[index2].Cells[1].Value = (object) payinOutDetail.Key.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvReports.Rows[index2].Cells[3].Value = (object) payinOutDetail.Value.comments;
        if (payinOutDetail.Value.payinout.ToUpper() == "PAYIN")
        {
          this.dgvReports.Rows[index2].Cells[2].Value = (object) "DP";
          this.dgvReports.Rows[index2].Cells[8].Value = (object) payinOutDetail.Value.amount;
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 += payinOutDetail.Value.amount;
        }
        else if (payinOutDetail.Value.payinout.ToUpper() == "PAYOUT")
        {
          this.dgvReports.Rows[index2].Cells[2].Value = (object) "WD";
          this.dgvReports.Rows[index2].Cells[8].Value = (object) (payinOutDetail.Value.amount * -1.0);
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 -= payinOutDetail.Value.amount;
        }
        ++index1;
      }
      this.dgvReports.Sort(this.dgvReports.Columns[1], ListSortDirection.Ascending);
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index1].Cells[7].Value = (object) "Totals:";
      this.dgvReports.Rows[index1].Cells[8].Value = (object) num4;
      this.dgvReports.Rows[index1].Cells[10].Value = (object) (num1 * Decimal.MinusOne);
      this.dgvReports.Rows[index1].Cells[9].Value = (object) num2;
      this.dgvReports.Rows[index1].Cells[11].Value = (object) num3;
      int index3 = index1 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index3].Cells[0].Value = (object) "Account Summary";
      int index4 = index3 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index4].Cells[0].Value = (object) "Beg.Balance";
      this.dgvReports.Rows[index4].Cells[1].Value = (object) begbal;
      int index5 = index4 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index5].Cells[0].Value = (object) "Margin In/Out";
      this.dgvReports.Rows[index5].Cells[1].Value = (object) num4;
      int index6 = index5 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index6].Cells[0].Value = (object) "Trading Profit/Loss";
      this.dgvReports.Rows[index6].Cells[1].Value = (object) num2;
      int index7 = index6 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index7].Cells[0].Value = (object) "Commissions";
      this.dgvReports.Rows[index7].Cells[1].Value = (object) (num1 * Decimal.MinusOne);
      int index8 = index7 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index8].Cells[0].Value = (object) "Net Trading Profit/Loss";
      this.dgvReports.Rows[index8].Cells[1].Value = (object) num3;
      int index9 = index8 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index9].Cells[0].Value = (object) "Balance";
      this.dgvReports.Rows[index9].Cells[1].Value = (object) (begbal + num3 + Convert.ToDecimal(num4));
    }

    private void DisplayLedger(
      Dictionary<string, Ledger> _Ledgervalues,
      Decimal begbal,
      SortedDictionary<DateTime, payinoutDetails> _PayinOutDetails,
      string codee)
    {
      Decimal num1 = new Decimal();
      Decimal num2 = new Decimal();
      Decimal num3 = new Decimal();
      double num4 = 0.0;
      if (_Ledgervalues.Count <= 0)
        return;
      this.AddLedgerCols();
      int index1 = 0;
      foreach (KeyValuePair<string, Ledger> ledgervalue in _Ledgervalues)
      {
        Ledger ledger = ledgervalue.Value;
        this.dgvReports.Rows.Add();
        this.dgvReports.Rows[index1].Cells[0].Value = (object) ledger.accountno;
        this.dgvReports.Rows[index1].Cells[1].Value = (object) ledger.CloseTime.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvReports.Rows[index1].Cells[2].Value = (object) "L";
        this.dgvReports.Rows[index1].Cells[3].Value = (object) ledger.orderno;
        this.dgvReports.Rows[index1].Cells[4].Value = (object) ledger.symbol;
        this.dgvReports.Rows[index1].Cells[5].Value = (object) ledger.sellqty;
        if (ledger.OpenTime > ledger.CloseTime)
        {
          this.dgvReports.Rows[index1].Cells[6].Value = (object) "S";
          this.dgvReports.Rows[index1].Cells[8].Value = (object) ledger.sellprice;
          this.dgvReports.Rows[index1].Cells[9].Value = (object) ledger.buyprice;
        }
        else
        {
          this.dgvReports.Rows[index1].Cells[6].Value = (object) "B";
          this.dgvReports.Rows[index1].Cells[8].Value = (object) ledger.buyprice;
          this.dgvReports.Rows[index1].Cells[9].Value = (object) ledger.sellprice;
        }
        this.dgvReports.Rows[index1].Cells[7].Value = (object) ledger.OpenTime.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvReports.Rows[index1].Cells[11].Value = (object) ledger.comm;
        this.dgvReports.Rows[index1].Cells[12].Value = (object) ledger.profitLoss;
        this.dgvReports.Rows[index1].Cells[13].Value = (object) ledger.NettPl;
        num1 += ledger.comm;
        num2 += Convert.ToDecimal(ledger.profitLoss);
        num3 += ledger.NettPl;
        ++index1;
      }
      foreach (KeyValuePair<DateTime, payinoutDetails> payinOutDetail in _PayinOutDetails)
      {
        int index2 = this.dgvReports.Rows.Add();
        this.dgvReports.Rows[index2].Cells[0].Value = (object) codee;
        this.dgvReports.Rows[index2].Cells[1].Value = (object) payinOutDetail.Key.ToString("dd/MM/yyyy HH:mm:ss");
        this.dgvReports.Rows[index2].Cells[3].Value = (object) payinOutDetail.Value.comments;
        if (payinOutDetail.Value.payinout.ToUpper() == "PAYIN")
        {
          this.dgvReports.Rows[index2].Cells[2].Value = (object) "DP";
          this.dgvReports.Rows[index2].Cells[10].Value = (object) payinOutDetail.Value.amount;
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 += payinOutDetail.Value.amount;
        }
        else if (payinOutDetail.Value.payinout.ToUpper() == "PAYOUT")
        {
          this.dgvReports.Rows[index2].Cells[2].Value = (object) "WD";
          this.dgvReports.Rows[index2].Cells[10].Value = (object) (payinOutDetail.Value.amount * -1.0);
          if (payinOutDetail.Value.comments.ToUpper() != "INITIAL MARGIN")
            num4 -= payinOutDetail.Value.amount;
        }
        ++index1;
      }
      this.dgvReports.Sort(this.dgvReports.Columns[1], ListSortDirection.Ascending);
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index1].Cells[9].Value = (object) "Totals:";
      this.dgvReports.Rows[index1].Cells[10].Value = (object) num4;
      this.dgvReports.Rows[index1].Cells[11].Value = (object) (num1 * Decimal.MinusOne);
      this.dgvReports.Rows[index1].Cells[12].Value = (object) num2;
      this.dgvReports.Rows[index1].Cells[13].Value = (object) num3;
      int index3 = index1 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index3].Cells[0].Value = (object) "Account Summary";
      int index4 = index3 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index4].Cells[0].Value = (object) "Beg.Balance";
      this.dgvReports.Rows[index4].Cells[1].Value = (object) begbal;
      int index5 = index4 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index5].Cells[0].Value = (object) "Margin In/Out";
      this.dgvReports.Rows[index5].Cells[1].Value = (object) num4;
      int index6 = index5 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index6].Cells[0].Value = (object) "Trading Profit/Loss";
      this.dgvReports.Rows[index6].Cells[1].Value = (object) num2;
      int index7 = index6 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index7].Cells[0].Value = (object) "Commissions";
      this.dgvReports.Rows[index7].Cells[1].Value = (object) (num1 * Decimal.MinusOne);
      int index8 = index7 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index8].Cells[0].Value = (object) "Net Trading Profit/Loss";
      this.dgvReports.Rows[index8].Cells[1].Value = (object) num3;
      int index9 = index8 + 1;
      this.dgvReports.Rows.Add();
      this.dgvReports.Rows[index9].Cells[0].Value = (object) "Balance";
      this.dgvReports.Rows[index9].Cells[1].Value = (object) (begbal + num3 + Convert.ToDecimal(num4));
    }

    private void btnExport_Click(object sender, EventArgs e)
    {
      if (this.dgvReports.Rows.Count > 0)
      {
        if (this.rdoCsvFrmt.Checked)
          Export.ExportToExcel(this.dgvReports, true);
        else if (this.rdo_FMT.Checked)
          Export.ExportToExcel(this.dgvReports, false);
        else if (this.tabControl1.SelectedIndex == 1 && (this.lstTrades.SelectedIndex == 0 || this.lstTrades.SelectedIndex == 1))
        {
          this.Cursor = Cursors.WaitCursor;
          this.btnExport.Enabled = false;
          Export.ExporttoTB(this.dgvReports);
          this.btnExport.Enabled = true;
          this.Cursor = Cursors.Default;
        }
        else if (this.rdoTxtFrmt.Checked)
        {
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              Export.ExportText(this.dgvReports, this.objmain, this.cmbExch.Text, true);
              break;
            case 2:
              if (this.lstOrders.SelectedIndex == 0)
              {
                Export.ExportText(this.dgvReports, this.objmain, this.cmbExch.Text, true);
                break;
              }
              this.objmain.DisplayMessage("Cannot export this report in .txt format, please export in .csv format.", 2);
              break;
          }
        }
        else if (this.rdoSauda.Checked)
        {
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              if (this.lstTrades.SelectedIndex != 1)
                break;
              Export.ExporttoSauda(this.dgvReports, this.objmain, true);
              break;
            case 2:
              if (this.lstOrders.SelectedIndex != 0)
                break;
              Export.ExporttoSauda(this.dgvReports, this.objmain, true);
              break;
          }
        }
        else if (this.rdoShilpi.Checked)
        {
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              if (this.lstTrades.SelectedIndex != 1)
                break;
              Export.ExporttoShilpi(this.dgvReports, this.objmain);
              break;
            case 2:
              if (this.lstOrders.SelectedIndex != 0)
                break;
              Export.ExporttoShilpi(this.dgvReports, this.objmain);
              break;
          }
        }
        else if (this.rdoLogics.Checked)
        {
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              if (this.lstTrades.SelectedIndex != 1)
                break;
              Export.ExporttoLogics(this.dgvReports, true, this.objmain);
              break;
            case 2:
              if (this.lstOrders.SelectedIndex != 0)
                break;
              Export.ExporttoLogics(this.dgvReports, true, this.objmain);
              break;
          }
        }
        else if (this.rdo_SaudaNew.Checked)
        {
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              if (this.lstTrades.SelectedIndex != 1)
                break;
              Export.ExporttoSaudaNew(this.dgvReports, this.objmain, true);
              break;
            case 2:
              if (this.lstOrders.SelectedIndex != 0)
                break;
              Export.ExporttoSaudaNew(this.dgvReports, this.objmain, true);
              break;
          }
        }
        else if (this.rdo_Exch.Checked)
        {
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              if (this.lstTrades.SelectedIndex != 1)
                break;
              Export.ExporttoExchange(this.dgvReports, true, this.objmain);
              break;
            case 2:
              if (this.lstOrders.SelectedIndex != 0)
                break;
              Export.ExporttoExchange(this.dgvReports, true, this.objmain);
              break;
          }
        }
        else
        {
          if (!this.rdo_Vijaya.Checked)
            return;
          switch (this.tabControl1.SelectedIndex)
          {
            case 1:
              if (this.lstTrades.SelectedIndex == 1)
              {
                Export.ExporttoVipulbhai(this.dgvReports, true, this.objmain);
                break;
              }
              break;
            case 2:
              if (this.lstOrders.SelectedIndex == 0)
              {
                Export.ExporttoVipulbhai(this.dgvReports, true, this.objmain);
                break;
              }
              break;
          }
        }
      }
      else
        this.objmain.DisplayMessage("Report Not Available to Export.", 2);
    }

    private void lstOrders_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.lstOrders.SelectedIndex == 0)
      {
        this.rdoTxtFrmt.Visible = true;
        this.rdoCsvFrmt.Visible = true;
      }
      else
        this.rdoTxtFrmt.Visible = false;
    }

    private void lstCommon_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.tabControl1.SelectedIndex != 1 && this.tabControl1.SelectedIndex != 2)
        return;
      this.rdoTxtFrmt.Visible = true;
    }

    private void lstTrades_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.tabControl1.SelectedIndex != 1 && this.tabControl1.SelectedIndex != 2)
        return;
      this.rdoTxtFrmt.Visible = true;
    }

    private void lstAccounts_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.tabControl1.SelectedIndex != 1 && this.tabControl1.SelectedIndex != 2)
        return;
      this.rdoTxtFrmt.Visible = true;
    }

    private void chkExchwise_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkExchwise.Checked)
      {
        this.rdoMcx.Visible = true;
        this.rdoNsefut.Visible = true;
        this.rdoNsecurr.Visible = true;
        this.rdoNseopt.Visible = true;
        this.rdoNcdex.Visible = true;
        foreach (KeyValuePair<int, SortedDictionary<string, Contracts>> exchconctract in this.objmain._Exchconctracts)
        {
          switch (exchconctract.Key)
          {
            case 1:
              this.rdoMcx.Visible = true;
              break;
            case 2:
              this.rdoNsefut.Visible = true;
              break;
            case 3:
              this.rdoNcdex.Visible = true;
              break;
            case 4:
              this.rdoNsecurr.Visible = true;
              break;
            case 5:
              this.rdoNseopt.Visible = true;
              break;
          }
        }
      }
      else
      {
        this.rdoMcx.Visible = false;
        this.rdoNsefut.Visible = false;
        this.rdoNsecurr.Visible = false;
        this.rdoNseopt.Visible = false;
        this.rdoNcdex.Visible = false;
        this.chkSymbolwise.Checked = false;
      }
    }

    private void chkSymbolwise_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkSymbolwise.Checked && this.chkExchwise.Checked)
        this.cmbSymbol.Visible = true;
      else
        this.cmbSymbol.Visible = false;
    }

    private void rdoMcx_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoMcx.Checked || !this.objmain._Exchconctracts.ContainsKey(1))
        return;
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "--Select Symbol--");
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[1])
        this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void rdoNsefut_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoNsefut.Checked || !this.objmain._Exchconctracts.ContainsKey(2))
        return;
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "--Select Symbol--");
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[2])
        this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void rdoNseopt_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoNseopt.Checked || !this.objmain._Exchconctracts.ContainsKey(5))
        return;
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "--Select Symbol--");
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[5])
        this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void rdoNsecurr_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoNsecurr.Checked || !this.objmain._Exchconctracts.ContainsKey(4))
        return;
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "--Select Symbol--");
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[4])
        this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void rdoNcdex_CheckedChanged(object sender, EventArgs e)
    {
      if (!this.rdoNcdex.Checked || !this.objmain._Exchconctracts.ContainsKey(3))
        return;
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "--Select Symbol--");
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[3])
        this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void rdoMcx_Click(object sender, EventArgs e)
    {
      this.rdoMcx.Checked = true;
      if (!this.rdoMcx.Checked || !this.objmain._Exchconctracts.ContainsKey(1))
        return;
      this.cmbSymbol.Items.Clear();
      this.cmbSymbol.Items.Add((object) "--Select Symbol--");
      foreach (KeyValuePair<string, Contracts> keyValuePair in this.objmain._Exchconctracts[1])
        this.cmbSymbol.Items.Add((object) keyValuePair.Key);
      this.cmbSymbol.SelectedIndex = 0;
    }

    private void rdoTxtFrmt_Click(object sender, EventArgs e)
    {
      if (this.rdoTxtFrmt.Checked)
        this.cmbExch.Visible = true;
      else
        this.cmbExch.Visible = false;
    }

    private void rdoTxtFrmt_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoTxtFrmt.Checked)
        this.cmbExch.Visible = true;
      else
        this.cmbExch.Visible = false;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.groupBox1 = new GroupBox();
      this.chkMisDtw = new CheckBox();
      this.label2 = new Label();
      this.label1 = new Label();
      this.Todate = new DateTimePicker();
      this.Fromdate = new DateTimePicker();
      this.treeView1 = new TreeView();
      this.lstCommon = new ListBox();
      this.dgvReports = new DataGridView();
      this.tabControl1 = new TabControl();
      this.tabPage1 = new TabPage();
      this.tabPage2 = new TabPage();
      this.lstTrades = new ListBox();
      this.tabPage3 = new TabPage();
      this.lstOrders = new ListBox();
      this.tabPage4 = new TabPage();
      this.lstAccounts = new ListBox();
      this.btnView = new Button();
      this.btnExport = new Button();
      this.groupBox2 = new GroupBox();
      this.cmbSymbol = new ComboBox();
      this.rdoNcdex = new RadioButton();
      this.rdoNsecurr = new RadioButton();
      this.rdoNseopt = new RadioButton();
      this.rdoNsefut = new RadioButton();
      this.rdoMcx = new RadioButton();
      this.chkSymbolwise = new CheckBox();
      this.chkExchwise = new CheckBox();
      this.rdoTxtFrmt = new RadioButton();
      this.rdoCsvFrmt = new RadioButton();
      this.cmbExch = new ComboBox();
      this.rdoSauda = new RadioButton();
      this.rdoShilpi = new RadioButton();
      this.rdoLogics = new RadioButton();
      this.rdo_SaudaNew = new RadioButton();
      this.rdo_Exch = new RadioButton();
      this.rdo_Vijaya = new RadioButton();
      this.rdo_FMT = new RadioButton();
      this.rdo_TB = new RadioButton();
      this.groupBox1.SuspendLayout();
      ((ISupportInitialize) this.dgvReports).BeginInit();
      this.tabControl1.SuspendLayout();
      this.tabPage1.SuspendLayout();
      this.tabPage2.SuspendLayout();
      this.tabPage3.SuspendLayout();
      this.tabPage4.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.chkMisDtw);
      this.groupBox1.Controls.Add((Control) this.label2);
      this.groupBox1.Controls.Add((Control) this.label1);
      this.groupBox1.Controls.Add((Control) this.Todate);
      this.groupBox1.Controls.Add((Control) this.Fromdate);
      this.groupBox1.ForeColor = Color.Navy;
      this.groupBox1.Location = new Point(4, 5);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(211, 78);
      this.groupBox1.TabIndex = 1;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Select Date";
      this.chkMisDtw.AutoSize = true;
      this.chkMisDtw.Location = new Point(8, 16);
      this.chkMisDtw.Name = "chkMisDtw";
      this.chkMisDtw.Size = new Size(15, 14);
      this.chkMisDtw.TabIndex = 4;
      this.chkMisDtw.UseVisualStyleBackColor = true;
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label2.ForeColor = Color.Black;
      this.label2.Location = new Point(29, 45);
      this.label2.Name = "label2";
      this.label2.Size = new Size(57, 13);
      this.label2.TabIndex = 3;
      this.label2.Text = "To Date:";
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label1.ForeColor = Color.Black;
      this.label1.Location = new Point(29, 17);
      this.label1.Name = "label1";
      this.label1.Size = new Size(69, 13);
      this.label1.TabIndex = 2;
      this.label1.Text = "From Date:";
      this.Todate.CustomFormat = "yyyy-MM-dd HH:mm:ss";
      this.Todate.Format = DateTimePickerFormat.Custom;
      this.Todate.Location = new Point(97, 44);
      this.Todate.Name = "Todate";
      this.Todate.Size = new Size(83, 20);
      this.Todate.TabIndex = 1;
      this.Fromdate.CustomFormat = "yyyy-MM-dd  HH:mm:ss";
      this.Fromdate.Format = DateTimePickerFormat.Custom;
      this.Fromdate.Location = new Point(98, 14);
      this.Fromdate.Name = "Fromdate";
      this.Fromdate.Size = new Size(82, 20);
      this.Fromdate.TabIndex = 0;
      this.treeView1.CheckBoxes = true;
      this.treeView1.Location = new Point(1, 90);
      this.treeView1.Name = "treeView1";
      this.treeView1.Size = new Size(211, 405);
      this.treeView1.TabIndex = 2;
      this.treeView1.AfterCheck += new TreeViewEventHandler(this.treeView1_AfterCheck);
      this.lstCommon.Dock = DockStyle.Fill;
      this.lstCommon.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lstCommon.FormattingEnabled = true;
      this.lstCommon.ItemHeight = 18;
      this.lstCommon.Items.AddRange(new object[12]
      {
        (object) "Allocated Margin",
        (object) "Payin",
        (object) "Payout",
        (object) "Auto Square Off",
        (object) "Force Square Off",
        (object) "Intraday Square Off",
        (object) "Admin Messages",
        (object) "Message Logs",
        (object) "Rejection Messages",
        (object) "Login/Logoff",
        (object) "Accounts Deleted",
        (object) "Registration Logs"
      });
      this.lstCommon.Location = new Point(3, 3);
      this.lstCommon.Name = "lstCommon";
      this.lstCommon.Size = new Size(221, 374);
      this.lstCommon.TabIndex = 3;
      this.lstCommon.SelectedIndexChanged += new EventHandler(this.lstCommon_SelectedIndexChanged);
      this.dgvReports.AllowUserToAddRows = false;
      this.dgvReports.AllowUserToDeleteRows = false;
      this.dgvReports.AllowUserToOrderColumns = true;
      this.dgvReports.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      this.dgvReports.BackgroundColor = Color.White;
      this.dgvReports.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvReports.Location = new Point(446, 88);
      this.dgvReports.Name = "dgvReports";
      this.dgvReports.ReadOnly = true;
      this.dgvReports.RowHeadersVisible = false;
      this.dgvReports.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
      this.dgvReports.Size = new Size(581, 407);
      this.dgvReports.TabIndex = 4;
      this.tabControl1.Controls.Add((Control) this.tabPage1);
      this.tabControl1.Controls.Add((Control) this.tabPage2);
      this.tabControl1.Controls.Add((Control) this.tabPage3);
      this.tabControl1.Controls.Add((Control) this.tabPage4);
      this.tabControl1.Location = new Point(213, 89);
      this.tabControl1.Name = "tabControl1";
      this.tabControl1.SelectedIndex = 0;
      this.tabControl1.Size = new Size(235, 406);
      this.tabControl1.TabIndex = 5;
      this.tabPage1.Controls.Add((Control) this.lstCommon);
      this.tabPage1.Location = new Point(4, 22);
      this.tabPage1.Name = "tabPage1";
      this.tabPage1.Padding = new Padding(3);
      this.tabPage1.Size = new Size(227, 380);
      this.tabPage1.TabIndex = 0;
      this.tabPage1.Text = "Common";
      this.tabPage1.UseVisualStyleBackColor = true;
      this.tabPage2.Controls.Add((Control) this.lstTrades);
      this.tabPage2.Location = new Point(4, 22);
      this.tabPage2.Name = "tabPage2";
      this.tabPage2.Padding = new Padding(3);
      this.tabPage2.Size = new Size(227, 380);
      this.tabPage2.TabIndex = 1;
      this.tabPage2.Text = "Trades";
      this.tabPage2.UseVisualStyleBackColor = true;
      this.lstTrades.Dock = DockStyle.Fill;
      this.lstTrades.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lstTrades.FormattingEnabled = true;
      this.lstTrades.ItemHeight = 18;
      this.lstTrades.Items.AddRange(new object[6]
      {
        (object) "DAY",
        (object) "CNF",
        (object) "GTC",
        (object) "INSERT",
        (object) "MAINTENANCE",
        (object) "DELETED TRADE"
      });
      this.lstTrades.Location = new Point(3, 3);
      this.lstTrades.Name = "lstTrades";
      this.lstTrades.Size = new Size(221, 374);
      this.lstTrades.TabIndex = 4;
      this.lstTrades.SelectedIndexChanged += new EventHandler(this.lstTrades_SelectedIndexChanged);
      this.tabPage3.Controls.Add((Control) this.lstOrders);
      this.tabPage3.Location = new Point(4, 22);
      this.tabPage3.Name = "tabPage3";
      this.tabPage3.Padding = new Padding(3);
      this.tabPage3.Size = new Size(227, 380);
      this.tabPage3.TabIndex = 2;
      this.tabPage3.Text = "Orders";
      this.tabPage3.UseVisualStyleBackColor = true;
      this.lstOrders.Dock = DockStyle.Fill;
      this.lstOrders.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lstOrders.FormattingEnabled = true;
      this.lstOrders.ItemHeight = 18;
      this.lstOrders.Items.AddRange(new object[5]
      {
        (object) "EXECUTED",
        (object) "PENDING",
        (object) "GTC PENDING",
        (object) "CANCELLED",
        (object) "MODIFIED"
      });
      this.lstOrders.Location = new Point(3, 3);
      this.lstOrders.Name = "lstOrders";
      this.lstOrders.Size = new Size(221, 374);
      this.lstOrders.TabIndex = 4;
      this.lstOrders.SelectedIndexChanged += new EventHandler(this.lstOrders_SelectedIndexChanged);
      this.tabPage4.Controls.Add((Control) this.lstAccounts);
      this.tabPage4.Location = new Point(4, 22);
      this.tabPage4.Name = "tabPage4";
      this.tabPage4.Padding = new Padding(3);
      this.tabPage4.Size = new Size(227, 380);
      this.tabPage4.TabIndex = 3;
      this.tabPage4.Text = "Accounts";
      this.tabPage4.UseVisualStyleBackColor = true;
      this.lstAccounts.Dock = DockStyle.Fill;
      this.lstAccounts.Font = new Font("Microsoft Sans Serif", 11.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.lstAccounts.FormattingEnabled = true;
      this.lstAccounts.ItemHeight = 18;
      this.lstAccounts.Items.AddRange(new object[12]
      {
        (object) "Brokerage",
        (object) "Cash Balance",
        (object) "DA Profit/Loss",
        (object) "Ledger",
        (object) "Ledger(average)",
        (object) "Loss Accounts",
        (object) "Margin Utilised",
        (object) "Net MTM Profit/Loss",
        (object) "Open Positions",
        (object) "Profit Accounts",
        (object) "Profit/Loss",
        (object) "Turnover Utilised"
      });
      this.lstAccounts.Location = new Point(3, 3);
      this.lstAccounts.Name = "lstAccounts";
      this.lstAccounts.Size = new Size(221, 374);
      this.lstAccounts.Sorted = true;
      this.lstAccounts.TabIndex = 4;
      this.lstAccounts.SelectedIndexChanged += new EventHandler(this.lstAccounts_SelectedIndexChanged);
      this.btnView.Location = new Point(608, 49);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(92, 34);
      this.btnView.TabIndex = 6;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.btnExport.Location = new Point(902, 48);
      this.btnExport.Name = "btnExport";
      this.btnExport.Size = new Size(92, 34);
      this.btnExport.TabIndex = 7;
      this.btnExport.Text = "Export";
      this.btnExport.UseVisualStyleBackColor = true;
      this.btnExport.Click += new EventHandler(this.btnExport_Click);
      this.groupBox2.Controls.Add((Control) this.cmbSymbol);
      this.groupBox2.Controls.Add((Control) this.rdoNcdex);
      this.groupBox2.Controls.Add((Control) this.rdoNsecurr);
      this.groupBox2.Controls.Add((Control) this.rdoNseopt);
      this.groupBox2.Controls.Add((Control) this.rdoNsefut);
      this.groupBox2.Controls.Add((Control) this.rdoMcx);
      this.groupBox2.Controls.Add((Control) this.chkSymbolwise);
      this.groupBox2.Controls.Add((Control) this.chkExchwise);
      this.groupBox2.Location = new Point(221, 5);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new Size(361, 78);
      this.groupBox2.TabIndex = 9;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Filter";
      this.groupBox2.Visible = false;
      this.cmbSymbol.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbSymbol.FormattingEnabled = true;
      this.cmbSymbol.Location = new Point(119, 47);
      this.cmbSymbol.Name = "cmbSymbol";
      this.cmbSymbol.Size = new Size(231, 21);
      this.cmbSymbol.TabIndex = 7;
      this.cmbSymbol.Visible = false;
      this.rdoNcdex.AutoSize = true;
      this.rdoNcdex.Location = new Point(411, 21);
      this.rdoNcdex.Name = "rdoNcdex";
      this.rdoNcdex.Size = new Size(62, 17);
      this.rdoNcdex.TabIndex = 6;
      this.rdoNcdex.Text = "NCDEX";
      this.rdoNcdex.UseVisualStyleBackColor = true;
      this.rdoNcdex.Visible = false;
      this.rdoNcdex.CheckedChanged += new EventHandler(this.rdoNcdex_CheckedChanged);
      this.rdoNsecurr.AutoSize = true;
      this.rdoNsecurr.Location = new Point(322, 21);
      this.rdoNsecurr.Name = "rdoNsecurr";
      this.rdoNsecurr.Size = new Size(78, 17);
      this.rdoNsecurr.TabIndex = 5;
      this.rdoNsecurr.Text = "NSECURR";
      this.rdoNsecurr.UseVisualStyleBackColor = true;
      this.rdoNsecurr.Visible = false;
      this.rdoNsecurr.CheckedChanged += new EventHandler(this.rdoNsecurr_CheckedChanged);
      this.rdoNseopt.AutoSize = true;
      this.rdoNseopt.Location = new Point(247, 20);
      this.rdoNseopt.Name = "rdoNseopt";
      this.rdoNseopt.Size = new Size(69, 17);
      this.rdoNseopt.TabIndex = 4;
      this.rdoNseopt.Text = "NSEOPT";
      this.rdoNseopt.UseVisualStyleBackColor = true;
      this.rdoNseopt.Visible = false;
      this.rdoNseopt.CheckedChanged += new EventHandler(this.rdoNseopt_CheckedChanged);
      this.rdoNsefut.AutoSize = true;
      this.rdoNsefut.Location = new Point(173, 21);
      this.rdoNsefut.Name = "rdoNsefut";
      this.rdoNsefut.Size = new Size(68, 17);
      this.rdoNsefut.TabIndex = 3;
      this.rdoNsefut.Text = "NSEFUT";
      this.rdoNsefut.UseVisualStyleBackColor = true;
      this.rdoNsefut.Visible = false;
      this.rdoNsefut.CheckedChanged += new EventHandler(this.rdoNsefut_CheckedChanged);
      this.rdoMcx.AutoSize = true;
      this.rdoMcx.Checked = true;
      this.rdoMcx.Location = new Point(119, 21);
      this.rdoMcx.Name = "rdoMcx";
      this.rdoMcx.Size = new Size(48, 17);
      this.rdoMcx.TabIndex = 2;
      this.rdoMcx.TabStop = true;
      this.rdoMcx.Text = "MCX";
      this.rdoMcx.UseVisualStyleBackColor = true;
      this.rdoMcx.Visible = false;
      this.rdoMcx.CheckedChanged += new EventHandler(this.rdoMcx_CheckedChanged);
      this.rdoMcx.Click += new EventHandler(this.rdoMcx_Click);
      this.chkSymbolwise.AutoSize = true;
      this.chkSymbolwise.Location = new Point(6, 49);
      this.chkSymbolwise.Name = "chkSymbolwise";
      this.chkSymbolwise.Size = new Size(81, 17);
      this.chkSymbolwise.TabIndex = 1;
      this.chkSymbolwise.Text = "Symbolwise";
      this.chkSymbolwise.UseVisualStyleBackColor = true;
      this.chkSymbolwise.CheckedChanged += new EventHandler(this.chkSymbolwise_CheckedChanged);
      this.chkExchwise.AutoSize = true;
      this.chkExchwise.Location = new Point(6, 19);
      this.chkExchwise.Name = "chkExchwise";
      this.chkExchwise.Size = new Size(95, 17);
      this.chkExchwise.TabIndex = 0;
      this.chkExchwise.Text = "Exchangewise";
      this.chkExchwise.UseVisualStyleBackColor = true;
      this.chkExchwise.CheckedChanged += new EventHandler(this.chkExchwise_CheckedChanged);
      this.rdoTxtFrmt.AutoSize = true;
      this.rdoTxtFrmt.Location = new Point(710, 44);
      this.rdoTxtFrmt.Name = "rdoTxtFrmt";
      this.rdoTxtFrmt.Size = new Size(75, 17);
      this.rdoTxtFrmt.TabIndex = 11;
      this.rdoTxtFrmt.Text = "Txt Format";
      this.rdoTxtFrmt.UseVisualStyleBackColor = true;
      this.rdoTxtFrmt.CheckedChanged += new EventHandler(this.rdoTxtFrmt_CheckedChanged);
      this.rdoTxtFrmt.Click += new EventHandler(this.rdoTxtFrmt_Click);
      this.rdoCsvFrmt.AutoSize = true;
      this.rdoCsvFrmt.Checked = true;
      this.rdoCsvFrmt.Location = new Point(710, 25);
      this.rdoCsvFrmt.Name = "rdoCsvFrmt";
      this.rdoCsvFrmt.Size = new Size(78, 17);
      this.rdoCsvFrmt.TabIndex = 12;
      this.rdoCsvFrmt.TabStop = true;
      this.rdoCsvFrmt.Text = "Csv Format";
      this.rdoCsvFrmt.UseVisualStyleBackColor = true;
      this.cmbExch.DropDownStyle = ComboBoxStyle.DropDownList;
      this.cmbExch.FormattingEnabled = true;
      this.cmbExch.Location = new Point(709, 64);
      this.cmbExch.Name = "cmbExch";
      this.cmbExch.Size = new Size(86, 21);
      this.cmbExch.TabIndex = 13;
      this.cmbExch.Visible = false;
      this.rdoSauda.AutoSize = true;
      this.rdoSauda.Location = new Point(709, 6);
      this.rdoSauda.Name = "rdoSauda";
      this.rdoSauda.Size = new Size(91, 17);
      this.rdoSauda.TabIndex = 14;
      this.rdoSauda.Text = "Sauda Format";
      this.rdoSauda.UseVisualStyleBackColor = true;
      this.rdoShilpi.AutoSize = true;
      this.rdoShilpi.Location = new Point(802, 6);
      this.rdoShilpi.Name = "rdoShilpi";
      this.rdoShilpi.Size = new Size(85, 17);
      this.rdoShilpi.TabIndex = 15;
      this.rdoShilpi.Text = "Shilpi Format";
      this.rdoShilpi.UseVisualStyleBackColor = true;
      this.rdoLogics.AutoSize = true;
      this.rdoLogics.Location = new Point(802, 24);
      this.rdoLogics.Name = "rdoLogics";
      this.rdoLogics.Size = new Size(91, 17);
      this.rdoLogics.TabIndex = 16;
      this.rdoLogics.Text = "Logics Format";
      this.rdoLogics.UseVisualStyleBackColor = true;
      this.rdo_SaudaNew.AutoSize = true;
      this.rdo_SaudaNew.Location = new Point(802, 44);
      this.rdo_SaudaNew.Name = "rdo_SaudaNew";
      this.rdo_SaudaNew.Size = new Size(81, 17);
      this.rdo_SaudaNew.TabIndex = 17;
      this.rdo_SaudaNew.Text = "Sauda New";
      this.rdo_SaudaNew.UseVisualStyleBackColor = true;
      this.rdo_Exch.AutoSize = true;
      this.rdo_Exch.Location = new Point(955, 26);
      this.rdo_Exch.Name = "rdo_Exch";
      this.rdo_Exch.Size = new Size(73, 17);
      this.rdo_Exch.TabIndex = 18;
      this.rdo_Exch.Text = "Exchange";
      this.rdo_Exch.UseVisualStyleBackColor = true;
      this.rdo_Exch.Visible = false;
      this.rdo_Vijaya.AutoSize = true;
      this.rdo_Vijaya.Location = new Point(902, 5);
      this.rdo_Vijaya.Name = "rdo_Vijaya";
      this.rdo_Vijaya.Size = new Size(53, 17);
      this.rdo_Vijaya.TabIndex = 19;
      this.rdo_Vijaya.Text = "Vijaya";
      this.rdo_Vijaya.UseVisualStyleBackColor = true;
      this.rdo_FMT.AutoSize = true;
      this.rdo_FMT.Location = new Point(902, 26);
      this.rdo_FMT.Name = "rdo_FMT";
      this.rdo_FMT.Size = new Size(47, 17);
      this.rdo_FMT.TabIndex = 20;
      this.rdo_FMT.Text = "FMT";
      this.rdo_FMT.UseVisualStyleBackColor = true;
      this.rdo_TB.AutoSize = true;
      this.rdo_TB.Location = new Point(802, 64);
      this.rdo_TB.Name = "rdo_TB";
      this.rdo_TB.Size = new Size(39, 17);
      this.rdo_TB.TabIndex = 21;
      this.rdo_TB.Text = "TB";
      this.rdo_TB.UseVisualStyleBackColor = true;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(1030, 494);
      this.Controls.Add((Control) this.rdo_TB);
      this.Controls.Add((Control) this.rdo_FMT);
      this.Controls.Add((Control) this.rdo_Vijaya);
      this.Controls.Add((Control) this.rdo_Exch);
      this.Controls.Add((Control) this.rdo_SaudaNew);
      this.Controls.Add((Control) this.rdoLogics);
      this.Controls.Add((Control) this.rdoShilpi);
      this.Controls.Add((Control) this.rdoSauda);
      this.Controls.Add((Control) this.cmbExch);
      this.Controls.Add((Control) this.rdoCsvFrmt);
      this.Controls.Add((Control) this.rdoTxtFrmt);
      this.Controls.Add((Control) this.groupBox2);
      this.Controls.Add((Control) this.btnExport);
      this.Controls.Add((Control) this.btnView);
      this.Controls.Add((Control) this.tabControl1);
      this.Controls.Add((Control) this.dgvReports);
      this.Controls.Add((Control) this.treeView1);
      this.Controls.Add((Control) this.groupBox1);
      this.FormBorderStyle = FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = nameof (MISReports);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "MIS Reports";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      ((ISupportInitialize) this.dgvReports).EndInit();
      this.tabControl1.ResumeLayout(false);
      this.tabPage1.ResumeLayout(false);
      this.tabPage2.ResumeLayout(false);
      this.tabPage3.ResumeLayout(false);
      this.tabPage4.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
