﻿// Decompiled with JetBrains decompiler
// Type: DTS.unlock
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class unlock : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    private Label label1;
    private Button btnunlock;
    public TextBox txtpassword;

    public unlock(Dashboard dashobj)
    {
      this.InitializeComponent();
      this.objdash = dashobj;
      this.txtpassword.Text = string.Empty;
      this.Icon = this.objdash.ico;
    }

    private void btnunlock_Click(object sender, EventArgs e)
    {
      if (this.txtpassword.Text != string.Empty)
      {
        if (this.objdash.Encryptdata(this.txtpassword.Text) == this.objdash.objinfo.password)
        {
          this.txtpassword.Text = "";
          this.objdash.InsertMsgBoard(" Workstation Unlocked Successfully!!", 2);
          this.Hide();
        }
        else
          this.objdash.DisplayMessage("Incorrect password.", 3);
      }
      else
        this.objdash.DisplayMessage("Enter password to Unlock.", 2);
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof (unlock));
      this.label1 = new Label();
      this.txtpassword = new TextBox();
      this.btnunlock = new Button();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(40, 22);
      this.label1.Name = "label1";
      this.label1.Size = new Size(56, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Password:";
      this.txtpassword.Location = new Point(102, 19);
      this.txtpassword.Name = "txtpassword";
      this.txtpassword.PasswordChar = '*';
      this.txtpassword.Size = new Size(100, 20);
      this.txtpassword.TabIndex = 1;
      this.btnunlock.Location = new Point(84, 55);
      this.btnunlock.Name = "btnunlock";
      this.btnunlock.Size = new Size(75, 23);
      this.btnunlock.TabIndex = 2;
      this.btnunlock.Text = "Unlock";
      this.btnunlock.UseVisualStyleBackColor = true;
      this.btnunlock.Click += new EventHandler(this.btnunlock_Click);
      this.AcceptButton = (IButtonControl) this.btnunlock;
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(242, 118);
      this.ControlBox = false;
      this.Controls.Add((Control) this.btnunlock);
      this.Controls.Add((Control) this.txtpassword);
      this.Controls.Add((Control) this.label1);
      this.FormBorderStyle = FormBorderStyle.FixedDialog;
      this.Icon = (Icon) componentResourceManager.GetObject("$this.Icon");
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (unlock);
      this.ShowInTaskbar = false;
      this.StartPosition = FormStartPosition.Manual;
      this.Text = "Unlock workstation";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
