﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDownloadContrct
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace DTS
{
  public class frmDownloadContrct : Form
  {
    private IContainer components = (IContainer) null;
    public SqlConnection conn;
    public Dashboard objdash;
    private Label label1;
    private ProgressBar progressBar1;
    private ListBox lstMsgBox;
    private ProgressBar progressBar2;
    private Label label2;
    private ProgressBar progressBar3;
    private Label label3;
    private ProgressBar progressBar4;
    private Label label4;
    private ProgressBar progressBar5;
    private Label label5;

    public frmDownloadContrct(SqlConnection db, Dashboard dash)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = db;
      this.Icon = this.objdash.ico;
    }

    public void DownloadContracts()
    {
      this.Invoke((Delegate) (() =>
      {
        this.lstMsgBox.Items.Clear();
        this.progressBar1.Value = 0;
        this.progressBar2.Value = 0;
        this.progressBar3.Value = 0;
        this.progressBar4.Value = 0;
        this.progressBar5.Value = 0;
      }));
      this.objdash._Symconctracts = new Dictionary<string, Contracts>();
      this.objdash._Exchconctracts = new Dictionary<int, SortedDictionary<string, Contracts>>();
      string userExch = this.objdash.GetUserExch();
      DateTime dateTime1 = this.objdash.GetServerTime().AddDays(-2.0);
      string selectCommandText1 = "Select Symbol,Expiry,Lotsize,MeasureLotPrice,TickPrice,Exch,Status,SymDescription,UserSymbol from Contracts where Exch in (" + userExch + ")";
      string[] strArray = new string[5]
      {
        "Select Symbol,Expiry,Lotsize,MeasureLotPrice,TickPrice,Exch,Status,SymDescription,UserSymbol from Contracts_History where Exch in (",
        userExch,
        ") and Expiry > '",
        null,
        null
      };
      DateTime dateTime2 = DateTime.Now;
      dateTime2 = dateTime2.AddMonths(-12);
      strArray[3] = dateTime2.ToString("yyyy-MM-dd 00:00:00");
      strArray[4] = "'";
      string selectCommandText2 = string.Concat(strArray);
      DataSet ds = new DataSet();
      using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText1, this.conn))
        sqlDataAdapter.Fill(ds);
      if (ds != null && ds.Tables[0].Rows.Count > 0)
      {
        this.Invoke((Delegate) (() =>
        {
          this.progressBar1.Minimum = 0;
          this.progressBar1.Maximum = ds.Tables[0].Rows.Count;
          this.progressBar1.Value = 0;
        }));
        Contracts objcon = new Contracts();
        for (int index = 0; index < ds.Tables[0].Rows.Count; ++index)
        {
          objcon.symbol = ds.Tables[0].Rows[index].ItemArray[0].ToString();
          objcon.expiry = Convert.ToDateTime(ds.Tables[0].Rows[index].ItemArray[1].ToString());
          objcon.lotsize = Convert.ToInt32(ds.Tables[0].Rows[index].ItemArray[2].ToString());
          objcon.measurelotsize = ds.Tables[0].Rows[index].ItemArray[3].ToString();
          objcon.tickprice = Convert.ToInt32(ds.Tables[0].Rows[index].ItemArray[4].ToString());
          objcon.exch = Convert.ToInt32(ds.Tables[0].Rows[index].ItemArray[5].ToString());
          objcon.status = Convert.ToInt32(ds.Tables[0].Rows[index].ItemArray[6].ToString());
          objcon.SymDesp = ds.Tables[0].Rows[index].ItemArray[7].ToString();
          objcon.UserSymbol = ds.Tables[0].Rows[index].ItemArray[8].ToString();
          if (!(objcon.symbol == "GOLDMM") && !(objcon.symbol == "SILVERMM") || ((this.objdash.objinfo.usertype == 4 || this.objdash.objinfo.usertype == 3) && this.objdash.objinfo.createdby == "A008" || this.objdash.objinfo.usertype == 2 && this.objdash.objinfo.clientcode == "A008" || this.objdash.objinfo.usertype == 1))
          {
            if (objcon.expiry > dateTime1)
              this.objdash.ManageContracts(objcon);
            this.Invoke((Delegate) (() => this.progressBar1.PerformStep()));
          }
        }
        Application.DoEvents();
      }
      DataSet dataSet = new DataSet();
      using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText2, this.conn))
        sqlDataAdapter.Fill(dataSet);
      if (dataSet != null && dataSet.Tables[0].Rows.Count > 0)
      {
        Contracts contracts = new Contracts();
        for (int index = 0; index < dataSet.Tables[0].Rows.Count; ++index)
        {
          contracts.symbol = dataSet.Tables[0].Rows[index].ItemArray[0].ToString();
          contracts.expiry = Convert.ToDateTime(dataSet.Tables[0].Rows[index].ItemArray[1].ToString());
          contracts.lotsize = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[2].ToString());
          contracts.measurelotsize = dataSet.Tables[0].Rows[index].ItemArray[3].ToString();
          contracts.tickprice = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[4].ToString());
          contracts.exch = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[5].ToString());
          contracts.status = Convert.ToInt32(dataSet.Tables[0].Rows[index].ItemArray[6].ToString());
          contracts.SymDesp = dataSet.Tables[0].Rows[index].ItemArray[7].ToString();
          contracts.UserSymbol = dataSet.Tables[0].Rows[index].ItemArray[8].ToString();
          if (!this.objdash._ContractsHistory.ContainsKey(contracts.SymDesp) && !this.objdash._Symconctracts.ContainsKey(contracts.SymDesp))
            this.objdash._ContractsHistory.Add(contracts.SymDesp, contracts);
        }
        Application.DoEvents();
      }
      this.objdash._FxSymbols = this.objdash.flag != 1 ? (FXSql.Connect236() ? FXSql.GetFXSymbols() : new List<string>()) : (FXSql.Connect() ? FXSql.GetFXSymbols() : new List<string>());
      if (this.objdash.objinfo.usertype == 2)
      {
        if (this.objdash.flag == 1)
        {
          if (FXSql.Connect())
            FXSql.GetclientwiseFXSettings(this.conn, this.objdash);
        }
        else if (FXSql.Connect236())
          FXSql.GetclientwiseFXSettings(this.conn, this.objdash);
      }
      this.Invoke((Delegate) (() =>
      {
        this.lstMsgBox.Items.Add((object) "Contracts Downloaded Successfully!!");
        Application.DoEvents();
      }));
      if (this.objdash.objinfo.usertype != 4)
        new Thread(new ThreadStart(((ThreadStart) (() => this.GetUserinformation())).Invoke)).Start();
      else
        new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadLimitMargin())).Invoke)).Start();
    }

    public void GetUserinformation()
    {
      this.objdash._Userinformation = new Dictionary<string, Userinfo>();
      this.objdash._lstDealers = new List<string>();
      this.objdash.dlaccounts = string.Empty;
      this.objdash._lstAccounts = new List<string>();
      this.objdash.claccounts = string.Empty;
      this.objdash._DAHierarchy = new Dictionary<string, Dictionary<string, Userinfo>>();
      this.Invoke((Delegate) (() =>
      {
        this.progressBar2.Minimum = 0;
        this.progressBar2.Maximum = 100;
        this.progressBar2.Value = 0;
      }));
      if (this.objdash.objinfo.usertype == 3)
      {
        this.RefreshMappedClients(this.conn);
        if (this.objdash.objinfo.mappedclients != null && this.objdash.objinfo.mappedclients != string.Empty)
        {
          string empty = string.Empty;
          string str;
          if (this.objdash.objinfo.mappedclients.Contains(","))
          {
            string[] strArray = this.objdash.objinfo.mappedclients.Split(',');
            for (int index = 0; index < strArray.Length; ++index)
            {
              if (strArray[index] != string.Empty)
                empty += string.Format("'{0}',", (object) strArray[index]);
            }
            str = empty.Substring(0, empty.Length - 1);
          }
          else
            str = string.Format("'{0}'", (object) this.objdash.objinfo.mappedclients);
          using (SqlCommand sqlCommand = new SqlCommand("Select * from Userinformation where Clientcode in (" + str + ")", this.conn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
                this.objdash.ManageUserinformation(this.ExtractUserinfo(reader));
            }
          }
        }
      }
      else
      {
        SqlCommand sqlCommand1 = new SqlCommand("GetUserinfor", this.conn);
        sqlCommand1.CommandType = CommandType.StoredProcedure;
        using (SqlCommand sqlCommand2 = sqlCommand1)
        {
          sqlCommand2.Parameters.AddWithValue("@createdby", (object) this.objdash.objinfo.clientcode);
          using (SqlDataReader reader = sqlCommand2.ExecuteReader())
          {
            while (reader.Read())
            {
              this.Invoke((Delegate) (() =>
              {
                this.progressBar2.PerformStep();
                Application.DoEvents();
              }));
              Userinfo userinfo = this.ExtractUserinfo(reader);
              if (userinfo.usertype == 2)
                userinfo.DAfund = this.GetDAfund(userinfo.clientcode);
              this.objdash.ManageUserinformation(userinfo);
              if (this.objdash.objinfo.usertype == 1 && !this.objdash._DAHierarchy.ContainsKey(userinfo.clientcode))
              {
                Dictionary<string, Userinfo> daHierarchy = this.GetDAHierarchy(userinfo.clientcode);
                this.objdash._DAHierarchy.Add(userinfo.clientcode, daHierarchy);
              }
            }
          }
        }
      }
      this.Invoke((Delegate) (() =>
      {
        this.progressBar2.Value = this.progressBar2.Maximum;
        this.lstMsgBox.Items.Add((object) "Userinformation Downloaded Successfully!!");
        Application.DoEvents();
      }));
      new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadLimitMargin())).Invoke)).Start();
    }

    private Dictionary<string, Userinfo> GetDAHierarchy(string clientcode)
    {
      Dictionary<string, Userinfo> dictionary = new Dictionary<string, Userinfo>();
      SqlCommand sqlCommand1 = new SqlCommand("GetUserinfor", this.conn);
      sqlCommand1.CommandType = CommandType.StoredProcedure;
      using (SqlCommand sqlCommand2 = sqlCommand1)
      {
        sqlCommand2.Parameters.AddWithValue("@createdby", (object) clientcode);
        using (SqlDataReader reader = sqlCommand2.ExecuteReader())
        {
          while (reader.Read())
          {
            Userinfo userinfo = this.ExtractUserinfo(reader);
            this.objdash.ManageUserinformation(userinfo);
            if (!dictionary.ContainsKey(userinfo.clientcode))
              dictionary.Add(userinfo.clientcode, userinfo);
            if (userinfo.usertype == 3)
            {
              if (!this.objdash._lstDealers.Contains(userinfo.clientcode))
                this.objdash._lstDealers.Add(userinfo.clientcode);
            }
            else if (userinfo.usertype == 4 && !this.objdash._lstAccounts.Contains(userinfo.clientcode))
              this.objdash._lstAccounts.Add(userinfo.clientcode);
          }
        }
      }
      return dictionary;
    }

    private Userinfo ExtractUserinfo(SqlDataReader reader)
    {
      Userinfo userinfo = new Userinfo();
      if (!reader.IsDBNull(1))
        userinfo.name = reader.GetString(1);
      if (!reader.IsDBNull(2))
        userinfo.clientcode = reader.GetString(2);
      if (!reader.IsDBNull(3))
        userinfo.username = reader.GetString(3);
      if (!reader.IsDBNull(4))
        userinfo.password = reader.GetString(4);
      if (!reader.IsDBNull(5))
        userinfo.regdate = Convert.ToDateTime(reader.GetValue(5));
      if (!reader.IsDBNull(6))
        userinfo.userstatus = reader.GetInt32(6);
      if (!reader.IsDBNull(7))
        userinfo.marginstatus = reader.GetInt32(7);
      if (!reader.IsDBNull(8))
        userinfo.productype = reader.GetInt32(8);
      if (!reader.IsDBNull(9))
        userinfo.usertype = reader.GetInt32(9);
      if (!reader.IsDBNull(10))
        userinfo.createdby = reader.GetString(10);
      if (!reader.IsDBNull(11))
        userinfo.Lastlogin = Convert.ToDateTime(reader.GetValue(11));
      if (!reader.IsDBNull(12))
        userinfo.pivots = reader.GetInt32(12);
      if (!reader.IsDBNull(13))
        userinfo.stockperform = reader.GetInt32(13);
      if (!reader.IsDBNull(14))
        userinfo.charts = reader.GetInt32(14);
      if (!reader.IsDBNull(15))
        userinfo.exchange = reader.GetString(15);
      if (!reader.IsDBNull(16))
        userinfo.offset = reader.GetInt32(16);
      if (!reader.IsDBNull(17))
        userinfo.mappedclients = reader.GetString(17);
      if (!reader.IsDBNull(18))
        userinfo.oddlot = reader.GetInt32(18);
      if (!reader.IsDBNull(20))
        userinfo.AppName = reader.GetString(20);
      userinfo.isModTrd = !reader.IsDBNull(22) ? reader.GetInt32(22) : 0;
      if (!reader.IsDBNull(23))
        userinfo.DApflsPercent = Convert.ToInt32(reader.GetValue(23));
      if (!reader.IsDBNull(24))
        userinfo.emailid = reader.GetString(24);
      if (!reader.IsDBNull(25))
        userinfo.Mobno = Convert.ToInt64(reader.GetValue(25));
      userinfo.OffsetExch = reader.IsDBNull(26) ? string.Empty : reader.GetString(26);
      if (!reader.IsDBNull(27))
        userinfo.isHLTrading = reader.GetInt32(27);
      userinfo.HighLowExch = reader.IsDBNull(28) ? string.Empty : reader.GetString(28);
      if (!reader.IsDBNull(31))
        userinfo.isSMS = reader.GetInt32(31);
      return userinfo;
    }

    public void DownloadLimitMargin()
    {
      this.objdash._ClientLimits = new Dictionary<string, Limits>();
      if (this.objdash._lstAccounts.Count > 0)
      {
        this.Invoke((Delegate) (() =>
        {
          this.progressBar3.Minimum = 0;
          this.progressBar3.Maximum = this.objdash._lstAccounts.Count;
          this.progressBar3.Value = 0;
        }));
        this.objdash._ClientLimits = new Dictionary<string, Limits>();
        if (this.conn.State == ConnectionState.Closed)
          this.conn = this.objdash.getConn();
        using (SqlCommand sqlCommand = new SqlCommand("Select * from Limitset where Clientcode in (" + this.objdash.claccounts + ")", this.conn))
        {
          try
          {
            using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
            {
              while (sqlDataReader.Read())
              {
                this.Invoke((Delegate) (() =>
                {
                  this.progressBar3.PerformStep();
                  Application.DoEvents();
                }));
                Limits objlimits = new Limits();
                if (!sqlDataReader.IsDBNull(1))
                  objlimits.clientcode = sqlDataReader.GetString(1);
                if (!sqlDataReader.IsDBNull(2))
                  objlimits.cashmrgn = Convert.ToDecimal(sqlDataReader.GetValue(2)) / new Decimal(100);
                if (!sqlDataReader.IsDBNull(3))
                  objlimits.turnoverlimit = Convert.ToDecimal(sqlDataReader.GetValue(3)) / new Decimal(100);
                if (!sqlDataReader.IsDBNull(4))
                  objlimits.mtmlosslimit = Convert.ToDecimal(sqlDataReader.GetValue(4)) / new Decimal(100);
                if (!sqlDataReader.IsDBNull(5))
                  objlimits.turnmulti = sqlDataReader.GetInt32(5);
                if (!sqlDataReader.IsDBNull(6))
                  objlimits.mtmmulti = Convert.ToInt32(sqlDataReader.GetValue(6));
                if (!sqlDataReader.IsDBNull(7))
                  objlimits.breakup = sqlDataReader.GetInt32(7);
                if (!sqlDataReader.IsDBNull(8))
                  objlimits.brkgtype = sqlDataReader.GetInt32(8);
                if (!sqlDataReader.IsDBNull(9))
                  objlimits.mcxIntrdybrkg = Convert.ToDecimal(sqlDataReader.GetValue(9));
                if (!sqlDataReader.IsDBNull(10))
                  objlimits.nsefutIntrdybrkg = Convert.ToDecimal(sqlDataReader.GetValue(10));
                if (!sqlDataReader.IsDBNull(11))
                  objlimits.ncdexIntrdybrkg = Convert.ToDecimal(sqlDataReader.GetValue(11));
                if (!sqlDataReader.IsDBNull(12))
                  objlimits.nsecurrIntrdybrkg = Convert.ToDecimal(sqlDataReader.GetValue(12));
                if (!sqlDataReader.IsDBNull(13))
                  objlimits.mcxCnfbrkg = Convert.ToDecimal(sqlDataReader.GetValue(13));
                if (!sqlDataReader.IsDBNull(14))
                  objlimits.nsefutCnfbrkg = Convert.ToDecimal(sqlDataReader.GetValue(14));
                if (!sqlDataReader.IsDBNull(15))
                  objlimits.ncdexCnfbrkg = Convert.ToDecimal(sqlDataReader.GetValue(15));
                if (!sqlDataReader.IsDBNull(16))
                  objlimits.nsecurrCnfbrkg = Convert.ToDecimal(sqlDataReader.GetValue(16));
                if (!sqlDataReader.IsDBNull(17))
                  objlimits.tradeattributes = sqlDataReader.GetInt32(17);
                if (!sqlDataReader.IsDBNull(18))
                  objlimits.mrgntype = sqlDataReader.GetInt32(18);
                if (!sqlDataReader.IsDBNull(19))
                  objlimits.isIntrasqoff = sqlDataReader.GetInt32(19);
                if (!sqlDataReader.IsDBNull(20))
                  objlimits.IsMrgnsqoff = sqlDataReader.GetInt32(20);
                if (!sqlDataReader.IsDBNull(21))
                  objlimits.timestamp = Convert.ToDateTime(sqlDataReader.GetValue(21));
                if (!sqlDataReader.IsDBNull(22))
                  objlimits.lotwisetype = sqlDataReader.GetInt32(22);
                if (!sqlDataReader.IsDBNull(23))
                  objlimits.mcxlots = sqlDataReader.GetInt32(23);
                if (!sqlDataReader.IsDBNull(24))
                  objlimits.ncxlots = sqlDataReader.GetInt32(24);
                if (!sqlDataReader.IsDBNull(25))
                  objlimits.nsefutlots = sqlDataReader.GetInt32(25);
                if (!sqlDataReader.IsDBNull(26))
                  objlimits.nsecurlots = sqlDataReader.GetInt32(26);
                objlimits.possitionValidity = sqlDataReader.IsDBNull(27) ? string.Empty : sqlDataReader.GetString(27);
                objlimits.Productype = sqlDataReader.IsDBNull(28) ? string.Empty : sqlDataReader.GetString(28);
                if (!sqlDataReader.IsDBNull(29))
                  objlimits.McxBrkup = sqlDataReader.GetInt32(29);
                if (!sqlDataReader.IsDBNull(30))
                  objlimits.NsefutBrkup = sqlDataReader.GetInt32(30);
                if (!sqlDataReader.IsDBNull(31))
                  objlimits.NcdexBrkup = sqlDataReader.GetInt32(31);
                if (!sqlDataReader.IsDBNull(32))
                  objlimits.NsecurBrkup = sqlDataReader.GetInt32(32);
                if (!sqlDataReader.IsDBNull(33))
                  objlimits.PendingOrderExec = sqlDataReader.GetInt32(33);
                objlimits.brkupType = !sqlDataReader.IsDBNull(35) ? sqlDataReader.GetInt32(35) : 2;
                if (!sqlDataReader.IsDBNull(34) && !this.objdash._ClientwiseLeverage.ContainsKey(objlimits.clientcode))
                  this.objdash._ClientwiseLeverage.Add(objlimits.clientcode, sqlDataReader.GetString(34));
                this.objdash.ManageLimitset(objlimits);
              }
            }
          }
          catch
          {
          }
        }
      }
      this.Invoke((Delegate) (() =>
      {
        this.progressBar3.Value = this.progressBar3.Maximum;
        this.lstMsgBox.Items.Add((object) "Limits/Margin Downloaded Successfully!!");
        Application.DoEvents();
      }));
      new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadSymbolMargin())).Invoke)).Start();
    }

    private void DownloadSymbolMargin()
    {
      this.objdash._ClientSymMrgn = new Dictionary<string, Dictionary<string, SymbolMargin>>();
      this.Invoke((Delegate) (() =>
      {
        this.progressBar4.Minimum = 0;
        this.progressBar4.Maximum = 100;
        this.progressBar4.Value = 0;
      }));
      string code = string.Empty;
      if (this.objdash.objinfo.usertype == 2 || this.objdash.objinfo.usertype == 1)
        code = !(this.objdash.claccounts == string.Empty) ? string.Format("{0},'{1}'", (object) this.objdash.claccounts, (object) this.objdash.objinfo.clientcode) : string.Format("'{0}'", (object) this.objdash.objinfo.clientcode);
      else if (this.objdash.objinfo.usertype == 3)
        code = string.Format("{0},'{1}'", (object) this.objdash.claccounts, (object) this.objdash.objinfo.createdby);
      else if (this.objdash.objinfo.usertype == 4)
        code = string.Format("'{0}','{1}'", (object) this.objdash.objinfo.clientcode, (object) this.objdash.objinfo.createdby);
      if (code != null & code != string.Empty)
      {
        using (SqlCommand sqlCommand = new SqlCommand(string.Format("Select * from SymbolwiseMargin where ClientCode in ({0})", (object) code), this.conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              this.Invoke((Delegate) (() =>
              {
                this.progressBar4.PerformStep();
                Application.DoEvents();
              }));
              SymbolMargin objmrgn = new SymbolMargin();
              if (!sqlDataReader.IsDBNull(1))
                objmrgn.symbol = sqlDataReader.GetString(1);
              if (!sqlDataReader.IsDBNull(2))
                objmrgn.intramrgn = sqlDataReader.GetInt32(2);
              if (!sqlDataReader.IsDBNull(3))
                objmrgn.intrabrkg = sqlDataReader.GetInt32(3);
              if (!sqlDataReader.IsDBNull(4))
                objmrgn.delvmrgn = sqlDataReader.GetInt32(4);
              if (!sqlDataReader.IsDBNull(5))
                objmrgn.delvbrkg = sqlDataReader.GetInt32(5);
              if (!sqlDataReader.IsDBNull(6))
                objmrgn.totlots = sqlDataReader.GetInt32(6);
              if (!sqlDataReader.IsDBNull(7))
                objmrgn.clientcode = sqlDataReader.GetString(7);
              if (!sqlDataReader.IsDBNull(8))
                objmrgn.brkupQty = sqlDataReader.GetInt32(8);
              this.objdash.ManageMargin(objmrgn);
            }
          }
        }
        using (SqlCommand sqlCommand = new SqlCommand(string.Format("Select * from ExchwiseMarginLots where Clientcode = '{0}'", (object) this.objdash.objinfo.createdby), this.conn))
        {
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              if (!sqlDataReader.IsDBNull(2))
                this.objdash.MCXlots = sqlDataReader.GetInt32(2);
              if (!sqlDataReader.IsDBNull(3))
                this.objdash.NSEFUTlots = sqlDataReader.GetInt32(3);
              if (!sqlDataReader.IsDBNull(4))
                this.objdash.NCDEXlots = sqlDataReader.GetInt32(4);
              if (!sqlDataReader.IsDBNull(5))
                this.objdash.NSECURlots = sqlDataReader.GetInt32(5);
              if (!sqlDataReader.IsDBNull(6))
                this.objdash.NSEOPTlots = sqlDataReader.GetInt32(6);
            }
          }
        }
        if (this.objdash.objinfo.usertype == 2)
        {
          this.DownloadGroupingList();
          this.DownloadTradeGroupingList();
          this.DownloadDPRLimit();
        }
        if (this.objdash.objinfo.usertype == 3 || this.objdash.objinfo.usertype == 4)
          this.DownloadDPRLimit();
        this.DownloadTradeSettings(code);
        this.DownloadBrkgType(code);
      }
      this.Invoke((Delegate) (() =>
      {
        this.progressBar4.Value = this.progressBar4.Maximum;
        this.lstMsgBox.Items.Add((object) "Symbolwise Margin Downloaded Successfully!!");
        Application.DoEvents();
        this.objdash.StartMarketFeeds();
      }));
      new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadOffset())).Invoke)).Start();
    }

    private void DownloadOffset()
    {
      this.objdash._ClientOffset = new Dictionary<string, SortedDictionary<string, double>>();
      string str = string.Empty;
      if (this.objdash.objinfo.usertype == 2 || this.objdash.objinfo.usertype == 3)
      {
        str = string.Format("'{0}'", (object) this.objdash.objinfo.clientcode);
        if (this.objdash.claccounts != null && this.objdash.claccounts.Length > 0)
          str += string.Format(",{0}", (object) this.objdash.claccounts);
        if (this.objdash.objinfo.usertype == 3)
          str += string.Format(",'{0}'", (object) this.objdash.objinfo.createdby);
      }
      else if (this.objdash.objinfo.usertype == 4)
        str = string.Format("'{0}','{1}'", (object) this.objdash.objinfo.clientcode, (object) this.objdash.objinfo.createdby);
      if (str.Length > 0)
      {
        using (SqlCommand sqlCommand = new SqlCommand("Select * from Offset where Clientcode in (" + str + ")", this.conn))
        {
          this.Invoke((Delegate) (() =>
          {
            this.progressBar5.Minimum = 0;
            this.progressBar5.Maximum = 500;
            this.progressBar5.Value = 0;
          }));
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              this.Invoke((Delegate) (() =>
              {
                this.progressBar5.PerformStep();
                Application.DoEvents();
              }));
              double offset = 0.0;
              if (!sqlDataReader.IsDBNull(1))
              {
                string clientcode = sqlDataReader.GetString(1);
                if (!sqlDataReader.IsDBNull(2))
                {
                  string symbol = sqlDataReader.GetString(2);
                  if (!sqlDataReader.IsDBNull(3))
                    offset = Convert.ToDouble(sqlDataReader.GetValue(3));
                  this.objdash.ManageOffset(clientcode, symbol, offset);
                }
              }
            }
          }
        }
      }
      this.Invoke((Delegate) (() =>
      {
        this.progressBar5.Value = this.progressBar5.Maximum;
        this.lstMsgBox.Items.Add((object) "Offset Downloaded Successfully!!");
        Application.DoEvents();
      }));
      new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadContractStatus())).Invoke)).Start();
    }

    private void DownloadContractStatus()
    {
      this.objdash._ClientContractStatus = new Dictionary<string, Dictionary<int, SortedDictionary<string, int>>>();
      string str = string.Empty;
      if (this.objdash.objinfo.usertype == 2 || this.objdash.objinfo.usertype == 3)
      {
        str = string.Format("'{0}'", (object) this.objdash.objinfo.clientcode);
        if (this.objdash.claccounts != null && this.objdash.claccounts.Length > 0)
          str += string.Format(",{0}", (object) this.objdash.claccounts);
        if (this.objdash.objinfo.usertype == 2)
        {
          if (this.objdash.dlaccounts != null && this.objdash.dlaccounts.Length > 0)
            str += string.Format(",{0}", (object) this.objdash.dlaccounts);
        }
        else
          str += string.Format(",'{0}'", (object) this.objdash.objinfo.createdby);
      }
      else if (this.objdash.objinfo.usertype == 1)
      {
        string clientCodes = this.objdash.GetClientCodes(1, this.objdash.objinfo.clientcode);
        str = clientCodes == null ? string.Format("'{0}'", (object) this.objdash.objinfo.clientcode) : string.Format("'{0}',{1}", (object) this.objdash.objinfo.clientcode, (object) clientCodes);
      }
      else if (this.objdash.objinfo.usertype == 4)
        str = string.Format("'{0}','{1}'", (object) this.objdash.objinfo.clientcode, (object) this.objdash.objinfo.createdby);
      if (str.Length > 0)
      {
        using (SqlCommand sqlCommand = new SqlCommand("Select * from ContractStatus where Clientcode in (" + str + ")", this.conn))
        {
          this.Invoke((Delegate) (() =>
          {
            this.progressBar5.Minimum = 0;
            this.progressBar5.Maximum = 500;
            this.progressBar5.Value = 0;
          }));
          using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
          {
            while (sqlDataReader.Read())
            {
              this.Invoke((Delegate) (() =>
              {
                this.progressBar5.PerformStep();
                Application.DoEvents();
              }));
              int status = 1;
              int exch = 0;
              if (!sqlDataReader.IsDBNull(1))
              {
                string clientcode = sqlDataReader.GetString(1);
                if (!sqlDataReader.IsDBNull(2))
                {
                  string symbol = sqlDataReader.GetString(2);
                  if (!sqlDataReader.IsDBNull(3))
                    status = sqlDataReader.GetInt32(3);
                  if (!sqlDataReader.IsDBNull(4))
                    exch = sqlDataReader.GetInt32(4);
                  this.objdash.ManageContractStatus(clientcode, symbol, status, exch);
                }
              }
            }
          }
        }
      }
      this.Invoke((Delegate) (() =>
      {
        this.progressBar5.Value = this.progressBar5.Maximum;
        this.lstMsgBox.Items.Add((object) "Contract Status Downloaded Successfully!!");
        Application.DoEvents();
      }));
      new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadMarketTimings())).Invoke)).Start();
    }

    private void DownloadMarketTimings()
    {
      using (SqlCommand sqlCommand = new SqlCommand("Select * from MarketTimings", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(1))
              this.objdash.NSETIME = sqlDataReader.GetString(1);
            if (!sqlDataReader.IsDBNull(2))
              this.objdash.MCXTIME = sqlDataReader.GetString(2);
            if (!sqlDataReader.IsDBNull(3))
              this.objdash.NCDEXTIME = sqlDataReader.GetString(3);
            if (!sqlDataReader.IsDBNull(4))
              this.objdash.NSECURRTIME = sqlDataReader.GetString(4);
          }
        }
      }
      this.CheckforSaturdayTrading();
      this.DownloadAgriCommTimings();
      this.Invoke((Delegate) (() =>
      {
        this.lstMsgBox.Items.Add((object) "Market Timings Downloaded Successfully!!");
        Application.DoEvents();
        this.objdash.btnRefreshData.Enabled = true;
        this.Hide();
      }));
    }

    private void GetDefaultData()
    {
      Thread.Sleep(5000);
      this.Invoke((Delegate) (() =>
      {
        this.progressBar4.Minimum = 0;
        this.progressBar4.Maximum = this.objdash._Symconctracts.Count;
        this.progressBar4.Value = 0;
      }));
      foreach (KeyValuePair<string, Contracts> symconctract in this.objdash._Symconctracts)
      {
        if (this.objdash.feedconn.State == ConnectionState.Open)
        {
          using (SqlCommand sqlCommand = new SqlCommand("Select Description,BidQty,Bid,Ask,AskQty,LTP,[Open],High,Low,[Close],NetChange,PercenChange,LTT,0,GetDate(),Volume,OI  from Marketview where Description = '" + symconctract.Key + "'", this.objdash.feedconn))
          {
            using (SqlDataReader reader = sqlCommand.ExecuteReader())
            {
              while (reader.Read())
              {
                this.Invoke((Delegate) (() =>
                {
                  this.progressBar4.PerformStep();
                  Application.DoEvents();
                }));
                this.objdash.ManageFeeds(this.objdash.GetMarketData(reader, false));
              }
            }
          }
        }
      }
      this.Invoke((Delegate) (() =>
      {
        this.lstMsgBox.Items.Add((object) "Market Data Downloaded Successfully!!");
        Application.DoEvents();
        this.Hide();
      }));
    }

    private void RefreshMappedClients(SqlConnection connn)
    {
      using (SqlCommand sqlCommand = new SqlCommand("Select Mappedclients from Userinformation where ClientCode = '" + this.objdash.objinfo.clientcode + "'", connn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              this.objdash.objinfo.mappedclients = sqlDataReader.GetString(0);
          }
        }
      }
    }

    private void DownloadGroupingList()
    {
      using (SqlCommand sqlCommand = new SqlCommand("select * from PayIN_OUTGrouping", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            string key = string.Empty;
            string str = string.Empty;
            if (!sqlDataReader.IsDBNull(1))
              key = sqlDataReader.GetString(1).Trim();
            if (!sqlDataReader.IsDBNull(2))
              str = sqlDataReader.GetString(2).Trim();
            if (!this.objdash._GroupwiseClientList.ContainsKey(key))
            {
              this.objdash._GroupwiseClientList.Add(key, new List<string>()
              {
                str
              });
            }
            else
            {
              List<string> groupwiseClient = this.objdash._GroupwiseClientList[key];
              if (!groupwiseClient.Contains(str))
                groupwiseClient.Add(str);
            }
            if (!this.objdash._AllGroupingCLients.Contains(str))
              this.objdash._AllGroupingCLients.Add(str);
          }
        }
      }
    }

    private void DownloadTradeGroupingList()
    {
      using (SqlCommand sqlCommand = new SqlCommand("select * from TradeGrouping", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            string key = string.Empty;
            string str = string.Empty;
            if (!sqlDataReader.IsDBNull(1))
              key = sqlDataReader.GetString(1).Trim();
            if (!sqlDataReader.IsDBNull(2))
              str = sqlDataReader.GetString(2).Trim();
            if (!this.objdash._UsertradeGrouping.ContainsKey(key))
            {
              this.objdash._UsertradeGrouping.Add(key, new List<string>()
              {
                str
              });
            }
            else
            {
              List<string> stringList = this.objdash._UsertradeGrouping[key];
              if (!stringList.Contains(str))
                stringList.Add(str);
            }
            if (!this.objdash._AllTradeGroupingCLients.Contains(str))
              this.objdash._AllTradeGroupingCLients.Add(str);
          }
        }
      }
    }

    private void CheckforSaturdayTrading()
    {
      if (this.objdash.GetServerTime().DayOfWeek != DayOfWeek.Saturday)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select isSaturday from MarketTimings", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
            this.objdash.isSaturdayTrading = !sqlDataReader.IsDBNull(0) && sqlDataReader.GetInt32(0) == 1;
        }
      }
    }

    public void StartDownloadContracts()
    {
      new Thread(new ThreadStart(((ThreadStart) (() => this.DownloadContracts())).Invoke)).Start();
    }

    private void DownloadDPRLimit()
    {
      string str = this.objdash.objinfo.clientcode;
      if (this.objdash.objinfo.usertype == 3 || this.objdash.objinfo.usertype == 4)
        str = this.objdash.objinfo.createdby;
      using (SqlCommand sqlCommand = new SqlCommand("Select * from DPRLimit where DACode = '" + str + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(2))
            {
              string symbol = sqlDataReader.GetString(2);
              if (!sqlDataReader.IsDBNull(3))
              {
                double DPR = Convert.ToDouble(sqlDataReader.GetValue(3));
                this.objdash.ManageDPRLimit(symbol, DPR);
              }
            }
          }
        }
      }
    }

    private double GetDAfund(string dacode)
    {
      using (SqlCommand sqlCommand = new SqlCommand("Select DACashMargin from DA_Funds where DACode = '" + dacode + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              return Convert.ToDouble(sqlDataReader.GetValue(0));
          }
        }
      }
      return 0.0;
    }

    private void DownloadAgriCommTimings()
    {
      this.objdash._SymbolwiseCommTiming = new Dictionary<string, DateTime>();
      using (SqlCommand sqlCommand = new SqlCommand("Select * from SymbolTradingTiming", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            string key = sqlDataReader.GetString(2);
            DateTime dateTime = Convert.ToDateTime(sqlDataReader.GetValue(3));
            if (!this.objdash._SymbolwiseCommTiming.ContainsKey(key))
              this.objdash._SymbolwiseCommTiming.Add(key, dateTime);
          }
        }
      }
    }

    private void DownloadTradeSettings(string code)
    {
      if (!(code != null & code != string.Empty))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("select Distinct T.Clientcode,C.Exch,T.Symbol,T.CloseAfterMins,T.VolumePercent,T.LastUpdate from TradeSettings T  , COntracts C where T.Symbol = C.Symbol and T.Clientcode in (" + code + ")", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
            this.objdash.ManageTradeSettings(new TradeSettings()
            {
              clientCode = sqlDataReader.GetString(0),
              exch = sqlDataReader.GetInt32(1),
              symbol = sqlDataReader.GetString(2),
              closeAfterMins = !sqlDataReader.IsDBNull(3) ? sqlDataReader.GetInt32(3) : 0,
              volumePercent = !sqlDataReader.IsDBNull(4) ? Convert.ToDouble(sqlDataReader.GetValue(4)) : 0.0
            });
        }
      }
    }

    private void DownloadTradeSettings1(string code)
    {
      if (!(code != null & code != string.Empty))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("select Distinct T.Clientcode,C.Exch,T.Symbol,T.CloseAfterMins,T.VolumePercent,T.LastUpdate from TradeSettings T  , COntracts C where T.Symbol = C.Symbol and T.Clientcode in ('" + code + "')", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
            this.objdash.ManageTradeSettings(new TradeSettings()
            {
              clientCode = sqlDataReader.GetString(0),
              exch = sqlDataReader.GetInt32(1),
              symbol = sqlDataReader.GetString(2),
              closeAfterMins = !sqlDataReader.IsDBNull(3) ? sqlDataReader.GetInt32(3) : 0,
              volumePercent = !sqlDataReader.IsDBNull(4) ? Convert.ToDouble(sqlDataReader.GetValue(4)) : 0.0
            });
        }
      }
    }

    private void DownloadBrkgType(string code)
    {
      if (!(code != null & code != string.Empty))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("select Clientcode,MCX,NSEFUT,NCDEX,NSECUR from ClientBrkgType  where Clientcode in (" + code + ")", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
            this.objdash.ManageBrokerageType(new BrkgType()
            {
              clientCode = sqlDataReader.GetString(0),
              mcx = !sqlDataReader.IsDBNull(1) ? sqlDataReader.GetInt32(1) : 0,
              nsefut = !sqlDataReader.IsDBNull(2) ? sqlDataReader.GetInt32(2) : 0,
              ncdex = !sqlDataReader.IsDBNull(3) ? sqlDataReader.GetInt32(3) : 0,
              nsecurr = !sqlDataReader.IsDBNull(4) ? sqlDataReader.GetInt32(4) : 0
            });
        }
      }
    }

    private void DownloadBrkgType2(string code)
    {
      if (!(code != null & code != string.Empty))
        return;
      using (SqlCommand sqlCommand = new SqlCommand("select Clientcode,MCX,NSEFUT,NCDEX,NSECUR from ClientBrkgType  where Clientcode in ('" + code + "')", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
            this.objdash.ManageBrokerageType(new BrkgType()
            {
              clientCode = sqlDataReader.GetString(0),
              mcx = !sqlDataReader.IsDBNull(1) ? sqlDataReader.GetInt32(1) : 0,
              nsefut = !sqlDataReader.IsDBNull(2) ? sqlDataReader.GetInt32(2) : 0,
              ncdex = !sqlDataReader.IsDBNull(3) ? sqlDataReader.GetInt32(3) : 0,
              nsecurr = !sqlDataReader.IsDBNull(4) ? sqlDataReader.GetInt32(4) : 0
            });
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.progressBar1 = new ProgressBar();
      this.lstMsgBox = new ListBox();
      this.progressBar2 = new ProgressBar();
      this.label2 = new Label();
      this.progressBar3 = new ProgressBar();
      this.label3 = new Label();
      this.progressBar4 = new ProgressBar();
      this.label4 = new Label();
      this.progressBar5 = new ProgressBar();
      this.label5 = new Label();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(21, 22);
      this.label1.Name = "label1";
      this.label1.Size = new Size(126, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Downloading Contracts...";
      this.progressBar1.Location = new Point(24, 38);
      this.progressBar1.Name = "progressBar1";
      this.progressBar1.Size = new Size(196, 12);
      this.progressBar1.TabIndex = 1;
      this.lstMsgBox.FormattingEnabled = true;
      this.lstMsgBox.Location = new Point(235, 18);
      this.lstMsgBox.Name = "lstMsgBox";
      this.lstMsgBox.Size = new Size(206, 225);
      this.lstMsgBox.TabIndex = 2;
      this.progressBar2.Location = new Point(24, 85);
      this.progressBar2.Name = "progressBar2";
      this.progressBar2.Size = new Size(196, 12);
      this.progressBar2.TabIndex = 4;
      this.label2.AutoSize = true;
      this.label2.Location = new Point(21, 68);
      this.label2.Name = "label2";
      this.label2.Size = new Size(154, 13);
      this.label2.TabIndex = 3;
      this.label2.Text = "Downloading Userinformation...";
      this.progressBar3.Location = new Point(24, 132);
      this.progressBar3.Name = "progressBar3";
      this.progressBar3.Size = new Size(196, 12);
      this.progressBar3.TabIndex = 6;
      this.label3.AutoSize = true;
      this.label3.Location = new Point(21, 114);
      this.label3.Name = "label3";
      this.label3.Size = new Size(113, 13);
      this.label3.TabIndex = 5;
      this.label3.Text = "Downloading Margin...";
      this.progressBar4.Location = new Point(24, 179);
      this.progressBar4.Name = "progressBar4";
      this.progressBar4.Size = new Size(196, 12);
      this.progressBar4.TabIndex = 8;
      this.label4.AutoSize = true;
      this.label4.Location = new Point(21, 161);
      this.label4.Name = "label4";
      this.label4.Size = new Size(162, 13);
      this.label4.TabIndex = 7;
      this.label4.Text = "Downloading Other Information...";
      this.progressBar5.Location = new Point(24, 226);
      this.progressBar5.Name = "progressBar5";
      this.progressBar5.Size = new Size(196, 12);
      this.progressBar5.Step = 1;
      this.progressBar5.TabIndex = 10;
      this.label5.AutoSize = true;
      this.label5.Location = new Point(21, 209);
      this.label5.Name = "label5";
      this.label5.Size = new Size(109, 13);
      this.label5.TabIndex = 9;
      this.label5.Text = "Downloading Offset...";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(453, 258);
      this.ControlBox = false;
      this.Controls.Add((Control) this.progressBar5);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.progressBar4);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.progressBar3);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.progressBar2);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.lstMsgBox);
      this.Controls.Add((Control) this.progressBar1);
      this.Controls.Add((Control) this.label1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = nameof (frmDownloadContrct);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Downloading Data";
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
