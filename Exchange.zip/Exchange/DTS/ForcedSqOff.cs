﻿// Decompiled with JetBrains decompiler
// Type: DTS.ForcedSqOff
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace DTS
{
  public class ForcedSqOff : Form
  {
    public SqlConnection conn = (SqlConnection) null;
    public Dashboard objmain = (Dashboard) null;
    private IContainer components = (IContainer) null;
    public int index;
    private GroupBox groupBox1;
    private Label label17;
    private TextBox txtValidity;
    private Label label7;
    private Label label6;
    private Label label4;
    private Label label3;
    private TextBox txtCSOQty;
    private TextBox txtCSObuysell;
    private TextBox txtCSOsymbol;
    private TextBox txtClientcode;
    private RadioButton rdoSymbolwise;
    private RadioButton rdoAllSym;
    private Button btnSquareoff;
    private GroupBox groupBox22;
    private TextBox txtCSOclientid;
    private Button btnCSOView;
    private Label label133;
    private DataGridView dgvClSquareOff;
    private TreeView treeView1;
    private Button btnView;
    private DataGridViewTextBoxColumn RegulationCode;
    private DataGridViewTextBoxColumn CSO_Symbol;
    private DataGridViewTextBoxColumn Buy_Sell;
    private DataGridViewTextBoxColumn CSO_Qty;
    private DataGridViewTextBoxColumn Validity;

    public ForcedSqOff(SqlConnection objconn, Dashboard dashobj)
    {
      this.InitializeComponent();
      this.conn = objconn;
      this.objmain = dashobj;
      this.Icon = this.objmain.ico;
    }

    public void CreateTree()
    {
      this.dgvClSquareOff.Rows.Clear();
      this.LoadTree();
    }

    private void rdoAllSym_CheckedChanged(object sender, EventArgs e)
    {
      if (this.rdoAllSym.Checked)
        this.groupBox1.Visible = false;
      else
        this.groupBox1.Visible = true;
    }

    private void btnView_Click(object sender, EventArgs e)
    {
      List<string> accounts = this.GetAccounts();
      this.dgvClSquareOff.Rows.Clear();
      try
      {
        foreach (KeyValuePair<string, buysellnetpospfls> keyValuePair in new Dictionary<string, buysellnetpospfls>((IDictionary<string, buysellnetpospfls>) this.objmain._NetProftLoss))
        {
          string[] strArray = keyValuePair.Key.Split('_');
          string key = strArray[0];
          string str = strArray[1];
          int int32 = Convert.ToInt32(strArray[2]);
          if (this.objmain._Symconctracts.ContainsKey(key) && accounts.Contains(str))
          {
            Contracts symconctract = this.objmain._Symconctracts[key];
            buysellnetpospfls buysellnetpospfls = keyValuePair.Value;
            if (buysellnetpospfls.buy_sell > 0)
            {
              int index = this.dgvClSquareOff.Rows.Add();
              this.dgvClSquareOff.Rows[index].Cells[0].Value = (object) str;
              this.dgvClSquareOff.Rows[index].Cells[1].Value = (object) key;
              this.dgvClSquareOff.Rows[index].Cells[2].Value = (object) Utils.GetBuysell(buysellnetpospfls.buy_sell);
              this.dgvClSquareOff.Rows[index].Cells[3].Value = (object) buysellnetpospfls.Qty;
              this.dgvClSquareOff.Rows[index].Cells[4].Value = (object) Utils.GetValidity(int32);
              this.dgvClSquareOff.Sort((DataGridViewColumn) this.RegulationCode, ListSortDirection.Ascending);
            }
          }
        }
      }
      catch
      {
      }
    }

    private List<string> GetAccounts()
    {
      List<string> stringList = new List<string>();
      foreach (TreeNode node1 in this.treeView1.Nodes)
      {
        switch (this.objmain.objinfo.usertype)
        {
          case 1:
            if (node1.Text == "DEALER ADMIN")
            {
              IEnumerator enumerator = node1.Nodes.GetEnumerator();
              try
              {
                while (enumerator.MoveNext())
                {
                  foreach (TreeNode node2 in ((TreeNode) enumerator.Current).Nodes)
                  {
                    if (node2.Text == "DEALER")
                    {
                      foreach (TreeNode node3 in node2.Nodes)
                      {
                        foreach (TreeNode node4 in node3.Nodes)
                        {
                          if (!stringList.Contains(node4.Text) && node4.Checked)
                            stringList.Add(node4.Text);
                        }
                      }
                    }
                    else
                    {
                      foreach (TreeNode node3 in node2.Nodes)
                      {
                        if (!stringList.Contains(node3.Text) && node3.Checked)
                          stringList.Add(node3.Text);
                      }
                    }
                  }
                }
                break;
              }
              finally
              {
                if (enumerator is IDisposable disposable)
                  disposable.Dispose();
              }
            }
            else
              break;
          case 2:
            string text = node1.Text;
            if (!(text == "DEALER"))
            {
              if (text == "CLIENT")
              {
                IEnumerator enumerator = node1.Nodes.GetEnumerator();
                try
                {
                  while (enumerator.MoveNext())
                  {
                    TreeNode current = (TreeNode) enumerator.Current;
                    if (!stringList.Contains(current.Text) && current.Checked)
                      stringList.Add(current.Text);
                  }
                  break;
                }
                finally
                {
                  if (enumerator is IDisposable disposable)
                    disposable.Dispose();
                }
              }
              else
                break;
            }
            else
            {
              IEnumerator enumerator = node1.Nodes.GetEnumerator();
              try
              {
                while (enumerator.MoveNext())
                {
                  foreach (TreeNode node2 in ((TreeNode) enumerator.Current).Nodes)
                  {
                    if (!stringList.Contains(node2.Text) && node2.Checked)
                      stringList.Add(node2.Text);
                  }
                }
                break;
              }
              finally
              {
                if (enumerator is IDisposable disposable)
                  disposable.Dispose();
              }
            }
        }
      }
      return stringList;
    }

    public void LoadTree()
    {
      this.treeView1.Nodes.Clear();
      switch (this.objmain.objinfo.usertype)
      {
        case 1:
          this.treeView1.Nodes.Add("DEALER ADMIN");
          int index1 = 0;
          using (Dictionary<string, Dictionary<string, Userinfo>>.Enumerator enumerator = this.objmain._DAHierarchy.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              KeyValuePair<string, Dictionary<string, Userinfo>> current = enumerator.Current;
              this.treeView1.Nodes[0].Nodes.Add(current.Key);
              this.treeView1.Nodes[0].Nodes[index1].Nodes.Add("DEALER");
              this.treeView1.Nodes[0].Nodes[index1].Nodes.Add("CIENT");
              foreach (KeyValuePair<string, Userinfo> keyValuePair in current.Value)
              {
                Userinfo userinfo = keyValuePair.Value;
                if (userinfo.usertype == 3)
                {
                  this.treeView1.Nodes[0].Nodes[index1].Nodes[0].Nodes.Add(userinfo.clientcode);
                  if (!(userinfo.mappedclients != string.Empty))
                    ;
                }
                else
                  this.treeView1.Nodes[0].Nodes[index1].Nodes[1].Nodes.Add(userinfo.clientcode);
              }
              ++index1;
            }
            break;
          }
        case 2:
          this.treeView1.Nodes.Add("DEALER");
          this.treeView1.Nodes.Add("CLIENT");
          int index2 = 0;
          using (Dictionary<string, Userinfo>.Enumerator enumerator = this.objmain._Userinformation.GetEnumerator())
          {
            while (enumerator.MoveNext())
            {
              KeyValuePair<string, Userinfo> current = enumerator.Current;
              string key = current.Key;
              Userinfo userinfo = current.Value;
              if (userinfo.usertype == 3)
              {
                this.treeView1.Nodes[0].Nodes.Add(userinfo.clientcode);
                if (userinfo.mappedclients != null && userinfo.mappedclients.Contains(","))
                {
                  string[] strArray = userinfo.mappedclients.Split(',');
                  for (int index3 = 0; index3 < strArray.Length; ++index3)
                  {
                    if (strArray[index3] != string.Empty)
                      this.treeView1.Nodes[0].Nodes[index2].Nodes.Add(strArray[index3]);
                  }
                }
                ++index2;
              }
              else
                this.treeView1.Nodes[1].Nodes.Add(userinfo.clientcode);
            }
            break;
          }
      }
    }

    private void btnSquareoff_Click(object sender, EventArgs e)
    {
      this.btnSquareoff.Enabled = false;
      if (this.dgvClSquareOff.Rows.Count > 0)
      {
        if (this.rdoAllSym.Checked)
        {
          for (int index = 0; index < this.dgvClSquareOff.Rows.Count; ++index)
          {
            string account = this.dgvClSquareOff.Rows[index].Cells[0].Value.ToString();
            string symbol = this.dgvClSquareOff.Rows[index].Cells[1].Value.ToString();
            int validity = (int) Enum.Parse(typeof (ValidityType), this.dgvClSquareOff.Rows[index].Cells[4].Value.ToString().ToUpper());
            int buysell = !(this.dgvClSquareOff.Rows[index].Cells[2].Value.ToString() == "B") ? 2 : 1;
            int int32 = Convert.ToInt32(this.dgvClSquareOff.Rows[index].Cells[3].Value);
            Contracts contract = this.objmain.GetContract(symbol);
            DateTime dtnow = new DateTime();
            if (!this.objmain.ValidateMarketTime(Utils.GetExch(contract.exch), ref dtnow))
            {
              this.objmain.DisplayMessage(Utils.GetExch(contract.exch) + " Market is closed, cannot Square-Off position.", 2);
            }
            else
            {
              if (this.SqOffPos(account, symbol, validity, buysell, int32))
              {
                this.ClearControls((Control) this);
                this.dgvClSquareOff.Rows[index].Visible = false;
              }
              Application.DoEvents();
              Thread.Sleep(1000);
            }
          }
        }
        else if (this.txtClientcode.Text != string.Empty && this.txtCSOsymbol.Text != string.Empty && (this.txtCSObuysell.Text != string.Empty && this.txtCSOQty.Text != string.Empty) && this.txtValidity.Text != string.Empty)
        {
          string text1 = this.txtClientcode.Text;
          string text2 = this.txtCSOsymbol.Text;
          int validity = (int) Enum.Parse(typeof (ValidityType), this.txtValidity.Text.ToUpper());
          int buysell = !(this.txtCSObuysell.Text == "B") ? 2 : 1;
          int int32 = Convert.ToInt32(this.txtCSOQty.Text);
          Contracts contract = this.objmain.GetContract(text2);
          DateTime dtnow = new DateTime();
          if (!this.objmain.ValidateMarketTime(Utils.GetExch(contract.exch), ref dtnow))
          {
            this.objmain.DisplayMessage(Utils.GetExch(contract.exch) + " Market is closed, cannot Square-Off position.", 2);
            return;
          }
          if (this.SqOffPos(text1, text2, validity, buysell, int32))
          {
            this.ClearControls((Control) this);
            this.dgvClSquareOff.Rows[this.index].Visible = false;
          }
          Thread.Sleep(1000);
        }
        else
          this.objmain.DisplayMessage("Select Position to Square Off", 2);
      }
      else
        this.objmain.DisplayMessage("Positions not available for Square-Off", 2);
      Thread.Sleep(1000);
      this.btnSquareoff.Enabled = false;
    }

    private bool SqOffPos(string account, string symbol, int validity, int buysell, int qty)
    {
      bool flag1 = false;
      string empty = string.Empty;
      if (this.objmain._Symconctracts.ContainsKey(symbol))
      {
        Contracts symconctract = this.objmain._Symconctracts[symbol];
        DateTime servertime = this.objmain.servertime;
        string symbol1 = symconctract.SymDesp;
        if (symconctract.symbol == "GOLDMM")
          symbol1 = symbol1.Replace("GOLDMM", "GOLD");
        else if (symconctract.symbol == "SILVERMM")
          symbol1 = symbol1.Replace("SILVERMM", "SILVER");
        Feeds feed = this.objmain.getFeed(symbol1);
        Trades trades = new Trades()
        {
          exch = symconctract.exch,
          Symbol = symbol,
          validity = validity,
          userremarks = string.Empty,
          producttype = 1,
          qty = qty,
          orderno = Trades.OrderNoGenerate(),
          clientcode = account,
          traderid = "Admin",
          Createon = servertime,
          Lastmodified = servertime,
          ordstatus = 4,
          exectype = 2
        };
        if (buysell == 1)
        {
          trades.buysell = 2;
          trades.Ordprice = feed.bid;
          trades.price = feed.bid;
        }
        else
        {
          trades.buysell = 1;
          trades.price = feed.ask;
          trades.price = feed.ask;
        }
        if (trades.qty > 0 && trades.price > Decimal.Zero && Trades.SaveOrder(trades, this.objmain.getConn()))
        {
          bool flag2 = Trades.SaveTrade(trades, this.objmain.getConn());
          if (flag2)
          {
            flag1 = flag2;
            this.objmain.DisplayConfirmationMsg(trades);
          }
        }
      }
      return flag1;
    }

    private void ClearControls(Control Control)
    {
      foreach (Control control in (ArrangedElementCollection) Control.Controls)
      {
        if (control is TextBox)
          ((TextBoxBase) control).Clear();
        if (control.HasChildren)
          this.ClearControls(control);
      }
    }

    private void dgvClSquareOff_CellClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.RowIndex <= -1)
        return;
      DataGridViewRow row = this.dgvClSquareOff.Rows[e.RowIndex];
      this.index = e.RowIndex;
      if (row != null)
      {
        this.ClearControls((Control) this);
        this.txtClientcode.Text = this.dgvClSquareOff.Rows[this.index].Cells[0].Value.ToString();
        this.txtCSOsymbol.Text = this.dgvClSquareOff.Rows[this.index].Cells[1].Value.ToString();
        this.txtCSObuysell.Text = this.dgvClSquareOff.Rows[this.index].Cells[2].Value.ToString();
        this.txtCSOQty.Text = this.dgvClSquareOff.Rows[this.index].Cells[3].Value.ToString();
        this.txtValidity.Text = this.dgvClSquareOff.Rows[this.index].Cells[4].Value.ToString();
      }
    }

    private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
    {
      foreach (TreeNode node in e.Node.Nodes)
        node.Checked = e.Node.Checked;
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      DataGridViewCellStyle gridViewCellStyle1 = new DataGridViewCellStyle();
      DataGridViewCellStyle gridViewCellStyle2 = new DataGridViewCellStyle();
      this.groupBox1 = new GroupBox();
      this.label17 = new Label();
      this.txtValidity = new TextBox();
      this.label7 = new Label();
      this.label6 = new Label();
      this.label4 = new Label();
      this.label3 = new Label();
      this.txtCSOQty = new TextBox();
      this.txtCSObuysell = new TextBox();
      this.txtCSOsymbol = new TextBox();
      this.txtClientcode = new TextBox();
      this.rdoSymbolwise = new RadioButton();
      this.rdoAllSym = new RadioButton();
      this.btnSquareoff = new Button();
      this.groupBox22 = new GroupBox();
      this.txtCSOclientid = new TextBox();
      this.btnCSOView = new Button();
      this.label133 = new Label();
      this.dgvClSquareOff = new DataGridView();
      this.RegulationCode = new DataGridViewTextBoxColumn();
      this.CSO_Symbol = new DataGridViewTextBoxColumn();
      this.Buy_Sell = new DataGridViewTextBoxColumn();
      this.CSO_Qty = new DataGridViewTextBoxColumn();
      this.Validity = new DataGridViewTextBoxColumn();
      this.treeView1 = new TreeView();
      this.btnView = new Button();
      this.groupBox1.SuspendLayout();
      this.groupBox22.SuspendLayout();
      ((ISupportInitialize) this.dgvClSquareOff).BeginInit();
      this.SuspendLayout();
      this.groupBox1.Controls.Add((Control) this.label17);
      this.groupBox1.Controls.Add((Control) this.txtValidity);
      this.groupBox1.Controls.Add((Control) this.label7);
      this.groupBox1.Controls.Add((Control) this.label6);
      this.groupBox1.Controls.Add((Control) this.label4);
      this.groupBox1.Controls.Add((Control) this.label3);
      this.groupBox1.Controls.Add((Control) this.txtCSOQty);
      this.groupBox1.Controls.Add((Control) this.txtCSObuysell);
      this.groupBox1.Controls.Add((Control) this.txtCSOsymbol);
      this.groupBox1.Controls.Add((Control) this.txtClientcode);
      this.groupBox1.Location = new Point(215, 33);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new Size(419, 60);
      this.groupBox1.TabIndex = 33;
      this.groupBox1.TabStop = false;
      this.groupBox1.Visible = false;
      this.label17.AutoSize = true;
      this.label17.Location = new Point(331, 17);
      this.label17.Name = "label17";
      this.label17.Size = new Size(40, 13);
      this.label17.TabIndex = 11;
      this.label17.Text = "Validity";
      this.txtValidity.Location = new Point(326, 34);
      this.txtValidity.Name = "txtValidity";
      this.txtValidity.ReadOnly = true;
      this.txtValidity.Size = new Size(71, 20);
      this.txtValidity.TabIndex = 10;
      this.label7.AutoSize = true;
      this.label7.Location = new Point(259, 17);
      this.label7.Name = "label7";
      this.label7.Size = new Size(23, 13);
      this.label7.TabIndex = 9;
      this.label7.Text = "Qty";
      this.label6.AutoSize = true;
      this.label6.Location = new Point(182, 17);
      this.label6.Name = "label6";
      this.label6.Size = new Size(47, 13);
      this.label6.TabIndex = 8;
      this.label6.Text = "Buy/Sell";
      this.label4.AutoSize = true;
      this.label4.Location = new Point(104, 18);
      this.label4.Name = "label4";
      this.label4.Size = new Size(41, 13);
      this.label4.TabIndex = 6;
      this.label4.Text = "Symbol";
      this.label3.AutoSize = true;
      this.label3.Location = new Point(10, 17);
      this.label3.Name = "label3";
      this.label3.Size = new Size(58, 13);
      this.label3.TabIndex = 5;
      this.label3.Text = "ClientCode";
      this.txtCSOQty.Location = new Point(250, 34);
      this.txtCSOQty.Name = "txtCSOQty";
      this.txtCSOQty.Size = new Size(71, 20);
      this.txtCSOQty.TabIndex = 4;
      this.txtCSObuysell.Location = new Point(174, 34);
      this.txtCSObuysell.Name = "txtCSObuysell";
      this.txtCSObuysell.ReadOnly = true;
      this.txtCSObuysell.Size = new Size(71, 20);
      this.txtCSObuysell.TabIndex = 3;
      this.txtCSOsymbol.Location = new Point(98, 34);
      this.txtCSOsymbol.Name = "txtCSOsymbol";
      this.txtCSOsymbol.ReadOnly = true;
      this.txtCSOsymbol.Size = new Size(71, 20);
      this.txtCSOsymbol.TabIndex = 1;
      this.txtClientcode.Location = new Point(6, 34);
      this.txtClientcode.Name = "txtClientcode";
      this.txtClientcode.ReadOnly = true;
      this.txtClientcode.Size = new Size(87, 20);
      this.txtClientcode.TabIndex = 0;
      this.rdoSymbolwise.AutoSize = true;
      this.rdoSymbolwise.Location = new Point(399, 10);
      this.rdoSymbolwise.Name = "rdoSymbolwise";
      this.rdoSymbolwise.Size = new Size(83, 17);
      this.rdoSymbolwise.TabIndex = 32;
      this.rdoSymbolwise.Text = "Symbol wise";
      this.rdoSymbolwise.UseVisualStyleBackColor = true;
      this.rdoAllSym.AutoSize = true;
      this.rdoAllSym.Checked = true;
      this.rdoAllSym.Location = new Point(343, 11);
      this.rdoAllSym.Name = "rdoAllSym";
      this.rdoAllSym.Size = new Size(36, 17);
      this.rdoAllSym.TabIndex = 31;
      this.rdoAllSym.TabStop = true;
      this.rdoAllSym.Text = "All";
      this.rdoAllSym.UseVisualStyleBackColor = true;
      this.rdoAllSym.CheckedChanged += new EventHandler(this.rdoAllSym_CheckedChanged);
      this.btnSquareoff.Font = new Font("Segoe UI", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnSquareoff.ForeColor = Color.Black;
      this.btnSquareoff.Location = new Point(502, 8);
      this.btnSquareoff.Name = "btnSquareoff";
      this.btnSquareoff.Size = new Size(108, 23);
      this.btnSquareoff.TabIndex = 28;
      this.btnSquareoff.Text = "Square Off";
      this.btnSquareoff.UseVisualStyleBackColor = true;
      this.btnSquareoff.Click += new EventHandler(this.btnSquareoff_Click);
      this.groupBox22.Controls.Add((Control) this.txtCSOclientid);
      this.groupBox22.Controls.Add((Control) this.btnCSOView);
      this.groupBox22.Controls.Add((Control) this.label133);
      this.groupBox22.Location = new Point(738, 124);
      this.groupBox22.Name = "groupBox22";
      this.groupBox22.Size = new Size(226, 58);
      this.groupBox22.TabIndex = 30;
      this.groupBox22.TabStop = false;
      this.groupBox22.Text = "View Position";
      this.groupBox22.Visible = false;
      this.txtCSOclientid.Location = new Point(10, 32);
      this.txtCSOclientid.Name = "txtCSOclientid";
      this.txtCSOclientid.ReadOnly = true;
      this.txtCSOclientid.Size = new Size(105, 20);
      this.txtCSOclientid.TabIndex = 20;
      this.btnCSOView.Font = new Font("Segoe UI", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnCSOView.ForeColor = Color.Black;
      this.btnCSOView.Location = new Point(139, 25);
      this.btnCSOView.Name = "btnCSOView";
      this.btnCSOView.Size = new Size(75, 23);
      this.btnCSOView.TabIndex = 21;
      this.btnCSOView.Text = "View";
      this.btnCSOView.UseVisualStyleBackColor = true;
      this.label133.AutoSize = true;
      this.label133.Font = new Font("Segoe UI", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.label133.Location = new Point(11, 17);
      this.label133.Name = "label133";
      this.label133.Size = new Size(50, 13);
      this.label133.TabIndex = 19;
      this.label133.Text = "Client Id";
      this.dgvClSquareOff.AllowUserToAddRows = false;
      this.dgvClSquareOff.AllowUserToDeleteRows = false;
      this.dgvClSquareOff.AllowUserToOrderColumns = true;
      this.dgvClSquareOff.AllowUserToResizeRows = false;
      this.dgvClSquareOff.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
      gridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle1.BackColor = SystemColors.Control;
      gridViewCellStyle1.Font = new Font("Segoe UI", 8.25f);
      gridViewCellStyle1.ForeColor = SystemColors.WindowText;
      gridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle1.WrapMode = DataGridViewTriState.True;
      this.dgvClSquareOff.ColumnHeadersDefaultCellStyle = gridViewCellStyle1;
      this.dgvClSquareOff.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgvClSquareOff.Columns.AddRange((DataGridViewColumn) this.RegulationCode, (DataGridViewColumn) this.CSO_Symbol, (DataGridViewColumn) this.Buy_Sell, (DataGridViewColumn) this.CSO_Qty, (DataGridViewColumn) this.Validity);
      gridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
      gridViewCellStyle2.BackColor = SystemColors.Window;
      gridViewCellStyle2.Font = new Font("Segoe UI", 8.25f);
      gridViewCellStyle2.ForeColor = Color.Black;
      gridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
      gridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
      gridViewCellStyle2.WrapMode = DataGridViewTriState.False;
      this.dgvClSquareOff.DefaultCellStyle = gridViewCellStyle2;
      this.dgvClSquareOff.Location = new Point(214, 99);
      this.dgvClSquareOff.Name = "dgvClSquareOff";
      this.dgvClSquareOff.ReadOnly = true;
      this.dgvClSquareOff.RowHeadersVisible = false;
      this.dgvClSquareOff.Size = new Size(420, 409);
      this.dgvClSquareOff.TabIndex = 29;
      this.dgvClSquareOff.CellClick += new DataGridViewCellEventHandler(this.dgvClSquareOff_CellClick);
      this.RegulationCode.HeaderText = "ClientCode";
      this.RegulationCode.Name = "RegulationCode";
      this.RegulationCode.ReadOnly = true;
      this.CSO_Symbol.HeaderText = "Symbol";
      this.CSO_Symbol.Name = "CSO_Symbol";
      this.CSO_Symbol.ReadOnly = true;
      this.Buy_Sell.HeaderText = "Buy/Sell";
      this.Buy_Sell.Name = "Buy_Sell";
      this.Buy_Sell.ReadOnly = true;
      this.Buy_Sell.Width = 50;
      this.CSO_Qty.HeaderText = "Qty";
      this.CSO_Qty.Name = "CSO_Qty";
      this.CSO_Qty.ReadOnly = true;
      this.CSO_Qty.Width = 50;
      this.Validity.HeaderText = "Validity";
      this.Validity.Name = "Validity";
      this.Validity.ReadOnly = true;
      this.treeView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
      this.treeView1.CheckBoxes = true;
      this.treeView1.Location = new Point(3, 8);
      this.treeView1.Name = "treeView1";
      this.treeView1.Size = new Size(206, 500);
      this.treeView1.TabIndex = 34;
      this.treeView1.AfterCheck += new TreeViewEventHandler(this.treeView1_AfterCheck);
      this.btnView.Font = new Font("Segoe UI", 8.25f, FontStyle.Bold, GraphicsUnit.Point, (byte) 0);
      this.btnView.ForeColor = Color.Black;
      this.btnView.Location = new Point(215, 8);
      this.btnView.Name = "btnView";
      this.btnView.Size = new Size(108, 23);
      this.btnView.TabIndex = 35;
      this.btnView.Text = "View";
      this.btnView.UseVisualStyleBackColor = true;
      this.btnView.Click += new EventHandler(this.btnView_Click);
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(639, 517);
      this.Controls.Add((Control) this.btnView);
      this.Controls.Add((Control) this.treeView1);
      this.Controls.Add((Control) this.groupBox1);
      this.Controls.Add((Control) this.rdoSymbolwise);
      this.Controls.Add((Control) this.rdoAllSym);
      this.Controls.Add((Control) this.btnSquareoff);
      this.Controls.Add((Control) this.groupBox22);
      this.Controls.Add((Control) this.dgvClSquareOff);
      this.MaximizeBox = false;
      this.Name = nameof (ForcedSqOff);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Force Square-Off";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox22.ResumeLayout(false);
      this.groupBox22.PerformLayout();
      ((ISupportInitialize) this.dgvClSquareOff).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
