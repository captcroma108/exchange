﻿// Decompiled with JetBrains decompiler
// Type: DTS.frmDashSetting
// Assembly: Exchange, Version=1.0.0.142, Culture=neutral, PublicKeyToken=null
// MVID: EE57E5D0-6FAC-445E-B124-7265472CA0DC
// Assembly location: D:\Exchange\Exchange.exe

using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace DTS
{
  public class frmDashSetting : Form
  {
    private IContainer components = (IContainer) null;
    public Dashboard objdash;
    public SqlConnection conn;
    private Label label1;
    private TextBox txtMessage;
    private Button btnSave;
    private Label label2;

    public frmDashSetting(Dashboard dash, SqlConnection db)
    {
      this.InitializeComponent();
      this.objdash = dash;
      this.conn = db;
      this.Icon = this.objdash.ico;
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
      if (this.conn.State == ConnectionState.Closed)
        this.conn = this.objdash.getConn();
      using (SqlCommand sqlCommand = new SqlCommand("UPdate Userinformation SET StatusMsg = '" + this.txtMessage.Text + "' where ClientCode = '" + this.objdash.objinfo.clientcode + "'", this.conn))
      {
        try
        {
          sqlCommand.ExecuteNonQuery();
          this.objdash.DisplayMessage("Message Saved Successfully!!", 1);
          this.objdash.lblStatus.Text = this.txtMessage.Text;
        }
        catch
        {
          this.objdash.DisplayMessage("Unable to Update Status Message.", 3);
        }
      }
    }

    private void frmDashSetting_Load(object sender, EventArgs e)
    {
      this.txtMessage.Text = "";
      if (this.conn.State != ConnectionState.Open)
        return;
      using (SqlCommand sqlCommand = new SqlCommand("Select StatusMsg from Userinformation where Clientcode = '" + this.objdash.objinfo.clientcode + "'", this.conn))
      {
        using (SqlDataReader sqlDataReader = sqlCommand.ExecuteReader())
        {
          while (sqlDataReader.Read())
          {
            if (!sqlDataReader.IsDBNull(0))
              this.txtMessage.Text = sqlDataReader.GetString(0);
          }
        }
      }
    }

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        this.components.Dispose();
      base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
      this.label1 = new Label();
      this.txtMessage = new TextBox();
      this.btnSave = new Button();
      this.label2 = new Label();
      this.SuspendLayout();
      this.label1.AutoSize = true;
      this.label1.Location = new Point(28, 31);
      this.label1.Name = "label1";
      this.label1.Size = new Size(53, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Message:";
      this.txtMessage.Location = new Point(87, 28);
      this.txtMessage.MaxLength = 300;
      this.txtMessage.Multiline = true;
      this.txtMessage.Name = "txtMessage";
      this.txtMessage.Size = new Size(222, 44);
      this.txtMessage.TabIndex = 1;
      this.btnSave.Location = new Point(131, 82);
      this.btnSave.Name = "btnSave";
      this.btnSave.Size = new Size(75, 23);
      this.btnSave.TabIndex = 2;
      this.btnSave.Text = "Save";
      this.btnSave.UseVisualStyleBackColor = true;
      this.btnSave.Click += new EventHandler(this.btnSave_Click);
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Microsoft Sans Serif", 9f, FontStyle.Regular, GraphicsUnit.Point, (byte) 0);
      this.label2.Location = new Point(6, 5);
      this.label2.Name = "label2";
      this.label2.Size = new Size(311, 15);
      this.label2.TabIndex = 3;
      this.label2.Text = "*Message will be displayed on bottom of the Dashboard";
      this.AutoScaleDimensions = new SizeF(6f, 13f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(336, 113);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.btnSave);
      this.Controls.Add((Control) this.txtMessage);
      this.Controls.Add((Control) this.label1);
      this.Name = nameof (frmDashSetting);
      this.Text = "Dashboard Setting";
      this.Load += new EventHandler(this.frmDashSetting_Load);
      this.ResumeLayout(false);
      this.PerformLayout();
    }
  }
}
